
import sbt._

object Configs {
  // Not needed since this is built in
  // val IntegrationTest = config("it") extend(Runtime)
  val EndToEndTest = config("e2e") extend IntegrationTest
  val all = Seq(IntegrationTest, EndToEndTest)
}