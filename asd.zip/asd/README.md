# Baldur - The Enterprise Data Hub Pipeline

More information relating to the team and the project can be found on the 
[EDH Wiki Space](https://confluence.influencehealth.com/display/EDH/Enterprise+Data+Hub+Home)

- [Build](#building-the-application)
- [Test](#testing-the-application)
- [Release](#releasing-the-application)
- [Deploy](#deploying-the-application)
- [Run](#running-the-application)

## Building the Application

There are two ways to compile test and package the baldur application to be able to run a job in a local development
environment.

### Split Assembly
The "split" assembly allows a developer to iterate quickly by only building and packaging the things that have changed.
 It can be run by using the following sbt task:
```bash
sbt build depsOnly
```
This will produce an application jar and a dependencies (-deps) jar.  This dependencies jar can remain unchanged unless 
a dependency is modified.  Subsequent builds should only need to run:
```bash
sbt build
```
to produce a new application jar containing the updated code.

*Note* - the `build` and `depsOnly` tasks are custom tasks defined in build.sbt to allow for different configurations
to be applied than when running the standard sbt tasks. 
- `sbt build` is roughly equivalent to `sbt test package`
- `sbt depsOnly` is roughly equivalent to `sbt assemblyPackageDependency` 

### Full Assembly
The "full" or "fat" assembly packages the entire application and all of its dependencies into a single jar using the sbt-assembly
plugin.  This task is intended to be used during release and deployment time, however it takes longer to complete and 
therefore is discouraged for local development. The command for the fat assembly is:
```bash
sbt assembly
```

*Note* - The full assembly jar will always be used if it is available.  Therefore running `sbt build` after creating an assembly
will not do anything useful. 

#### A note on "clean"
It is generally a good idea to run `sbt clean` as a part of the first build you perform after pulling down any new
code from git or checking out a new branch.  This will eliminate the possibility of stale changes being cached in your
local workspace after pulling down changes from github.

However, during normal development prefixing either `build depsOnly` or `assembly` with `clean` is generally only 
necessary when you have made significant changes to the dependencies of the application or if you are performing a large 
refactoring that changes significant amounts of code.

## Testing the Application
Baldur contains an automated test suite powered by the Cucumber BDD framework. To execute the suite of end-to-end 
feature tests, run the following task:
```bash
sbt qa
```

To run the cucumber test suite without repackaging the application just run:
```bash
sbt e2e:test
```

Running the automated test suite for the application requires that there be both a running Cassandra instance as
well as a lookups service instance.

Prior to committing a PR, it is generally a good idea to run `sbt clean qa` just to make sure you're 
getting a completely fresh set of compiled assets to run the tests against.

## Releasing the Application
There are two kinds of releases in the baldur application:

1. A nightly SNAPSHOT release containing the latest reviewed changes for the current sprint
2. A bi-weekly production release done at the end of a sprint after all code has been reviewed, tested, and merged

In almost all cases, these activities will be performed on the Jenkins CI server that acts as the "golden image" for
all builds of the EDH. Below is a description of the activities that are performed during each of these releases.

### Baldur Distribution
While the split and full assemblies work well enough in a development setting, they are not sufficient by themselves
to run the baldur application in a staging or production environment.  In order to do this other scripts and assets
that are required are packaged up into a .zip file that we call a Baldur distribution.  This is in reality the
binary artifact that is produced during each release

### Publish
Publishing is done when a build has successfully passed the automated continuous integration tests and is ready to be
deployed into an environment.  It creates the artifacts that Ansible will use to deploy and install Baldur in an
integrated testing environment. Publish is also the command that is used to create the nightly SNAPSHOT release. 

The publish task is responsible for:

1. Running a full build of the application including all automated tests 
2. Packaging the baldur .jar and the .zip distribution (with the assembly included)
3. Pushing the .jar and .zip assets to the appropriate Amazon S3 repo (releases or snapshots)
4. Creating a Docker image of the existing application distribution
5. Pushing the 'influence/baldur' image for both the current version and latest tag to dockerhub

The command to publish the baldur distribution is:
```bash
sbt publish
```

### Release
Releasing is much like publishing, but it can only be done once per version.  This is because in addition to the publish
activites above, it will also:

1. Update the version of the application in the version.sbt file
2. Add a tag to the git respository for the revision that is being used in the current release version.

The release process will abort if attempting to release a version which has already been released, or if there are
any '-SNAPSHOT' dependencies in the resolved dependency graph.
```bash
sbt release
```
As you have probably figured out by now, the release command is used at the end of each sprint to produce the official
production release version for Baldur.

### Troubleshooting the Publish or Release process
Because both publish and release combine a couple of different activities, it may be helpful during the course of
development to test only one of these steps by itself

#### Building just the zip distribution
To execute just the command that will package up a zip distribution, but not attempt to push it to a remote repository
use: 
```bash
sbt makeDistro
```

#### Building just the Docker image
To build just the docker image similar to running `docker build` in the previous deployment paradigm, use:
```bash
sbt docker
```

## Deploying the Application
Application deployment is done from the [jenkins console](https://jenkins.edh.influencehealth.com)

## Running the Application
As of version 0.7.0, the Baldur application has been overhauled with an entirely new command line interface. This new
interface was designed using the same concepts that were outlined in the 
[EDH CLI Design Draft](https://confluence.influencehealth.com/display/EDH/EDH+Command+Line+Interface+Design+Draft).
There have been a few minor modifications to account for the details of how today's jobs are invoked. This page 
also describes the intended mapping in most cases between the legacy script and the new script to be used.
If a needed job is not yet implemented in the scripts below, please check out 
[working with legacy scripts](#working-with-legacy-scripts)

The Baldur CLi is written in bash and is therefore only compatible with linux and mac osx.  If you are a Windows user, 
please check the << insert link >> for how to RDP or ssh into one of the integrated testing environments to execute 
commands.

#### OSX Prerequisites

The Baldur application uses long form options via the `getopt` command.  The `getopt` command that comes with Mac OSX is 
based on BSD `getopt` and is not compatible with the GNU `getopt` that comes with modern linux distributions. Therefore, 
to work with the edh CLI on a Mac OSX device you must install gnu-getopt using homebrew.

If you already have homebrew installed, it is as easy as:

```bash
brew install gnu-getopt
```

Then make sure to add the following to your `.zshrc` or `.bashrc`.

```bash
export FLAGS_GETOPT_CMD="$(brew --prefix gnu-getopt)/bin/getopt"
```

In addition to the cli commands you'll need a working postgres installation for the project to work from end to end. You can begin by running the following commands to install postgres and setup your database

```bash
brew install postgres
psql
your.username=# CREATE user svc_baldur WITH password '12345';
your.username=# CREATE DATABASE cdp OWNER svc_baldur;
your.username=# \q
```



### EDH Commands
- [Load](#load)
- [Migrate](#migrate)
- [Enrich](#enrich)
- [Collapse](#collapse)
- [Refresh](#refresh)
- [Sync](#synchronize)
- [Experian](#experian)
- [Delete](#delete)
- [Dns](#dns)

#### Load
`edh load` is the primary command to bring new data from external files into the EDH.  It can be called using the 
following syntax
```
edh load [command] [options]
```
There are 3 steps to perform a full load currently:
1. *Cleanse* - takes a baldur configuation, ingests files based on that configuration and prepares a file for step 2
   
   *Donor* - takes a customer id and input file and ingests that data into a file to be picked up by anchor in step 2
2. *Anchor* - takes the output of the cleanse step, sends it to anchor, and retrieves the result once it is processed
3. *Identify* - takes an input file (anchor's output) and loads it into the edh

##### Example Cleanse Load
```
edh load cleanse -e local -C local/newmovers.config -p small

edh load donor -c 128 -p large -i "fixtures/donorLoad/sample-donor-file.txt" -e local
```
##### Example Anchor Process
```
edh load anchor -e local -i "target/output/donorLoad_toAnchor_127_INFLUENCE HEALTH~001228_20170817T212153.116Z.txt"
```
Notes: 
 * the input file on this step is the output file of the previous cleanse/donor step
 * the _-z_ option is used to specify if you want to leave the output of anchor process in zip format.

##### Example Identify Load
```
edh load identify -e stage -i fixtures/identify/ulm_anchor_output.txt -p small
```
Note: the input file on this step is the output file of the anchor step

#### Migrate
Migrate is the command used to load information from the EPDB system into the EDH.
```
edh migrate [command] [options]
```

There are 4 steps to perform a full customer migration:
1. *Cleanse* - takes a customer-specific EPDB table and perpares a file for anchor
2. *Anchor* - takes the output of the cleanse step, sends it to anchor, and retrieves the result once it is processed
3. *Persons* - takes an input file (anchor's output) and loads it into the database
4. *Activities* - takes a customer-specific EPDB table of activities and loads it into the database
5. *Lists* - takes a customer-specific EPDB table of marketing lists and loads it into the database

##### Example Anchor Process
```
edh migrate anchor -e local -i "target/output/epdb_toAnchor_127_INFLUENCE HEALTH~001228_20170817T212153.116Z.txt"
```
Notes: 
 * the input file on this step is the output file of the previous cleanse/donor step
 * the _-z_ option is used to specify if you want to leave the output of anchor process in zip format.

##### Example Migrate Process
```
edh migrate persons -i fixtures/migration/migration_anchor_output.txt -p large -e local
```
Note: the input file on this step is the output file of the anchor step

#### Enrich
[Enrich.sh](bin/enrich.sh) is the primary command to enrich data that is already loaded into the EDH.
```
edh enrich {enrich step} -e {environment} -c {customerId} -p {profile}
```
There are many enrichment commands:

1. *residence* - Runs address-preferencing and householding for a given customer
2. *children* - Runs the presence-of-child logic for a given customer
3. *dnslist* - Runs DNS Enrich for mail, email, call and text field
4. *locations* - Runs location scoring for a given customer
5. *propensities* - Runs propensities for a given customer
6. *e-propensities* - Not yet implemented
7. *ccs-propensities* - Not yet implemented
8. *recipes* - Runs recipe scoring for a given customer
9. *experian-recipes* - Runs experian specific recipe scoring for a given customer

##### Example Enrich Residence Process
```
edh enrich residence -c 127 -e local -p large
```
##### Example Enrich DnsList Process
```
edh enrich dnslist -c 127 -e stage -p large
```

#### Collapse
*Not yet implemented*

#### Refresh
*Not yet implemented*

#### Synchronize
*Not yet implemented*

#### Experian
[Experian.sh](bin/experian.sh) is the primary command to load data from experian (external files) into the EDH.  It can be called using the following syntax
```
edh experian {load step} -e {environment} -c {customerId} -b {experianBasePath} -P {prospectCleanFlag} -i {inputFile} -p {profile} [-z]
```
There are 3 steps to perform an experian load currently:
1. *Cleanse* - takes the file from experian and cleanses its data and puts it into a proper format for the EDH Baldur anchor process
2. *Anchor* - takes the output of the cleanse step, sends it to anchor, and retrieves the result once it is processed
2. *Raw Load* - takes an input file (anchor's output) and loads it into experian keyspace in cassandra
3. *Prospect Load* - takes the data in the experian keyspace in cassandra and identifies and enriches it and loads it into the datahub keyspace in cassandra.

##### Parameters
* load step: which step in the process to perform: cleanse | raw_load | prospect_load
* customerId : the customer id for the prospect load step (e.g 128)
* experianBaseBath: used as the base path when looking for both input files and outputting them. (e.g fixtures/experian, /media/edh1/experian)
* prospectCleanFlag: flag to tell the prospect process to do some further clean up when the load is complete. (true | false)
* inputFile: the input file to the anchor step

##### Example Cleanse Load
```
edh experian cleanse -e local -b "fixtures/experian" -p small
```

##### Example Anchor Process
```
edh experian anchor -e local -i "fixtures/experian/output/experian_toAnchor_0_INFLUENCE HEALTH~001228_fileexperiancleanse-part0-20170717T200850.111Z.txt"
```

Notes: 
 * the input file on this step is the output file of the previous cleanse/donor step
 * the _-z_ option is used to specify if you want to leave the output of anchor process in zip format.

##### Example Raw Load
```
edh experian raw -e local -p small -b "fixtures/experian"
```
Note: the input file on this step is the output file of the anchor step

##### Example Prospect Load
```
edh experian prospect -e local -c 20001 -P false -p small
```
#### Delete
`edh delete` is the primary command to remove customer data from EDH (also previously known as truncate). It can be 
called using the following syntax

_**WARNING**: Truncates/Deletes are an extremely expensive operation on cassandra causing large amounts of tombstones to occur. After truncate is completed it is highly recommended that devops perform a repair on the cassandra nodes to prevent these tombstones from killing the system and its performance._

_Please send a note to the #edh-team slack channel when running a truncate so that the data services team knows to run these repairs._
```
edh delete [sub-command] [options]
```
the following sub-commands are available for the delete command:
1. *customer* - deletes all data for a customer

##### Example Delete Customer
```
edh delete customer -e local -c 119 -p small
```

#### Dns
[Dns.sh](bin/commands/dns.sh) is the primary command to either check or update persons from specific DNS list from EDH.
```
edh dns --help
```
There are two sub commands:

1. *check* - Check the current DNS list for a client
2. *update* - Update a person or group of persons from specific DNS channel

##### Example Dns Check Process
```
edh dns check -c 119 -e stage -p small
```
Notes:
 * It takes customer_id as input and validate for valid customer_id
 * It will query Cassandra for each person which are in any of the DNS channel
 * The output file with current DNS will be created at path /media/edh1/stag/dns with current DateTime. e.g. currentDns_119_20170921T190314.769+0530.csv

##### Example Dns Update Process
```
edh dns update -c 119 -i fixtures/dns/currentDns_119_sample_Input.csv -e stage -p small
```
Notes:
 * It takes customer_id and path of file as input
 * Input file template is present at fixtures/dns/currentDns_119_sample_Input.csv
 * If any person_id does not exist in EDH, it will show message on console with list of person_ids
 * If person_id exist in EDH, it will update the DNS channel and reasons as indicated in file input

### Working with Legacy Scripts
If a specific job or function has not been fully implemented in the new format, it is still perfectly acceptable to 
use the original script along with the necessary modifications to run Baldur.  However, it is highly recommended that 
any time an existing legacy script is needed (outside of an emergency), the script functionality is migrated over to
the newer usage paradigm. Original baldur scripts from all of the various repositories including the edh-cli can be 
found in the [legacy scripts directory](legacy_scripts/)

### Debugging the Application
Also as of 0.5.0, Baldur supports attaching the debugger via a command line parameter.

One of the following flags should be added as the last parameter of any script invocation in order to perpare the 
JVM to attach a debugger.
```
[-d | --debug | -s | --suspend]
```

##### Example Usage
```
edh load identify -e local -i fixtures/identify/utilization_anchor_output_small.txt -p small --suspend
```

Full information on how to interact can be found on the wiki at 
[Debugging Baldur in Intellij](https://confluence.influencehealth.com/display/EDH/Debugging+in+IntelliJ)

### Further Process Documentation:

#### Anchor Process Notes:
Documentation on the anchor process can be found here: 
[Anchor Process Information](https://confluence.influencehealth.com/display/EDH/Anchor+Process+Information)
