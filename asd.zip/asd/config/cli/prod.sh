#!/usr/bin/env bash

# Spark options
SPARK_URL=${SPARK_URL:-'spark://10.132.48.197:7077'}
COMPRESS=${COMPRESS:-true}
DRIVER_JAVA_OPTIONS=${DRIVER_JAVA_OPTIONS:-'-XX:+UseG1GC'}
EXECUTOR_JAVA_OPTIONS=${EXECUTOR_JAVA_OPTIONS:-'-XX:+UseG1GC'}
SPARK_EVENTLOG_ENABLED=true
SPARK_EVENTLOG_DIR="/media/edh1/spark/logs"

# Postgres options
POSTGRES_HOST=${POSTGRES_HOST:-'jdbc:postgresql://cdp-prod-01.cwyo7tp6c9cu.us-east-1.rds.amazonaws.com/cdp?sslmode=verify-ca&sslrootcert=/ssl/rds-ssl-ca-cert.pem'}
POSTGRES_USER=${POSTGRES_USER:-'svc_baldur'}
POSTGRES_PASSWORD=${POSTGRES_PASSWORD:-'c(bcY4OKBj$Md8q'}
POSTGRES_SCHEMAS=${POSTGRES_SCHEMAS:-'datahub'}

# Cassandra options
#CASSANDRA_HOST=${CASSANDRA_HOST:-'cass01clus01.edh.prod.influencehealth.local,cass02clus01.edh.prod.influencehealth.local,cass03clus01.edh.prod.influencehealth.local'}
#CASSANDRA_USE_SSL=${CASSANDRA_USE_SSL:-'true'}
#CASSANDRA_SSL_PASS=${CASSANDRA_SSL_PASS:-'d@t@hub1!'}
#CASSANDRA_TRUSTSTORE=${CASSANDRA_TRUSTSTORE:-'/ssl/datahub.truststore'}
#CASSANDRA_SSL_CERT=${CASSANDRA_SSL_CERT:-'/ssl/datahub.pem'}
#CASSANDRA_SSL_PROTOCOL=${CASSANDRA_SSL_PROTOCOL:-'TLS'}
#CASSANDRA_INPUT_CONSISTENCY_LEVEL=${CASSANDRA_INPUT_CONSISTENCY_LEVEL:-'LOCAL_ONE'}
#CASSANDRA_OUTPUT_CONSISTENCY_LEVEL=${CASSANDRA_OUTPUT_CONSISTENCY_LEVEL:-'LOCAL_QUORUM'}
#CASSANDRA_OUTPUT_BATCH_SIZE_ROWS=${CASSANDRA_OUTPUT_BATCH_SIZE_ROWS:-'10'}
#CASSANDRA_OUTPUT_CONCURRENT_WRITES=${CASSANDRA_OUTPUT_CONCURRENT_WRITES:-'10'}
#CASSANDRA_RECORD_METRICS=${CASSANDRA_RECORD_METRICS:-'true'}

if [[ ${ENABLE_CASSANDRA_READS_PER_SEC} == "true" ]]; then
    CASSANDRA_READS_PER_SECOND=2147483646
fi

ANCHOR_TARGET_DIR="edh_prod_new"

# anchor settings
ANCHOR_SFTP_USER="influence1"
ANCHOR_SFTP_PASS="22xYsev5#"
ANCHOR_REMOTE_SERVER=FTPInfluence.AnchorComputerSoftware.com
ANCHOR_UPLOAD_REMOTE_PATH="/ncoa/${ANCHOR_TARGET_DIR}/input"
ANCHOR_DOWNLOAD_REMOTE_PATH="/ncoa/${ANCHOR_TARGET_DIR}/output"
ANCHOR_MAX_RETRIES=72
ANCHOR_SLEEP_TIME=60

ENRICH_ADDRESS_OUTPUT_PATH=${ENRICH_ADDRESS_OUTPUT_PATH:-'/media/edh1/baldur/anchor_upload/'}
ENRICH_ADDRESS_TEMP_PATH=${ENRICH_ADDRESS_TEMP_PATH:-'/media/edh1/baldur/anchor_temp/'}
ENRICH_ADDRESS_FILE_PREFIX=${ENRICH_ADDRESS_FILE_PREFIX:-"baldur_ToAnchor"}
ENRICH_ADDRESS_DOWNLOAD_LOCAL_PATH=${ENRICH_ADDRESS_DOWNLOAD_LOCAL_PATH:-'/media/edh1/baldur/anchor_download/'}
ENRICH_ADDRESS_OUTPUT_FILE_COUNT=${ENRICH_ADDRESS_OUTPUT_FILE_COUNT:-"1"}
ENRICH_ADDRESS_FILE_DELIMITER=${ENRICH_ADDRESS_FILE_DELIMITER:-"|"}

JAVA_OPT_ENRICH_ADDRESS_CONFIG="\
-Dapp.enrich.address.output.path=${ENRICH_ADDRESS_OUTPUT_PATH} \
-Dapp.enrich.address.temp.path=${ENRICH_ADDRESS_TEMP_PATH} \
-Dapp.enrich.address.output.filename.prefix=${ENRICH_ADDRESS_FILE_PREFIX} \
-Dapp.enrich.address.output.count=${ENRICH_ADDRESS_OUTPUT_FILE_COUNT} \
-Dapp.enrich.address.file.delimiter=${ENRICH_ADDRESS_FILE_DELIMITER} \
-Dapp.enrich.address.download.local.path=${ENRICH_ADDRESS_DOWNLOAD_LOCAL_PATH} \
-Dapp.utils.script.path=${BASE_DIR}/bin/utils
"

# AWS automation settings
TASKRUNNER_WORKER_GROUP="edh-spark-jobs-prod"
TASKRUNNER_LOG_BUCKET="s3://edh-app-logs-prod/"

# Flyway Configuration
REDSHIFT_URL='jdbc:redshift://cdp-redshift-prod-redshiftcluster-1qbtso3tdms3f.caostj0ejdrg.us-east-1.redshift.amazonaws.com:5439/cdp?AuthMech=REQUIRE&ssl=TRUE'
REDSHIFT_USER='svc_baldur'
REDSHIFT_PASSWORD='4iu1nN^5#1Hi$kX'
REDSHIFT_SCHEMAS='datahub'

# Stats Configuration

JAVA_OPT_STATS_FILE_PATH=${JAVA_OPT_STATS_FILE_PATH:-"-Dapp.job.stats.file.path=/media/edh1/baldur/stats"}

ENRICH_CAREGROUPERS_OUTPUT_PATH=${ENRICH_CAREGROUPERS_OUTPUT_PATH:-"/media/edh1/baldur/CareGroupers_Upload"}
ENRICH_CAREGROUPERS_TEMP_PATH=${ENRICH_CAREGROUPERS_TEMP_PATH:-"/media/edh1/baldur/CareGroupers_Temp"}
ENRICH_CAREGROUPERS_INPUT_PATH=${ENRICH_CAREGROUPERS_INPUT_PATH:-"/media/edh1/baldur/CareGroupers_Download"}
ENRICH_CAREGROUPERS_FILE_PREFIX=${ENRICH_CAREGROUPERS_FILE_PREFIX:-"baldur_ToCareGroupers"}
ENRICH_CAREGROUPERS_FILE_DELIMITER=${ENRICH_CAREGROUPERS_FILE_DELIMITER:-"|"}

JAVA_OPT_ENRICH_CAREGROUPERS_CONFIG="-Dapp.enrich.caregroupers.output.path=${ENRICH_CAREGROUPERS_OUTPUT_PATH} \
-Dapp.enrich.caregroupers.temp.path=${ENRICH_CAREGROUPERS_TEMP_PATH} \
-Dapp.enrich.caregroupers.output.filename.prefix=${ENRICH_CAREGROUPERS_FILE_PREFIX} \
-Dapp.enrich.caregroupers.file.delimiter=${ENRICH_CAREGROUPERS_FILE_DELIMITER} \
-Dapp.enrich.caregroupers.input.path=${ENRICH_CAREGROUPERS_INPUT_PATH} \
"

#sg2 Service account Prod
SG2_SERVICE_ACCOUNT_USER="svc_sg2"
SG2_SERVICE_ACCOUNT_PASSWORD="gr0up1tUp!"
SG2_SERVICE_ACCOUNT_HOST="sg2-01.cdp.prod.influencehealth.local"