#!/usr/bin/env bash

# Spark options
SPARK_URL=${SPARK_URL:-'spark://10.0.50.8:7077'}
COMPRESS=${COMPRESS:-true}
DRIVER_JAVA_OPTIONS=${DRIVER_JAVA_OPTIONS:-'-XX:+UseG1GC'}
EXECUTOR_JAVA_OPTIONS=${EXECUTOR_JAVA_OPTIONS:-'-XX:+UseG1GC'}
SPARK_EVENTLOG_ENABLED=true
SPARK_EVENTLOG_DIR="/media/edh1/spark/logs"

# Postgres options
POSTGRES_HOST=${POSTGRES_HOST:-'jdbc:postgresql://cdp-staging.cxbbfzt4krc5.us-east-1.rds.amazonaws.com/cdp?sslmode=verify-ca&sslrootcert=/ssl/rds-ssl-ca-cert.pem'}
POSTGRES_USER=${POSTGRES_USER:-'svc_baldur'}
POSTGRES_PASSWORD=${POSTGRES_PASSWORD:-'apdyjI&R7U7ZO)Y'}
POSTGRES_SCHEMAS=${POSTGRES_SCHEMAS:-'datahub'}

ANCHOR_TARGET_DIR="edh_stag_new"

# anchor settings
ANCHOR_SFTP_USER="influence1"
ANCHOR_SFTP_PASS="22xYsev5#"
ANCHOR_REMOTE_SERVER=FTPInfluence.AnchorComputerSoftware.com
ANCHOR_UPLOAD_REMOTE_PATH="/ncoa/${ANCHOR_TARGET_DIR}/input"
ANCHOR_DOWNLOAD_REMOTE_PATH="/ncoa/${ANCHOR_TARGET_DIR}/output"
ANCHOR_MAX_RETRIES=72
ANCHOR_SLEEP_TIME=60

ENRICH_ADDRESS_OUTPUT_PATH=${ENRICH_ADDRESS_OUTPUT_PATH:-'/media/edh1/baldur/anchor_upload/'}
ENRICH_ADDRESS_TEMP_PATH=${ENRICH_ADDRESS_TEMP_PATH:-'/media/edh1/baldur/anchor_temp/'}
ENRICH_ADDRESS_FILE_PREFIX=${ENRICH_ADDRESS_FILE_PREFIX:-"baldur_ToAnchor"}
ENRICH_ADDRESS_DOWNLOAD_LOCAL_PATH=${ENRICH_ADDRESS_DOWNLOAD_LOCAL_PATH:-'/media/edh1/baldur/anchor_download/'}
ENRICH_ADDRESS_OUTPUT_FILE_COUNT=${ENRICH_ADDRESS_OUTPUT_FILE_COUNT:-"1"}
ENRICH_ADDRESS_FILE_DELIMITER=${ENRICH_ADDRESS_FILE_DELIMITER:-"|"}

JAVA_OPT_ENRICH_ADDRESS_CONFIG="\
-Dapp.enrich.address.output.path=${ENRICH_ADDRESS_OUTPUT_PATH} \
-Dapp.enrich.address.temp.path=${ENRICH_ADDRESS_TEMP_PATH} \
-Dapp.enrich.address.output.filename.prefix=${ENRICH_ADDRESS_FILE_PREFIX} \
-Dapp.enrich.address.output.count=${ENRICH_ADDRESS_OUTPUT_FILE_COUNT} \
-Dapp.enrich.address.file.delimiter=${ENRICH_ADDRESS_FILE_DELIMITER} \
-Dapp.enrich.address.download.local.path=${ENRICH_ADDRESS_DOWNLOAD_LOCAL_PATH} \
-Dapp.utils.script.path=${BASE_DIR}/bin/utils
"

# Elasticsearsch settings
ES_USER="azureuser"
ES_PASSWORD="Medseek123"
ES_PORT=9200
ES_HOST="searchmasters.shared.staging.influencehealth.local"
ES_NUM_REPLICAS=2
ES_NUM_SHARDS=4

# AWS automation settings
TASKRUNNER_WORKER_GROUP="edh-spark-jobs-staging"
TASKRUNNER_LOG_BUCKET="s3://edh-app-logs-staging/"

# Flyway Configuration
REDSHIFT_URL='jdbc:redshift://cdp-redshift-staging-redshiftcluster-1vhqtitb90jm3.c25nwdcdpolh.us-east-1.redshift.amazonaws.com:5439/cdp?AuthMech=REQUIRE&ssl=TRUE'
REDSHIFT_USER='svc_baldur'
REDSHIFT_PASSWORD='%waqIeic8GkSnxL'
REDSHIFT_SCHEMAS='datahub'

# Stats Configuration
JAVA_OPT_STATS_FILE_PATH=${JAVA_OPT_STATS_FILE_PATH:-"-Dapp.job.stats.file.path=/media/edh1/baldur/stats"}

ENRICH_CAREGROUPERS_OUTPUT_PATH=${ENRICH_CAREGROUPERS_OUTPUT_PATH:-"/media/edh1/baldur/CareGroupers_Upload"}
ENRICH_CAREGROUPERS_TEMP_PATH=${ENRICH_CAREGROUPERS_TEMP_PATH:-"/media/edh1/baldur/CareGroupers_Temp"}
ENRICH_CAREGROUPERS_INPUT_PATH=${ENRICH_CAREGROUPERS_INPUT_PATH:-"/media/edh1/baldur/CareGroupers_Download"}
ENRICH_CAREGROUPERS_FILE_PREFIX=${ENRICH_CAREGROUPERS_FILE_PREFIX:-"baldur_ToCareGroupers"}
ENRICH_CAREGROUPERS_FILE_DELIMITER=${ENRICH_CAREGROUPERS_FILE_DELIMITER:-"|"}

JAVA_OPT_ENRICH_CAREGROUPERS_CONFIG="-Dapp.enrich.caregroupers.output.path=${ENRICH_CAREGROUPERS_OUTPUT_PATH} \
-Dapp.enrich.caregroupers.temp.path=${ENRICH_CAREGROUPERS_TEMP_PATH} \
-Dapp.enrich.caregroupers.output.filename.prefix=${ENRICH_CAREGROUPERS_FILE_PREFIX} \
-Dapp.enrich.caregroupers.file.delimiter=${ENRICH_CAREGROUPERS_FILE_DELIMITER} \
-Dapp.enrich.caregroupers.input.path=${ENRICH_CAREGROUPERS_INPUT_PATH} \
"
#sg2 Service account Prod
SG2_SERVICE_ACCOUNT_USER="svc_sg2"
SG2_SERVICE_ACCOUNT_PASSWORD="gr0up1tUp!"
SG2_SERVICE_ACCOUNT_HOST="sg2-01.cdp.staging.influencehealth.local"