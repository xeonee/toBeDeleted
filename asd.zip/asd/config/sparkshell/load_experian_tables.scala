sql(
  """CREATE TEMPORARY VIEW person_master
    |USING org.apache.spark.sql.cassandra
    |OPTIONS (
    |  table "person_master",
    |  keyspace "experian"
    |)""".stripMargin)