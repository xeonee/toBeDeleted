sql(
  """CREATE TEMPORARY VIEW lookups
    |USING org.apache.spark.sql.cassandra
    |OPTIONS (
    |  table "lookups",
    |  keyspace "lookups"
    |)""".stripMargin)
