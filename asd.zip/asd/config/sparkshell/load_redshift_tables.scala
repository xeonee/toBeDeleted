sql(
   s"""CREATE TEMPORARY TABLE activities
     |USING com.databricks.spark.redshift
     |OPTIONS (
     |  dbtable "staging.activities",
     |  tempdir 's3a://ih-spark-tmp',
     |  url "jdbc:redshift://10.128.64.41:5439/dev?user=$redshiftUser&password=$redshiftPass"
     |)""".stripMargin)

sql(
   s"""CREATE TEMPORARY TABLE persons
     |USING com.databricks.spark.redshift
     |OPTIONS (
     |  dbtable "staging.persons",
     |  tempdir 's3a://ih-spark-tmp',
     |  url "jdbc:redshift://10.128.64.41:5439/dev?user=$redshiftUser&password=$redshiftPass"
     |)""".stripMargin)

sql(
  s"""CREATE TEMPORARY TABLE list_person
     |USING com.databricks.spark.redshift
     |OPTIONS (
     |  dbtable "staging.person_list",
     |  tempdir 's3a://ih-spark-tmp',
     |  url "jdbc:redshift://10.128.64.41:5439/dev?user=$redshiftUser&password=$redshiftPass"
     |)""".stripMargin)

sql(
  s"""CREATE TEMPORARY TABLE list_person_emails
     |USING com.databricks.spark.redshift
     |OPTIONS (
     |  dbtable "staging.person_list_emails",
     |  tempdir 's3a://ih-spark-tmp',
     |  url "jdbc:redshift://10.128.64.41:5439/dev?user=$redshiftUser&password=$redshiftPass"
     |)""".stripMargin)

sql(
  s"""CREATE TEMPORARY TABLE list_person_phone_numbers
     |USING com.databricks.spark.redshift
     |OPTIONS (
     |  dbtable "staging.person_list_phone_numbers",
     |  tempdir 's3a://ih-spark-tmp',
     |  url "jdbc:redshift://10.128.64.41:5439/dev?user=$redshiftUser&password=$redshiftPass"
     |)""".stripMargin)

val newMovers = { sqlContext.read.format("com.databricks.spark.redshift")
  .option("url", s"jdbc:redshift://10.128.64.41:5439/dev?user=$redshiftUser&password=$redshiftPass")
  .option("tempdir", "s3a://ih-spark-tmp")
  .option("query", """
    | select p.customer_id, p.person_id, a.activity_id, a.activity_date, a.location_id from staging.person_activities a
    | join staging.persons p on a.person_record_id = p.person_record_id
    | where activity_type = 'new movers'
    """.stripMargin)
  .load()
}

newMovers.registerTempTable("new_movers")

def moveMonth(customerId: Int) = {

  sqlContext.read.format("com.databricks.spark.redshift")
    .option("url", s"jdbc:redshift://10.128.64.41:5439/dev?user=$redshiftUser&password=$redshiftPass")
    .option("tempdir", "s3a://ih-spark-tmp")
    .option("query", s"""
      | SELECT dateadd(month, -1, max(activity_date)) FROM 
      |  staging.persons as p JOIN staging.activities as a
      |   ON p.person_record_id = a.person_record_id 
      |   JOIN rdw_stg.src_servicearea as serviceareas ON SUBSTRING(a.activity, 13,5) = serviceareas.zip
      |      where household_income NOT IN ('1,000-14,999', '15,000-24,999')
      """)
    .load().head.getTimestamp(0)

}