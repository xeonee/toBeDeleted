sql(
  """CREATE TEMPORARY VIEW person_list
    |USING org.apache.spark.sql.cassandra
    |OPTIONS (
    |  table "person_list",
    |  keyspace "lists"
    |)""".stripMargin)

sql(
  """CREATE TEMPORARY VIEW person_list_load_results
    |USING org.apache.spark.sql.cassandra
    |OPTIONS (
    |  table "person_list_load_results",
    |  keyspace "lists"
    |)""".stripMargin)

sql(
  """CREATE TEMPORARY VIEW list_metadata_id_lookup
    |USING org.apache.spark.sql.cassandra
    |OPTIONS (
    |  table "list_metadata_id_lookup",
    |  keyspace "lists"
    |)""".stripMargin)

sql(
  """CREATE TEMPORARY VIEW list_metadata_date_lookup
    |USING org.apache.spark.sql.cassandra
    |OPTIONS (
    |  table "list_metadata_date_lookup",
    |  keyspace "lists"
    |)""".stripMargin)

sql(
  """CREATE TEMPORARY VIEW person_list_lookup
    |USING org.apache.spark.sql.cassandra
    |OPTIONS (
    |  table "person_list_lookup",
    |  keyspace "lists"
    |)""".stripMargin)