

sql(
  """CREATE TEMPORARY VIEW customer_person_ids
    |USING org.apache.spark.sql.cassandra
    |OPTIONS (
    |  table "customer_person_ids",
    |  keyspace "datahub"
    |)""".stripMargin)

sql(
  """CREATE TEMPORARY VIEW person_activity
    |USING org.apache.spark.sql.cassandra
    |OPTIONS (
    |  table "person_activity",
    |  keyspace "datahub"
    |)""".stripMargin)

sql(
  """CREATE TEMPORARY VIEW person_master
    |USING org.apache.spark.sql.cassandra
    |OPTIONS (
    |  table "person_master",
    |  keyspace "datahub"
    |)""".stripMargin)

sql(
  """CREATE TEMPORARY VIEW person_master_changes
    |USING org.apache.spark.sql.cassandra
    |OPTIONS (
    |  table "person_master_changes",
    |  keyspace "datahub"
    |)""".stripMargin)

sql(
  """CREATE TEMPORARY VIEW source_identity
    |USING org.apache.spark.sql.cassandra
    |OPTIONS (
    |  table "source_identity",
    |  keyspace "datahub"
    |)""".stripMargin)


sql(
  """CREATE TEMPORARY VIEW person_propensity
    |USING org.apache.spark.sql.cassandra
    |OPTIONS (
    |  table "person_propensity",
    |  keyspace "datahub"
    |)""".stripMargin)

sql(
  """CREATE TEMPORARY VIEW person_identity_to_source
    |USING org.apache.spark.sql.cassandra
    |OPTIONS (
    |  table "person_identity_to_source",
    |  keyspace "datahub"
    |)""".stripMargin)

sql(
  """CREATE TEMPORARY VIEW person_collapse_history
    |USING org.apache.spark.sql.cassandra
    |OPTIONS (
    |  table "person_collapse_history",
    |  keyspace "datahub"
    |)""".stripMargin)

sql(
  """CREATE TEMPORARY VIEW person_recipes
    |USING org.apache.spark.sql.cassandra
    |OPTIONS (
    |  table "person_recipes",
    |  keyspace "datahub"
    |)""".stripMargin)

sql(
  """CREATE TEMPORARY VIEW addresses
    |USING org.apache.spark.sql.cassandra
    |OPTIONS (
    |  table "addresses",
    |  keyspace "datahub"
    |)""".stripMargin)

sql(
  """CREATE TEMPORARY VIEW households
    |USING org.apache.spark.sql.cassandra
    |OPTIONS (
    |  table "households",
    |  keyspace "datahub"
    |)""".stripMargin)

sql(
  """CREATE TEMPORARY VIEW cleansed_activities
    |USING org.apache.spark.sql.cassandra
    |OPTIONS (
    |  table "cleansed_activities",
    |  keyspace "datahub"
    |)""".stripMargin)

sql(
  """CREATE TEMPORARY VIEW unidentifiable_activities
    |USING org.apache.spark.sql.cassandra
    |OPTIONS (
    |  table "unidentifiable_activities",
    |  keyspace "datahub"
    |)""".stripMargin)

sql(
  """CREATE TEMPORARY VIEW ungroupable_activities
    |USING org.apache.spark.sql.cassandra
    |OPTIONS (
    |  table "sg2_ungroupable_activities",
    |  keyspace "datahub"
    |)""".stripMargin)