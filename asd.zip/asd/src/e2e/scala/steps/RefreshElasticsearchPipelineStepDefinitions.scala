package steps

import com.influencehealth.edh.Constants
import cucumber.api.scala.{EN, ScalaDsl}
import org.joda.time.format.DateTimeFormat
import org.scalatest.Matchers
import utils.EndToEndTestBase

class RefreshElasticsearchPipelineStepDefinitions extends ScalaDsl with EN with EndToEndTestBase with Matchers {


  And("""^number of documents in ([a-zA-Z]+)/([a-zA-Z]+) should be (\d+)""") {
    (esIndex: String, esDocument: String, numberOfRecords: Int) =>
    //      val esRDD = sparkSession.sparkContext.esRDD(s"$esIndex/$esDocument")
    //      assert(esRDD.count() == numberOfRecords)
  }


  And("""^number of encounters in latest ([a-zA-Z]+) index should be (\d+) where ([a-z|A-Z|_]+) equals "(.*)"$""") {
    (customer: String, expectedCount: Int, columnName: String, columnValue: String) =>
      val dateTimeFormat = DateTimeFormat.forPattern("yyyyMMdd")
      val esIndex = s"${customer}_${dateTimeFormat.print(Constants.Today)}"
      val esDocument = "person"
    //      val esRDD = sparkSession.sparkContext.esRDD(s"$esIndex/$esDocument")
    //      assert(esRDD.filter(t => t._1 == columnValue).map(_._2("encounters").asInstanceOf[Seq[AnyRef]]).first().size == expectedCount)
  }

  And("""^number of encounters in ([a-zA-Z]+)/([a-zA-Z]+) should be (\d+) where ([a-z|A-Z|_]+) equals "(.*)"$""") {
    (esIndex: String, esDocument: String, expectedCount: Int, columnName: String, columnValue: String) =>
    //      val esRDD = sparkSession.sparkContext.esRDD(s"$esIndex/$esDocument")
    //      assert(esRDD.filter(t => t._1 == columnValue).map(_._2("encounters").asInstanceOf[Seq[AnyRef]]).first().size == expectedCount)
  }
}
