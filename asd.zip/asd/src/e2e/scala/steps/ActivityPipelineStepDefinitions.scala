package steps

import cucumber.api.scala.{EN, ScalaDsl}
import org.scalatest.Matchers
import utils.{EndToEndTestBase, PostgresTestingUtils}

class ActivityPipelineStepDefinitions extends ScalaDsl with EN with EndToEndTestBase with Matchers {

   And("""^number of records in ([a-z|A-Z|_]+).([a-z|A-Z|_]+) should be (\d+)$""") {
     (keyspace: String, tableName: String, expectedCount: Int) =>
       PostgresTestingUtils.countRows(s"$keyspace.$tableName") shouldBe expectedCount
   }

   And("""^number of records in ([a-z|A-Z|_]+).([a-z|A-Z|_]+) should be (\d+) where ([a-z|A-Z|_]+) equals "([a-z|A-Z|0-9|_|-]*)"$""") {
     (postgresSchema: String, tableName: String, expectedCount: Int, columnName: String, columnValue: String) =>
       PostgresTestingUtils.
         countDataWhereEqualTo(s"$postgresSchema.$tableName", columnName, columnValue) shouldBe expectedCount
   }

  Given("""^number of records in ([a-z|A-Z|_]+).([a-z|A-Z|_]+) should be (\d+) where ([a-z|A-Z|_]+) equals "([a-z|A-Z|0-9|_|-]*)" and ([a-z|A-Z|_]+) equals "(.*)"$""") {
    (keyspace: String, tableName: String, expectedCount: Int, column1: String, column1Value: String, column2: String, column2Value: String) =>

      PostgresTestingUtils.countDataWhere(
        s"$keyspace.$tableName",
        r => r.getString(column1) == column1Value && r.getString(column2) == column2Value
      ) shouldBe expectedCount
  }

    Given("""^successful run of activity enrichment pipeline with ([a-z|A-Z|_]+).([a-z|A-Z|_]+) having (\d+) records$""") {
      (keyspace: String, tableName: String, expectedCount: Int) =>
        PostgresTestingUtils.countRows(s"$keyspace.$tableName") shouldBe expectedCount
    }
}
