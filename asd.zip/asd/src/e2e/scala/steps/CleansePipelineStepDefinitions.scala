package steps

import com.influencehealth.edh.utils.{DataLakeUtilities, S3Utilities}
import cucumber.api.scala.{EN, ScalaDsl}
import org.scalatest.Matchers
import utils.EndToEndTestBase

class CleansePipelineStepDefinitions extends ScalaDsl with EN with EndToEndTestBase with Matchers {

  var s3BatchUrl: String = _
  var activityType: String = _
  var cleanseActivitiesCount: Int = 0
  var keyspaceTableName: String = _
  val CleansedActivitiesTableName: String = "cleansed_activities"
  var customer: String = _


  Given("""^the required ([a-zA-z-]+) files at (.*)$""") {
    (activity: String, s3Url: String) =>
      activityType = activity
      s3BatchUrl = s3Url
  }

  Then("""^number of ([a-zA-z-]+) files generated should contain (\d+) records""") { (jobName: String, numberOfRecords: Int) =>
    jobName match {
      case "cleansed" =>
        val cleansedFilePath = DataLakeUtilities.buildS3PathForCleansedOutput(s3BatchUrl)
        val df = sparkSession.read.parquet(cleansedFilePath)
        df.count() shouldBe numberOfRecords
      case "error" =>
        val errorFilePath = DataLakeUtilities.buildS3PathForErrorOutput(s3BatchUrl, "invalid-records.csv")
        val df = sparkSession.read.option("header", true).csv(errorFilePath)
        df.count() shouldBe numberOfRecords
    }
  }

  And("""^number of files (\w+) should be (\d+)""") {
    (jobName: String, numberOfRecords: Int) =>
      val objectName = DataLakeUtilities.buildS3DestinationPrefixForFileArchival(s3BatchUrl, activityType)
      val listOfArchivedFiles: List[String] =
        S3Utilities
          .getAvailableBatchDirectoryUrlsForInputBatchId(s3Client, s"s3a://$AWSBucketName", objectName)
      listOfArchivedFiles should have length numberOfRecords
  }

  var batchId: String = _

  And("""^number of cleansed records in cleansed.activities for (\w+) should be (\d+)$""") {
    (customer: String, expectedResult: Int) =>
      batchId = DataLakeUtilities.getBatchId(customer, s3BatchUrl)
      cleanseActivitiesCount shouldBe expectedResult
  }

  Given("""^the data is present in cleansed_activities$""") { () =>
    cleanseActivitiesCount should be > 0
  }

  And("""^the metadata for cleansed files must be updated$""") { () =>
    val bucketName = DataLakeUtilities.extractBucketNameFromS3RawBatchUrl(s3BatchUrl)
    val objectName = DataLakeUtilities.extractS3SourcePrefixForFileArchival(s3BatchUrl)
    val availableListOfFiles = S3Utilities.
      getAvailableBatchDirectoryUrlsForInputBatchId(s3Client, s"s3a://$bucketName", objectName)

    assert(availableListOfFiles.exists(x => x.endsWith("SUCCESS")))
  }
}
