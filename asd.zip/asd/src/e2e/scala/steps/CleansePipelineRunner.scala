package steps


import cucumber.api.CucumberOptions
import cucumber.api.junit.Cucumber
import org.junit.runner.RunWith
import org.junit.{AfterClass, BeforeClass}
import utils.{EndToEndTestBase, FileUtilities}

import scala.util.Try

/**
  * Main class that runs all cucumber feature tests
  */
@RunWith(classOf[Cucumber])
@CucumberOptions(
  features = Array("classpath:features"), // path of feature files
  glue = Array("classpath:steps"), // path of step definition files
  tags = Array("@DataCleanse"), // , @SchemaMigrate, @DataLoad, @LoadCheck
  monochrome = false, // Displays the console output in much readable way
  plugin = Array("pretty", "html:target/cucumber") // HTML reports
)
class CleansePipelineRunner {}

object CleansePipelineRunner extends EndToEndTestBase {

  @BeforeClass
  def setUpTheEnvironment(): Unit = {

    Try(tearDownS3Files)

    val schemaMigrateCommand = "cdp schema postgres migrate -e test"

    sys.process.Process(
      schemaMigrateCommand, new java.io.File(getProjectPath), "POSTGRES_SCHEMAS" -> databaseSchema).!
  }

  private def tearDownS3Files = {
    FileUtilities.deleteFilesOnS3(s3Client, AWSBucketName, s"experian/cleansed/")
    FileUtilities.deleteFilesOnS3(s3Client, AWSBucketName, s"newmovers/cleansed/")
    FileUtilities.deleteFilesOnS3(s3Client, AWSBucketName, s"social_security_administration/error/")
    FileUtilities.deleteFilesOnS3(s3Client, AWSBucketName, s"social_security_administration/cleansed/")
    FileUtilities.deleteFilesOnS3(s3Client, AWSBucketName, s"christus/cleansed/")
    FileUtilities.deleteFilesOnS3(s3Client, AWSBucketName, s"christus/error/")
    FileUtilities.deleteFilesOnS3(s3Client, AWSBucketName, s"chomp/cleansed/")
    FileUtilities.deleteFilesOnS3(s3Client, AWSBucketName, s"chomp/error/")
    FileUtilities.deleteFilesOnS3(s3Client, AWSBucketName, s"tanner/cleansed/")
    FileUtilities.deleteFilesOnS3(s3Client, AWSBucketName, s"tanner/error/")
  }

  @AfterClass
  def oneTimeTearDown(): Unit = {
    tearDownS3Files
  }

}