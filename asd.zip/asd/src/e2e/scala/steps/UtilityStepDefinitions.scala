package steps

import java.io.File

import com.typesafe.scalalogging.LazyLogging
import cucumber.api.scala.{EN, ScalaDsl}
import org.scalatest.Matchers
import utils.{EndToEndTestBase, Utilities}

import scala.sys.process.Process

/**
  * Step Definitions for all features
  */
class UtilityStepDefinitions extends ScalaDsl with EN with EndToEndTestBase with Matchers with LazyLogging {

  var processExitCode: Int = _
  var keyspaceTableName: String = _
  var tableColumn: String = _
  var customerId: String = _
  var file: File = _
  var inputConfig: String = _
  val expectedResult: Int = 0
  var filePath: String = _

  When("""^cleansing ([a-z]+) using path (.*)$""") { (activityType: String, pathPrefix: String) =>
    val cleanseCommand: String = s"cdp cleanse $activityType -p small -e test -i s3a://$AWSBucketName/$pathPrefix"
    println(s"Running with command: $cleanseCommand")
    processExitCode = Process(cleanseCommand, new java.io.File(getProjectPath), "POSTGRES_SCHEMAS" -> databaseSchema,
      "S3_PRE_FIX" -> AWSBucketPrefix).!
  }

  When("""^cleansing ([a-z]+) for customer ([a-z]+) using path (.*)$""") { (activityType: String, customer: String, pathPrefix: String) =>
    activityType match {
      case "newmovers" | "prospect" | "deceased"=>
        println(activityType)
        val cleanseCommand: String = s"cdp cleanse $activityType -p small -e test -c $customer -i s3a://$AWSBucketName/$pathPrefix"
        processExitCode = Process(cleanseCommand, new java.io.File(getProjectPath), "POSTGRES_SCHEMAS" ->
          databaseSchema, "S3_PRE_FIX" -> AWSBucketPrefix).!
      case _ =>
        val cleanseCommand: String = s"cdp cleanse $activityType -p small -e test -c $customer -i s3a://$AWSBucketName/$customer/$pathPrefix"
        processExitCode = Process(cleanseCommand, new java.io.File(getProjectPath), "POSTGRES_SCHEMAS" ->
          databaseSchema, "S3_PRE_FIX" -> AWSBucketPrefix).!
    }
  }

  When("""^running the command$""") { edhCommand: String =>
    processExitCode = Process(edhCommand, new java.io.File(getProjectPath), "POSTGRES_SCHEMAS" -> databaseSchema).!
  }

  Then("""^the job should finish without throwing an error$""") { () =>
    assert(processExitCode == expectedResult, "Did not return exit code = " + expectedResult)
  }

  And("""^the count of records inserted should be (\d+)$""") { expectedResult: Int =>
  }

  // TODO this needs to be parameterized
  Given("""^the fixture "fixtures/identify/chomp/baldur_20180131T1430067500500.txt" was loaded$""") { () =>
    // TODO this probably needs to be made into a check along the lines of "there are persons for customer X"
  }

  And("""^the count of locations scored should be (\d+)$""") { expectedResult: Int =>
  }

  // TODO this needs to be parameterized
  Given("""^the fixture "fixtures/identify/chomp/baldur_20180131T1430067500500.txt" was loaded and enriched$""") { () =>
    // TODO this probably needs to be made into a check along the lines of "there are enriched persons for customer X"
  }

  Given("""^a running postgres instance$""") { () =>
    //    val command: String = s""" pg_isready --dbname=$databaseName --host=$databaseHost --username=$databaseUser """
    //    val output: String = Process(command, new java.io.File(getProjectPath)).!!
    //    output should contain ("accepting connections")
  }

  Then("""^an output file should be generated$""") { () =>
    file = new File(getProjectPath +
      "/target/newmovers/output/newmoversCleanse_toAnchor_1_INFLUENCE HEALTH~001228_20171023T000000.000Z.txt")
    assert(file.exists && !file.isDirectory)
  }

  Then("""^the contents of output file should match desired cleanse results$""") { () =>
    // TODO add a check for this
  }

  Given(
    """the fixture "fixtures/identify/chomp/baldur_20180131T1430067500500.txt" was loaded, enriched and collapsed"""
  ) {
    () =>
    // TODO this probably needs to be made into a check along the lines of "there are collapsed persons for customer X"
  }

  When("""^running the delete command$""") { (edhCommand: String) =>
    import sys.process._
    processExitCode = ("echo Y" #> edhCommand).!
  }

  And("""^the count of "persons" records inserted should be (\d+)$""") { (expectedResult: Int) =>
    keyspaceTableName = "test.persons"
    tableColumn = "*"
  }

  Given("""the required target directory""") {
    () =>
    // TODO this probably needs to be made into a check along the lines of "there are collapsed persons for customer X"
  }

  Given("""the fixture "fixtures/identify/chomp/baldur_20180131T1430067500500.txt" was loaded collapsed""") {
    () =>
    // TODO this probably needs to be made into a check along the lines of "there are collapsed persons for customer X"
  }

  And("""^the number of lines generated in the (\w+) Activity output should be (\d+)$""") {
    (jobName: String, expectedResult: Int) =>
      val jobType: String = Utilities.getOutputFolderPath(jobName)
      filePath = getProjectPath.concat(jobType).
        concat(Utilities.getOutputFileName(getProjectPath.concat(jobType), ".txt"))
      assert(scala.io.Source.fromFile(filePath).getLines.size.equals(expectedResult))
  }

  And("""^the number of lines generated from the experian cleanse (\w+) Activity output should be (\d+)$""") {
    (fileNameIdentifier: String, expectedResult: Int) =>
      val jobType: String = Utilities.getOutputFolderPath("experian")
      filePath = getProjectPath.concat(jobType).concat(Utilities.getOutputFileName(
        getProjectPath.concat(jobType), fileNameIdentifier))
      assert(scala.io.Source.fromFile(filePath).getLines.size.equals(expectedResult))
  }

  When("""^updating the records in ([a-z|A-Z|_]+).([a-z|A-Z|_]+) where ([a-z|A-Z|_]+) equals "(.*)"$""") {
    (keyspace: String, tableName: String, columnName: String, columnValue: String) =>
  }

}

