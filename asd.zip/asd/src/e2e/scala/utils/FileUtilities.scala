package utils

import java.io.File
import java.nio.file.{Files, Paths, StandardCopyOption}

import com.amazonaws.services.s3.model.{ObjectMetadata, PutObjectRequest, _}
import com.amazonaws.services.s3.{AmazonS3, AmazonS3Client}

import scala.collection.JavaConversions._

object FileUtilities {
  /**
    * Copies files from S3 to local directory
    *
    * @param bucketName
    * @param sourceKey
    * @param splitFileNameIdentifier
    * @param targetDirectory
    * @param projectPath
    */
  def downloadFilesFromS3(s3client: AmazonS3, bucketName: String, sourceKey: String,
                          splitFileNameIdentifier: String, targetDirectory: String, projectPath: String): Unit = {

    val x = projectPath.concat(targetDirectory).concat(sourceKey)
    // Create the directory
    val dir: File = new File(x)
    val successful: Boolean = dir.mkdirs()
    if (!successful) {
      throw new RuntimeException("Can't make the required directory.")
    }

    // list objects
    val objectListing: ObjectListing = s3client.listObjects(new ListObjectsRequest()
      .withBucketName(bucketName).withPrefix(sourceKey))
    for (objectSummary <- objectListing.getObjectSummaries) {
      val fileName = objectSummary.getKey.split(splitFileNameIdentifier) {
        1
      }
      // get objects
      val s3Obj: S3Object = s3client.getObject(bucketName, sourceKey.concat(fileName))
      val s3is: S3ObjectInputStream = s3Obj.getObjectContent

      // store objects
      Files.copy(s3is, Paths.get(x.concat(fileName)), StandardCopyOption.REPLACE_EXISTING)
      s3is.close()
    }
  }

  /**
    * Copies files to S3
    *
    * @param bucketName
    * @param destinationKeys
    * @param sourceDirectory
    */
  def uploadFilesToS3(s3client: AmazonS3, bucketName: String, destinationKeys: String,
                      sourceDirectory: String, fileExtension: String): Unit = {
    val list: List[String] = getListOfFileNames(sourceDirectory, fileExtension)
    list.foreach(x => {
      val file: File = new File(sourceDirectory.concat(x))
      val putRequest: PutObjectRequest = new PutObjectRequest(bucketName, destinationKeys.concat(x), file)
      val objectMetadata = new ObjectMetadata
      objectMetadata.setServerSideEncryption(ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION)
      putRequest.setMetadata(objectMetadata)
      s3client.putObject(putRequest)
    })
  }

  /**
    * deletes all the object keys on S3
    *
    * @param bucketName
    * @param destinationKeys
    */
  def deleteFilesOnS3(s3client: AmazonS3, bucketName: String, destinationKeys: String): Unit = {
    // list objects
    val objectListing: ObjectListing = s3client.listObjects(new ListObjectsRequest()
      .withBucketName(bucketName).withPrefix(destinationKeys))
    for (objectSummary <- objectListing.getObjectSummaries) {
      s3client.deleteObject(bucketName, objectSummary.getKey)
    }
  }

  def fileExistsOnS3(
                      s3Client: AmazonS3Client,
                      bucketName: String,
                      destinationKey: String,
                      fileName: String
                    ): Boolean = {

    val objectListing: ObjectListing = s3Client.listObjects(new ListObjectsRequest()
      .withBucketName(bucketName))
    objectListing.getObjectSummaries.exists(_.getKey == fileName)

  }

  /**
    * Gets a list of file names with specified file extension present in a directory
    *
    * @param directory
    * @param fileExtension
    * @return
    */
  def getListOfFileNames(directory: String, fileExtension: String): List[String] = {
    var listOfFileNames: List[String] = List()
    val d = new File(directory)
    if (d.exists && d.isDirectory) {
      val list: List[File] = d.listFiles.filter(_.isFile).toList
      list.foreach(x => {
        if (x.getName.contains(fileExtension)) {
          listOfFileNames = listOfFileNames :+ x.getName
        }
      })
      listOfFileNames
    } else {
      List[String]()
    }
  }

}
