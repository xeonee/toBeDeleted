package utils

import java.io.{File, FileNotFoundException}

import org.joda.time.{DateTimeZone, LocalDate}

object Utilities {

  val currentDate: String = LocalDate.now(DateTimeZone.UTC).toString

  /**
    * Gets the file names that are generated from cleanse, nemovers & donor jobs
    * @param directoryPath input directory path
    * @return
    */
  def getOutputFileName(directoryPath: String, fileNameIdentifier: String): String = {
    val listOfFiles: Array[String] = new File(directoryPath).list
    var listOfFilesInNewMovers: Array[String] = null
    var listOfFilesHavingOutputFolders: Array[String] = null

    var counterForCleanse: Int = 0
    var counterForOtherFiles: Int = 0

    var fileName: String = null
    for (file <- listOfFiles) {
      file match {
        case x if x.endsWith(fileNameIdentifier) => counterForCleanse += 1
        case x if x.startsWith("newmovers_") => listOfFilesInNewMovers = new File(directoryPath.concat(file)).list
          for (newMoverFile <- listOfFilesInNewMovers) {
            newMoverFile match {
              case y if y.toString.endsWith(fileNameIdentifier) => fileName = x.concat("/").concat(
                listOfFilesInNewMovers {
                0
              })
                counterForOtherFiles += 1
              case _ =>
            }
          }
        case x if x.startsWith("output") => listOfFilesHavingOutputFolders = new File(directoryPath.concat(file)).list
          for (f <- listOfFilesHavingOutputFolders) {
            f match {
              case y if y.toString.endsWith(fileNameIdentifier) || y.toString.contains(fileNameIdentifier)=>
                fileName = x.concat("/").
                concat(listOfFilesHavingOutputFolders {
                0
              })
                counterForOtherFiles += 1
              case _ =>
            }
          }
        case _ =>
      }
    }
      if (counterForCleanse == 1) {
        fileName = listOfFiles {0}
        fileName
      }
      else if(counterForOtherFiles == 1){
        fileName
      }
      else {
        throw new FileNotFoundException()
      }
  }

  /**
    * Gets the output folder path that are generated from cleanse, nemovers & donor jobs
    * @param jobName name of the job
    * @return
    */
  def getOutputFolderPath(jobName: String): String = {
    jobName match {
      case "cleanse" => "/target/test/"
      case "newmover" => "target/test_newmovers/"
      case "donor" => "target/donor_test/"
      case "experian" => "/target/experian/"
    }
  }

}