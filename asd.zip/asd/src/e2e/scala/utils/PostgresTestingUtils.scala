package utils

import com.datastax.driver.core.Row
import com.influencehealth.edh.utils.DataLakeUtilities
/**
  * Utility class encompassing common functionaliy for postgres db
  */
object PostgresTestingUtils extends EndToEndTestBase {
  /**
    * Generic method to fetch counts for data
    *
    * @param tableName table name
    * @return count
    */
  def countRows(tableName: String): Int = {
    val savedActivities = databaseDao.getActivitiesByCustomer("christus")
    savedActivities.count().toInt
  }

  def countDataWhere(tableName: String, filter: Row => Boolean): Int = {
    val savedActivities = databaseDao.getActivitiesByCustomer("christus")
    savedActivities.count().toInt
  }

  def countDataWhereEqualTo(tableName: String, columnName: String, columnValue: String): Int = {
    val customer = DataLakeUtilities.extractCustomerFromBatchId(columnValue)
    getPostgresSession(sparkSession)
    tableName match {
      case "test.persons" =>
        val savedActivities = databaseDao.getPersonsByBatchId(columnValue)
        savedActivities.count().toInt
      case "test.activities" =>
        val savedActivities = databaseDao.getActivitiesByCustomer(customer)
        val filterSavedActivities = savedActivities.filter(_.batchId == columnValue)
        filterSavedActivities.count().toInt
    }
  }

  /**
    * Generic method to truncate any table
    *
    * @param tableName table name
    * @return count
    */
  def truncateTables(tableName: String): Unit = {
    getPostgresSession(sparkSession)
    databaseDao.truncateDB()
  }

}