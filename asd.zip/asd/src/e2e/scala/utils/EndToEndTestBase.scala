package utils

import java.io.File

import com.amazonaws.auth.{AWSCredentials, BasicAWSCredentials}
import com.amazonaws.services.s3.{AmazonS3, AmazonS3Client}
import com.influencehealth.edh.aws.s3.S3Config
import com.influencehealth.edh.config.{ConfigLoader, DatabaseConfig, PostgresConfig}
import com.influencehealth.edh.dao.{DatabaseDao, PostgresDatabaseDao}
import com.typesafe.config.{Config, ConfigFactory}
import mojolly.inflector.Inflector
import org.apache.spark.sql.SparkSession
import org.flywaydb.core.Flyway
import ru.yandex.qatools.embed.postgresql.EmbeddedPostgres
import ru.yandex.qatools.embed.postgresql.distribution.Version

import scala.language.postfixOps
import scala.sys.process._

trait EndToEndTestBase {

  val projectCmd = "bin/edh"

  val configReference: String = getProjectPath.concat("config/app/test.conf")
  val config: Config = ConfigFactory.parseFile(new File(configReference)).resolve()

  val AWSAccessKey: String = config.getString("aws-accesskey")
  val AWSSecretKey: String = config.getString("aws-secretkey")
  val AWSBucketName: String = config.getString("s3.datalake.bucket")

  val databaseHost: String = config.getString("postgres.host")
  val databaseName: String = config.getString("postgres.db")
  val databaseUser: String = config.getString("postgres.user")
  val databaseSchema: String = config.getString("postgres.schema")

  val branchName: String = ("git branch" !!).split("\n").
    find(_.contains("*")).
    head.replace("*", "").
    trim.replaceFirst("^-+", "").
    replaceAll("-+$", "")

  val AWSBucketPrefix: String = if (branchName == "sprint") {
    ""
  } else {
    Inflector.dasherize(branchName) + "/"
  }

  val s3Config = S3Config(AWSAccessKey, AWSSecretKey)

  val AWSCredentials: AWSCredentials = new BasicAWSCredentials(AWSAccessKey, AWSSecretKey)

  private var _s3client: AmazonS3 = _

  val s3Client: AmazonS3 = {
    if (_s3client == null) {
      _s3client = new AmazonS3Client(AWSCredentials)
    }
    _s3client
  }

  private var _spark: SparkSession = _
  /**
    * Sets Spark Configurations
    */
  def sparkSession: SparkSession = {

    val builder = initBuilder

    _spark = builder.getOrCreate()
    _spark.sparkContext.setLogLevel("WARN")

    _spark.sparkContext.addFile("config/application.conf") // (s"$pwd/config/application.conf")
    _spark.sparkContext.addFile("config/app/test.conf") // (s"$pwd/config/app/test.conf")
    s3Config.configureS3(_spark.sparkContext.hadoopConfiguration)
    setEnv("EDH_ENV", "test")
    _spark
  }

  /**
    * Extracts Project Path
    */
  def getProjectPath: String = {
    val projectPath = getClass.getResource("").getPath
    val projectDir = projectPath.substring(0, projectPath.indexOf("target"))
    projectDir
  }

  /**
    * Creates postgres Session
    */
  private var _databaseDao: DatabaseDao = _
  private var _postgres: EmbeddedPostgres = _
  def getPostgresSession(_sparkSession:SparkSession): EmbeddedPostgres = {
    if (_postgres == null) {
      implicit val sparkSession: SparkSession = _sparkSession
      val appConfig = ConfigLoader.appConfig
      val dbConfig: DatabaseConfig = PostgresConfig(appConfig)

      val postgresVersion = Version.Main.V9_6
      _postgres  = new EmbeddedPostgres(postgresVersion)

      val url = _postgres.start(
        dbConfig.host,
        dbConfig.port,
        dbConfig.database,
        dbConfig.user,
        dbConfig.password,
        java.util.Collections.emptyList()
      )
      println(url)
      // cleanAndMigrateDB(dbConfig)

      _databaseDao = new PostgresDatabaseDao(dbConfig)
    }
    _postgres
  }

  protected def initBuilder: SparkSession.Builder = SparkSession.builder()
    .master("local[2]")
    .appName(this.getClass.getSimpleName)
    .config("spark.ui.enabled", value = false)
    .config("spark.ui.showConsoleProgress", value = false)
    .config("spark.sql.shuffle.partitions", value = 1)
    .config("spark.driver.allowMultipleContexts", value = true)
    .config("spark.driver.host", value = "localhost")
    .config("spark.debug.maxToStringFields", value = 10000)

  def setEnv(key: String, value: String) = {
    val field = System.getenv().getClass.getDeclaredField("m")
    field.setAccessible(true)
    val map = field.get(System.getenv()).asInstanceOf[java.util.Map[java.lang.String, java.lang.String]]
    map.put(key, value)
  }

  private def cleanAndMigrateDB(dbConfig: DatabaseConfig): Unit = {

    val flyway: Flyway = new Flyway()

    flyway.setDataSource(
      s"jdbc:postgresql://${dbConfig.host}:${dbConfig.port}/${dbConfig.database}", dbConfig.user, dbConfig.password
    )
    flyway.setSchemas(dbConfig.schema)
    flyway.setLocations(s"classpath://postgres")
    flyway.clean()
    flyway.migrate()
  }
  lazy val databaseDao: DatabaseDao = _databaseDao

}