package com.influencehealth.edh.cleanse.hra

import com.influencehealth.edh.dao._
import com.influencehealth.edh.model.schema.HraSchema
import com.influencehealth.edh.test.spark.SparkSpecBase
import com.influencehealth.edh.{AppCleanser, Constants}
import org.apache.spark.sql.{DataFrame, Row}
import org.scalamock.scalatest.MockFactory
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}

class CleanseHraHealthwareSpec extends FlatSpec with SparkSpecBase with BeforeAndAfter with Matchers with MockFactory {

  val InputDirectoryPath: String = "fixtures/cleanse/hra/healthware/"
  val DateBatchReceived: String = "11/01/2018"
  val Customer: String = "chomp"
  val BatchId = s"chomp-hra-${Constants.HraHealthWareFormat}-2017-11"

  it should "cleanse hra healthware successfully" in {

    val rawData = Map(
      HRAHeaderV2 -> spark.createDataFrame(spark.sparkContext.parallelize(Seq(
        // Row( "TRANSACTION_ID" , "ASSESSMENT_CODE" , "TRANSACTION_DATE" , "FIRST_NAME" , "MIDDLE_NAME" , "LAST_NAME" , "ADDRESS1" , "ADDRESS2" , "CITY" , "STATE" , "ZIP" , "SEX" , "DOB" , "PHONE1" , "EMAIL1" )
        Row("4280197", null, "2018-09-20 04:16:59", "Marie", "Jan", "Cur", "866  St", " 202", " Braunfels", "TX", "78130", "Female", "1949-02-18", "(123) 123-2000", "xyz@gmail.com"),
        Row("4291192", "c8e74ec4-eb60-4777-be9a-2a88d95cfbc7", "2018-09-21 07:22:16", null, "W", null, null, null, " City", "TX", "77611", "Male", "1967-11-28", null, "abc@gmail.com")
      )), HraSchema.hraHeaderV2Schema),
      HRADetailV2 -> spark.createDataFrame(spark.sparkContext.parallelize(Seq(
        // Row( "TRANSACTION_ID" , "ASSESSMENT_CODE" , "CAMPAIGN_ID" , "ASSESSMENT_DESC" , "QUESTION_DESC" , "ANSWER_DESC" )
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Age" , "69" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "At Risk Offer" , "AT-RISK" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Blood Pressure" , "Blood pressure medications" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "BMI Calculation" , "26.4" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "BP Last Checked" , "Less than 1 year ago" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Cardiologist" , "No" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Cholesterol Last Checked" , "Less than 1 year ago" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Conditions None" , "None of the above apply" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Dentist" , "Yes" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Diabetes" , "No" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Diastolic" , "81-84" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Disclaimer" , "I AGREE TO THE DISCLAIMER" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Do You Use Tobacco" , "No, but I have smoked before" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Estrogen" , "No" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Ethnicity" , "Caucasian" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Exercise" , "1-2 times" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Family History Cardiovascular Disease" , "Cardiovascular (heart) disease" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Family History High Blood Pressure" , "High blood pressure" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Gender" , "Female" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "HDL" , "60 or more" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Height - Feet" , "5" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Height - Inches" , "3" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "How long ago did you stop smoking" , "6-10 years" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "How many cigarettes did you smoke per day" , "Less than half a pack" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "How many years did you smoke for" , "40" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "LDL" , "160-189" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Leg Pain" , "Yes" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Low Risk Offer" , "NOT-QUALIFIED" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Marketing Source" , "Hospital Website" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Menopausal" , "Yes" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "None" , "None of the above apply" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "PCP Name" , "Dr John Y Lee" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Primary Care Physician" , "Yes" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Stress" , "Average/Normal" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Systolic" , "121-129" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Total Cholesterol" , "240-279" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Weight" , "149" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "When is Leg Pain?" , "Only at rest" ),
          Row( "4280197" , "3262" , "38007" , "heartaware" , "Zip" , "78130" ),
          Row( "4291192" , "3268" , "38052" , "weightaware" , "Age" , "50" ),
          Row( "4291192" , "3268" , "38052" , "weightaware" , "At Risk Offer" , "AT-RISK" ),
          Row( "4291192" , "3268" , "38052" , "weightaware" , "BMI Calculation" , "40.4" ),
          Row( "4291192" , "3268" , "38052" , "weightaware" , "BP Last Checked" , "Less than 1 year ago" ),
          Row( "4291192" , "3268" , "38052" , "weightaware" , "Cardiologist" , "No" ),
          Row( "4291192" , "3268" , "38052" , "weightaware" , "Cholesterol Last Checked" , "Less than 1 year ago" ),
          Row( "4291192" , "3268" , "38052" , "weightaware" , "Diabetes" , "Prediabetes" ),
          Row( "4291192" , "3268" , "38052" , "weightaware" , "Diagnosed High Cholesterol" , "Yes" ),
          Row( "4291192" , "3268" , "38052" , "weightaware" , "Diagnosed Hypertension" , "No" ),
          Row( "4291192" , "3268" , "38052" , "weightaware" , "Diagnosed with Sleep Apnea" , "No" ),
          Row( "4291192" , "3268" , "38052" , "weightaware" , "Disclaimer" , "I AGREE TO THE DISCLAIMER" ),
          Row( "4291192" , "3268" , "38052" , "weightaware" , "Do You Snore Most Nights" , "Yes" ),
          Row( "4291192" , "3268" , "38052" , "weightaware" , "Do You Use Tobacco" , "No, but I have smoked before" ),
          Row( "4291192" , "3268" , "38052" , "weightaware" , "Endocrinologist" , "No" ),
          Row( "4291192" , "3268" , "38052" , "weightaware" , "Ethnicity" , "Caucasian" ),
          Row( "4291192" , "3268" , "38052" , "weightaware" , "Exercise" , "3-4 times" ),
          Row( "4291192" , "3268" , "38052" , "weightaware" , "Gender" , "Male" ),
          Row( "4291192" , "3268" , "38052" , "weightaware" , "Height - Feet" , "5" ),
          Row( "4291192" , "3268" , "38052" , "weightaware" , "Height - Inches" , "11" ),
          Row( "4291192" , "3268" , "38052" , "weightaware" , "How long ago did you stop smoking" , "6-10 years" ),
          Row( "4291192" , "3268" , "38052" , "weightaware" , "How many cigarettes did you smoke per day" , "Less than half a pack" ),
          Row( "4291192" , "3268" , "38052" , "weightaware" , "How many years did you smoke for" , "1" ),
          Row( "4291192" , "3268" , "38052" , "weightaware" , "How Often Do You Quit Breathing During Sleep" , "Rarely" ),
          Row( "4291192" , "3268" , "38052" , "weightaware" , "ID" , "c8e74ec4-eb60-4777-be9a-2a88d95cfbc7" )
      )), HraSchema.hraDetailV2Schema)
    )

    val mockFileSystemDao = mock[FileSystemDao]

    (mockFileSystemDao.readHRAFile _).expects(false, Constants.HraHealthWareFormat, Seq(InputDirectoryPath)).returns(rawData)

    val (cleansedDataFrame: DataFrame, dirtyDataFrame: DataFrame) = AppCleanser.cleanseData(
      Some(Customer), Constants.HraActivityType, BatchId, false, InputDirectoryPath,
      Constants.HraHealthWareFormat, DateBatchReceived, mockFileSystemDao)


    assert(cleansedDataFrame.count() == 1)
    val firstNames = cleansedDataFrame.select("firstName").collectAsList()
    assert(firstNames.get(0).getString(0).equals("Marie"))
    val lastNames = cleansedDataFrame.select("lastName").collectAsList()
    assert(lastNames.get(0).getString(0).equals("Cur"))
    val source = cleansedDataFrame.select("source").collectAsList()
    assert(source.get(0).getString(0).equals(Constants.HraActivityType))

    assert(dirtyDataFrame.count() == 1)
    val firstName = dirtyDataFrame.select("firstName").collectAsList()
    assert(firstName.get(0).getString(0) == null)

  }


}