package com.influencehealth.edh.cleanse.callcenter

import com.influencehealth.edh.dao.FileSystemDao
import com.influencehealth.edh.model.schema.CallCenterSchema
import com.influencehealth.edh.test.spark.SparkSpecBase
import com.influencehealth.edh.{AppCleanser, Constants}
import org.apache.spark.sql.{DataFrame, Row}
import org.scalamock.scalatest.MockFactory
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}

class CleanseCallCenterConiferSpec extends FlatSpec with SparkSpecBase with BeforeAndAfter with Matchers with MockFactory {

  val InputDirectoryPath: String = "fixtures/cleanse/callcenter/conifer/callcenter_conifer_fixture.xls"
  val DateBatchReceived: String = "11/01/2017"
  val Customer: String = "chomp"
  val BatchId = "chomp-callcenter-conifer-2017-11"

  it should "cleanse all data" in {

    val rawData = spark.createDataFrame(
      spark.sparkContext.parallelize(Seq(
        Row("04/24/18", "10:34:35", "Class Enrollment", null, "Web Site", "NP - Franklin News and Banner", "Medical Ctr. Carrollton", "45549", "47412", "Henry", "Eight", "06/17/89", null, "123 Main St", null, "Atlanta", "GA", "30304", "123 999-1234", null, "heng@yahoo.com", null, "24/04/2018", null, "No Appointment Made", null, null, null, null, null, "Get Healthy, Live Well (All)", "Tai Chi for Health - TC", "Tai Chi for Health - TC", "30/04/2018", "18"),
        Row("2/26/2018", "15:13:06", "Class Referral", null, "932Abs Hlt", "Unknown", "Medical Ctr. Carrollton", "44111", "45923", null, "UGA", null, null, null, null, null, "GA", null, null, null, null, null, "26/02/2018", null, "No Appointment Made", null, null, null, null, null, "Community Services", "Indigent /Charity Care Program - TC", null, null, null),
        Row("1/31/2018", "13:09:27", "Class Referral", null, "932Abs Hlt", "Internet Form Submission", "Medical Ctr. Carrollton", "43623", "45387", "Anna", "Boleen", "3/2/1999", "Female", "123 Village Road", null, "Atlanta", "GA", "30304", null, "(123) 999-6666", "justAnny@yahoo.com", "Verbal Consent", "31/01/2018", null, "No Appointment Made", null, null, null, null, "Requirements Not Met", "Community Services", "Sleep Disorder Center - TC", null, null, null),
        Row("4/5/2018", "07:40:57", "Physician Referral", null, "932Abs Hlt", "Internet - Google", "Medical Ctr. Carrollton", "44991", "46776", "Kalaey", null, "9/28/2010", "Female", null, null, "Atlanta", "GA", "30304", null, null, null, "Decline Consent", "05/04/2018", null, "Appointment Made", "Manley , Suzy", "1659362127", null, null, "Requested by Name", "Physician Referral", null, null, null, null),
        Row("2/7/2018", "08:59:35", "Class Referral", null, "932Abs Hlt", "Unknown", "Medical Ctr. Carrollton", "43734", "44067", null, "Carol EMC", null, null, "MANDY ROBINSON", null, "Atlanta", "GA", "30304", "123 666-7515", null, null, null, "07/02/2018", null, "No Appointment Made", null, null, null, null, null, "Community Services", "Freshstart Tobacco Cessation - Series - Carrollton - TC", null, null, null)
      )),
      CallCenterSchema.callCenterConiferSchema
    )

    val mockFileSystemDao = mock[FileSystemDao]

    (mockFileSystemDao.readCallCenterFile _).expects(false, Constants.CallCenterConiferFormat, Seq(InputDirectoryPath)).returns(rawData)

    val (cleansedDataFrame: DataFrame, dirtyDataFrame: DataFrame) = AppCleanser.cleanseData(
      Some(Customer), Constants.CallCenterActivityType, BatchId, false, InputDirectoryPath,
      Constants.CallCenterConiferFormat, "11/01/2017", mockFileSystemDao
    )

    cleansedDataFrame.count() shouldBe 2
    val firstNames = cleansedDataFrame.select("firstName").collectAsList()
    firstNames.get(0).getString(0) shouldBe "Henry"
    firstNames.get(1).getString(0) shouldBe "Anna"
    val source = cleansedDataFrame.select("source").collectAsList()
    source.get(0).getString(0) shouldBe "CALLCENTER"
    val sourceRecordId = cleansedDataFrame.select("sourceRecordId").collectAsList()
    sourceRecordId.get(0).getString(0) shouldBe "ae7f14fad30357c7f5339f8a5b70501d"
    sourceRecordId.get(1).getString(0) shouldBe "d74771757fa0ae8a31fb43b3cefbb103"
    val dateOfBirth = cleansedDataFrame.select("dateOfBirth").collectAsList()
    dateOfBirth.get(0).getDate(0).toString shouldBe "1989-06-17"
    dateOfBirth.get(1).getDate(0).toString shouldBe "1999-03-02"
    val activityDate = cleansedDataFrame.select("activityDate").collectAsList()
    activityDate.get(0).getString(0) shouldBe "2018-04-24 00:00:00"
    activityDate.get(1).getString(0) shouldBe "2018-01-31 00:00:00"
    val data = cleansedDataFrame.select("lastName").collectAsList()
    data.get(0).getString(0) shouldBe "Eight"
    dirtyDataFrame.count() shouldBe 3
    val dateOfDeath = dirtyDataFrame.select("lastName").collectAsList()
    dateOfDeath.get(0).getString(0) shouldBe "UGA"

  }


}
