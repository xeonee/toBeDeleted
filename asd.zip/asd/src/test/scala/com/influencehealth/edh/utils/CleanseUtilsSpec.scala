package com.influencehealth.edh.utils

import com.influencehealth.edh.test.spark.SparkSpecBase
import org.scalatest.{FlatSpec, Matchers}

class CleanseUtilsSpec extends FlatSpec with SparkSpecBase with Matchers {
  it should "parse a valid date" in {
    import spark.implicits._
    val dates = spark.createDataset(List("12/20/1976", "")).toDF()
    val parsedDates = dates.withColumn("parsedDates", CleanseUtils.parseDate(dates("value")))
    val values = parsedDates.select("parsedDates").collectAsList()
    values.get(0).getString(0) should equal("1976-12-20T00:00:00.000Z")
    values.get(1).getString(0) should equal("")
  }

  it should "cleanseAndParse phone numbers" in {
    import spark.implicits._
    val data = spark.createDataset(List[String]("111-111-1111", "98631231654654654")).toDF()
    val parsedData = data.withColumn("parsedData", CleanseUtils.cleanseAndParsePhone(data("value")))
    val values = parsedData.select("parsedData").collectAsList()
    values.get(0).getString(0) should equal("1111111111")
    values.get(1).getString(0) should equal("98631231654654654")
  }

  it should "trim a string" in {
    import spark.implicits._
    val data = spark.createDataset(List[String]("data   ")).toDF()
    val parsedData = data.transform(CleanseUtils.trimValue("value"))
    val values = parsedData.select("value").collectAsList()
    values.get(0).getString(0) should equal("data")
  }

  it should "remove FFFD" in {
    import spark.implicits._
    //noinspection ScalaStyle
    val data = spark.createDataset(List[String]("\uFFFD")).toDF()
    val parsedData = data.transform(CleanseUtils.removeFFFD("value"))
    val values = parsedData.select("value").collectAsList()
    values.get(0).getString(0) should equal(" ")
  }

  it should "remove quotes" in {
    import spark.implicits._
    val data = spark.createDataset(List[String]("testing\"123")).toDF()
    val parsedData = data.transform(CleanseUtils.removeQuotes("value"))
    val values = parsedData.select("value").collectAsList()
    values.get(0).getString(0) should equal("testing123")
  }

  it should "collapse spaces" in {
    import spark.implicits._
    val data = spark.createDataset(List[String]("testing   123")).toDF()
    val parsedData = data.transform(CleanseUtils.collapseSpaces("value"))
    val values = parsedData.select("value").collectAsList()
    values.get(0).getString(0) should equal("testing 123")
  }

  it should "remove null" in {
    import spark.implicits._
    val data = spark.createDataset(List[String]("null")).toDF()
    val parsedData = data.transform(CleanseUtils.removeNull("value"))
    val values = parsedData.select("value").collectAsList()
    values.get(0).getString(0) should equal("")
  }

  it should "remove None" in {
    import spark.implicits._
    val data = spark.createDataset(List[String]("None")).toDF()
    val parsedData = data.transform(CleanseUtils.removeNone("value"))
    val values = parsedData.select("value").collectAsList()
    values.get(0).getString(0) should equal("")
  }


  it should "extract correct zip5 from zip string" in {
    import spark.implicits._
    val data = spark.createDataset(List[String]("30157-6976", "302174037", "301579-976")).toDF()
    val parsedData = data.withColumn("zip5", CleanseUtils.get_zip5(data("value")))
    val values = parsedData.select("zip5").collectAsList()
    values.get(0).getString(0) should equal("30157")
    values.get(1).getString(0) should equal("30217")
    values.get(2).getString(0) should equal(null)
  }

  it should "extract correct zip4 from zip string" in {
    import spark.implicits._
    val data = spark.createDataset(List[String]("30157-6976", "302174037", "301579-976")).toDF()
    val parsedData = data.withColumn("zip4", CleanseUtils.get_zip4(data("value")))
    val values = parsedData.select("zip4").collectAsList()
    values.get(0).getString(0) should equal("6976")
    values.get(1).getString(0) should equal("4037")
    values.get(2).getString(0) should equal(null)
  }

  it should "cleanse empty strings as nulls" in {
    import spark.implicits._
    val data = spark.createDataset(List[String]("", " ", "middleName ")).toDF()
    val parsedData = data.withColumn("col", CleanseUtils.cleanseStringColumns(data("value")))
    val values = parsedData.select("col").collectAsList()
    values.get(0).getString(0) should equal(null)
    values.get(1).getString(0) should equal(null)
    values.get(2).getString(0) should equal("middleName")
  }

  it should "validate emails" in {
    import spark.implicits._
    val data = spark.createDataset(List( "abc.abc@something.something",
      "abc.abc@xyz.something.",
      "abc.abc@something.xyzz",
      "abc.abc@something.",
      "arturo.delgado@stvin",
      "abc.abcsomething.com",
      "abc%abc@something.xyz",
      "abcabcsomething.xyz")).toDF()

    val parsedData = data.withColumn("email", CleanseUtils.isValidEmail(data("value")))
    val values = parsedData.select("email").collectAsList()

    values.get(0).getBoolean(0) should equal(true)
    values.get(1).getBoolean(0) should equal(false)
    values.get(2).getBoolean(0) should equal(true)
    values.get(3).getBoolean(0) should equal(false)
    values.get(4).getBoolean(0) should equal(false)
    values.get(5).getBoolean(0) should equal(false)
    values.get(6).getBoolean(0) should equal(false)
    values.get(7).getBoolean(0) should equal(false)
  }

  "isPositive" should "return true for positive values and false for negative values" in {
    val negativeNumber = "-19990.99"
    val positiveNumber = "19990.99"
    assert(CleanseUtils.isPositiveNumeric(negativeNumber).equals(false))
    assert(CleanseUtils.isPositiveNumeric(positiveNumber).equals(true))
  }

  "ethnicInsight" should "return valid language values from StandardLanguageMap" in {
    import spark.implicits._

    val ethnicInsightDF = spark.createDataset(
      List(("ethnicInput1", 1,"religion1", "01", "group1", "country1"),
          ("ethnicInput2", 2,"religion2", "00", "group2", "country2"),
          ("ethnicInput3", 3,"religion3", null, "group3", "country3")))
        .toDF("ethnicInput", "experianGroupInput", "religionInput", "languageInput", "groupInput", "countryInput")

    val df = ethnicInsightDF.withColumn("ethnicInsight", CleanseUtils.ethnicInsight($"ethnicInput",
      $"experianGroupInput", $"religionInput", $"languageInput", $"groupInput", $"countryInput"))

    val values = df.select("ethnicInsight").collectAsList

    values.get(0).getString(0).toString should be ("ethnicInput101religion1englishgroup1country1")
    values.get(1).getString(0).toString should be ("ethnicInput202religion2nullgroup2country2")
    values.get(2).getString(0).toString should be ("ethnicInput303religion3nullgroup3country3")
  }

}
