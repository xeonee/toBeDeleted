package com.influencehealth.edh.cleanse.deceased

import com.influencehealth.edh.dao.FileSystemDao
import com.influencehealth.edh.model.schema.DeceasedPersonsSchema
import com.influencehealth.edh.test.spark.SparkSpecBase
import com.influencehealth.edh.{AppCleanser, Constants}
import org.apache.spark.sql.{DataFrame, Row}
import org.scalamock.scalatest.MockFactory
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}

class CleanseDeceasedPersonSpec extends FlatSpec with SparkSpecBase with BeforeAndAfter with Matchers with MockFactory {

  val InputDirectoryPath: String = "fixtures/cleanse/deceased/"
  val DateBatchReceived: String = "11/01/2017"
  val Customer = "chomp"
  val BatchId = "chomp-deceased-standard-2017-11"

  it should "correctly cleanse deceased persons file" in {

    val rawData: DataFrame = spark.createDataFrame(
      spark.sparkContext.parallelize(Seq(
        Row("A", "999999991", "LEBLANC", null, "CLAUDE", "FRANCIS", "P", "12272017", "05051921"),
        Row("A", "999999993", "KNOX", null, "CHARLES", "EDWARD", "V", null, "05131925"),
        Row("A", "999999992", "YOST", null, "BUCK", "LANDRY", "P", "01242018", "05041950"),
        Row("A", "999999994", "RENZULLI", null, "MARJORIE", "LOUISE", "P", "01012018", null)
      )),
      DeceasedPersonsSchema.schema)

    val mockFileSystemDao = mock[FileSystemDao]

    (mockFileSystemDao.readDeceasedFile _).expects(false, Seq(InputDirectoryPath)).returns(rawData)

    val (cleansedDataFrame: DataFrame, dirtyDataFrame: DataFrame) = AppCleanser.cleanseData(
      Some(Customer), Constants.DeceasedActivityType, BatchId, false, InputDirectoryPath,
      Constants.DeceasedInfluenceHealthFormat, "11/01/2017", mockFileSystemDao
    )

    cleansedDataFrame.count() shouldBe 3
    val dateOfBirth = cleansedDataFrame.select("dateOfBirth").collectAsList()
    dateOfBirth.get(0).getDate(0).toString shouldBe "1921-05-05"
    val dateOfDeath = cleansedDataFrame.select("dateOfDeath").collectAsList()
    dateOfDeath.get(0).getDate(0).toString shouldBe "2017-12-27"
    val source = cleansedDataFrame.select("source").collectAsList()
    source.get(0).getString(0) shouldBe "DECEASED"
    val sourceRecordId = cleansedDataFrame.select("sourceRecordId").orderBy("sourceRecordId").collectAsList()
    sourceRecordId.get(0).getString(0) shouldBe "999999991"
    sourceRecordId.get(1).getString(0) shouldBe "999999992"
    val lastNames = cleansedDataFrame.orderBy("sourceRecordId").select("lastName").collectAsList()
    lastNames.get(0).getString(0) shouldBe "LEBLANC"
    lastNames.get(1).getString(0) shouldBe "YOST"

    dirtyDataFrame.count() shouldBe 1
    val invalidDateOfDeath = dirtyDataFrame.select("dateOfDeath").collectAsList()
    invalidDateOfDeath.get(0).getString(0) shouldBe null
  }


}
