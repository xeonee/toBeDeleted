package com.influencehealth.edh.cleanse.marketinglist

import com.influencehealth.edh.dao.FileSystemDao
import com.influencehealth.edh.model.schema.MarketingListSchema
import com.influencehealth.edh.test.spark.SparkSpecBase
import com.influencehealth.edh.{AppCleanser, Constants}
import org.apache.spark.sql.{DataFrame, Row}
import org.scalamock.scalatest.MockFactory
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}

class CleanseMarketingListSpec extends FlatSpec with SparkSpecBase with BeforeAndAfter with Matchers with MockFactory {

  val InputDirectoryPath: String = "fixtures/cleanse/marketinglist/"
  val DateBatchReceived: String = "11/01/2017"
  val Customer: String = "chomp"
  val BatchId = "chomp-marketinglist-influencehealth-2017-11"

  it should "cleanse all data" in {


    val rawData: DataFrame = spark.createDataFrame(spark.sparkContext.parallelize(Seq(
        Row( "Anytown Hospital" , "Doe" , "John" , "Q" , "123 Sunny Street" , "Apt 456" , "Madison" , "WI" , "53719" , "Male" , "12/16/21" , "608-000-1000" , "john@email.com" , "Colon Screening Event Nov 2013" , "9/10/17" ),
        Row( "Anytown Hospital" , "Doe" , "Jane" , "Marie" ,null,null, "Madison" , "WI" , "53717" , "Female" ,null,null,null, "BreastCancerMonthEventOct2013" , "9/10/2017" )
    )), MarketingListSchema.marketinglistSchema)

    val mockFileSystemDao = mock[FileSystemDao]

    (mockFileSystemDao.readMarketingListFile _).expects(false, Seq(InputDirectoryPath)).returns(rawData)

    val (cleansedDataFrame: DataFrame, dirtyDataFrame: DataFrame) = AppCleanser.cleanseData(
      Some(Customer), Constants.MarketingListActivityType, BatchId, false, InputDirectoryPath,
      Constants.MarketingListInfluenceHealthFormat, DateBatchReceived, mockFileSystemDao
    )

    cleansedDataFrame.count() shouldBe 1

    val data = cleansedDataFrame.select("listName").collectAsList()
    data.get(0).getString(0) shouldBe "Colon Screening Event Nov 2013"
    // data.get(1).getString(0) shouldBe "BreastCancerMonthEventOct2013"

    val firstNames = cleansedDataFrame.select("firstName").collectAsList()
    firstNames.get(0).getString(0) shouldBe "John"
    val lastNames = cleansedDataFrame.select("lastName").collectAsList()
    lastNames.get(0).getString(0) shouldBe "Doe"
    val dateOfBirth = cleansedDataFrame.select("dateOfBirth").collectAsList()
    dateOfBirth.get(0).getDate(0).toString shouldBe "1921-12-16"
    val activityDate = cleansedDataFrame.select("activityDate").collectAsList()
    activityDate.get(0).getString(0).toString shouldBe "2017-09-10 00:00:00"
    val source = cleansedDataFrame.select("source").collectAsList()
    source.get(0).getString(0) shouldBe "HOSPITAL" // TODO: used to be MARKETINGLIST
    val sourceRecordId = cleansedDataFrame.select("sourceRecordId").collectAsList()
    sourceRecordId.get(0).getString(0) shouldBe "d482c223adf5504feb12e61ec785d0c0"

    dirtyDataFrame.count() shouldBe 1
    val dirtyData = dirtyDataFrame.select("emails").collectAsList()
    dirtyData.get(0).getString(0) shouldBe null
  }



}