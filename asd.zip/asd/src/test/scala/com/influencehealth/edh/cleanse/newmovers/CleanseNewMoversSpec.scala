package com.influencehealth.edh.cleanse.newmovers

import com.influencehealth.edh.dao.FileSystemDao
import com.influencehealth.edh.model.schema.NewMoversSchema
import com.influencehealth.edh.test.spark.SparkSpecBase
import com.influencehealth.edh.{AppCleanser, Constants}
import org.apache.spark.sql.{DataFrame, Row}
import org.scalamock.scalatest.MockFactory
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}

class CleanseNewMoversSpec extends FlatSpec with SparkSpecBase with BeforeAndAfter with Matchers with MockFactory {

  val InputDirectoryPath: String = "fixtures/cleanse/newmovers/"
  val DateBatchReceived: String = "2018-11"
  val BatchId = "experian-newmovers-influencehealth-2018-05"

  it should "cleanse all data" in {

    val rawData: DataFrame = spark.createDataFrame(spark.sparkContext.parallelize(Seq(
        Row( " " , "Ivan" , " " , "SINGH" , " " ,null, "123 MAIN ST " , "AVENEL" , "NJ" , "95043" , "00000" , "U" , "28" , "F" , "5M" , "U" ),
        Row( "MR" , "Luis" , "P" , "PEREZ" , " " ,null, "124 MAIN AVE " , "AVENEL" , "NJ" , "95043" , "00000" , "M" , "62" , "E" , "5S" , "U" )
    )), NewMoversSchema.schema)


    val mockFileSystemDao = mock[FileSystemDao]

    (mockFileSystemDao.readNewMoverFile _).expects(false, Seq(InputDirectoryPath)).returns(rawData)

    val (cleansedDataFrame: DataFrame, dirtyDataFrame: DataFrame) = AppCleanser.cleanseData(
      None, Constants.NewMoverActivityType, BatchId, false, InputDirectoryPath,
      Constants.NewMoverExperianFormat, DateBatchReceived, mockFileSystemDao
    )

    val data = cleansedDataFrame.select("firstName").collectAsList()
    data.get(0).getString(0) shouldBe "Ivan"
    data.get(1).getString(0) shouldBe "Luis"

    cleansedDataFrame.count() shouldBe 2
    val address1 = cleansedDataFrame.select("city").collectAsList()
    address1.get(0).getString(0) shouldBe "AVENEL"
    val source = cleansedDataFrame.select("source").collectAsList()
    source.get(0).getString(0) shouldBe "NEWMOVERS"
    val sourceRecordId = cleansedDataFrame.select("sourceRecordId").collectAsList()

    sourceRecordId.get(0).getString(0) shouldBe "ebd50861b5eb315fcd3b0b86d86750c4"
    sourceRecordId.get(1).getString(0) shouldBe "fae25c002730666aad050c8a8e58b908"

    cleansedDataFrame.count() shouldBe 2L

  }

}
