//package com.influencehealth.edh.load.epdblists
//
//import java.sql.Date
//import java.time.LocalDate
//
//import com.influencehealth.edh.test.spark.SparkSpecBase
//import org.apache.spark.sql.types._
//import org.apache.spark.sql.{DataFrame, Row}
//import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}
//
//import scala.collection.JavaConverters._
//
//class LoadEpdbListsSpec extends FlatSpec with SparkSpecBase with BeforeAndAfter with Matchers {
//
//  var listPersons: DataFrame = _
//
//  val CustomerId: Int = 0
//
//  val Customer: String = "peachtree"
//
//
//  override def beforeAll = {
//
//    super.beforeAll()
//
//    val personRow1: Row = Row(
//      0,
//      "person_id1",
//      Array("email1@gmail.com;email_type"),
//      Array("phone_number1;phone_type"),
//      Date.valueOf(LocalDate.now()),
//      Array("1234567890"),
//      Array(1),
//      Map("11111" -> "prop_score", "22222" -> null),
//      Map("11111" -> "recipe_score", "22222" -> null),
//      "38"
//    )
//
//    val originalListPersons: DataFrame = sparkSession.createDataFrame(List(personRow1).asJava, StructType(Array(
//      StructField("created_at", TimestampType, true),
//      StructField("dob", DateType, true),
//      StructField("customer_id", IntegerType, true)
//    )))
//
//    listPersons = LoadEpdbListsApp.prepareListPersonsForIdentification(originalListPersons, CustomerId, Customer)
//
//  }
//
//  ignore should "populate epdbPersonId" in {
//    listPersons.columns should contain("person_record_id")
//    listPersons.columns should contain("date_modified")
//    listPersons.columns should contain("date_created")
//    val row = listPersons.first()
//    row.getAs[String]("person_record_id") shouldBe "0::person_id1"
//  }
//
//  ignore should "populate primaryEmail" in {
//    listPersons.count() shouldBe 1
//    listPersons.columns should contain("person_record_id")
//    val row = listPersons.first()
//    row.getAs[String]("person_record_id") shouldBe "0::person_id1"
//
//  }
//
//  ignore should "populate primaryPhoneNumber" in {
//    listPersons.columns should contain("person_record_id")
//    val row = listPersons.first()
//    row.getAs[String]("person_record_id") shouldBe "0::person_id"
//  }
//
//  ignore should "create derived columns for person emails" in {
//    listPersons.columns should contain("email")
//    listPersons.columns should contain("email_type")
//    val row = listPersons.first()
//    row.getAs[String]("email") shouldBe "EMAIL1@GMAIL.COM"
//    row.getAs[String]("email_type") shouldBe "EMAIL_TYPE"
//  }
//
//  ignore should "create derived columns for person lists" in {
//    listPersons.columns should contain("list_id")
//    listPersons.count() shouldBe 1
//    val row = listPersons.first()
//    row.getAs[String]("list_id") shouldBe "1234567890"
//  }
//
//  ignore should "create derived columns for person locations" in {
//    listPersons.columns should contain("location_preference")
//    listPersons.columns should contain("location_id")
//    val row = listPersons.first()
//    row.getAs[Int]("location_preference") shouldBe 0
//    row.getAs[Int]("location_id") shouldBe 1
//  }
//
//  ignore should "create derived columns for person phone numbers" in {
//    listPersons.columns should contain("phone")
//    listPersons.columns should contain("phone_type")
//    val row = listPersons.first()
//    row.getAs[String]("phone") shouldBe "phone_number1"
//    row.getAs[String]("phone_type") shouldBe "PHONE_TYPE"
//  }
//
//  ignore should "create derived columns for person propensities" in {
//    listPersons.count() shouldBe 1
//    val row = listPersons.first()
//    row.getAs[Int]("propensity_id") shouldBe 11111
//    row.getAs[String]("propensity_score") shouldBe "prop_score"
//  }
//
//  ignore should "create derived columns for person recipes" in {
//    listPersons.count() shouldBe 1
//    val row = listPersons.first()
//    row.getAs[Int]("recipe_id") shouldBe 11111
//    row.getAs[String]("recipe_score") shouldBe "recipe_score"
//  }
//
//  ignore should "have 4 digit language column value for persons" in {
//    listPersons.columns should contain("language")
//    val row = listPersons.first()
//    row.getAs[String]("language").length shouldBe 4
//  }
//
//}
