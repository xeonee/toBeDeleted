package com.influencehealth.edh.enrich.person.residence

import java.sql.Timestamp
import java.time.LocalDateTime

import com.influencehealth.edh.Constants
import com.influencehealth.edh.model.{Address, Coordinates, Person}

object EnrichResidenceTestData {

  val person: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID1",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(0),
    dateSourceAgeReceived = Some(java.sql.Date.valueOf("2018-05-05")),
    isDeceased = Some(false),
    address1 = Some("address1"),
    city = Some("city1"),
    state = Some("state1"),
    zip5 = Some("zip1"),
    addressCoordinates = Some(Coordinates(123456, -123456)),
    isValidAddress = Some(true),
    addressId = Some("100")
  )

  val person2: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID2",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(3),
    dateSourceAgeReceived = Some(java.sql.Date.valueOf("2018-05-05")),
    isDeceased = Some(false),
    address1 = Some("address2"),
    city = Some("city2"),
    state = Some("state2"),
    zip5 = Some("zip2"),
    addressCoordinates = Some(Coordinates(123456, -123456)),
    isValidAddress = Some(false),
    addressId = Some("101")
  )

  val person3: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID3",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    dateOfBirth = Some(java.sql.Date.valueOf("2013-05-05")),
    isDeceased = Some(false),
    address1 = Some("address3"),
    city = Some("city3"),
    state = Some("state3"),
    zip5 = Some("zip3"),
    addressCoordinates = Some(Coordinates(33333, -33333)),
    isValidAddress = Some(true)
  )

  val person4: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID4",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(5),
    dateSourceAgeReceived = Some(java.sql.Date.valueOf("2019-01-01")),
    isDeceased = Some(true),
    address1 = Some("address4"),
    city = Some("city4"),
    state = Some("state4"),
    zip5 = Some("zip4"),
    addressCoordinates = Some(Coordinates(44444, -44444)),
    isValidAddress = Some(true)
  )

  val person5: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID5",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(8),
    dateSourceAgeReceived = Some(java.sql.Date.valueOf("2019-01-01")),
    isDeceased = Some(false),
    address1 = Some("address5"),
    city = Some("city5"),
    state = Some("state5"),
    zip5 = Some("zip5"),
    addressCoordinates = Some(Coordinates(5123456, -1523456)),
    isValidAddress = Some(true),
    addressId = Some("104")
  )

  val person6: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID6",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(11),
    dateSourceAgeReceived = Some(java.sql.Date.valueOf("2019-01-01")),
    isDeceased = Some(false),
    address1 = Some("address6"),
    city = Some("city6"),
    state = Some("state6"),
    zip5 = Some("zip6"),
    addressCoordinates = Some(Coordinates(1234556, -1234556)),
    isValidAddress = Some(false)
  )

  val person7: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID7",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(14),
    dateSourceAgeReceived = Some(java.sql.Date.valueOf("2019-01-01")),
    isDeceased = Some(false),
    address1 = Some("address7"),
    city = Some("city7"),
    state = Some("state7"),
    zip5 = Some("zip7"),
    addressCoordinates = Some(Coordinates(77777, -77777)),
    isValidAddress = Some(true)
  )

  val person8: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID8",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(17),
    dateSourceAgeReceived = Some(java.sql.Date.valueOf("2019-01-01")),
    isDeceased = Some(false),
    address1 = Some("address8"),
    city = Some("city8"),
    state = Some("state8"),
    zip5 = Some("zip8"),
    addressCoordinates = Some(Coordinates(1523456, -1234565)),
    isValidAddress = Some(false)
  )

  val person9: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID9",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(16),
    dateSourceAgeReceived = Some(java.sql.Date.valueOf("2019-01-01")),
    isDeceased = Some(false),
    address1 = Some("address9"),
    city = Some("city9"),
    state = Some("state9"),
    zip5 = Some("zip9"),
    addressCoordinates = Some(Coordinates(1234536, -1233456)),
    isValidAddress = Some(true),
    addressId = Some("200")
  )

  val person10: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID10",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(19),
    dateSourceAgeReceived = Some(java.sql.Date.valueOf("2019-01-01")),
    isDeceased = Some(false),
    address1 = Some("address10"),
    city = Some("city10"),
    state = Some("state10"),
    zip5 = Some("zip10"),
    addressCoordinates = Some(Coordinates(1234536, -1233456)),
    isValidAddress = Some(false),
    addressId = Some("210")
  )

  val person11: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID11",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(3),
    dateSourceAgeReceived = Some(java.sql.Date.valueOf("2019-01-01")),
    isDeceased = Some(true)
  )

  val person12: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID12",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(4),
    dateSourceAgeReceived = Some(java.sql.Date.valueOf("2019-01-01")),
    isDeceased = Some(true),
    address1 = Some("address12"),
    city = Some("city12"),
    state = Some("state12"),
    zip5 = Some("zip12"),
    addressCoordinates = Some(Coordinates(1234356, -1233456)),
    isValidAddress = Some(true),
    addressId = Some("220")
  )

  val person13: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID13",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(5),
    dateSourceAgeReceived = Some(java.sql.Date.valueOf("2019-01-01")),
    isDeceased = Some(true),
    address1 = Some("address13"),
    city = Some("city13"),
    state = Some("state13"),
    zip5 = Some("zip13"),
    addressCoordinates = Some(Coordinates(1213456, -1234526)),
    isValidAddress = Some(true),
    addressId = Some("230")
  )

  val person14: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID14",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(8),
    isDeceased = Some(true),
    address1 = Some("address14"),
    dateSourceAgeReceived = Some(java.sql.Date.valueOf("2018-05-05")),
    city = Some("city14"),
    state = Some("state14"),
    zip5 = Some("zip14"),
    addressCoordinates = Some(Coordinates(1234561, -1234156)),
    isValidAddress = Some(false),
    addressId = Some("240")
  )

  val person15: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID6",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(11),
    dateSourceAgeReceived = Some(java.sql.Date.valueOf("2019-01-01")),
    isDeceased = Some(true),
    address1 = Some("address15"),
    city = Some("city15"),
    state = Some("state15"),
    zip5 = Some("zip15"),
    addressCoordinates = Some(Coordinates(123456, -123456)),
    isValidAddress = Some(true),
    addressId = Some("250")
  )

  val person16: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID15",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(14),
    dateSourceAgeReceived = Some(java.sql.Date.valueOf("2019-01-01")),
    isDeceased = Some(true),
    address1 = Some("address16"),
    city = Some("city16"),
    state = Some("state16"),
    zip5 = Some("zip16"),
    addressCoordinates = Some(Coordinates(123456, -123456)),
    isValidAddress = Some(true),
    addressId = Some("260")
  )

  val person17: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID17",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(17),
    dateSourceAgeReceived = Some(java.sql.Date.valueOf("2019-01-01")),
    isDeceased = Some(true),
    address1 = Some("address17"),
    city = Some("city17"),
    state = Some("state17"),
    zip5 = Some("zip517"),
    addressCoordinates = Some(Coordinates(123456, -123456)),
    isValidAddress = Some(true),
    addressId = Some("270")
  )

  val person18: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID18",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(18),
    dateSourceAgeReceived = Some(java.sql.Date.valueOf("2019-01-01")),
    isDeceased = Some(true),
    address1 = Some("address18"),
    city = Some("city18"),
    state = Some("state18"),
    zip5 = Some("zip17"),
    addressCoordinates = Some(Coordinates(123456, -123456)),
    isValidAddress = Some(true),
    addressId = Some("280")
  )

  val person19: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID10",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(19),
    dateSourceAgeReceived = Some(java.sql.Date.valueOf("2019-01-01")),
    isDeceased = Some(true),
    address1 = Some("address19"),
    city = Some("city19"),
    state = Some("state19"),
    zip5 = Some("zip17"),
    addressCoordinates = Some(Coordinates(123456, -123456)),
    isValidAddress = Some(true),
    addressId = Some("390")
  )

  val person20: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID20",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = None,
    dateSourceAgeReceived = Some(java.sql.Date.valueOf("2019-01-01")),
    isDeceased = Some(true),
    address1 = Some("address20"),
    city = Some("city20"),
    state = Some("state20"),
    zip5 = Some("zip20"),
    addressCoordinates = Some(Coordinates(123456, -123456)),
    isValidAddress = Some(true),
    addressId = Some("380")
  )

  val person21: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID21",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(17),
    address1 = Some("address21"),
    city = Some("city21"),
    dateSourceAgeReceived = Some(java.sql.Date.valueOf("2018-05-05")),
    state = Some("state21"),
    zip5 = Some("zip521"),
    addressCoordinates = Some(Coordinates(123456, -123456)),
    isValidAddress = Some(true),
    addressId = Some("380")
  )

  val person22: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID22",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = None,
    dateSourceAgeReceived = None,
    isDeceased = None,
    address1 = Some("address22"),
    city = Some("city22"),
    state = Some("state22"),
    zip5 = Some("zip22"),
    addressCoordinates = Some(Coordinates(123456, -123456)),
    isValidAddress = Some(true),
    addressId = Some("380")
  )

  val person23: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID23",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(15),
    sex = Some(Constants.SexFemale),
    address1 = Some("address22"),
    city = Some("city22"),
    state = Some("state22"),
    zip5 = Some("zip22"),
    addressCoordinates = Some(Coordinates(123456, -123456)),
    isValidAddress = Some(true),
    addressId = Some("370")
  )

  val person24: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID24",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(15),
    sex = Some(Constants.SexMale),
    personType = Some(Constants.PersonTypePatient),
    address1 = Some("address24"),
    city = Some("city24"),
    state = Some("state"),
    zip5 = Some("zip524"),
    addressCoordinates = Some(Coordinates(123456, -123456)),
    isValidAddress = Some(true),
    addressId = Some("360")
  )

  val person25: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID25",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(20),
    sex = Some(Constants.SexFemale),
    personType = Some(Constants.PersonTypeNewMover),
    address1 = Some("address25"),
    city = Some("city25"),
    state = Some("state25"),
    zip5 = Some("zip25"),
    addressCoordinates = Some(Coordinates(123456, -123456)),
    isValidAddress = Some(true),
    addressId = Some("350")
  )

  val person26: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID26",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(20),
    sex = Some(Constants.SexMale),
    personType = Some(Constants.PersonTypeProspect),
    address1 = Some("address26"),
    city = Some("city26"),
    state = Some("state26"),
    zip5 = Some("zip26"),
    addressCoordinates = Some(Coordinates(123456, -123456)),
    isValidAddress = Some(true),
    addressId = Some("340")
  )

  val person27: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID27",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(70),
    sex = Some(Constants.SexFemale),
    personType = Some(Constants.PersonTypeQualifiedProspect),
    address1 = Some("address27"),
    city = Some("city27"),
    state = Some("state27"),
    zip5 = Some("zip527"),
    addressCoordinates = Some(Coordinates(123456, -123456)),
    isValidAddress = Some(true),
    addressId = Some("320")
  )

  val person28: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID28",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(70),
    sex = Some(Constants.SexMale),
    personType = Some(Constants.PersonTypeQualifiedProspect),
    address1 = Some("address28"),
    city = Some("city28"),
    state = Some("state28"),
    zip5 = Some("zip28"),
    addressCoordinates = Some(Coordinates(123456, -123456)),
    isValidAddress = Some(true),
    addressId = Some("310")
  )

  val person29: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID29",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(0),
    sex = Some(Constants.SexMale),
    personType = Some(Constants.PersonTypeFamilyMember),
    address1 = Some("address29"),
    city = Some("city29"),
    state = Some("state29"),
    zip5 = Some("zip29"),
    addressCoordinates = Some(Coordinates(123456, -123456)),
    isValidAddress = Some(true),
    addressId = Some("300")
  )


  val address1_ = Address(
    customer = "somecustomer",
    addressId = "100",
    address1 = "address1",
    city = "city1",
    state = "state1",
    zip5 = "zip1",
    addressCoordinates = Coordinates(11111.0f, -11111.0f)
  )

  val address2_ = Address(
    customer = "somecustomer",
    addressId = "101",
    address1 = "address2",
    city = "city2",
    state = "state2",
    zip5 = "zip2",
    addressCoordinates = Coordinates(22222.0f, -22222.0f)
  )

  val address3_ = Address(
    customer = "somecustomer",
    addressId = "102",
    address1 = "address3",
    city = "city3",
    state = "state3",
    zip5 = "zip3",
    addressCoordinates = Coordinates(33333.0f, -33333.0f)
  )

  val address4_ = Address(
    customer = "somecustomer",
    addressId = "103",
    address1 = "address4",
    city = "city4",
    state = "state4",
    zip5 = "zip4",
    addressCoordinates = Coordinates(44444.0f, -44444.0f)
  )

  val address5_ = Address(
    customer = "somecustomer",
    addressId = "104",
    address1 = "address5",
    city = "city5",
    state = "state5",
    zip5 = "zip5",
    addressCoordinates = Coordinates(55555.0f, -55555.0f)
  )

  val address6_ = Address(
    customer = "somecustomer",
    addressId = "105",
    address1 = "address51",
    city = "city52",
    state = "state53",
    zip5 = "zip54",
    addressCoordinates = Coordinates(66666.0f, -66666.0f)
  )

  val address7_ = Address(
    customer = "somecustomer",
    addressId = "106",
    address1 = "address81",
    city = "city81",
    state = "state81",
    zip5 = "zip81",
    addressCoordinates = Coordinates(77777.0f, -77777.0f)
  )

  val person30: Person = Person(
    customer = "somecustomer",
    personId = "PERSONID30",
    personType = Some("PROSPECT"),
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    sourceAge = Some(40),
    isDeceased = Some(false),
    address1 = Some("address30"),
    city = Some("city30"),
    state = Some("state30"),
    zip5 = Some("zip30"),
    addressCoordinates = Some(Coordinates(123456, -123456)),
    isValidAddress = Some(true),
    addressId = Some("1010"),
    hasChildZeroToThree = Some(true),
    hasChildFourToSix = Some(true),
    hasChildSevenToNine = Some(false)
  )

  val address_ = List(address1_, address2_, address3_, address4_, address5_, address6_, address7_)

  var persons: List[Person] = List(person, person2, person3, person4, person5, person6, person7, person8, person9,
    person10, person11, person12, person13, person14, person15, person16, person17, person18, person19, person20,
    person21, person22, person23, person24, person25, person26, person27, person28, person29, person30)

}
