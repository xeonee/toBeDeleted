
package com.influencehealth.edh.enrich.person.residence

import java.util.UUID

import com.influencehealth.edh.Constants
import com.influencehealth.edh.config.EnrichJobConfig
import com.influencehealth.edh.model.{Person, Address}
import com.influencehealth.edh.test.spark.SparkSpecBase
import org.apache.spark.sql.Dataset
import org.scalatest.{FlatSpec, Matchers}


class EnrichResidenceStepSpec extends FlatSpec with Matchers with SparkSpecBase {

  val addressId1 = Some(UUID.randomUUID().toString)
  var enrichResidenceStep: EnrichResidenceStep = _
  var personsDf: Dataset[Person] = _
  var enrichedPersons: Dataset[Person] = _


  override def beforeAll(): Unit = {
    super.beforeAll()
    implicit val enrichJobConfig: EnrichJobConfig = new EnrichJobConfig(
      jobType = "",
      subJobType = "",
      customer = "testcustomer",
      customerId = 12,
      customerPafName = None,
      customerLocations = Seq.empty,
      customerServiceAreas = Set.empty,
      activityType = None,
      batchId = None,
      batchFormat = "",
      bucketUrl = "",
      allOrApplicable = "applicable",
      executorCores = 10,
      inputFilePath = None,
      failOnError = true,
      databaseConfig = None,
      anchorConfig = None,
      sg2Config = None,
      user = "testuser",
      profile = "",
      environment = "",
      fullRefresh = false
    )

    enrichResidenceStep = new EnrichResidenceStep("", None)(enrichJobConfig, spark)
  }

  "Address preference" should "assign correctly based on age & sex" in {

    val assignedAddressPreference: List[Person] =
      enrichResidenceStep.assignAddressPreference(EnrichResidenceTestData.persons)

    assignedAddressPreference.exists(x => x.personId == "PERSONID23" &&
      x.sourceAge.contains(15) && x.sex.contains(Constants.SexFemale) && x.addressPreference.contains(4)) shouldBe true
    assignedAddressPreference.exists(x => x.personId == "PERSONID24" &&
      x.sourceAge.contains(15) && x.sex.contains(Constants.SexMale) && x.addressPreference.contains(5)) shouldBe true
    assignedAddressPreference.exists(x => x.personId == "PERSONID25" &&
      x.sourceAge.contains(20) && x.sex.contains(Constants.SexFemale) && x.addressPreference.contains(0)) shouldBe true
    assignedAddressPreference.exists(x => x.personId == "PERSONID26" &&
      x.sourceAge.contains(20) && x.sex.contains(Constants.SexMale) && x.addressPreference.contains(1)) shouldBe true
    assignedAddressPreference.exists(x => x.personId == "PERSONID27" &&
      x.sourceAge.contains(70) && x.sex.contains(Constants.SexFemale) && x.addressPreference.contains(2)) shouldBe true
    assignedAddressPreference.exists(x => x.personId == "PERSONID28" &&
      x.sourceAge.contains(70) && x.sex.contains(Constants.SexMale) && x.addressPreference.contains(3)) shouldBe true
    assignedAddressPreference.exists(x => x.personId == "PERSONID29" &&
      x.sourceAge.contains(0) && x.sex.contains(Constants.SexMale) && x.addressPreference.contains(6)) shouldBe true
    assignedAddressPreference.exists(x => x.personId == "PERSONID22" &&
      x.addressPreference.contains(28)) shouldBe true

  }

  // TODO when Business/Product decides the logic
  ignore should "assign correctly based on Person Type" in {

    val assignedFamilyPersonType: List[Person] =
      enrichResidenceStep.assignFamilyPersonType(EnrichResidenceTestData.persons)

    assignedFamilyPersonType.exists(x => x.personId == "PERSONID23" &&
      x.personType.isEmpty) shouldBe true
    assignedFamilyPersonType.exists(x => x.personId == "PERSONID24" &&
      x.personType.contains(Constants.PersonTypePatient)) shouldBe true
    assignedFamilyPersonType.exists(x => x.personId == "PERSONID25" &&
      x.personType.contains(Constants.PersonTypeNewMover)) shouldBe true
    assignedFamilyPersonType.exists(x => x.personId == "PERSONID26" &&
      x.personType.contains(Constants.PersonTypeProspect)) shouldBe true
    assignedFamilyPersonType.exists(x => x.personId == "PERSONID27"
      && x.personType.contains(Constants.PersonTypeQualifiedProspect)) shouldBe true
    assignedFamilyPersonType.exists(x => x.personId == "PERSONID28" &&
      x.personType.contains(Constants.PersonTypeQualifiedProspect)) shouldBe true
    assignedFamilyPersonType.exists(x => x.personId == "PERSONID29" &&
      x.personType.contains(Constants.PersonTypeFamilyMember)) shouldBe true
  }

  "Presence of child flag" should "assign correctly" in {
    val isChildPresent1: Boolean = enrichResidenceStep.isChildPresent(EnrichResidenceTestData.person2)
    val isChildPresent2: Boolean = enrichResidenceStep.isChildPresent(EnrichResidenceTestData.person14)
    val isChildPresent3: Boolean = enrichResidenceStep.isChildPresent(EnrichResidenceTestData.person20)
    val isChildPresent4: Boolean = enrichResidenceStep.isChildPresent(EnrichResidenceTestData.person21)
    val isChildPresent5: Boolean = enrichResidenceStep.isChildPresent(EnrichResidenceTestData.person22)

    isChildPresent1 shouldBe true
    isChildPresent2 shouldBe false
    isChildPresent3 shouldBe false
    isChildPresent4 shouldBe false
    isChildPresent5 shouldBe false

  }


  "isChildPresent" should "be updated correctly" in {
    val assignPresenceOfChildInAHousehold: List[Person] =
      enrichResidenceStep.assignPresenceOfChildInAHousehold(EnrichResidenceTestData.persons)

    assignPresenceOfChildInAHousehold.exists(x => x.personId == "PERSONID1" &&
      x.isChildPresent.contains(true)) shouldBe true
    assignPresenceOfChildInAHousehold.exists(x => x.personId == "PERSONID9" &&
      x.isChildPresent.contains(false)) shouldBe false
    assignPresenceOfChildInAHousehold.exists(x => x.personId == "PERSONID30" &&
      x.isChildPresent.contains(true)) shouldBe true

  }

  "Child bucket" should "be updated correctly" in {

    val assignedChildAgeBucket: List[Person] =
      enrichResidenceStep.assignChildAgeBucket(EnrichResidenceTestData.persons)

    assignedChildAgeBucket.exists(x => x.personId == "PERSONID1" &&
      x.hasChildZeroToThree.contains(true)) shouldBe true
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID1" &&
      x.hasChildFourToSix.contains(false)) shouldBe false
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID1" &&
      x.hasChildSevenToNine.contains(false)) shouldBe false
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID1" &&
      x.hasChildTenToTwelve.contains(false)) shouldBe false
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID1" &&
      x.hasChildThirteenToFifteen.contains(false)) shouldBe false
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID1" &&
      x.hasChildSixteenToEighteen.contains(false)) shouldBe false

    assignedChildAgeBucket.exists(x => x.personId == "PERSONID2" &&
      x.hasChildZeroToThree.contains(true)) shouldBe true
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID3" &&
      x.hasChildFourToSix.contains(true)) shouldBe true
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID4" &&
      x.hasChildFourToSix.contains(true)) shouldBe true
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID5" &&
      x.hasChildSevenToNine.contains(true)) shouldBe true
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID6" &&
      x.hasChildTenToTwelve.contains(true)) shouldBe true
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID7" &&
      x.hasChildThirteenToFifteen.contains(true)) shouldBe true
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID8" &&
      x.hasChildSixteenToEighteen.contains(true)) shouldBe true
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID9" &&
      x.hasChildSixteenToEighteen.contains(true)) shouldBe true

    assignedChildAgeBucket.exists(x => x.personId == "PERSONID10" &&
      x.hasChildSixteenToEighteen.contains(false)) shouldBe false

    assignedChildAgeBucket.exists(x => x.personId == "PERSONID11" &&
      x.hasChildZeroToThree.contains(false)) shouldBe false
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID12" &&
      x.hasChildZeroToThree.contains(false)) shouldBe false
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID13" &&
      x.hasChildFourToSix.contains(false)) shouldBe false
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID14" &&
      x.hasChildFourToSix.contains(false)) shouldBe false
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID15" &&
      x.hasChildSevenToNine.contains(false)) shouldBe false
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID16" &&
      x.hasChildTenToTwelve.contains(false)) shouldBe false
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID17" &&
      x.hasChildThirteenToFifteen.contains(false)) shouldBe false
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID18" &&
      x.hasChildSixteenToEighteen.contains(false)) shouldBe false
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID19" &&
      x.hasChildSixteenToEighteen.contains(false)) shouldBe false

    assignedChildAgeBucket.exists(x => x.personId == "PERSONID20" &&
      x.hasChildZeroToThree.contains(false)) shouldBe false
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID21" &&
      x.hasChildSixteenToEighteen.contains(false)) shouldBe false
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID22" &&
      x.hasChildSevenToNine.contains(false)) shouldBe false
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID30" &&
      x.hasChildZeroToThree.contains(true)) shouldBe true
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID30" &&
      x.hasChildFourToSix.contains(true)) shouldBe true
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID30" &&
      x.hasChildSevenToNine.contains(false)) shouldBe false
    assignedChildAgeBucket.exists(x => x.personId == "PERSONID30" &&
      x.hasChildSixteenToEighteen.contains(false)) shouldBe false
  }

  it should "drop duplicate addressIDs from dataset" in {
    import spark.implicits._
    val newAddressRecords: Dataset[Address] = (EnrichResidenceTestData.address_ :+ EnrichResidenceTestData.address1_).toDS()
    val addressByCustomer: Dataset[Address] = Seq(EnrichResidenceTestData.address1_, EnrichResidenceTestData.address2_).toDS()
    val result: Dataset[Address] = enrichResidenceStep.dropDuplicateAddressId(newAddressRecords, addressByCustomer)

    result.count shouldBe 5

    // as record with address id "101" already present in addressByCustomer dataset, it will not be returned.
    result.map(x => x.addressId).collect.toSeq should equal (Array("102", "103", "104", "105", "106"))
  }

}

