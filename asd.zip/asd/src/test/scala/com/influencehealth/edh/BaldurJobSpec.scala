package com.influencehealth.edh

import com.influencehealth.edh.test.spark.SparkSpecBase
import org.scalatest.{BeforeAndAfter, Ignore, Matchers}

@Ignore
class BaldurJobSpec extends SparkSpecBase with Matchers with BeforeAndAfter {

  before {
    def setEnv(key: String, value: String) = {
      val field = System.getenv().getClass.getDeclaredField("m")
      field.setAccessible(true)
      val map = field.get(System.getenv()).asInstanceOf[java.util.Map[java.lang.String, java.lang.String]]
      map.put(key, value)
    }

    setEnv("EDH_ENV", "test")
  }


  // TODO: Update to use BaldurApp
  "BaldurJob" should "load the correct app configuration from typesafe config given correct environment" in {

    //    val job = new TestJob()
    //    val config = job.appConfig
    //
    //    config.isEmpty shouldBe false
    //    config.getString("amqp.host") shouldBe "127.0.0.1"
    //    config.getInt("amqp.ttl-mins") shouldBe 1
    //    config.getString("app.customer") shouldBe "peachtree"
    //    config.getString("redshift.connection-string") shouldBe "localhost?user=fakeuser&password=fakepass"
  }

  //  class TestJob extends BaldurJob {
  //
  //  }

}
