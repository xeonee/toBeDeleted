package com.influencehealth.edh.utils

import com.influencehealth.edh.test.spark.SparkSpecBase
import org.scalatest.{FlatSpec, Matchers}

class PersonUtilsSpec  extends FlatSpec with SparkSpecBase with Matchers {

  it should "validate input date and update the Century value to 19 if the input date is greater than today's date" in {
    import spark.implicits._
    val data = List[String]("2011-12-16 00:00:00.0", "2021-12-16 00:00:00.0", "").toDS().toDF()
    val parsedData = data.withColumn("parsedData", PersonUtils.validateInputDate(data("value")))
    val values = parsedData.select("parsedData").collectAsList()
    values.get(0).getTimestamp(0).toString should be ("2011-12-16 00:00:00.0")
    values.get(1).getTimestamp(0).toString should be ("1921-12-16 00:00:00.0")
    values.get(2).getString(0) should be (null)
  }

  "Age" should "correctly calculate based on data of birth" in {
    val dateOfBirth = "1990-04-26"
    PersonUtils.computeAge(Some(java.sql.Date.valueOf(dateOfBirth)), None, None) shouldBe Some(28)
  }

  it should "correctly calculate based on date source age received and source age" in {
    val dateSourceAgeReceived= "1990-04-26"
    PersonUtils.computeAge(None, Some(32), Some(java.sql.Date.valueOf(dateSourceAgeReceived))) shouldBe Some(60)
  }
}
