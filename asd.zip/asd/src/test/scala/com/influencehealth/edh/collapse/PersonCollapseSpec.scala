package com.influencehealth.edh.collapse

import java.sql.Timestamp

import com.influencehealth.edh.Constants
import com.influencehealth.edh.model.{Person, PersonLocation, PersonPhoneNumber}
import com.influencehealth.edh.updater.PersonUpdaterImpl
import com.influencehealth.edh.test.spark.SparkSpecBase
import org.scalatest.Matchers

class PersonCollapseSpec extends SparkSpecBase with Matchers {

  it should "not update a person when new person mostRelevantActivityType is " +
    "< than the old person mostRelevantActivityType" in {

    val oldestPerson = Person(
      customer = "tanner",
      personId = "person1",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      mostRelevantActivityType = Some(Constants.EncounterActivityType),
      firstName = Some("James")
    )

    val newestPerson = Person(
      customer = "tanner",
      personId = "person2",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      mostRelevantActivityType = Some(Constants.ProspectActivityType),
      firstName = Some("Charles")
    )

    val updatedPerson = PersonUpdaterImpl.updatePerson(oldestPerson, newestPerson)

    updatedPerson.firstName.get.shouldEqual("James")

  }

  it should "correctly update middleName" in {

    val oldestPerson = Person(
      customer = "tanner",
      personId = "person1",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      mostRelevantActivityType = Some(Constants.EncounterActivityType),
      firstName = Some("James"),
      middleName = Some("C")
    )

    val newestPerson = Person(
      customer = "tanner",
      personId = "person2",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      mostRelevantActivityType = Some(Constants.EncounterActivityType),
      firstName = Some("James"),
      middleName = Some("Charles")
    )

    val updatedPerson = PersonUpdaterImpl.updatePerson(oldestPerson, newestPerson)

    updatedPerson.middleName.get shouldEqual "Charles"

  }

  it should "not update middleName" in {

    val oldestPerson = Person(
      customer = "tanner",
      personId = "person1",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      mostRelevantActivityType = Some(Constants.EncounterActivityType),
      middleName = Some("Charles")
    )

    val newestPerson = Person(
      customer = "tanner",
      personId = "person2",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      mostRelevantActivityType = Some(Constants.EncounterActivityType),
      middleName = Some("C")
    )

    val updatedPerson = PersonUpdaterImpl.updatePerson(oldestPerson, newestPerson)

    updatedPerson.middleName.get shouldEqual "Charles"

  }

  it should "correctly update middleName when the old value and new value have length of 1" in {

    val oldestPerson = Person(
      customer = "tanner",
      personId = "person1",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      mostRelevantActivityType = Some(Constants.EncounterActivityType),
      middleName = Some("X")
    )

    val newestPerson = Person(
      customer = "tanner",
      personId = "person2",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      mostRelevantActivityType = Some(Constants.EncounterActivityType),
      middleName = Some("C")
    )

    val updatedPerson = PersonUpdaterImpl.updatePerson(oldestPerson, newestPerson)

    updatedPerson.middleName.get shouldEqual "C"

  }

  it should "append mrids and remove duplicates when updating person" in {

    val oldestPerson = Person(
      customer = "tanner",
      personId = "person1",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      mostRelevantActivityType = Some(Constants.EncounterActivityType),
      mrids = Seq("mrid1", "mrid2", "mrid3")
    )

    val newestPerson = Person(
      customer = "tanner",
      personId = "person2",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      mostRelevantActivityType = Some(Constants.EncounterActivityType),
      mrids = Seq("mrid3", "mrid4")
    )

    val updatedPerson = PersonUpdaterImpl.updatePerson(oldestPerson, newestPerson)

    updatedPerson.mrids shouldEqual Seq("mrid3", "mrid4", "mrid1", "mrid2")

  }

  it should "not update locations with null value" in {

    val oldestPerson = Person(
      customer = "tanner",
      personId = "person1",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      mostRelevantActivityType = Some(Constants.EncounterActivityType),
      locations = Seq(PersonLocation("location1", 1), PersonLocation("location2", 2))
    )

    val newestPerson = Person(
      customer = "tanner",
      personId = "person2",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      mostRelevantActivityType = Some(Constants.EncounterActivityType),
      locations = Seq.empty[PersonLocation]
    )

    val updatedPerson = PersonUpdaterImpl.updatePerson(oldestPerson, newestPerson)

    updatedPerson.locations.head.location shouldEqual "location1"
    updatedPerson.locations.head.preference shouldEqual 1

    updatedPerson.locations.last.location shouldEqual "location2"
    updatedPerson.locations.last.preference shouldEqual 2

  }

  it should "correctly update emails" in {

    val oldestPerson = Person(
      customer = "tanner",
      personId = "person1",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      mostRelevantActivityType = Some(Constants.EncounterActivityType),
      emails = Seq("email blaba@company.com")
    )

    val newestPerson = Person(
      customer = "tanner",
      personId = "person2",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      mostRelevantActivityType = Some(Constants.EncounterActivityType),
      emails = Seq("email@gmail.com\n")
    )

    val updatedPerson = PersonUpdaterImpl.updatePerson(oldestPerson, newestPerson)

    updatedPerson.emails.size shouldEqual 2

    updatedPerson.emails.head shouldEqual "email@gmail.com"

    updatedPerson.emails.last shouldEqual "email blaba@company.com"

  }

  it should "correctly update phoneNumbers" in {

    val oldestPerson = Person(
      customer = "tanner",
      personId = "person1",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      mostRelevantActivityType = Some(Constants.EncounterActivityType),
      phoneNumbers = Seq(PersonPhoneNumber("11111", Constants.PhoneTypeWork))
    )

    val newestPerson = Person(
      customer = "tanner",
      personId = "person2",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      mostRelevantActivityType = Some(Constants.EncounterActivityType),
      phoneNumbers = Seq(PersonPhoneNumber(phone = "55555"))
    )

    val updatedPerson = PersonUpdaterImpl.updatePerson(oldestPerson, newestPerson)

    updatedPerson.phoneNumbers.size shouldEqual 2

    updatedPerson.phoneNumbers.head.phone shouldEqual "55555"
    updatedPerson.phoneNumbers.head.phoneType shouldBe Constants.PhoneTypeMobile

    updatedPerson.phoneNumbers.last.phone shouldEqual "11111"
    updatedPerson.phoneNumbers.last.phoneType shouldEqual Constants.PhoneTypeWork

  }

  it should "correctly merge phoneNumbers" in {

    val oldestPerson = Person(
      customer = "tanner",
      personId = "person1",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      mostRelevantActivityType = Some(Constants.EncounterActivityType),
      phoneNumbers = Seq(PersonPhoneNumber("11111", Constants.PhoneTypeWork))
    )

    val newestPerson = Person(
      customer = "tanner",
      personId = "person2",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      mostRelevantActivityType = Some(Constants.EncounterActivityType)
    )

    val updatedPerson = PersonUpdaterImpl.updatePerson(oldestPerson, newestPerson)

    updatedPerson.phoneNumbers.size shouldEqual 1

    updatedPerson.phoneNumbers.head.phone shouldEqual "11111"
    updatedPerson.phoneNumbers.head.phoneType shouldEqual Constants.PhoneTypeWork

  }


  it should "atomically update address fields" in {

    val oldestPerson = Person(
      customer = "tanner",
      personId = "person1",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      mostRelevantActivityType = Some(Constants.EncounterActivityType),
      address2 = Some("Apt 321"),
      zip5 = Some("30309")
    )

    val newestPerson = Person(
      customer = "tanner",
      personId = "person2",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      mostRelevantActivityType = Some(Constants.EncounterActivityType),
      middleName = Some("C"),
      address1 = Some("123 10th St NE"),
      address2 = Some("Apt 421"),
      city = Some("Atlanta"),
      state = Some("GA")
    )

    val updatedPerson = PersonUpdaterImpl.updatePerson(oldestPerson, newestPerson)

    updatedPerson.address1.get shouldEqual "123 10th St NE"
    updatedPerson.address2.get shouldEqual "Apt 421"
    updatedPerson.city.get shouldEqual "Atlanta"
    updatedPerson.zip5 shouldBe None

  }

}
