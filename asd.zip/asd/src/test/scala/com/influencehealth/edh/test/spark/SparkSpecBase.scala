package com.influencehealth.edh.test.spark

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession
import org.scalatest.{Suite, _}

/**
  * Base class for any tests needing SparkConf, SparkContext, sparkSession, or StreamingContext
  */
trait SparkSpecBase extends FlatSpec with BeforeAndAfterAll {
  this: Suite =>

  private var _spark: SparkSession = _

  /**
    * Initializes all spark related objects
    */
  override def beforeAll(): Unit = {
    super.beforeAll()
    Logger.getRootLogger.setLevel(Level.WARN)

    val builder = initBuilder

    _spark = builder.getOrCreate()
    _spark.sparkContext.setLogLevel("WARN")

    def pwd = System.getProperty("user.dir")

    _spark.sparkContext.addFile(s"$pwd/config/application.conf")
    _spark.sparkContext.addFile(s"$pwd/config/app/test.conf")

    def setEnv(key: String, value: String) = {
      val field = System.getenv().getClass.getDeclaredField("m")
      field.setAccessible(true)
      val map = field.get(System.getenv()).asInstanceOf[java.util.Map[java.lang.String, java.lang.String]]
      map.put(key, value)
    }
    setEnv("EDH_ENV", "test")

  }

  protected def initBuilder: SparkSession.Builder = SparkSession.builder()
    .master("local[2]")
    .appName(this.getClass.getSimpleName)
    .config("spark.ui.enabled", value = false)
    .config("spark.ui.showConsoleProgress", value = false)
    .config("spark.sql.shuffle.partitions", value = 1)
    .config("spark.driver.allowMultipleContexts", value = true)
    .config("spark.driver.host", value = "localhost")
    .config("spark.debug.maxToStringFields", value = 10000)

  /**
    * Handles spark shutdown
    */
  override def afterAll(): Unit = {
    if (_spark != null) {}
    _spark.stop()
    _spark = null
    super.afterAll()
  }


  lazy val spark: SparkSession = _spark

}
