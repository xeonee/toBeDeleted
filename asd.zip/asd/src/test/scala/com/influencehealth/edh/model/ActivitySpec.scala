package com.influencehealth.edh.model

import org.scalatest.{FlatSpec, Matchers}

class ActivitySpec extends FlatSpec with Matchers {



}
