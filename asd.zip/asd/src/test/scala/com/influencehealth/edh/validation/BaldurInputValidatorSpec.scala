package com.influencehealth.edh.validation

import com.influencehealth.edh.dataframe.columns._
import com.influencehealth.edh.load.activities.ActivityLoader
import com.influencehealth.edh.model.Activity
import com.influencehealth.edh.test.spark.SparkSpecBase
import mojolly.inflector.Inflector
import org.apache.spark.sql.functions.col
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}

import scala.collection.JavaConverters._


class BaldurInputValidatorSpec extends FlatSpec with SparkSpecBase with BeforeAndAfter with Matchers {

  def getErrorsArray(validator: BaldurInputValidator) = {
    validator.splitInvalidData()._1.select("errors").collectAsList().asScala.flatMap(_.getList[String](0).asScala).toList
  }

  it should "return a collection of errors when a dataframe contains invalid values" in {

    import spark.implicits._

    val activityType = "encounter"
    val customer = "tanner"
    val filePathForNonExperian: String = "fixtures/load/activities/validation.parquet/"

    val activitiesDataFrame = ActivityLoader.readActivityFiles(spark, filePathForNonExperian,
      activityType, customer, Set(), "dummyBatchId")

    val updatedActivities = activitiesDataFrame.
      select(activitiesDataFrame.schema.map(c => col(c.name) as Inflector.camelize(c.name)): _*).
      drop("assessmentResults").
      withColumnRenamed("language", IsoLanguageCode).
      withColumnRenamed("age", "sourceAge").
      withColumnRenamed("financialClassId", "financialClass")

    val activities = updatedActivities.transform(Activity.transformToActivitySchema).as[Activity]

    val validationErrors: Seq[String] = new BaldurInputValidator(activities.toDF()).splitInvalidData()._1.
      select("errors").collectAsList().asScala.flatMap(_.getList[String](0).asScala)

    // emails
    // validationErrors should contain(s"[angelwind75@yahoo.com.] is not valid value for column: $Email")
    // validationErrors should contain(s"[Jessgerdi55@gmailcom] is not valid value for column: $Email")
    // validationErrors should contain(s"[n/a] is not valid value for column: $Email")
    // validationErrors should contain(s"[pages 8384@gmail.com] is not valid value for column: $Email")
    // validationErrors should contain(s"[mbmicham@comcast] is not valid value for column: $Email")
    // validationErrors should contain(s"[angelwind75@yahoo.com.] is not valid value for column: $Email")

    // phone numbers
    validationErrors should contain(s"[(123) 1234 123] is not valid value for column: $HomePhone")
    validationErrors should contain(s"[(xxx) 1234 123] is not valid value for column: $HomePhone")
    validationErrors should contain(s"[(123) 1234 12] is not valid value for column: $MobilePhone")
    validationErrors should contain(s"[+1-8303785826] is not valid value for column: $HomePhone")

    // age and age groups
    validationErrors should contain(s"[160] is not valid value for column: $SourceAge")

    // language
    validationErrors should contain(s"[0] is not valid value for column: $IsoLanguageCode")
    validationErrors should contain(s"[XX] is not valid value for column: $IsoLanguageCode")

    // state and county
    validationErrors should contain(s"[XX] is not valid value for column: $State")
    validationErrors should contain(s"[999] is not valid value for column: $County")
    validationErrors should contain(s"[100] is not valid value for column: $County")
    validationErrors should contain(s"[100000] is not valid value for column: $County")

    // zip4
    validationErrors should contain(s"[12345] is not valid value for column: $Zip4")
    validationErrors should contain(s"[999] is not valid value for column: $Zip4")
    validationErrors should contain(s"[n/a] is not valid value for column: $Zip4")
    validationErrors should contain(s"[UNKNOWN] is not valid value for column: $Zip4")

    // zip5
    validationErrors should contain(s"[9999] is not valid value for column: $Zip5")
    validationErrors should contain(s"[123456] is not valid value for column: $Zip5")
    validationErrors should contain(s"[12$$34] is not valid value for column: $Zip5")
    validationErrors should contain(s"[n/a] is not valid value for column: $Zip5")
    validationErrors should contain(s"[UNKNOWN] is not valid value for column: $Zip5")

    // payer type
    validationErrors should contain(s"[AA] is not valid value for column: $PayerType")
    validationErrors should contain(s"[XX] is not valid value for column: $PayerType")
    validationErrors should contain(s"[UNKNOWN] is not valid value for column: $PayerType")

    // occupation
    validationErrors should contain(s"[999] is not valid value for column: $Occupation")
    validationErrors should contain(s"[55] is not valid value for column: $Occupation")
    validationErrors should contain(s"[XX] is not valid value for column: $OccupationGroup")
    validationErrors should contain(s"[UNKNOWN] is not valid value for column: $OccupationGroup")

    // beehive cluster
    validationErrors should contain(s"[20] is not valid value for column: $BeehiveCluster")
    validationErrors should contain(s"[25] is not valid value for column: $BeehiveCluster")

    // wealth rating
    validationErrors should contain(s"[-1] is not valid value for column: $WealthRating")
    validationErrors should contain(s"[10] is not valid value for column: $WealthRating")

    // race and religion
    validationErrors should contain(s"[A] is not valid value for column: $Religion")
    validationErrors should contain(s"[UNKNOWN] is not valid value for column: $Religion")
    validationErrors should contain(s"[X] is not valid value for column: $Race")
    validationErrors should contain(s"[UNKNOWN] is not valid value for column: $Race")

    // financial class id
    validationErrors should contain(s"[99999] is not valid value for column: $FinancialClass")
    validationErrors should contain(s"[1234] is not valid value for column: $FinancialClass")

    // combined owner
    validationErrors should contain(s"[1] is not valid value for column: $CombinedOwner")
    validationErrors should contain(s"[X] is not valid value for column: $CombinedOwner")
    validationErrors should contain(s"[UNKNOWN] is not valid value for column: $CombinedOwner")

    // dwell type
    validationErrors should contain(s"[9] is not valid value for column: $DwellType")
    validationErrors should contain(s"[X] is not valid value for column: $DwellType")
    validationErrors should contain(s"[UNKNOWN] is not valid value for column: $DwellType")

    // portal status
    // validationErrors should contain(s"[99] is not valid value for column: $PortalStatus")
    // validationErrors should contain(s"[8] is not valid value for column: $PortalStatus")
    // validationErrors should contain(s"[UNKNOWN] is not valid value for column: $PortalStatus")

    // marital status
    validationErrors should contain(s"[A] is not valid value for column: $MaritalStatus")
    validationErrors should contain(s"[999] is not valid value for column: $MaritalStatus")
    validationErrors should contain(s"[UNKNOWN] is not valid value for column: $MaritalStatus")

    // education
    validationErrors should contain(s"[9] is not valid value for column: $Education")
    // values with string characters are dropped when read in as an Activity
    // validationErrors should contain(s"[y] is not valid value for column: $Education")
    // validationErrors should contain(s"[UNKNOWN] is not valid value for column: $Education")

    // cost
    // values with string characters are dropped when read in as an Activity
    // validationErrors should contain(s"[12$$345] is not valid value for column: $Cost")

    // activityDate
    validationErrors should contain(s"[null] is not valid value for column: $ActivityDate")
  }

  // Disabling email check to let invalid emails pass through
  ignore should "validate email values" in {
    import spark.sqlContext.implicits._

    val df = Seq(
      ("1", "1", Option("abc@xyz.com")),
      ("2", "2", Option("angelwind75@yahoo.com.")),
      ("3", "3", Option("Jessgerdi55@gmailcom")),
      ("4", "4", Option("n/a")),
      ("5", "5", Option("pages 8384@gmail.com")),
      ("6", "6", Option("mbmicham@comcast"))
    ).toDF(Source, SourceRecordId, Email)

    val validator = new BaldurInputValidator(df)

    val errorList = getErrorsArray(validator)

    assert(errorList contains s"[angelwind75@yahoo.com.] is not valid value for column: $Email")
    assert(errorList contains s"[Jessgerdi55@gmailcom] is not valid value for column: $Email")
    assert(errorList contains s"[n/a] is not valid value for column: $Email")
    assert(errorList contains s"[pages 8384@gmail.com] is not valid value for column: $Email")
    assert(errorList contains s"[mbmicham@comcast] is not valid value for column: $Email")
  }

  it should "validate phone values" in {
    import spark.sqlContext.implicits._

    val df = Seq(
      ("1", "1", "(123) 1234 123"),
      ("2", "2", "(xxx) 1234 123"),
      ("3", "3", "(123) 1234 12"),
      ("4", "4", "n/a"),
      ("5", "5", "+1-8303785826")
    ).toDF(Source, SourceRecordId, HomePhone)

    val validator = new BaldurInputValidator(df)

    df.withColumn(HomePhone, validator.validatePhone(HomePhone)(col(HomePhone))).collect()

    val errorList = getErrorsArray(validator)

    assert(errorList contains s"[(123) 1234 123] is not valid value for column: $HomePhone")
    assert(errorList contains s"[(xxx) 1234 123] is not valid value for column: $HomePhone")
    assert(errorList contains s"[n/a] is not valid value for column: $HomePhone")
    assert(errorList contains s"[+1-8303785826] is not valid value for column: $HomePhone")
  }

  it should "validate sourceAge values" in {
    import spark.sqlContext.implicits._

    val df = Seq(
      ("1", "1", "160"),
      ("2", "2", "-1")
    ).toDF(Source, SourceRecordId, SourceAge)

    val validator = new BaldurInputValidator(df)

    df.withColumn(SourceAge, validator.validateAge(SourceAge)(col(SourceAge))).collect()
    val errorList = getErrorsArray(validator)

    assert(errorList contains s"[160] is not valid value for column: $SourceAge")
    assert(errorList contains s"[-1] is not valid value for column: $SourceAge")
  }

  it should "validate IsoLanguageCode values" in {
    import spark.sqlContext.implicits._

    val df = Seq(
      ("1", "1", "hin"),
      ("2", "2", "nor"),
      ("3", "3", "eng"),
      ("4", "4", "0"),
      ("5", "5", "XX")
    ).toDF(Source, SourceRecordId, IsoLanguageCode)

    val validator = new BaldurInputValidator(df)
    df.withColumn(IsoLanguageCode, validator.validateIsoLanguageCode(IsoLanguageCode)(col(IsoLanguageCode))).collect()
    val errorList = getErrorsArray(validator)

    assert(errorList contains s"[0] is not valid value for column: $IsoLanguageCode")
    assert(errorList contains s"[XX] is not valid value for column: $IsoLanguageCode")
    assert(!(errorList contains s"[hin] is not valid value for column: $IsoLanguageCode"))
    assert(!(errorList contains s"[nor] is not valid value for column: $IsoLanguageCode"))
    assert(!(errorList contains s"[eng] is not valid value for column: $IsoLanguageCode"))
  }

  it should "validate state values" in {
    import spark.sqlContext.implicits._

    val df = Seq(
      ("1", "1", "XX"),
      ("2", "2", "AL")
    ).toDF(Source, SourceRecordId, State)

    val validator = new BaldurInputValidator(df)

    df.withColumn(State, validator.validateState(State)(col(State))).collect()
    val errorList = getErrorsArray(validator)

    assert(errorList contains s"[XX] is not valid value for column: $State")
  }

  it should "validate county values" in {
    import spark.sqlContext.implicits._

    val df = Seq(
      ("1", "1", "999"),
      ("2", "2", "100")
    ).toDF(Source, SourceRecordId, County)

    val validator = new BaldurInputValidator(df)

    df.withColumn(County, validator.validateCounty(County)(col(County))).collect()

    val errorList = getErrorsArray(validator)

    assert(errorList contains s"[999] is not valid value for column: $County")
    assert(errorList contains s"[100] is not valid value for column: $County")
  }

  it should "validate Zip4 values" in {
    import spark.sqlContext.implicits._

    val df = Seq(
      ("1", "1", "12345"),
      ("2", "2", "999"),
      ("3", "3", "n/a")
    ).toDF(Source, SourceRecordId, Zip4)

    val validator = new BaldurInputValidator(df)

    df.withColumn(Zip4, validator.validateZip4(Zip4)(col(Zip4))).collect()
    val errorList = getErrorsArray(validator)

    assert(errorList contains s"[12345] is not valid value for column: $Zip4")
    assert(errorList contains s"[999] is not valid value for column: $Zip4")
    assert(errorList contains s"[n/a] is not valid value for column: $Zip4")
  }

  it should "validate Zip5 values" in {
    import spark.sqlContext.implicits._

    val df = Seq(
      ("1", "1", "12$34"),
      ("2", "2", "9999"),
      ("3", "3", "123456")
    ).toDF(Source, SourceRecordId, Zip5)

    val validator = new BaldurInputValidator(df)

    df.withColumn(Zip5, validator.validateZip5(Zip5)(col(Zip5))).collect()
    val errorList = getErrorsArray(validator)

    assert(errorList contains s"[12$$34] is not valid value for column: $Zip5")
    assert(errorList contains s"[9999] is not valid value for column: $Zip5")
    assert(errorList contains s"[123456] is not valid value for column: $Zip5")
  }

  it should "validate payer type" in {
    import spark.sqlContext.implicits._

    val df = Seq(
      ("1", "1", "AA"),
      ("2", "2", "XX"),
      ("3", "3", "UNKNOWN")
    ).toDF(Source, SourceRecordId, PayerType)

    val validator = new BaldurInputValidator(df)

    df.withColumn("payer_type", validator.validatePayerType(PayerType)(col(PayerType))).collect()
    val errorList = getErrorsArray(validator)

    assert(errorList contains s"[AA] is not valid value for column: $PayerType")
    assert(errorList contains s"[XX] is not valid value for column: $PayerType")
    assert(errorList contains s"[UNKNOWN] is not valid value for column: $PayerType")
  }

  it should "validate occupation values" in {
    import spark.sqlContext.implicits._

    val df = Seq(
      ("1", "1", "999"),
      ("2", "2", "55")
    ).toDF(Source, SourceRecordId, Occupation)

    val validator = new BaldurInputValidator(df)

    df.withColumn(Occupation, validator.validateOccupation(Occupation)(col(Occupation))).collect()
    val errorList = getErrorsArray(validator)

    assert(errorList contains s"[999] is not valid value for column: $Occupation")
    assert(errorList contains s"[55] is not valid value for column: $Occupation")
  }

  it should "validate occupation group values" in {
    import spark.sqlContext.implicits._

    val df = Seq(
      ("1", "1", "XX"),
      ("2", "2", "UNKNOWN")
    ).toDF(Source, SourceRecordId, OccupationGroup)

    val validator = new BaldurInputValidator(df)

    df.withColumn(OccupationGroup, validator.validateOccupationGroup(OccupationGroup)(col(OccupationGroup))).collect()

    val errorList = getErrorsArray(validator)

    assert(errorList contains s"[XX] is not valid value for column: $OccupationGroup")
    assert(errorList contains s"[UNKNOWN] is not valid value for column: $OccupationGroup")
  }

  it should "validate beehive cluster values" in {
    import spark.sqlContext.implicits._

    val df = Seq(
      ("1", "1", "20"),
      ("2", "2", "25")
    ).toDF(Source, SourceRecordId, BeehiveCluster)

    val validator = new BaldurInputValidator(df)

    df.withColumn(BeehiveCluster, validator.validateBeehiveCluster(BeehiveCluster)(col(BeehiveCluster))).collect()

    val errorList = getErrorsArray(validator)

    assert(errorList contains s"[20] is not valid value for column: $BeehiveCluster")
    assert(errorList contains s"[25] is not valid value for column: $BeehiveCluster")
  }

  it should "validate wealth rating values" in {
    import spark.sqlContext.implicits._

    val df = Seq(
      ("1", "1", "-1"),
      ("2", "2", "10"),
      ("3", "3", "9")
    ).toDF(Source, SourceRecordId, WealthRating)

    val validator = new BaldurInputValidator(df)

    df.withColumn(WealthRating, validator.validateWealthRating(WealthRating)(col(WealthRating))).collect()

    val errorList = getErrorsArray(validator)

    assert(errorList contains s"[-1] is not valid value for column: $WealthRating")
    assert(errorList contains s"[10] is not valid value for column: $WealthRating")
  }

  it should "validate race values" in {
    import spark.sqlContext.implicits._

    val df = Seq(
      ("1", "1", "X"),
      ("2", "2", "UNKNOWN")
    ).toDF(Source, SourceRecordId, Race)

    val validator = new BaldurInputValidator(df)

    df.withColumn(Race, validator.validateRace(Race)(col(Race))).collect()

    val errorList = getErrorsArray(validator)

    assert(errorList contains s"[X] is not valid value for column: $Race")
    assert(errorList contains s"[UNKNOWN] is not valid value for column: $Race")
  }

  it should "validate religion values" in {
    import spark.sqlContext.implicits._

    val df = Seq(
      ("1", "1", "A"),
      ("2", "2", "UNKNOWN")
    ).toDF(Source, SourceRecordId, Religion)

    val validator = new BaldurInputValidator(df)

    df.withColumn(Religion, validator.validateReligion(Religion)(col(Religion))).collect()

    val errorList = getErrorsArray(validator)

    assert(errorList contains s"[A] is not valid value for column: $Religion")
    assert(errorList contains s"[UNKNOWN] is not valid value for column: $Religion")
  }

  it should "validate financial class values" in {
    import spark.sqlContext.implicits._

    val df = Seq(
      ("1", "1", "99999"),
      ("2", "2", "1234")
    ).toDF(Source, SourceRecordId, FinancialClass)

    val validator = new BaldurInputValidator(df)

    df.withColumn(FinancialClass, validator.validateFinancialClass(FinancialClass)(col(FinancialClass))).collect()

    val errorList = getErrorsArray(validator)

    assert(errorList contains s"[99999] is not valid value for column: $FinancialClass")
    assert(errorList contains s"[1234] is not valid value for column: $FinancialClass")
  }

  it should "validate combined owner values" in {
    import spark.sqlContext.implicits._

    val df = Seq(
      ("1", "1", "1"),
      ("2", "2", "X"),
      ("3", "3", "UNKNOWN")
    ).toDF(Source, SourceRecordId, CombinedOwner)

    val validator = new BaldurInputValidator(df)

    df.withColumn(CombinedOwner, validator.validateCombinedOwner(CombinedOwner)(col(CombinedOwner))).collect()

    val errorList = getErrorsArray(validator)

    assert(errorList contains s"[1] is not valid value for column: $CombinedOwner")
    assert(errorList contains s"[X] is not valid value for column: $CombinedOwner")
    assert(errorList contains s"[UNKNOWN] is not valid value for column: $CombinedOwner")
  }

  it should "validate dwell type values" in {
    import spark.sqlContext.implicits._

    val df = Seq(
      ("1", "1", "9"),
      ("2", "2", "X"),
      ("3", "3", "UNKNOWN")
    ).toDF(Source, SourceRecordId, DwellType)

    val validator = new BaldurInputValidator(df)

    df.withColumn(DwellType, validator.validateDwellType(DwellType)(col(DwellType))).collect()

    val errorList = getErrorsArray(validator)

    assert(errorList contains s"[9] is not valid value for column: $DwellType")
    assert(errorList contains s"[X] is not valid value for column: $DwellType")
    assert(errorList contains s"[UNKNOWN] is not valid value for column: $DwellType")
  }

  // TODO
  ignore should "validate portal status values" in {
    import spark.sqlContext.implicits._

    val df = Seq(
      ("1", "1", "99"),
      ("2", "2", "8"),
      ("3", "3", "UNKNOWN")
    ).toDF(Source, SourceRecordId, PortalStatus)

    val validator = new BaldurInputValidator(df)

    df.withColumn(PortalStatus, validator.validatePortalStatus(PortalStatus)(col(PortalStatus))).collect()

    val errorList = getErrorsArray(validator)

    assert(errorList contains s"[99] is not valid value for column: $PortalStatus")
    assert(errorList contains s"[8] is not valid value for column: $PortalStatus")
    assert(errorList contains s"[UNKNOWN] is not valid value for column: $PortalStatus")
  }

  it should "validate marital status values" in {
    import spark.sqlContext.implicits._

    val df = Seq(
      ("1", "1", "A"),
      ("2", "2", "999"),
      ("3", "3", "UNKNOWN")
    ).toDF(Source, SourceRecordId, MaritalStatus)

    val validator = new BaldurInputValidator(df)

    df.withColumn(MaritalStatus, validator.validateMaritalStatus(MaritalStatus)(col(MaritalStatus))).collect()

    val errorList = getErrorsArray(validator)

    assert(errorList contains s"[A] is not valid value for column: $MaritalStatus")
    assert(errorList contains s"[999] is not valid value for column: $MaritalStatus")
    assert(errorList contains s"[UNKNOWN] is not valid value for column: $MaritalStatus")
  }

  it should "validate education values" in {
    import spark.sqlContext.implicits._

    val df = Seq(
      ("1", "1", "9"),
      ("2", "2", "Y"),
      ("3", "3", "UNKNOWN")
    ).toDF(Source, SourceRecordId, Education)

    val validator = new BaldurInputValidator(df)

    df.withColumn(Education, validator.validateEducation(Education)(col(Education))).collect()
    val errorList = getErrorsArray(validator)

    assert(errorList contains s"[9] is not valid value for column: $Education")
    assert(errorList contains s"[Y] is not valid value for column: $Education")
    assert(errorList contains s"[UNKNOWN] is not valid value for column: $Education")
  }

  it should "validate sourcePatientType values" in {
    import spark.sqlContext.implicits._

    val df = Seq(
      ("1", "1", "INPATIENT"),
      ("2", "2", "OUTPATIENT"),
      ("3", "3", "K"),
      ("4", "4", "UNKNOWN"),
      ("5", "5", "")
    ).toDF(Source, SourceRecordId, SourcePatientType)

    val validator = new BaldurInputValidator(df)

    df.withColumn(SourcePatientType, validator.validateSourcePatientType(
      SourcePatientType)(col(SourcePatientType))).collect()
    val errorList = getErrorsArray(validator)

    assert(errorList contains s"[K] is not valid value for column: $SourcePatientType")
    assert(errorList contains s"[UNKNOWN] is not valid value for column: $SourcePatientType")
    assert(!(errorList contains s"[INPATIENT] is not valid value for column: $SourcePatientType"))
  }

}
