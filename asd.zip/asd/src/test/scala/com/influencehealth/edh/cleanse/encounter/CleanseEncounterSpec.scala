package com.influencehealth.edh.cleanse.encounter


import com.influencehealth.edh.dao._
import com.influencehealth.edh.model.schema.EncounterSchema
import com.influencehealth.edh.test.spark.SparkSpecBase
import com.influencehealth.edh.{AppCleanser, Constants}
import org.apache.spark.sql.{DataFrame, Row}
import org.scalamock.scalatest.MockFactory
import org.scalatest.{BeforeAndAfter, FlatSpec, Ignore, Matchers}

@Ignore
class CleanseEncounterSpec extends FlatSpec with SparkSpecBase with BeforeAndAfter with Matchers with MockFactory {

  val InputDirectoryPath: String = "fixtures/cleanse/encounter/chomp/"
  val DateBatchReceived: String = "11/01/2017"
  val Customer: String = "chomp"
  val BatchId = "chomp-encounter-influencehealth-2017-11"

  it should "cleanse encounter file" in {

    import spark.implicits._
    // FileReader.readFilesFromS3(spark, InputDirectoryPath, null, Constants.EncounterActivityType, null, false)

    val rawData = Map(
      GuarantorFile -> spark.createDataFrame(spark.sparkContext.parallelize(Seq(
        Row("29006061", "100000", "EDMONDSON", "JAELYNN", null, null, null, null, null, "GA", "30116-5443", null),
        Row("29006062", "100000", "JOHN", "HOLMS", null, null, null, null, null, "NY", "30116-5443", null),
        Row("29006065", "100000", "JOHN", "HOLMS", null, null, null, null, null, "NY", "30116-5443", null),
        Row("29006063", "200000", "JOHN", "MAYOR", null, null, null, null, null, "NY", "30116-5443", null),
        Row("29006066", "300000", "NORAH", "JONES", null, null, null, null, null, "NY", "30116-5443", null),
        Row("29006068", "300000", "NORAH", "JONES", null, null, null, null, null, "NY", "30116-5443", null),
        Row("29006069", "300000", "NORAH", "JONES", null, null, null, null, null, "NY", "30116-5443", null),
        Row("29006070", "700000", "NULL", "NULL", "NULL", "DUNCAN,RICHARD ALLEN", "350 W CLUB DR", "NULL", "CARROLLTON", "GA", "30117", "US"),
        Row("29006067", "600000", "NULL", "NULL", "NULL", "DUNCAN,RICHARD ALLEN", "350 W CLUB DR", "NULL", "CARROLLTON", "GA", "30116-5443", "US"),
        Row("29006065", "500000", "NORAH", "JONES", null, null, null, null, null, "UK", "30116-5443", null)
      )), EncounterSchema.guarantorSchema),

      PrognosisFile ->
        spark.createDataFrame(spark.sparkContext.parallelize(Seq(
          // Row("PATIENT_ID", "DIAG_ID", "SEQUENCE_NO", "MX_VERSION", "MX_CODE")
          Row("100000", "29006061", "2", "9", "74833"),
          Row("200000", "29006063", "3", "9", "87463"),
          Row("300000", "29006066", "2", "10", "17493"),
          Row("600000", "29006067", "3", "9", "16792"),
          Row("200000", "29006063", "2", "10", null),
          Row("300000", "29006068", "3", "9", "74528"),
          Row("100000", "29006065", "2", "10", "74829"),
          Row("300000", "29006066", "3", "9", "84639"),
          Row("700000", "29006070", "2", "10", "83528"),
          Row("300000", "29006069", "3", "9", "36290")
        )), EncounterSchema.prognosisSchema),
      CurrentProceduralTerminologyFile ->
        spark.createDataFrame(spark.sparkContext.parallelize(Seq(
          // Row("Medical Record", "Patient Number", "Sequence Number", "MX_VERSION", "MX_CODE")
          Row("100000", "29006061", "2", "C", "77057"),
          Row("300000", "29006064", "1", "H", "94629"),
          Row("100000", "29006062", "2", "C", "42729"),
          Row("300000", "29006066", "1", "H", "37382"),
          Row("100000", "29006065", "2", null, "47293"),
          Row("600000", "29006062", "1", "H", "93748"),
          Row("100000", "29006061", "2", "C", "29642"),
          Row("700000", "29006062", "1", "H", "80274"),
          Row("100000", "29006065", "2", "C", "47307"),
          Row("300000", "29006069", "1", "H", null),
          Row("300000", "29006069", "1", "C", "93279")
        )), EncounterSchema.currentProceduralTerminologySchema),
      VisitFile ->
        spark.createDataFrame(spark.sparkContext.parallelize(Seq(
          Row("HOS", "OPTIMUM", "100000", "29006061", "12/01/2015", "12/31/2015", "01/04/2016", "30", "01", "O", "E", "999", "F", "MANAGED CARE", "KPHM", "KAISER PPO/HMO", "0", "91413", null, "1"),
          Row("HOS", "EPIC", "100000", "29006062", "12/01/2015", "12/31/2015", "01/04/2016", "30", "01", "O", "E", "999", "F", "MANAGED CARE", "KPHM", "KAISER PPO/HMO", "0", "91413", null, "2"),
          Row("HOS", "OPTIMUM", "100000", "29006065", "12/02/2015", "12/30/2015", "01/07/2017", "30", "01", "O", "E", "888", "F", "MANAGED CARE100", "KPHM", "PHM", "0", "91413", null, "1"),
          Row("HOS", "ALLSCRIPTS", "200000", "29006063", "12/02/2015", "12/30/2015", "01/07/2017", "30", "01", "I", "N", "888", "F", "MANAGED CARE100", "KPHM", "PHM", "0", "91413", null, "3"),
          Row("HOS", "CERNER", "300000", "29006064", "12/02/2015", "12/30/2015", "01/07/2017", "30", "01", "I", "N", "888", "F", "MEDICARE", "KPHM", "PHM", "0", "91413", null, "1"),
          Row("HOS", "NEXTGEN", "300000", "29006066", "12/02/2015", "12/30/2015", "01/07/2017", "30", "01", "I", "N", "888", "F", "MEDICARE", "KPHM", "PHM", "0", "91413", null, "1"),
          Row("HOS", "CERNER", "300000", "29006068", "12/02/2015", "12/30/2015", "01/07/2017", "30", "01", null, "N", "888", "F", "MEDICARE", "KPHM", "PHM", "0", "91413", null, "1"),
          Row("HOS", "OPTIMUM", "300000", "29006069", "12/02/2015", "12/30/2015", "01/07/2017", "30", "01", "K", "N", "888", "F", "MEDICARE", "KPHM", "PHM", "0", "91413", null, "1"),
          Row("HOS", "OPTIMUM", "600000", "29006067", "12/02/2015", "12/30/2015", "01/07/2017", "30", "01", "O", "N", "888", "F", "MEDICAID", "KPHM", "PHM", "0", "91413", null, "3"),
          Row("HOS", "NEXTGEN", "700000", "29006070", "12/02/2015", "12/30/2015", "01/07/2017", "30", "01", "O", "N", "888", "F", "SELF", "KPHM", "PHM", "0", "91413", null, "4")
        )), EncounterSchema.visitSchema),
      BiometricFile -> spark.createDataFrame(spark.sparkContext.parallelize(Seq(
        // Row("VISIT_ID", "PATIENT_ID", "SYSTOLIC", "DIASTOLIC", "HEIGHT", "WEIGHT", "BMI")
        Row("29006061", "100000", null, null, "0", "0", null),
        Row("29006062", "100000", null, null, "0", "0", null),
        Row("29006063", "200000", null, null, "0", "0", null),
        Row("29006064", "300000", null, null, "0", "0", null),
        Row("29006065", "100000", null, null, "0", "0", null)
      )), EncounterSchema.biometricSchema),
      FinancialFile -> spark.createDataFrame(spark.sparkContext.parallelize(Seq(
        // Row("VISIT_ID", "PATIENT_ID", "TOTAL_CHARGES", "TOTAL_COST", "NET_REVENUE", "CONTRIBUTION_MARGIN", "PROFIT")
        Row("29006061", "100000", "790", null, null, null, null),
        Row("29006062", "200000", "1190", null, null, null, null),
        Row("29006063", "200000", "79232", null, null, null, null),
        Row("29006064", "300000", "9240", null, null, null, null),
        Row("29006065", "100000", "452", null, null, null, null)
      )), EncounterSchema.financialSchema),
      DemographicFile -> spark.createDataFrame(spark.sparkContext.parallelize(Seq(
        // Row("PATIENT_ID", "LAST_NAME", "FIRST_NAME", "MIDDLE_NAME", "PREFIX", "PERSONAL SUFFIX", "PROFESSIONAL SUFFIX", "ADDRESS1", "ADDRESS2", "CITY", "STATE", "ZIP", "COUNTRY", "SEX", "DOB", "DOD", "EXCLUSION_FLAG", "HOME_PHONE", "MOBILE_PHONE", "WORK_PHONE", "EMAIL", "MARITAL_STATUS", "RACE", "EMPLOYER", "PORTAL_STATUS")
        Row("100000", "Elsol", "Miguel", null, null, null, null, "15  Ave.", null, "Cuyahoga Falls", "CA", "30656", "US", "F", "04/24/1978", null, null, "7065491067", null, null, null, "W", "B", null, null),
        Row("200000", "MonteNegro", "Patricia", null, null, null, null, "70  Road", null, "Far Rockaway", "MN", "30866", "US", "F", "04/24/1968", "09/24/2016", null, "7065491067", null, null, null, "W", "B", null, null),
        Row("300000", "Lucas", "George", null, null, null, null, "9919  Street ", null, "San Lorenzo", "NY", "38366", "US", "F", "04/24/1958", "09/24/2016", null, "7065491067", null, null, null, "W", "B", null, null),
        Row("400000", "Burton", "Tim", null, null, null, null, "739  Ave.", null, "Dothan", "AL", "92866", "US", "F", "04/24/1988", "09/24/2016", null, "7065491067", null, null, null, "W", "B", null, null),
        Row("500000", "DeGeneres", "Ellen", null, null, null, null, "80  Lane", null, "Marshfield", "UK", "38266", "US", "F", "04/24/1998", "09/24/2016", null, "7065491067", null, null, null, "W", "B", null, null),
        Row("600000", "Hathaway", "Anne", null, null, null, null, "905 El  St.", null, "Henrico", "VA", "23228", "US", "F", "04/24/2008", "09/24/2016", null, "7065491067", null, null, null, "W", "B", null, null),
        Row("700000", "Anniston", "Jennifer", null, null, null, null, "ELD  PLACE", null, "SANDY SPRINGS", "GA", "30866", "US", "F", "04/24/1969", "09/24/2016", null, "7065491067", null, null, null, "W", "B", null, null)
      )), EncounterSchema.demographicSchema),
      PhysicianFile -> spark.createDataFrame(spark.sparkContext.parallelize(Seq(
        // Row("PHYSICIAN_ID", "PHYSICIAN_NPI", "LAST_NAME", "FIRST_NAME", "MIDDLE_NAME", "FULL_NAME", "PERSONAL_SUFFIX", "PROFESSIONAL_SUFFIX", "PRIMARY_SPECIALTY_CODE", "PRIMARY_SPECIALTY_DESC")
        Row("1", null, "VUITTON", "LOUIS", "G", "LOUIS, VUITTON", null, null, "GS", "GENERAL SURGERY"),
        Row("2", null, "KORS", "MICHEAL", "G", "MICHEAL, KORS", null, null, "CAR", "CARDIOLOGY"),
        Row("3", null, "VERSACHE", "DONATELLA", "G", null, null, null, "GAS", "GASTRONOMY"),
        Row("4", null, "SPADE", "KATE", "G", "SPADE, KATE AG", null, null, "ORTHO", "ORTHOPEDICS"))), EncounterSchema.physicianSchema),
      DiagnosisFile ->
        // Row("PATIENT_ID", "DIAG_ID", "SEQUENCE_NO", "MX_VERSION", "MX_CODE")
        spark.createDataFrame(spark.sparkContext.parallelize(Seq(
          Row("200000", "29006063", "2", "10", "34839"),
          Row("100000", "29006062", "2", "10", "43319"),
          Row("300000", "29006068", "3", "9", "98763"),
          Row("200000", "29006063", "3", "9", "74858"),
          Row("100000", "29006061", "2", "10", "82734"),
          Row("300000", "29006069", "2", "10", "37892"),
          Row("300000", "29006069", "3", "9", null),
          Row("600000", "29006067", "3", "9", "63829"),
          Row("700000", "29006070", "2", "10", "92834"),
          Row("300000", "29006064", "3", null, "90742")
        )), EncounterSchema.diagnosisSchema),

      FacilityFile ->
        //     Row( "PATIENT_ID" , "VISIT_ID" , "HOSPITAL_ID" , "HOSPITAL_DESC" , "BUSINESS_UNIT" , "BUSINESS_UNIT_DESC" , "SITE_ID" , "SITE_DESC" , "CLINIC_ID" , "CLINIC_DESC" , "PRACTICE_LOCATION_ID" , "PRACTICE_LOCATION_DESC" )
        // TODO: Had to change HOSPITAL_ID from "01" to "chomp". Abstract out the retrieving of location data so this is no longer a problem
        spark.createDataFrame(spark.sparkContext.parallelize(Seq(
          Row("100000", "29006061", "chomp", "Athens Regional Medical Center", "1457", "GUMUCIO, CESAR A", null, null, null, null, null, null),
          Row("200000", "29006063", "chomp", "North Well", "1457", "SOUTH, ATLANTA A", null, null, null, null, null, null),
          Row("300000", "29006069", "chomp", "Athens Regional Medical Center", "1457", "GUMUCIO, CESAR A", null, null, null, null, null, null),
          Row("600000", "29006067", "chomp", "North Well", "1457", "SOUTH, ATLANTA A", null, null, null, null, null, null),
          Row("700000", "29006070", "chomp", "Athens Regional Medical Center", "1457", "GUMUCIO, CESAR A", null, null, null, null, null, null),
          Row("100000", "29006062", "chomp", "Athens Regional Medical Center", "1457", "GUMUCIO, CESAR A", null, null, null, null, null, null),
          Row("300000", "29006068", "chomp", "Athens Regional Medical Center", "1457", "GUMUCIO, CESAR A", null, null, null, null, null, null),
          Row("300000", "29006066", "chomp", "North Well", "1457", "SOUTH, ATLANTA A", null, null, null, null, null, null)
        )), EncounterSchema.facilitySchema)
    )

    val mockFileSystemDao = mock[FileSystemDao]

    (mockFileSystemDao.readEncounterFiles _).expects(false, Seq(InputDirectoryPath)).returns(rawData)

    val (cleansedDataFrame: DataFrame, dirtyDataFrame: DataFrame) = AppCleanser.cleanseData(
      Some(Customer), Constants.EncounterActivityType, BatchId, false, InputDirectoryPath,
      Constants.EncounterInfluenceHealthFormat, DateBatchReceived, mockFileSystemDao
    )

    cleansedDataFrame.count() shouldBe 8

    val row = cleansedDataFrame.where($"sourceRecordId" === "29006062")
    val firstNames = row.select("firstName").collectAsList()
    firstNames.get(0).getString(0) shouldBe "Miguel"
    val lastNames = row.select("lastName").collectAsList()
    lastNames.get(0).getString(0) shouldBe "Elsol"
    val guarantorZip5 = row.select("guarantorZip5").collectAsList()
    assert(guarantorZip5.get(0).getString(0).equals("30116"))
    val sourcePatientType = cleansedDataFrame.select("sourcePatientType").collectAsList()
    assert(sourcePatientType.get(0).getString(0).equals("OUTPATIENT")) // when input value is O
    assert(sourcePatientType.get(1).getString(0).equals("INPATIENT"))  // when input value is I
    assert(sourcePatientType.get(2).getString(0).equals("OUTPATIENT")) // when input value is null
    assert(sourcePatientType.get(3).getString(0).equals("OUTPATIENT")) // when input value is K that is other than I & O

    val locationCode = row.select("locationCode").collectAsList()
    assert(locationCode.get(0).getString(0).equals("670"))
    val sourceLocationDesc = row.select("sourceLocationDesc").collectAsList()
    assert(sourceLocationDesc.get(0).getString(0).equals("Athens Regional Medical Center"))

    row.select("diagnosisCodes").collectAsList()
    row.select("procedureCodes").collectAsList()
    row.select("currentProceduralTerminologyCodes").collectAsList()

    dirtyDataFrame.count() shouldBe 4

    val data = dirtyDataFrame.select("errors").collectAsList()

    data.get(0).getList[String](0) should contain allOf("Hospital/Clinic (Ids & Desc) are missing", "Input HOSPITAL_ID is not matching with customer hospital locations")

    data.get(2).getList[String](0) should contain allOf(
      "sourceType is null",
      "source is null",
      "sourceRecordId is null",
      "medical codes(cp/dx) are missing",
      "Hospital/Clinic (Ids & Desc) are missing",
      // TODO: Decide on how to populate this value - "Input State value is not matching with defined state values",
      "Input HOSPITAL_ID is not matching with customer hospital locations")
  }


  //  it should "intake and join all the files" in {
  //    import spark.implicits._
  //    // Intake Utilization files
  //    incomingEncounterRawRecordsDf.count() shouldBe 12
  //    val data = incomingEncounterRawRecordsDf.
  //      where($"sourceRecordId" === "29006061" || $"sourceRecordId" === "29006062").select()
  //    data.count() shouldBe 2
  //
  //    val dxCodeData = incomingEncounterRawRecordsDf.
  //      where($"sourceRecordId" === "29006061").
  //      select("diagnosisCodes").collectAsList()
  //    dxCodeData.get(0).getAs[List[Row]]("diagnosisCodes").size shouldBe 1
  //    val pxCodeData = data.select("procedureCodes").collectAsList()
  //    pxCodeData.get(0).getAs[List[Row]]("procedureCodes").size shouldBe 1
  //    pxCodeData.get(0).getAs[List[Row]]("procedureCodes").head.getAs[String]("medicalCode") shouldBe "74833"
  //    pxCodeData.get(0).getAs[List[Row]]("procedureCodes").head.getAs[String]("medicalCodeType") shouldBe "9"
  //    pxCodeData.get(0).getAs[List[Row]]("procedureCodes").head.getAs[Int]("sequenceNumber") shouldBe 2
  //    val cptCodeData = data.select("currentProceduralTerminologyCodes").collectAsList()
  //    cptCodeData.get(0).getAs[List[Row]]("currentProceduralTerminologyCodes").size shouldBe 2
  //  }

}