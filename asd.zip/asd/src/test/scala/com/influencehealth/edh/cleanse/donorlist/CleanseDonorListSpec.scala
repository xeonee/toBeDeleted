package com.influencehealth.edh.cleanse.donorlist

import com.influencehealth.edh.dao.FileSystemDao
import com.influencehealth.edh.model.schema.DonorListSchema
import com.influencehealth.edh.test.spark.SparkSpecBase
import com.influencehealth.edh.{AppCleanser, Constants}
import org.apache.spark.sql.{DataFrame, Row}
import org.scalamock.scalatest.MockFactory
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}

class CleanseDonorListSpec extends FlatSpec with SparkSpecBase with BeforeAndAfter with Matchers with MockFactory {

  val InputDirectoryPath: String = "fixtures/cleanse/donorlist/"
  val DateBatchReceived: String = "11/01/2017"
  val Customer: String = "chomp"
  val BatchId = "chomp-donorlist-influencehealth-2017-11"

  var incomingDonorListRawRecordsDf: DataFrame = _
  var cleansedDataFrame: DataFrame = _
  var dirtyDataFrame: DataFrame = _

  it should "cleanse donor data" in {

    val rawData = spark.createDataFrame(spark.sparkContext.parallelize(Seq(
        Row( "Foundation" , "Advance" , "207508" , "Ms." , "James" , "Louisa" , " " , " " , " " , "Business" , "Last" , "Institute of Int'l Relations" , "123 Buren Street" , "Monterey" , "CA" , "93940" , "F" , "7/30/1988" ,null,null),
        Row( "Foundation" ,null, "30484" , "Mr." , "Steven" , "Robert" , "W." , " " , " " , "Home" , "Good" , "Post Office Box 1234" , " " , "Carmel" , "CA" , "93921" , "M" , "7/30/1926" , "123-456-3131" ,null)
    )), DonorListSchema.donorlistSchema)

    val mockFileSystemDao = mock[FileSystemDao]

    (mockFileSystemDao.readDonorListFile _).expects(false, Seq(InputDirectoryPath)).returns(rawData)

    val (cleansedDataFrame: DataFrame, dirtyDataFrame: DataFrame) = AppCleanser.cleanseData(
      Some(Customer), Constants.DonorListActivityType, BatchId, false, InputDirectoryPath,
      Constants.DonorListInfluenceHealthFormat, DateBatchReceived, mockFileSystemDao
    )

    cleansedDataFrame.count() shouldBe 1
    val data = cleansedDataFrame.select("addressType").collectAsList()
    data.get(0).getString(0) shouldBe "Business"
    val firstNames = cleansedDataFrame.select("firstName").collectAsList()
    firstNames.get(0).getString(0) shouldBe "Louisa"
    val lastNames = cleansedDataFrame.select("lastName").collectAsList()
    lastNames.get(0).getString(0) shouldBe "James"
    val dateOfBirth = cleansedDataFrame.select("dateOfBirth").collectAsList()
    dateOfBirth.get(0).getDate(0).toString shouldBe "1988-07-30"

    dirtyDataFrame.count() shouldBe 1
    dirtyDataFrame.select("addressType").collectAsList().get(0).getString(0) shouldBe "Home"
    val dirtyData = dirtyDataFrame.select("source").collectAsList()
    dirtyData.get(0).getString(0) shouldBe null
  }

}