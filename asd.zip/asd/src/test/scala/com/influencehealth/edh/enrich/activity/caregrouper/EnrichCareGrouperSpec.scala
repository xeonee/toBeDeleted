package com.influencehealth.edh.enrich.activity.caregrouper

import java.sql.{Date, Timestamp}

import com.influencehealth.edh.enrich.activity.caregrouper.CareGrouperGenerator.getIndividualCodes
import com.influencehealth.edh.model.{Activity, ActivityMedicalCode, AssessmentResults, Coordinates}
import com.influencehealth.edh.test.spark.SparkSpecBase
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.functions._
import org.scalatest.{FlatSpec, Matchers}

class EnrichCareGrouperSpec extends FlatSpec with SparkSpecBase with Matchers {
  it should "extract ICD codes for the input diagnosisCodes " in {
    import spark.implicits._
    val activities: Dataset[Activity] = spark.sparkContext.parallelize(
      Seq(
        Activity(
          customer = "tanner",
          activityId = "activity1",
          personId = Some("person1"),
          batchId = "batch1",
          sourceRecordId = None,
          sourcePersonId = None,
          dateCreated = new Timestamp(System.currentTimeMillis()),
          activityDate = new Date(System.currentTimeMillis()),
          diagnosisCodes = Seq(ActivityMedicalCode(
            medicalCode = "diagnosis 1",
            medicalCodeType = "10",
            sequenceNumber = 0
          )),
          procedureCodes = Seq(ActivityMedicalCode(
            medicalCode = "diagnosis 1",
            medicalCodeType = "10",
            sequenceNumber = 1
          )),
          currentProceduralTerminologyCodes = Seq(ActivityMedicalCode(
            medicalCode = "diagnosis 1",
            medicalCodeType = "10",
            sequenceNumber = 1
          )),
          assessmentResults = Seq(AssessmentResults(
            variable = "value",
            value = "variable"
          )),
          profit = Some(new java.math.BigDecimal("2073.00"))
        ),
        Activity(
          customer = "tanner",
          activityId = "activity2",
          personId = Some("person1"),
          batchId = "batch1",
          sourceRecordId = None,
          sourcePersonId = None,
          dateCreated = new Timestamp(System.currentTimeMillis()),
          activityDate = new Date(System.currentTimeMillis()),
          profit = Some(new java.math.BigDecimal("2073.00")),
          addressCoordinates = Some(Coordinates(lat = 38.8951f, lon = -77.0364f))
        )
      )
    ).toDS()

    val updatedActivities = activities
      .withColumn("diag1",getIndividualCodes(0)(col("diagnosisCodes")))
      .withColumn("diag2", getIndividualCodes(1)(col("diagnosisCodes")))

    val diag1List = updatedActivities.select("diag1").collectAsList()
    diag1List.get(0).getString(0) shouldBe "diagnosis 1"
    diag1List.get(1).getString(0) shouldBe null

    val diag2List = updatedActivities.select("diag2").collectAsList()
    diag2List.get(0).getString(0) shouldBe null
    diag2List.get(1).getString(0) shouldBe null

  }
}

