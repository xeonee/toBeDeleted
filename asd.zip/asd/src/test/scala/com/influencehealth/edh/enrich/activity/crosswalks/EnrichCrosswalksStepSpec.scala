package com.influencehealth.edh.enrich.activity.crosswalks

import java.sql.{Date, Timestamp}
import java.time.{LocalDate, LocalDateTime}
import java.util.UUID

import com.influencehealth.edh.Constants
import com.influencehealth.edh.config.EnrichJobConfig
import com.influencehealth.edh.dataframe.columns._
import com.influencehealth.edh.enrich.person.location.EnrichLocationsTestData
import com.influencehealth.edh.model.Activity
import com.influencehealth.edh.test.spark.SparkSpecBase
import org.scalatest.{FlatSpec, Matchers}

class EnrichCrosswalksStepSpec extends FlatSpec with Matchers with SparkSpecBase {
  
  implicit val enrichJobConfig: EnrichJobConfig = new EnrichJobConfig(
    jobType = "",
    subJobType = "",
    customer = "testcustomer",
    customerId = 12,
    customerPafName = None,
    customerLocations = EnrichLocationsTestData.locations,
    customerServiceAreas = Set.empty,
    activityType = None,
    batchId = None,
    batchFormat = "",
    bucketUrl = "",
    allOrApplicable = "applicable",
    executorCores = 10,
    inputFilePath = None,
    failOnError = true,
    databaseConfig = None,
    anchorConfig = None,
    sg2Config = None,
    user = "testuser",
    profile = "",
    environment = "",
    fullRefresh = false
  )

  val personId: String = UUID.randomUUID().toString

  it should "Correctly set inferredPayerType from payerType for Prospects And should set proper location name for " +
    "input location code" in {

    import spark.implicits._

    val activities = spark.createDataset[Activity](Seq(
      Activity(
        customer = "testcustomer",
        activityId = "",
        batchId = "",
        dateCreated = Timestamp.valueOf(LocalDateTime.now()),
        activityDate = Date.valueOf(LocalDate.now()),
        personId = Some("personId"),
        financialClass = None,
        payerType = Some("NI"),
        lastName = Some("cam"),
        maritalStatus = Some(Constants.MaritalStatusMarried),
        occupation = Some("08"),
        householdIncome = Some("A"),
        education = Some(Constants.EducationBachelorDegree),
        sourceAge = Some(25),
        isChildPresent = Some(true),
        locationCode = Some("601")
      )
    ))

    val enrichCrosswalksStep = new EnrichCrosswalksStep("EnrichCrossWalksUnitTest", None)(enrichJobConfig, spark)

    val enrichActivities = enrichCrosswalksStep.process(activities)

    enrichActivities.select(InferredPayerType).first.getString(0) shouldBe Constants.PayerTypeNotProfitableInferred
    enrichActivities.select(LocationDesc).first.getString(0) shouldBe "locationName2"
  }

  ignore should "correctly set inferredPayerType for Prospects And should set proper location name for " +
    "input location code" in {

    import spark.implicits._

    val activities = spark.createDataset(Seq(
      Activity(
        customer = "testcustomer",
        personId = Some("ca2c8fe9-acc7-4ac6-ab2b-6787a83029a8"),
        activityId = "",
        batchId = "",
        dateCreated = Timestamp.valueOf(LocalDateTime.now()),
        activityDate = Date.valueOf(LocalDate.now()),
        payerType = Some("PI"),
        lastName = Some("TEST"),
        maritalStatus = Some(Constants.MaritalStatusSingle),
        occupation = Some("08"),
        householdIncome = Some("A"),
        education = Some(Constants.EducationBachelorDegree),
        sourceAge = Some(50),
        isChildPresent = Some(true),
        locationCode = Some("600")
      )
    ))

    val enrichCrosswalksStep = new EnrichCrosswalksStep("EnrichCrossWalksUnitTest", None)(enrichJobConfig, spark)

    val enrichActivities = enrichCrosswalksStep.process(activities)

    enrichActivities.select(InferredPayerType).first.getString(0) shouldBe Constants.PayerTypeProfitableInferred
    enrichActivities.select(LocationDesc).first.getString(0) shouldBe "locationName1"
  }

  it should "correctly set inferredPayerType for Patients And should set proper location name for " +
    "input location code" in {

    import spark.implicits._

    val activities = spark.createDataset(Seq(
      Activity(
        customer = "testcustomer",
        personId = Some("faf7ed19-bc82-44d4-8adc-86b6945edd45"),
        activityId = "",
        batchId = "",
        dateCreated = Timestamp.valueOf(LocalDateTime.now()),
        activityDate = Date.valueOf(LocalDate.now()),
        payerType = Some("NI"),
        lastName = Some("cam"),
        maritalStatus = Some(Constants.MaritalStatusMarried),
        occupation = Some("08"),
        householdIncome = Some("A"),
        education = Some(Constants.EducationBachelorDegree),
        sourceAge = Some(25),
        isChildPresent = Some(true),
        locationCode = Some("602")
      )
    ))

    val enrichCrosswalksStep = new EnrichCrosswalksStep("EnrichCrossWalksUnitTest", None)(enrichJobConfig, spark)

    val enrichActivities = enrichCrosswalksStep.process(activities)

    enrichActivities.select(InferredPayerType).first.getString(0) shouldBe Constants.PayerTypeNotProfitableInferred
    enrichActivities.select(LocationDesc).first.getString(0) shouldBe "locationName3"
  }

  it should "get correct beehive cluster" in {

    import spark.implicits._

    val activities = spark.createDataset[Activity](Seq(
      Activity(
        customer = "testcustomer",
        personId = Some("personId"),
        activityId = "",
        batchId = "",
        dateCreated = Timestamp.valueOf(LocalDateTime.now()),
        activityDate = Date.valueOf(LocalDate.now()),
        payerType = Some("NI"),
        lastName = Some("cam"),
        maritalStatus = Some(Constants.MaritalStatusMarried),
        occupation = Some("08"),
        householdIncome = Some("A"),
        education = Some(Constants.EducationBachelorDegree),
        sourceAge = Some(25),
        beehiveCluster = None,
        isChildPresent = Some(true) // TODO: Figure out why this only works when isChildPresent is set to true
        )
    ))

    val enrichCrosswalksStep = new EnrichCrosswalksStep("EnrichCrossWalksUnitTest", None)(enrichJobConfig, spark)

    val enrichActivities = enrichCrosswalksStep.process(activities)

    enrichActivities.select(BeehiveCluster).first.getAs[Int](BeehiveCluster) shouldBe 21
  }

  it should "get correct upper emails" in {

    import spark.implicits._

    val activities = spark.createDataset[Activity](Seq(
      Activity(
        customer = "testcustomer",
        personId = Some("personId"),
        activityId = "",
        batchId = "",
        dateCreated = Timestamp.valueOf(LocalDateTime.now()),
        activityDate = Date.valueOf(LocalDate.now()),
        payerType = Some("NI"),
        lastName = Some("cam"),
        maritalStatus = Some(Constants.MaritalStatusMarried),
        occupation = Some("08"),
        householdIncome = Some("A"),
        education = Some(Constants.EducationBachelorDegree),
        sourceAge = Some(25),
        email = Some("test@company.com"),
        isChildPresent = Some(true) // TODO: Figure out why this only works when isChildPresent is set to true
      )
    ))

    val enrichCrosswalksStep = new EnrichCrosswalksStep("EnrichCrossWalksUnitTest", None)(enrichJobConfig, spark)

    val enrichActivities = enrichCrosswalksStep.process(activities)

    enrichActivities.select(Email).first.getAs[String](Email) shouldBe "TEST@COMPANY.COM"
  }

  it should "Correctly set FinancialClass and PayerType for Prospects" in {

    import spark.implicits._

    val activities = spark.createDataset[Activity](Seq(
      Activity(
        customer = "testcustomer",
        personId = Some("personId"),
        activityId = "",
        batchId = "",
        activityType = Some("PROSPECT"),
        dateCreated = Timestamp.valueOf(LocalDateTime.now()),
        activityDate = Date.valueOf(LocalDate.now()),
        payerType = None,
        lastName = Some("cam"),
        maritalStatus = Some(Constants.MaritalStatusMarried),
        occupation = Some("08"),
        householdIncome = Some("A"),
        education = Some(Constants.EducationBachelorDegree),
        sourceAge = Some(25),
        beehiveCluster = None,
        isChildPresent = Some(true)
      )
    ))

    val enrichCrosswalksStep = new EnrichCrosswalksStep("EnrichCrossWalksUnitTest", None)(enrichJobConfig, spark)

    val enrichActivities = enrichCrosswalksStep.process(activities)

    enrichActivities.select(FinancialClass).first.getString(0) shouldBe Constants.FinancialClassTargetPayerUnprofitable
    enrichActivities.select(PayerType).first.getString(0) shouldBe Constants.PayerTypeNotProfitableInferredDesc
  }

  it should "Correctly set FinancialClass and PayerType for Prospects having age > 65" in {

    import spark.implicits._

    val activities = spark.createDataset[Activity](Seq(
      Activity(
        customer = "tanner",
        personId = Some("personId"),
        activityId = "",
        batchId = "",
        activityType = Some("PROSPECT"),
        dateCreated = Timestamp.valueOf(LocalDateTime.now()),
        activityDate = Date.valueOf(LocalDate.now()),
        payerType = None,
        lastName = Some("MARSHALL"),
        maritalStatus = Some(Constants.MaritalStatusMarried),
        occupation = Some("05"),
        householdIncome = Some("A"),
        education = Some(Constants.EducationHighSchool),
        sourceAge = Some(70),
        beehiveCluster = Some(14),
        isChildPresent = Some(false)
      )
    ))

    val enrichCrosswalksStep = new EnrichCrosswalksStep("EnrichCrossWalksUnitTest", None)(enrichJobConfig, spark)

    val enrichActivities = enrichCrosswalksStep.process(activities)

    enrichActivities.select(FinancialClass).first.getString(0) shouldBe Constants.FinancialClassTargetPayerMedicare
    enrichActivities.select(PayerType).first.getString(0) shouldBe Constants.PayerTypeMedicareInferredDesc
  }

  it should "Correctly set FinancialClass and PayerType for Patients" in {

    import spark.implicits._

    val activities = spark.createDataset[Activity](Seq(
      Activity(
        customer = "tanner",
        personId = Some("personId"),
        activityId = "",
        batchId = "",
        activityType = Some("ENCOUNTER"),
        sourceFinancialClass = Some("MEDICARE PART A"),
        source = Some("Meditech"),
        sourceType = Some("Hospital"),
        dateCreated = Timestamp.valueOf(LocalDateTime.now()),
        activityDate = Date.valueOf(LocalDate.now()),
        payerType = None,
        lastName = Some("cam"),
        maritalStatus = Some(Constants.MaritalStatusMarried),
        occupation = Some("08"),
        householdIncome = Some("A"),
        education = Some(Constants.EducationBachelorDegree),
        sourceAge = Some(25),
        beehiveCluster = None,
        isChildPresent = Some(true)
      )
    ))

    val enrichCrosswalksStep = new EnrichCrosswalksStep("EnrichCrossWalksUnitTest", None)(enrichJobConfig, spark)

    val enrichActivities = enrichCrosswalksStep.process(activities)

    enrichActivities.select(FinancialClass).first.getString(0) shouldBe "medicare"
    enrichActivities.select(PayerType).first.getString(0) shouldBe "MK"
  }

}
