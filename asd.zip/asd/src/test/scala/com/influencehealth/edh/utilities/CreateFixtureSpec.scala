package com.influencehealth.edh.utilities

import com.influencehealth.edh.dao.FileReader
import com.influencehealth.edh.test.spark.SparkSpecBase
import com.influencehealth.edh.utilities.fixture.DeIdentifier
import org.apache.spark.sql.DataFrame
import org.scalatest.{BeforeAndAfter, FlatSpec, Ignore, Matchers}

/**
  * Created by pallavi.karan on 11/8/17.
  */
@Ignore
class CreateFixtureSpec extends
  FlatSpec with SparkSpecBase with BeforeAndAfter with Matchers {

  val InputDirectoryPath: String = "fixtures/cleanse/encounter/chomp/"
  var normalizedDataFrame: DataFrame = _
  var listOfFileTypes: List[(String, DataFrame)] = List()
  var deIdentifiedDataFrames: DataFrame = _
  var listOfExtractedDataFrames: List[(String, DataFrame)] = List()
  var incomingListOfEncounterFilesDf: DataFrame = _

  // TODO: Re-enable create fixutres app with FileDao
  before {
    // Load encounter files
    // incomingListOfEncounterFilesDf = _
    // FileReader.readFilesFromS3(sparkSession, InputDirectoryPath, null, "encounter", s3client, false)
  }

  /**
    * For iterating the list of items
    *
    * @param listOfValidDataFrames list of dfs
    * @return
    */
  def listIterator(listOfValidDataFrames: List[(String, DataFrame)]): List[String] = {
    var returnList: List[String] = List()
    for (x <- listOfValidDataFrames) {
      returnList = returnList :+ x._1
    }
    returnList
  }


  "Intake encounter files" should "normalize data by joining all the files" in {
    assert(incomingListOfEncounterFilesDf.count() == 4)
  }

  "deIdentifyEncounterData method" should "match count of deidentified rows" in {
    deIdentifiedDataFrames = DeIdentifier.deIdentifyEncounterData(incomingListOfEncounterFilesDf)
    assert(deIdentifiedDataFrames.count() == 4)
  }

  "extractColumnsAndSplitDataFrames method" should "return a list of extracted dataframes" in {
    listOfExtractedDataFrames = ???
    //      DeIdentifier.
    //      generateListsOfDeidentifiedDataFrames(deIdentifiedDataFrames)
    val list: List[String] = listIterator(listOfExtractedDataFrames)
    assert(list.equals(
      List(FileReader.Demographic,
        FileReader.CurrentProceduralTerminology,
        FileReader.Diagnosis,
        FileReader.Prognosis,
        FileReader.Facility,
        FileReader.Visit,
        FileReader.Guarantor,
        FileReader.Biometric,
        FileReader.Physician,
        FileReader.Financial)))
  }

  "extractColumnsAndSplitDataFrames method" should "split data correctly" in {

    for (z <- listOfExtractedDataFrames) {
      z._1 match {
        case w if w.contains(FileReader.Biometric) => assert(z._2.count() == 3)
        case w if w.contains(FileReader.Diagnosis) => assert(z._2.count() == 4)
        case w if w.contains(FileReader.Facility) => assert(z._2.count() == 3)
        case w if w.contains(FileReader.Financial) => assert(z._2.count() == 3)
        case w if w.contains(FileReader.Visit) => assert(z._2.count() == 3)
        case w if w.contains(FileReader.CurrentProceduralTerminology) => assert(z._2.count() == 3)
        case w if w.contains(FileReader.Demographic) => assert(z._2.count() == 2)
        case w if w.contains(FileReader.Prognosis) => assert(z._2.count() == 3)
        case w if w.contains(FileReader.Guarantor) => assert(z._2.count() == 3)
        case w if w.contains(FileReader.Physician) => assert(z._2.count() == 1)
      }
    }
  }

}