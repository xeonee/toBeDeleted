package com.influencehealth.edh.enrich.person.location

import java.sql.{Date, Timestamp}
import java.time.{LocalDate, LocalDateTime}
import java.util.UUID

import com.influencehealth.edh.lookup_clients.support.ServiceArea
import com.influencehealth.edh.lookups.messages.{Address, Location, Point}
import com.influencehealth.edh.model.{Activity, Coordinates, Person}
import com.influencehealth.edh.Constants

object EnrichLocationsTestData {

  val lat: Float = 33.3878f
  val lon: Float = -84.8254f
  val lat2: Float = 35.7711f
  val lon2: Float = -109.1790f

  val address1 = Address(
    Address1 = Some("address1"),
    Address2 = Some("address2"),
    City = Some("city"),
    State = Some("state"),
    Zip = Some("30309"),
    Zip4 = Some("1281"),
    GeoJson = Point.create("-84.39486".toDouble, "33.808587".toDouble),
    Lat = Some("33.808587".toDouble),
    Lon = Some("-84.39486".toDouble)
  )

  val address2 = Address(
    Address1 = Some("address1"),
    Address2 = Some("address2"),
    City = Some("city"),
    State = Some("state"),
    Zip = Some("30124"),
    Zip4 = Some("4526"),
    GeoJson = Point.create("-84.507658".toDouble, "33.452348".toDouble),
    Lat = Some("33.452348".toDouble),
    Lon = Some("-84.507658".toDouble)
  )

  val address3 = Address(
    Address1 = Some("address1"),
    Address2 = Some("address2"),
    City = Some("city"),
    State = Some("state"),
    Zip = Some("30143"),
    Zip4 = Some("4872"),
    GeoJson = Point.create("-84.447131".toDouble, "34.446111".toDouble),
    Lat = Some("34.446111".toDouble),
    Lon = Some("-84.447131".toDouble)
  )

  val address4 = Address(
    Address1 = Some("address1"),
    Address2 = Some("address2"),
    City = Some("city"),
    State = Some("state"),
    Zip = Some("30265"),
    Zip4 = Some("1618"),
    GeoJson = Point.create("-84.755036".toDouble, "33.357103".toDouble),
    Lat = Some("33.357103".toDouble),
    Lon = Some("-84.755036".toDouble)
  )

  val address5 = Address(
    Address1 = Some("address1"),
    Address2 = Some("address2"),
    City = Some("city"),
    State = Some("state"),
    Zip = Some("30281"),
    Zip4 = Some("5085"),
    GeoJson = Point.create("-84.227174".toDouble, "33.510351".toDouble),
    Lat = Some("33.510351".toDouble),
    Lon = Some("-84.227174".toDouble)
  )

  val address6 = Address(
    Address1 = Some("address1"),
    Address2 = Some("address2"),
    City = Some("city"),
    State = Some("state"),
    Zip = Some("87020"),
    Zip4 = Some("2188"),
    GeoJson = Point.create("-107.828069".toDouble, "35.161185".toDouble),
    Lat = Some("35.161185".toDouble),
    Lon = Some("-107.828069".toDouble)
  )

  val location1: Location = Location(
    CustomerId = 1,
    Id = 600,
    RefId = "locationCode1",
    Name = "locationName1",
    Address = address1,
    ClientKey = "clientKey",
    OrgKey = None,
    OrgId = None,
    AvailableZipCodes = Set(),
    PrimaryServiceAreaZipCodes = Set(),
    SecondaryServiceAreaZipCodes = Set(),
    TertiaryServiceAreaZipCodes = Set(),
    MarketAreas = Map(),
    UpdatedAt = Constants.Today
  )

  val location2: Location = Location(
    CustomerId = 1,
    Id = 601,
    RefId = "locationCode2",
    Name = "locationName2",
    Address = address2,
    ClientKey = "clientKey",
    OrgKey = None,
    OrgId = None,
    AvailableZipCodes = Set(),
    PrimaryServiceAreaZipCodes = Set(),
    SecondaryServiceAreaZipCodes = Set(),
    TertiaryServiceAreaZipCodes = Set(),
    MarketAreas = Map(),
    UpdatedAt = Constants.Today
  )

  val location3: Location = Location(
    CustomerId = 1,
    Id = 602,
    RefId = "locationCode3",
    Name = "locationName3",
    Address = address3,
    ClientKey = "clientKey",
    OrgKey = None,
    OrgId = None,
    AvailableZipCodes = Set(),
    PrimaryServiceAreaZipCodes = Set(),
    SecondaryServiceAreaZipCodes = Set(),
    TertiaryServiceAreaZipCodes = Set(),
    MarketAreas = Map(),
    UpdatedAt = Constants.Today
  )

  val location4: Location = Location(
    CustomerId = 1,
    Id = 603,
    RefId = "locationCode4",
    Name = "locationName4",
    Address = address4,
    ClientKey = "clientKey",
    OrgKey = None,
    OrgId = None,
    AvailableZipCodes = Set(),
    PrimaryServiceAreaZipCodes = Set(),
    SecondaryServiceAreaZipCodes = Set(),
    TertiaryServiceAreaZipCodes = Set(),
    MarketAreas = Map(),
    UpdatedAt = Constants.Today
  )

  val location5: Location = Location(
    CustomerId = 1,
    Id = 604,
    RefId = "locationCode5",
    Name = "locationName5",
    Address = address5,
    ClientKey = "clientKey",
    OrgKey = None,
    OrgId = None,
    AvailableZipCodes = Set(),
    PrimaryServiceAreaZipCodes = Set(),
    SecondaryServiceAreaZipCodes = Set(),
    TertiaryServiceAreaZipCodes = Set(),
    MarketAreas = Map(),
    UpdatedAt = Constants.Today
  )

  val location6: Location = Location(
    CustomerId = 20000,
    Id = 495,
    RefId = "locationCode6",
    Name = "locationName6",
    Address = address6,
    ClientKey = "clientKey",
    OrgKey = None,
    OrgId = None,
    AvailableZipCodes = Set(),
    PrimaryServiceAreaZipCodes = Set(),
    SecondaryServiceAreaZipCodes = Set(),
    TertiaryServiceAreaZipCodes = Set(),
    MarketAreas = Map(),
    UpdatedAt = Constants.Today
  )


  val locations: Seq[Location] = Seq(
    location1, location2, location3, location4, location5, location6
  )

  val serviceArea1: ServiceArea = ServiceArea(
    customerId = 1,
    locationId = 600,
    zip5 = "30263",
    serviceAreaName = "Secondary"
  )

  val serviceArea2: ServiceArea = ServiceArea(
    customerId = 1,
    locationId = 601,
    zip5 = "30263",
    serviceAreaName = "Secondary"
  )

  val serviceArea3: ServiceArea = ServiceArea(
    customerId = 1,
    locationId = 603,
    zip5 = "30263",
    serviceAreaName = "Primary"
  )

  val serviceArea4: ServiceArea = ServiceArea(
    customerId = 20000,
    locationId = 495,
    zip5 = "86504",
    serviceAreaName = "Primary"
  )

  val serviceAreas: Set[ServiceArea] = Set(serviceArea1, serviceArea2, serviceArea3)

  val activity1 = Activity(
    customer = "",
    activityId = "",
    batchId = "",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    locationDesc = Some("locationName1"),
    activityType = Some(Constants.EncounterActivityType),
    sourceRecordId = Some(UUID.randomUUID().toString),
    source = Some("someSource"),
    sourceType = Some("someSourceType"),
    activityDate = Date.valueOf("2015-01-01"),
    zip5 = Some("30000")
  )

  val activity2 = Activity(
    customer = "",
    activityId = "",
    batchId = "",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    locationDesc = Some("locationName1"),
    activityType = Some(Constants.EncounterActivityType),
    sourceRecordId = Some(UUID.randomUUID().toString),
    source = Some("someSource"),
    sourceType = Some("someSourceType"),
    activityDate = Date.valueOf(LocalDate.now()),
    zip5 = Some("30000")
  )

  val activity3 = Activity(
    customer = "",
    activityId = "",
    batchId = "",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    locationDesc = Some("locationName2"),
    activityType = Some(Constants.EncounterActivityType),
    sourceRecordId = Some(UUID.randomUUID().toString),
    source = Some("someSource"),
    sourceType = Some("someSourceType"),
    activityDate = Date.valueOf("2015-02-15"),
    zip5 = Some("30263")
  )

  val activity4 = Activity(
    customer = "",
    activityId = "",
    batchId = "",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    locationDesc = Some("locationName2"),
    activityType = Some(Constants.EncounterActivityType),
    sourceRecordId = Some(UUID.randomUUID().toString),
    source = Some("someSource"),
    sourceType = Some("someSourceType"),
    activityDate = Date.valueOf("2015-02-01"),
    zip5 = Some("30263")
  )

  val activity5 = Activity(
    customer = "",
    activityId = "",
    batchId = "",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    locationDesc = Some("locationName3"),
    activityType = Some(Constants.ProspectDefaultMessageType),
    sourceRecordId = Some(UUID.randomUUID().toString),
    source = Some("someSource"),
    sourceType = Some("someSourceType"),
    activityDate = Date.valueOf(LocalDate.now()),
    zip5 = Some("30263")
  )

  val activity6 = Activity(
    customer = "",
    activityId = "",
    batchId = "",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    locationDesc = Some("locationName3"),
    activityType = Some(Constants.ProspectDefaultMessageType),
    sourceRecordId = Some(UUID.randomUUID().toString),
    source = Some("someSource"),
    sourceType = Some("someSourceType"),
    activityDate = Date.valueOf("2015-06-01"),
    zip5 = None
  )

  val utilActivities: Seq[Activity] = Seq(
    activity1, activity2, activity3, activity4
  )

  val nonUtilActivities: Seq[Activity] = Seq(
    activity5, activity6
  )

  val person: Person = Person(
    customer = "somecustomer",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    personId = "PERSONID1",
    zip5 = Option("30263"),
    addressCoordinates = Some(Coordinates(lat,lon)),
    activities = utilActivities ++ nonUtilActivities
  )

  val person2: Person = Person(
    customer = "somecustomer",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    personId = "PERSONID2",
    zip5 = Option("86504"),
    addressCoordinates = Some(Coordinates(lat2, lon2))
  )

  val invalidMultiLocationPerson: Person = Person(
    customer = "somecustomer",
    dateCreated = Timestamp.valueOf(LocalDateTime.now()),
    personId = UUID.randomUUID().toString
  )

}
