package com.influencehealth.edh.identity

import java.sql.{Date, Timestamp}
import java.time.{LocalDate, LocalDateTime}
import com.influencehealth.edh.Constants
import com.influencehealth.edh.model.Activity
import com.influencehealth.edh.test.spark.SparkSpecBase
import org.apache.spark.sql.Dataset
import org.scalatest.Matchers

class EnrichIdentitySpec extends SparkSpecBase with Matchers {

  it should "correctly split unidentifiable records from identifiable records" in {

    val validActivity1: Activity = Activity(
      customer = "",
      activityId = "",
      batchId = "",
      dateCreated = Timestamp.valueOf(LocalDateTime.now()),
      activityDate = Date.valueOf(LocalDate.now()),
      firstName = Some("MUSANNA"),
      lastName = Some("OVERR"),
      address1 = Some("145 KENT DR"),
      zip5 = Some("12345"),
      isValidAddress = Some(true)
    )

    val validActivity2: Activity = Activity(
      customer = "",
      activityId = "",
      batchId = "",
      dateCreated = Timestamp.valueOf(LocalDateTime.now()),
      activityDate = Date.valueOf(LocalDate.now()),
      firstName = Some("MUSANNA"),
      lastName = Some("OVERR"),
      homePhone = Some("5555555555"),
      isValidAddress = Some(false)
    )

    val validActivity3: Activity = Activity(
      customer = "",
      activityId = "",
      batchId = "",
      dateCreated = Timestamp.valueOf(LocalDateTime.now()),
      activityDate = Date.valueOf(LocalDate.now()),
      firstName = Some("MUSANNA"),
      lastName = Some("OVERR"),
      mobilePhone = Some("5555555555"),
      isValidAddress = Some(false)
    )

    val validActivity4: Activity = Activity(
      customer = "",
      activityId = "",
      batchId = "",
      dateCreated = Timestamp.valueOf(LocalDateTime.now()),
      activityDate = Date.valueOf(LocalDate.now()),
      firstName = Some("MUSANNA"),
      lastName = Some("OVERR"),
      email = Some("iknowwhatyoudidlastsummer@creepygmail.com"),
      isValidAddress = Some(false)
    )

    val validActivity5: Activity = Activity(
      customer = "",
      activityId = "",
      batchId = "",
      dateCreated = Timestamp.valueOf(LocalDateTime.now()),
      activityDate = Date.valueOf(LocalDate.now()),
      firstName = Some("MUSANNA"),
      lastName = Some("OVERR"),
      homePhone = Some("5555555555"),
      isValidAddress = None
    )

    val invalidActivity1: Activity = Activity(
      customer = "",
      activityId = "",
      batchId = "",
      dateCreated = Timestamp.valueOf(LocalDateTime.now()),
      activityDate = Date.valueOf(LocalDate.now()),
      firstName = Some("MUSANNA"),
      lastName = None,
      address1 = Some("145 KENT DR"),
      zip5 = Some("12345"),
      isValidAddress = Some(true)
    )

    val invalidActivity2: Activity = Activity(
      customer = "",
      activityId = "",
      batchId = "",
      dateCreated = Timestamp.valueOf(LocalDateTime.now()),
      activityDate = Date.valueOf(LocalDate.now()),
      firstName = None,
      lastName = Some("OVERR"),
      address1 = Some("145 KENT DR"),
      zip5 = Some("12345"),
      isValidAddress = Some(true)
    )

    val invalidActivity3: Activity = Activity(
      customer = "",
      activityId = "",
      batchId = "",
      dateCreated = Timestamp.valueOf(LocalDateTime.now()),
      activityDate = Date.valueOf(LocalDate.now()),
      firstName = None,
      lastName = Some("OVERR"),
      address1 = Some("145 KENT DR"),
      zip5 = Some("12345"),
      isValidAddress = Some(false)
    )


    import spark.implicits._

    val activities: Dataset[Activity] = spark.
      createDataset(List(
        validActivity1,
        validActivity2,
        validActivity3,
        validActivity4,
        validActivity5,
        invalidActivity1,
        invalidActivity2,
        invalidActivity3
      ))

    val (validActivities, invalidActivities) = EnrichIdentity.splitOnIdentifiableData(
                                                activities,Constants.EncounterActivityType)

    validActivities.count shouldBe 5
    invalidActivities.count shouldBe 3
  }

}
