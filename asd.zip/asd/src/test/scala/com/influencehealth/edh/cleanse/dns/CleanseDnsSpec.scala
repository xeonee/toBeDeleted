package com.influencehealth.edh.cleanse.dns


import com.influencehealth.edh.dao.FileSystemDao
import com.influencehealth.edh.model.schema.DnsSchema
import com.influencehealth.edh.test.spark.SparkSpecBase
import com.influencehealth.edh.{AppCleanser, Constants}
import org.apache.spark.sql.{DataFrame, Row}
import org.scalamock.scalatest.MockFactory
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}

class CleanseDnsSpec extends FlatSpec with SparkSpecBase with BeforeAndAfter with Matchers with MockFactory {

  val InputDirectoryPath: String = "fixtures/cleanse/dns/foundation"
  val DateBatchReceived: String = "11/01/2017"
  val Customer: String = "chomp"
  val BatchId = "chomp-dns-foundation-2017-11"

  it should "cleanse dns files" in {

    val rawData: DataFrame = spark.createDataFrame(spark.sparkContext.parallelize(Seq(
      Row("Sparrow", "Jack", "J", "1234 State St.", null, "Madison", "WI", "71822", "M", "5/12/1956", null, "jack.sparrow@sample.com", "Deceased"),
      Row("Doo", "Scooby", "S", "5678 Main St", null, "Madison", "WI", "71822", "F", "1/1/1975", "608-555-1234", null, "Opt Out"),
      Row("First", "Last", "S", "5678 Main St", null, "Madison", "WI", "71822", "F", "1/1/1975", "6085551234", null, null),
      Row(null, null, null, null, null, null, null, null, null, null, null, "myemail@gmail.com", "MailChimp_Unsubscribed List"),
      Row(null, null, null, null, null, null, null, null, null, null, null, "bestemail@aol.com", "MailChimp_Unsubscribed List"),
      Row(null, null, null, null, null, null, null, null, null, null, null, "email@hotmail.com", "MailChimp_Unsubscribed List")
    )), DnsSchema.DnsSchema)


    val mockFileSystemDao = mock[FileSystemDao]

    (mockFileSystemDao.readDoNotSolicitFile _).expects(false, Seq(InputDirectoryPath)).returns(rawData)

    val (cleansedDataFrame: DataFrame, dirtyDataFrame: DataFrame) = AppCleanser.cleanseData(
      Some(Customer), Constants.DoNotSolicitActivityType, BatchId, false, InputDirectoryPath,
      Constants.DoNotSolicitFoundationFormat, DateBatchReceived, mockFileSystemDao
    )

    cleansedDataFrame.count() shouldBe 5
    val firstNames = cleansedDataFrame.select("firstName").collectAsList()
    firstNames.get(0).getString(0) shouldBe "Jack"
    val sourceDnsReason = cleansedDataFrame.select("sourceDnsReason").collectAsList()
    sourceDnsReason.get(0).getString(0) shouldBe "Deceased"
    val dateOfBirth = cleansedDataFrame.select("dateOfBirth").collectAsList()
    dateOfBirth.get(0).getDate(0).toString shouldBe "1956-05-12"
    val source = cleansedDataFrame.select("source").collectAsList()
    source.get(0).getString(0) shouldBe "DNS"
    val sourceRecordId = cleansedDataFrame.select("sourceRecordId").collectAsList()
    sourceRecordId.get(0).getString(0) shouldBe "37b49a7b291953a5d72eb2ba18b50412"
    sourceRecordId.get(1).getString(0) shouldBe "10a280cea7f08409b3b2d44fe6bef7a5"
    val data = cleansedDataFrame.select("lastName").collectAsList()
    data.get(0).getString(0) shouldBe "Sparrow"
    data.get(1).getString(0) shouldBe "Doo"
    val email = cleansedDataFrame.select("email").collectAsList()
    email.get(0).getString(0) shouldBe "jack.sparrow@sample.com"
    email.get(1).getString(0) shouldBe null

    dirtyDataFrame.count() shouldBe 1
    val dirtyData = dirtyDataFrame.select("sourceDnsReason").collectAsList()
    dirtyData.get(0).getString(0) shouldBe null

  }

}
