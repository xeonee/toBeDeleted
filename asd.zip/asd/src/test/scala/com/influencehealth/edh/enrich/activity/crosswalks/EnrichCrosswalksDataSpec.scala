package com.influencehealth.edh.enrich.activity.crosswalks

import java.util.UUID

import com.influencehealth.edh.enrich.activity.crosswalks.helper._
import com.influencehealth.edh.test.spark.SparkSpecBase
import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StructField, _}
import org.scalatest.{FlatSpec, Matchers}


class EnrichCrosswalksDataSpec extends FlatSpec with SparkSpecBase with Matchers {

  val personId: String = UUID.randomUUID().toString

  it should "Correctly set patient_type if source and source_type matches for client" in {

    val crosswalkDataContext: CrosswalkData =
      CrosswalkData(spark: SparkSession)

    val crosswalkDerivatives = CrosswalkDerivatives(crosswalkDataContext)

    val p1 = Row("northwell", personId, "SEM", "Hospital", "A", "null")

    val a = spark.sparkContext.parallelize(Seq(p1))

    val schema = StructType(List(
      StructField("customer", StringType, false),
      StructField("person_id", StringType, false),
      StructField("source", StringType, false),
      StructField("source_type", StringType, false),
      StructField("source_patient_type", StringType, false),
      StructField("patient_type", StringType, false)
    ))

    val allActivityPersonDf = spark.createDataFrame(a, schema)

    val personWithPatientType = allActivityPersonDf
      .withColumn("patient_type",
        upper(crosswalkDerivatives.patientType(
          col("source_patient_type"),
          col("customer"),
          col("source"),
          col("source_type"))
        ))

    assert(personWithPatientType.select("patient_type").first.getString(0) == "OUTPATIENT")
  }

  it should "Correctly set patient_type with default source and source_type for client" in {

    val crosswalkDataContext: CrosswalkData =
      CrosswalkData(spark: SparkSession)

    val crosswalkDerivatives = CrosswalkDerivatives(crosswalkDataContext)

    val p1 = Row("northwell", personId, "EXPERIAN", "PROSPECT", "E", "null")

    val a = spark.sparkContext.parallelize(Seq(p1))

    val schema = StructType(List(
      StructField("customer", StringType, false),
      StructField("person_id", StringType, false),
      StructField("source", StringType, false),
      StructField("source_type", StringType, false),
      StructField("source_patient_type", StringType, false),
      StructField("patient_type", StringType, false)
    ))

    val allActivityPersonDf = spark.createDataFrame(a, schema)

    val personWithPatientType = allActivityPersonDf
      .withColumn("patient_type",
        upper(crosswalkDerivatives.patientType(
          col("source_patient_type"),
          col("customer"),
          col("source"),
          col("source_type"))
        ))

    assert(personWithPatientType.select("patient_type").first.getString(0) == "OUTPATIENT")
  }

  it should "Correctly set patient_type with default customer_id, source and source_type for client" in {

    val crosswalkDataContext: CrosswalkData =
      CrosswalkData(spark: SparkSession)

    val crosswalkDerivatives = CrosswalkDerivatives(crosswalkDataContext)

    val p1 = Row("northwell", personId, "EXPERIAN", "PROSPECT", "INPATIENT", "null")

    val a = spark.sparkContext.parallelize(Seq(p1))

    val schema = StructType(List(
      StructField("customer", StringType, false),
      StructField("person_id", StringType, false),
      StructField("source", StringType, false),
      StructField("source_type", StringType, false),
      StructField("source_patient_type", StringType, false),
      StructField("patient_type", StringType, false)
    ))

    val allActivityPersonDf = spark.createDataFrame(a, schema)

    val personWithPatientType = allActivityPersonDf
      .withColumn("patient_type",
        upper(crosswalkDerivatives.patientType(
          col("source_patient_type"),
          col("customer"),
          col("source"),
          col("source_type"))
        ))

    assert(personWithPatientType.select("patient_type").first.getString(0) == "INPATIENT")
  }

  it should "Correctly set activity_type for source lvm and sourceType call center" in {

    val crosswalkDataContext: CrosswalkData =
      CrosswalkData(spark: SparkSession)

    val crosswalkDerivatives = CrosswalkDerivatives(crosswalkDataContext)

    val p1 = Row("northwell", personId, "lvm", "call center", "INPATIENT", "LIT")

    val a = spark.sparkContext.parallelize(Seq(p1))

    val schema = StructType(List(
      StructField("customer", StringType, false),
      StructField("person_id", StringType, false),
      StructField("source", StringType, false),
      StructField("source_type", StringType, false),
      StructField("source_patient_type", StringType, false),
      StructField("source_activity_type", StringType, false)
    ))

    val allActivityPersonDf = spark.createDataFrame(a, schema)

    val personWithPatientType = allActivityPersonDf
      .withColumn("patient_type",
        upper(crosswalkDerivatives.patientType(
          col("source_patient_type"),
          col("customer"),
          col("source"),
          col("source_type"))
        ))
      .withColumn("activity_type", crosswalkDerivatives.activityType(
        col("source_activity_type"),
        col("customer"),
        col("source"),
        col("source_type"))
      )

    assert(personWithPatientType.select("activity_type").first.getString(0) == "literature")

  }
  it should "Correctly set er_patient default customer_id, source and source_type for client" in {

    val crosswalkDataContext: CrosswalkData =
      CrosswalkData(spark: SparkSession)

    val crosswalkDerivatives = CrosswalkDerivatives(crosswalkDataContext)

    val p1 = Row("northwell", personId, "SEM", "Hospital", "INPATIENT", "LIT", "E", false)

    val a = spark.sparkContext.parallelize(Seq(p1))

    val schema = StructType(List(
      StructField("customer", StringType, false),
      StructField("person_id", StringType, false),
      StructField("source", StringType, false),
      StructField("source_type", StringType, false),
      StructField("source_patient_type", StringType, false),
      StructField("source_activity_type", StringType, false),
      StructField("source_er_patient", StringType, false),
      StructField("er_patient", BooleanType, false)
    ))

    val allActivityPersonDf = spark.createDataFrame(a, schema)

    val personWithPatientType = allActivityPersonDf
      .withColumn("er_patient", crosswalkDerivatives.erPatient(
        col("source_er_patient"),
        col("customer"),
        col("source"),
        col("source_type"))
      )

    assert(personWithPatientType.select("er_patient").first.getString(0).equalsIgnoreCase("true"))

  }
  it should "Correctly set marital_status default customer_id, source and source_type for client" in {

    val crosswalkDataContext: CrosswalkData =
      CrosswalkData(spark: SparkSession)

    val crosswalkDerivatives = CrosswalkDerivatives(crosswalkDataContext)

    val p1 = Row("northwell", personId, "SEM", "Hospital", "INPATIENT", "LIT", "E", false, "M")

    val a = spark.sparkContext.parallelize(Seq(p1))

    val schema = StructType(List(
      StructField("customer", StringType, false),
      StructField("person_id", StringType, false),
      StructField("source", StringType, false),
      StructField("source_type", StringType, false),
      StructField("source_patient_type", StringType, false),
      StructField("source_activity_type", StringType, false),
      StructField("source_er_patient", StringType, false),
      StructField("er_patient", BooleanType, false),
      StructField("source_marital_status", StringType, false)

    ))

    val allActivityPersonDf = spark.createDataFrame(a, schema)

    val personWithPatientType = allActivityPersonDf
      .withColumn("marital_status", upper(crosswalkDerivatives.maritalStatus(
        col("source_marital_status"),
        col("customer"),
        col("source"),
        col("source_type")))
      )

    assert(personWithPatientType.select("marital_status").first.getString(0) == "MARRIED")
  }
  it should "Correctly set race for default customer_id, source and source_type for client" in {

    val crosswalkDataContext: CrosswalkData =
      CrosswalkData(spark: SparkSession)

    val crosswalkDerivatives = CrosswalkDerivatives(crosswalkDataContext)

    val p1 = Row("northwell", personId, "SEM", "Hospital", "INPATIENT", "LIT", "E", "M", "H")

    val a = spark.sparkContext.parallelize(Seq(p1))

    val schema = StructType(List(
      StructField("customer", StringType, false),
      StructField("person_id", StringType, false),
      StructField("source", StringType, false),
      StructField("source_type", StringType, false),
      StructField("source_patient_type", StringType, false),
      StructField("source_activity_type", StringType, false),
      StructField("source_er_patient", StringType, false),
      StructField("source_marital_status", StringType, false),
      StructField("source_race", StringType, false)
    ))

    val allActivityPersonDf = spark.createDataFrame(a, schema)

    val personWithPatientType = allActivityPersonDf
      .withColumn("race", upper(crosswalkDerivatives.race(
        col("source_race"),
        col("customer"),
        col("source"),
        col("source_type")))
      )

    assert(personWithPatientType.select("race").first.getString(0) == "H")

  }

  it should "Correctly set sex for default customer_id, source and source_type for client" in {

    val crosswalkDataContext: CrosswalkData =
      CrosswalkData(spark: SparkSession)

    val crosswalkDerivatives = CrosswalkDerivatives(crosswalkDataContext)

    val p1 = Row("northwell", personId, "SEM", "Hospital", "INPATIENT", "LIT", "E", "M", "W", "Female")

    val a = spark.sparkContext.parallelize(Seq(p1))

    val schema = StructType(List(
      StructField("customer", StringType, false),
      StructField("person_id", StringType, false),
      StructField("source", StringType, false),
      StructField("source_type", StringType, false),
      StructField("source_patient_type", StringType, false),
      StructField("source_activity_type", StringType, false),
      StructField("source_er_patient", StringType, false),
      StructField("source_marital_status", StringType, false),
      StructField("source_race", StringType, false),
      StructField("source_sex", StringType, false)
    ))

    val allActivityPersonDf = spark.createDataFrame(a, schema)

    val personWithPatientType = allActivityPersonDf
      .withColumn("sex", upper(crosswalkDerivatives.sex(
        col("source_sex"),
        col("customer"),
        col("source"),
        col("source_type")))
      )

    assert(personWithPatientType.select("sex").first.getString(0) == "FEMALE")
  }

  it should "Correctly set location_id for default customer_id, source and source_type for client" in {

    val crosswalkDataContext: CrosswalkData =
      CrosswalkData(spark: SparkSession)

    val crosswalkDerivatives = CrosswalkDerivatives(crosswalkDataContext)

    val p1 = Row("chomp", personId, "SEM", "Hospital", "INPATIENT", "LIT", "E", "M", "W", "Female", "chomp", "996-1163")

    val a = spark.sparkContext.parallelize(Seq(p1))

    val schema = StructType(List(
      StructField("customer", StringType, false),
      StructField("person_id", StringType, false),
      StructField("source", StringType, false),
      StructField("source_type", StringType, false),
      StructField("source_patient_type", StringType, false),
      StructField("source_activity_type", StringType, false),
      StructField("source_er_patient", StringType, false),
      StructField("source_marital_status", StringType, false),
      StructField("source_race", StringType, false),
      StructField("source_sex", StringType, false),
      StructField("hospital_id", StringType, false),
      StructField("clinic_id", StringType, false)
    ))

    val allActivityPersonDf = spark.createDataFrame(a, schema)

    val personWithPatientType = allActivityPersonDf
      .withColumn("location_id", crosswalkDerivatives.clientLocation(
        col("hospital_id"),
        col("clinic_id"),
        col("customer"),
        col("source"),
        col("source_type"))
      )

    assert(personWithPatientType.select("location_id").first.getString(0) == "670")
  }


  it should "Correctly set discharge_status for default customer, source and source_type for client" in {

    val crosswalkDataContext: CrosswalkData =
      CrosswalkData(spark: SparkSession)

    val crosswalkDerivatives = CrosswalkDerivatives(crosswalkDataContext)

    val p1 = Row("chomp", personId, "SEM", "Hospital", "INPATIENT", "LIT", "E", "M", "W", "Female", "chomp", "06")

    val a = spark.sparkContext.parallelize(Seq(p1))

    val schema = StructType(List(
      StructField("customer", StringType, false),
      StructField("person_id", StringType, false),
      StructField("source", StringType, false),
      StructField("source_type", StringType, false),
      StructField("source_patient_type", StringType, false),
      StructField("source_activity_type", StringType, false),
      StructField("source_er_patient", StringType, false),
      StructField("source_marital_status", StringType, false),
      StructField("source_race", StringType, false),
      StructField("source_sex", StringType, false),
      StructField("source_client", StringType, false),
      StructField("source_discharge_status", StringType, false)
    ))

    val allActivityPersonDf = spark.createDataFrame(a, schema)

    val personWithPatientType = allActivityPersonDf
      .withColumn("discharge_status", crosswalkDerivatives.dischargeStatus(
        col("source_discharge_status"))
      )

    assert(personWithPatientType.select("discharge_status").first.getString(0) == "6")
  }


  it should "Correctly set exclusion_flag for default customer, source and source_type for client" in {

    val crosswalkDataContext: CrosswalkData =
      CrosswalkData(spark: SparkSession)

    val crosswalkDerivatives = CrosswalkDerivatives(crosswalkDataContext)

    val p1 = Row("chomp", personId, "SEM", "Hospital", "INPATIENT", "LIT", "E", "M", "W", "Female", "chomp", "3")

    val a = spark.sparkContext.parallelize(Seq(p1))

    val schema = StructType(List(
      StructField("customer", StringType, false),
      StructField("person_id", StringType, false),
      StructField("source", StringType, false),
      StructField("source_type", StringType, false),
      StructField("source_patient_type", StringType, false),
      StructField("source_activity_type", StringType, false),
      StructField("source_er_patient", StringType, false),
      StructField("source_marital_status", StringType, false),
      StructField("source_race", StringType, false),
      StructField("source_sex", StringType, false),
      StructField("source_client", StringType, false),
      StructField("source_exclusion_flag", StringType, false)
    ))

    val allActivityPersonDf = spark.createDataFrame(a, schema)

    val personWithPatientType = allActivityPersonDf
      .withColumn("exclusion_flag", crosswalkDerivatives.exclusionFlag(
        col("source_exclusion_flag"),
        col("customer"),
        col("source"),
        col("source_type"))
      )

    assert(personWithPatientType.select("exclusion_flag").first.getString(0) == "3")
  }

  it should "Correctly set financial_class_id for client present in lookup" in {

    val crosswalkDataContext: CrosswalkData =
      CrosswalkData(spark: SparkSession)

    val crosswalkDerivatives = CrosswalkDerivatives(crosswalkDataContext)

    val p1 = Row("tanner", personId, "Meditech", "Hospital", "MEDICARE PART A")

    val a = spark.sparkContext.parallelize(Seq(p1))

    val schema = StructType(List(
      StructField("customer", StringType, false),
      StructField("personId", StringType, false),
      StructField("source", StringType, false),
      StructField("sourceType", StringType, false),
      StructField("sourceFinancialClass", StringType, false)
    ))

    val allActivityPersonDf = spark.createDataFrame(a, schema)
    val personWithPatientType = allActivityPersonDf
      .withColumn("financialClass", crosswalkDerivatives.financialClass(
        col("sourceFinancialClass"),
        col("customer"),
        col("source"),
        col("sourceType"))
      )
    assert(personWithPatientType.select("financialClass").first.getString(0) == "medicare")
  }

  it should "Correctly set financial Class for default source and source_type" in {

    val crosswalkDataContext: CrosswalkData =
      CrosswalkData(spark: SparkSession)

    val crosswalkDerivatives = CrosswalkDerivatives(crosswalkDataContext)

    val p1 = Row("christus", personId, "default", "default", "COMMERCIAL")

    val a = spark.sparkContext.parallelize(Seq(p1))

    val schema = StructType(List(
      StructField("customer", StringType, false),
      StructField("personId", StringType, false),
      StructField("source", StringType, false),
      StructField("sourceType", StringType, false),
      StructField("sourceFinancialClass", StringType, false)
    ))

    val allActivityPersonDf = spark.createDataFrame(a, schema)

    val personWithPatientType = allActivityPersonDf
      .withColumn("financialClass", crosswalkDerivatives.financialClass(
        col("sourceFinancialClass"),
        col("customer"),
        col("source"),
        col("sourceType"))
      )

    assert(personWithPatientType.select("financialClass").first.getString(0) == "commercial")
  }

  it should "Correctly set financial_class for client present in lookup" in {

    val crosswalkDataContext: CrosswalkData =
      CrosswalkData(spark: SparkSession)

    val crosswalkDerivatives = CrosswalkDerivatives(crosswalkDataContext)

    val p1 = Row("northwell", personId, "SEM", "Hospital", "MEDICARE TOTAL")

    val a = spark.sparkContext.parallelize(Seq(p1))

    val schema = StructType(List(
      StructField("customer", StringType, false),
      StructField("person_id", StringType, false),
      StructField("source", StringType, false),
      StructField("source_type", StringType, false),
      StructField("source_financial_class", StringType, false)
    ))

    val allActivityPersonDf = spark.createDataFrame(a, schema)

    val personWithPatientType = allActivityPersonDf
      .withColumn("financial_class", crosswalkDerivatives.financialClass(
        col("source_financial_class"),
        col("customer"),
        col("source"),
        col("source_type"))
      )

    assert(personWithPatientType.select("financial_class").first.getString(0) == "medicare")
  }

  /*  it should "Correctly set financial_class for default customer, source and source_type" in {

      val crosswalkDataContext: CrosswalkData =
        CrosswalkData(sparkSession: SparkSession)

      val crosswalkDerivatives = CrosswalkDerivatives(crosswalkDataContext)

      val p1 = Row("default", personId, "SEM", "Hospital","commercial")

      val a = sparkSession.sparkContext.parallelize(Seq(p1))

      val schema = StructType(List(
        StructField("customer", StringType, false),
        StructField("person_id", StringType, false),
        StructField("source", StringType, false),
        StructField("source_type", StringType, false),
        StructField("source_financial_class", StringType, false)
      ))

      val allActivityPersonDf = sparkSession.createDataFrame(a, schema)

      val personWithPatientType = allActivityPersonDf
        .withColumn("financial_class", crosswalkDerivatives.financialClass(
          col("source_financial_class"),
          col("customer"),
          col("source"),
          col("source_type"))
        )

      assert(personWithPatientType.select("financial_class").first.getString(0) == "commercial")
    } */

  it should "Correctly set payer_type for client present in lookup" in {

    val crosswalkDataContext: CrosswalkData =
      CrosswalkData(spark: SparkSession)

    val crosswalkDerivatives = CrosswalkDerivatives(crosswalkDataContext)

    val p1 = Row("northwell", personId, "SEM", "Hospital", "MEDICARE TOTAL")

    val a = spark.sparkContext.parallelize(Seq(p1))

    val schema = StructType(List(
      StructField("customer", StringType, false),
      StructField("person_id", StringType, false),
      StructField("source", StringType, false),
      StructField("source_type", StringType, false),
      StructField("source_financial_class", StringType, false)
    ))

    val allActivityPersonDf = spark.createDataFrame(a, schema)

    val personWithPatientType = allActivityPersonDf
      .withColumn("financial_class", crosswalkDerivatives.financialClass(
        col("source_financial_class"),
        col("customer"),
        col("source"),
        col("source_type"))
      )
      .withColumn("payer_type", upper(crosswalkDerivatives.payerType(
        col("source_financial_class"),
        col("customer"),
        col("source"),
        col("source_type")))
      )

    assert(personWithPatientType.select("payer_type").first.getString(0) == "PK")
  }

  /*  it should "Correctly set payer_type for default customer, source and source_type" in {

      val crosswalkDataContext: CrosswalkData =
        CrosswalkData(sparkSession: SparkSession)

      val crosswalkDerivatives = CrosswalkDerivatives(crosswalkDataContext)

      val p1 = Row("chomp", personId, "SEM", "Hospital", "commercial")

      val a = sparkSession.sparkContext.parallelize(Seq(p1))

      val schema = StructType(List(
        StructField("customer", StringType, false),
        StructField("person_id", StringType, false),
        StructField("source", StringType, false),
        StructField("source_type", StringType, false),
        StructField("source_financial_class", StringType, false)
      ))

      val allActivityPersonDf = sparkSession.createDataFrame(a, schema)

      val personWithPatientType = allActivityPersonDf
        .withColumn("financial_class", crosswalkDerivatives.financialClass(
          col("source_financial_class"),
          col("customer"),
          col("source"),
          col("source_type"))
        )
        .withColumn("payer_type", upper(crosswalkDerivatives.payerType(
          col("source_financial_class"),
          col("customer"),
          col("source"),
          col("source_type")))
        )

      assert(personWithPatientType.select("payer_type").first.getString(0) == "PK")
    } */

  it should "Correctly set payer_type for customer CHRISTUS and source, source_type as athena" in {

    val crosswalkDataContext: CrosswalkData =
      CrosswalkData(spark: SparkSession)

    val crosswalkDerivatives = CrosswalkDerivatives(crosswalkDataContext)

    val p1 = Row("christus", personId, "athena", "athena", "MEDICARE PART B")

    val a = spark.sparkContext.parallelize(Seq(p1))

    val schema = StructType(List(
      StructField("customer", StringType, false),
      StructField("person_id", StringType, false),
      StructField("source", StringType, false),
      StructField("source_type", StringType, false),
      StructField("source_financial_class", StringType, false)
    ))

    val allActivityPersonDf = spark.createDataFrame(a, schema)

    val personWithPatientType = allActivityPersonDf
      .withColumn("financial_class", crosswalkDerivatives.financialClass(
        col("source_financial_class"),
        col("customer"),
        col("source"),
        col("source_type"))
      )
      .withColumn("payer_type", upper(crosswalkDerivatives.payerType(
        col("source_financial_class"),
        col("customer"),
        col("source"),
        col("source_type")))
      )

    assert(personWithPatientType.select("payer_type").first.getString(0) == "MK")
  }

  it should "Correctly calculate Revenue when gross_margin is null from financials for customer" in {

    val crosswalkDataContext: CrosswalkData =
      CrosswalkData(spark: SparkSession)

    val crosswalkDerivatives = CrosswalkDerivatives(crosswalkDataContext)

    val p1 = Row("christus", personId, "athena", "athena", "MC", "MEDICARE", 1550.00, null)

    val a = spark.sparkContext.parallelize(Seq(p1))

    val schema = StructType(List(
      StructField("customer", StringType, false),
      StructField("person_id", StringType, false),
      StructField("source", StringType, false),
      StructField("source_type", StringType, false),
      StructField("source_financial_class_id", StringType, false),
      StructField("source_financial_class", StringType, false),
      StructField("charges", DoubleType, false),
      StructField("gross_margin", DecimalType(38,18), true)
    ))

    val allActivityPersonDf = spark.createDataFrame(a, schema)

    val personWithPatientType = allActivityPersonDf
      .withColumn("gross_margin", when(col("gross_margin").isNull && col("charges").isNotNull, crosswalkDerivatives.profitProxy(
      col("source_financial_class"),
      col("customer"),
      col("source"),
      col("source_type"),
      col("charges"))).otherwise(col("gross_margin"))
    )
    personWithPatientType.select("gross_margin").first.getDecimal(0) shouldBe new java.math.BigDecimal("77.500000000000000000")
  }

  it should "Use Revenue from financials if it is provided by customer" in {

    val crosswalkDataContext: CrosswalkData =
      CrosswalkData(spark: SparkSession)

    val crosswalkDerivatives = CrosswalkDerivatives(crosswalkDataContext)

    val p1 = Row("christus", personId, "athena", "athena", "MC", "MEDICARE", 1550.00, new java.math.BigDecimal("65.500000000000000000"))

    val a = spark.sparkContext.parallelize(Seq(p1))

    val schema = StructType(List(
      StructField("customer", StringType, false),
      StructField("person_id", StringType, false),
      StructField("source", StringType, false),
      StructField("source_type", StringType, false),
      StructField("source_financial_class_id", StringType, false),
      StructField("source_financial_class", StringType, false),
      StructField("charges", DoubleType, false),
      StructField("gross_margin", DecimalType(38,18), false)
    ))

    val allActivityPersonDf = spark.createDataFrame(a, schema)

    val personWithPatientType = allActivityPersonDf
      .withColumn("gross_margin", when(col("gross_margin").isNull && col("charges").isNotNull, crosswalkDerivatives.profitProxy(
        col("source_financial_class"),
        col("customer"),
        col("source"),
        col("source_type"),
        col("charges"))).otherwise(col("gross_margin"))
    )
    personWithPatientType.select("gross_margin").first.getDecimal(0) shouldBe new java.math.BigDecimal("65.500000000000000000")
  }

  it should "Correctly set deceased_flag and opt_out_direct_mail using discharge_status " in {

    val crosswalkDataContext: CrosswalkData =
      CrosswalkData(spark: SparkSession)

    val crosswalkDerivatives = CrosswalkDerivatives(crosswalkDataContext)

    val p1 = Row("chomp", personId, "SEM", "Hospital", "9020", "null", "03", "20", null)

    val a = spark.sparkContext.parallelize(Seq(p1))

    val schema = StructType(List(
      StructField("customer", StringType, false),
      StructField("person_id", StringType, false),
      StructField("source", StringType, false),
      StructField("source_type", StringType, false),
      StructField("financial_class_id_orig", StringType, false),
      StructField("financial_class_orig", StringType, false),
      StructField("source_exclusion_flag", StringType, false),
      StructField("source_discharge_status", StringType, false),
      StructField("date_of_death", TimestampType)

    ))

    val allActivityPersonDf = spark.createDataFrame(a, schema)

    val personWithPatientType = allActivityPersonDf
      .withColumn("discharge_status", crosswalkDerivatives.dischargeStatus(
        col("source_discharge_status"))
      )
      .withColumn("exclusion_flag", crosswalkDerivatives.exclusionFlag(
        col("source_exclusion_flag"),
        col("customer"),
        col("source"),
        col("source_type"))
      )
      .withColumn("deceased_flag", crosswalkDerivatives.deceasedFlag(
        col("discharge_status"),
        col("exclusion_flag"),
        col("date_of_death"))
      )
      .withColumn("opt_out_direct_mail", crosswalkDerivatives.dnsBool(
        col("discharge_status"),
        col("exclusion_flag"))
      )

    assert(personWithPatientType.select("deceased_flag").first.getBoolean(0))

  }

  it should "Correctly set opt_out_direct_mail using discharge_status " in {

    val crosswalkDataContext: CrosswalkData =
      CrosswalkData(spark: SparkSession)

    val crosswalkDerivatives = CrosswalkDerivatives(crosswalkDataContext)

    val p1 = Row("chomp", personId, "SEM", "Hospital", "9020", "null", "2", "21", null)

    val a = spark.sparkContext.parallelize(Seq(p1))

    val schema = StructType(List(
      StructField("customer", StringType, false),
      StructField("person_id", StringType, false),
      StructField("source", StringType, false),
      StructField("source_type", StringType, false),
      StructField("financial_class_id_orig", StringType, false),
      StructField("financial_class_orig", StringType, false),
      StructField("source_exclusion_flag", StringType, false),
      StructField("source_discharge_status", StringType, false),
      StructField("date_of_death", TimestampType)

    ))

    val allActivityPersonDf = spark.createDataFrame(a, schema)

    val personWithPatientType = allActivityPersonDf
      .withColumn("discharge_status", crosswalkDerivatives.dischargeStatus(
        col("source_discharge_status"))
      )
      .withColumn("exclusion_flag", crosswalkDerivatives.exclusionFlag(
        col("source_exclusion_flag"),
        col("customer"),
        col("source"),
        col("source_type"))
      )
      .withColumn("deceased_flag", crosswalkDerivatives.deceasedFlag(
        col("discharge_status"),
        col("exclusion_flag"),
        col("date_of_death"))
      )
      .withColumn("opt_out_direct_mail", crosswalkDerivatives.dnsBool(
        col("discharge_status"),
        col("exclusion_flag"))
      )

    assert(personWithPatientType.select("opt_out_direct_mail").first.getBoolean(0))

  }

  it should "Correctly set deceased_flag and opt_out_direct_mail using exclusion_flag " in {

    val crosswalkDataContext: CrosswalkData =
      CrosswalkData(spark: SparkSession)

    val crosswalkDerivatives = CrosswalkDerivatives(crosswalkDataContext)

    val p1 = Row("chomp", personId, "SEM", "Hospital", "9020", "null", "1", "06", null)

    val a = spark.sparkContext.parallelize(Seq(p1))

    val schema = StructType(List(
      StructField("customer", StringType, false),
      StructField("person_id", StringType, false),
      StructField("source", StringType, false),
      StructField("source_type", StringType, false),
      StructField("financial_class_id_orig", StringType, false),
      StructField("financial_class_orig", StringType, false),
      StructField("source_exclusion_flag", StringType, false),
      StructField("source_discharge_status", StringType, false),
      StructField("date_of_death", TimestampType)

    ))

    val allActivityPersonDf = spark.createDataFrame(a, schema)

    val personWithPatientType = allActivityPersonDf
      .withColumn("discharge_status", crosswalkDerivatives.dischargeStatus(
        col("source_discharge_status"))
      )
      .withColumn("exclusion_flag", crosswalkDerivatives.exclusionFlag(
        col("source_exclusion_flag"),
        col("customer"),
        col("source"),
        col("source_type"))
      )
      .withColumn("deceased_flag", crosswalkDerivatives.deceasedFlag(
        col("discharge_status"),
        col("exclusion_flag"),
        col("date_of_death"))
      )

    assert(personWithPatientType.select("deceased_flag").first.getBoolean(0))
  }
}
