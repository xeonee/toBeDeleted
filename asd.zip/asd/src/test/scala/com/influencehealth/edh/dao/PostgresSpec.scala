package com.influencehealth.edh.dao

import java.io.File
import java.sql.{Date, Timestamp}

import com.influencehealth.edh.Constants
import com.influencehealth.edh.model._
import com.influencehealth.edh.test.database.PostgresSpecBase
import com.influencehealth.edh.test.spark.SparkSpecBase
import com.influencehealth.edh.updater.PersonUpdater
import org.apache.spark.sql.Dataset
import org.scalatest.{BeforeAndAfterEach, FlatSpec, Ignore, Matchers}
import com.typesafe.config.{Config, ConfigFactory}
import com.influencehealth.edh.BaldurApplication
import com.influencehealth.edh.config.CleanseJobConfig
import com.influencehealth.edh.lookups.client.LookupsClient
import org.apache.spark.sql.SparkSession

@Ignore
class PostgresSpec extends FlatSpec with PostgresSpecBase with SparkSpecBase with BeforeAndAfterEach with Matchers {

  override def afterEach(): Unit = {
    databaseDao.deleteCustomersActivities("tanner")
    databaseDao.deleteCustomersPersons("tanner")
    super.afterEach()
  }

  it should "save person and activities data with simple types into Postgres" in {

    import spark.implicits._

    val persons: Dataset[Person] = spark.sparkContext.parallelize(
      Seq(
        Person(
          customer = "tanner",
          personId = "person1",
          dateCreated = new Timestamp(System.currentTimeMillis()),
          locations = Seq(PersonLocation("location1", 1), PersonLocation("location2", 2)),
          addressCoordinates = Some(Coordinates(lon = -73.989308f, lat = 40.741895f))
        )
      )
    ).toDS()

    val activities: Dataset[Activity] = spark.sparkContext.parallelize(
      Seq(
        Activity(
          customer = "tanner",
          activityId = "activity1",
          personId = Some("person1"),
          batchId = "batch1",
          sourceRecordId = None,
          sourcePersonId = None,
          dateCreated = new Timestamp(System.currentTimeMillis()),
          activityDate = new Date(System.currentTimeMillis()),
          diagnosisCodes = Seq(ActivityMedicalCode(
            medicalCode = "diagnosis 1",
            medicalCodeType = "10",
            sequenceNumber = 1
          )),
          procedureCodes = Seq(ActivityMedicalCode(
            medicalCode = "diagnosis 1",
            medicalCodeType = "10",
            sequenceNumber = 1
          )),
          currentProceduralTerminologyCodes = Seq(ActivityMedicalCode(
            medicalCode = "diagnosis 1",
            medicalCodeType = "10",
            sequenceNumber = 1
          )),
          assessmentResults = Seq(AssessmentResults(
            variable = "value",
            value = "variable"
          )),
          profit = Some(new java.math.BigDecimal("2073.00"))
        ),
        Activity(
          customer = "tanner",
          activityId = "activity2",
          personId = Some("person1"),
          batchId = "batch1",
          sourceRecordId = None,
          sourcePersonId = None,
          dateCreated = new Timestamp(System.currentTimeMillis()),
          activityDate = new Date(System.currentTimeMillis()),
          profit = Some(new java.math.BigDecimal("2073.00")),
          addressCoordinates = Some(Coordinates(lat = 38.8951f, lon = -77.0364f))
        )
      )
    ).toDS()

    databaseDao.savePersonsAndActivities(persons, activities)
    val savedActivities = databaseDao.getActivitiesByCustomer("tanner")
    savedActivities.count() shouldEqual 2
    val savedPersons = databaseDao.getPersonsByCustomer("tanner")

    savedPersons.count() shouldEqual 1
    savedPersons.head().addressCoordinates.get.lat shouldBe 40.741895f
    savedPersons.head().addressCoordinates.get.lon shouldBe -73.989308f

    savedActivities.head().diagnosisCodes.head.medicalCode shouldEqual "diagnosis 1"
    savedActivities.head().diagnosisCodes.head.medicalCodeType shouldEqual "10"
    savedActivities.head().diagnosisCodes.head.sequenceNumber shouldEqual 1

    savedActivities.head().procedureCodes.head.medicalCode shouldEqual "diagnosis 1"
    savedActivities.head().procedureCodes.head.medicalCodeType shouldEqual "10"
    savedActivities.head().procedureCodes.head.sequenceNumber shouldEqual 1

    savedActivities.head().currentProceduralTerminologyCodes.head.medicalCode shouldEqual "diagnosis 1"
    savedActivities.head().currentProceduralTerminologyCodes.head.medicalCodeType shouldEqual "10"
    savedActivities.head().currentProceduralTerminologyCodes.head.sequenceNumber shouldEqual 1

    savedActivities.head().assessmentResults.head.variable shouldEqual "value"
    savedActivities.head().assessmentResults.head.value shouldEqual "variable"

  }

  it should "extract persons from activities and save them into Postgres" in {

    import spark.implicits._

    val activities: Dataset[Activity] = spark.sparkContext.parallelize(
      Seq(
        Activity(
          customer = "tanner",
          activityId = "activity1",
          personId = Some("person1"),
          batchId = "batch1",
          sourceRecordId = None,
          sourcePersonId = None,
          dateCreated = new Timestamp(System.currentTimeMillis()),
          activityDate = new Date(System.currentTimeMillis()),
          diagnosisCodes = Seq(ActivityMedicalCode(
            medicalCode = "diagnosis 1",
            medicalCodeType = "code 1",
            sequenceNumber = 0
          )),
          mobilePhone = Some("4041234567")
        ),
        Activity(
          customer = "tanner",
          activityId = "activity2",
          personId = Some("person2"),
          batchId = "batch1",
          sourceRecordId = None,
          sourcePersonId = None,
          dateCreated = new Timestamp(System.currentTimeMillis()),
          activityDate = new Date(System.currentTimeMillis()),
          censusTract = Some("TEST"),
          homePhone = Some("4041234567"),
          workPhone = Some("123456")
        )
      )
    ).toDS()

    val persons = PersonUpdater.getPersons(activities)
    databaseDao.savePersonsAndActivities(persons, activities)

    databaseDao.getActivitiesByCustomer("tanner").count() shouldEqual 2
    val databasePersons = databaseDao.getPersonsByCustomer("tanner")

    databasePersons.count() shouldEqual 2

    databasePersons.
      filter(p => p.personId == "person1" &&
        p.primaryPhoneNumberType.contains(Constants.PhoneTypeMobile)).count() shouldEqual 1

    databasePersons.
      filter(p => p.personId == "person2" &&
        p.primaryPhoneNumberType.contains(Constants.PhoneTypeHome)).count() shouldEqual 1

    val person1PhonePreference = databasePersons.filter(p => p.personId == "person1")
      .map(_.phoneNumbers).collect().head.head

    person1PhonePreference.phone shouldEqual "4041234567"
    person1PhonePreference.phoneType shouldEqual Constants.PhoneTypeMobile

    val person2PhonePreferences: Seq[PersonPhoneNumber] = databasePersons.filter(p => p.personId == "person2")
      .map(_.phoneNumbers).collect().head

    person2PhonePreferences shouldEqual Array(
      PersonPhoneNumber(phone = "4041234567", Constants.PhoneTypeHome),
      PersonPhoneNumber(phone = "123456", phoneType = Constants.PhoneTypeWork)
    )

  }

  it should "save person into Postgres and correctly parse personLocations data from postgres" in {

    import spark.implicits._

    val persons: Dataset[Person] = spark.sparkContext.parallelize(
      Seq(
        Person(
          customer = "tanner",
          personId = "person1",
          dateCreated = new Timestamp(System.currentTimeMillis()),
          locations = Seq(PersonLocation("location1", 1), PersonLocation("location2", 2))
        )
      )
    ).toDS()


    databaseDao.savePersons(persons)
    val databasePersons = databaseDao.getPersonsByCustomer("tanner")
    databasePersons.count() shouldEqual 1

    val personLocations: Dataset[PersonLocation] = databasePersons.flatMap(p => p.locations)
    personLocations.count() shouldEqual 2

    personLocations.head().location shouldEqual "location1"
    personLocations.head().preference shouldEqual 1

    personLocations.take(2)(1).location shouldEqual "location2"
    personLocations.take(2)(1).preference shouldEqual 2

  }


  it should "save person into Postgres and correctly parse phoneNumbers data from postgres" in {

    import spark.implicits._

    val persons: Dataset[Person] = spark.sparkContext.parallelize(
      Seq(
        Person(
          customer = "tanner",
          personId = "person1",
          dateCreated = new Timestamp(System.currentTimeMillis()),
          phoneNumbers = Seq(
            PersonPhoneNumber("5555555", Constants.PhoneTypeMobile),
            PersonPhoneNumber("111111", Constants.PhoneTypeHome)
          )
        )
      )
    ).toDS()

    databaseDao.savePersons(persons)
    val databasePersons = databaseDao.getPersonsByCustomer("tanner")
    databasePersons.count() shouldEqual 1

    val phoneNumbers: Dataset[PersonPhoneNumber] = databasePersons.flatMap(p => p.phoneNumbers)
    phoneNumbers.count() shouldEqual 2

    phoneNumbers.head().phone shouldEqual "5555555"
    phoneNumbers.head().phoneType shouldEqual Constants.PhoneTypeMobile

    phoneNumbers.take(2)(1).phone shouldEqual "111111"
    phoneNumbers.take(2)(1).phoneType shouldEqual Constants.PhoneTypeHome

  }


  it should "save person into Postgres and correctly parse emails data from postgres" in {

    import spark.implicits._

    val persons: Dataset[Person] = spark.sparkContext.parallelize(
      Seq(
        Person(
          customer = "tanner",
          personId = "person1",
          dateCreated = new Timestamp(System.currentTimeMillis()),
          emails = Seq("blablba@company.com", "blablba@company.com")
        )
      )
    ).toDS()

    databaseDao.savePersons(persons)
    val databasePersons = databaseDao.getPersonsByCustomer("tanner")
    databasePersons.count() shouldEqual 1

    val emails: Dataset[String] = databasePersons.flatMap(p => p.emails)
    emails.count() shouldEqual 2

    emails.head() shouldEqual "blablba@company.com"

    emails.take(2)(1) shouldEqual "blablba@company.com"

  }

  it should "save a person into Postgres then update it " in {

    import spark.implicits._

    val persons: Dataset[Person] = spark.sparkContext.parallelize(
      Seq(
        Person(
          customer = "tanner",
          personId = "person1",
          dateCreated = new Timestamp(System.currentTimeMillis()),
          locations = Seq(PersonLocation("location1", 1), PersonLocation("location2", 2))
        )
      )
    ).toDS()

    databaseDao.savePersons(persons)
    val databasePersons = databaseDao.getPersonsByCustomer("tanner")
    databasePersons.count() shouldEqual 1

    val updatedPersons = persons.map(p =>
      p.copy(locations = p.locations.map(pl => PersonLocation(pl.location, pl.preference + 1)))
    )

    databaseDao.savePersons(updatedPersons)
    val updatedDatabasePersons = databaseDao.getPersonsByCustomer("tanner")
    updatedDatabasePersons.count() shouldEqual 1

    val personLocations: Dataset[PersonLocation] = updatedDatabasePersons.flatMap(p => p.locations)
    personLocations.count() shouldEqual 2

    personLocations.head().location shouldEqual "location1"
    personLocations.head().preference shouldEqual 2

    personLocations.take(2)(1).location shouldEqual "location2"
    personLocations.take(2)(1).preference shouldEqual 3
  }

  it should "correctly fetch persons and activities from Postgres using batchId" in {

    import spark.implicits._

    val persons: Dataset[Person] = spark.sparkContext.parallelize(
      Seq(
        Person(
          customer = "tanner",
          personId = "person1",
          dateCreated = new Timestamp(System.currentTimeMillis())
        )
      )
    ).toDS()

    val activities: Dataset[Activity] = spark.sparkContext.parallelize(
      Seq(
        Activity(
          customer = "tanner",
          activityId = "activity1",
          personId = Some("person1"),
          batchId = "batch1",
          sourceRecordId = None,
          sourcePersonId = None,
          dateCreated = new Timestamp(System.currentTimeMillis()),
          activityDate = new Date(System.currentTimeMillis()),
          diagnosisCodes = Seq(ActivityMedicalCode(
            medicalCode = "diagnosis 1",
            medicalCodeType = "code 1",
            sequenceNumber = 0
          )),
          profit = Some(new java.math.BigDecimal("2073.00"))
        ),
        Activity(
          customer = "tanner",
          activityId = "activity2",
          personId = Some("person1"),
          batchId = "batch1",
          sourceRecordId = None,
          sourcePersonId = None,
          dateCreated = new Timestamp(System.currentTimeMillis()),
          activityDate = new Date(System.currentTimeMillis()),
          profit = Some(new java.math.BigDecimal("2073.00"))
        )
      )
    ).toDS()

    databaseDao.savePersonsAndActivities(persons, activities)
    databaseDao.getActivitiesByBatchId("batch1").count() shouldEqual 2

    val savedPersonsWithActivities = databaseDao.getPersonsByBatchId("batch1")
    savedPersonsWithActivities.count() shouldEqual 1
    savedPersonsWithActivities.flatMap(_.activities).count() shouldEqual 2

    val savedPersons = databaseDao.getPersonsByBatchId("batch1", full = false)
    savedPersons.count() shouldEqual 1
    savedPersons.flatMap(_.activities).count() shouldEqual 0

  }

  it should "save sg2 data and correctly parse it from postgres" in {

    import spark.implicits._

    val persons: Dataset[Person] = spark.sparkContext.parallelize(
      Seq(
        Person(
          customer = "tanner",
          personId = "person1",
          dateCreated = new Timestamp(System.currentTimeMillis())
        )
      )
    ).toDS()

    val activities: Dataset[Activity] = spark.sparkContext.parallelize(
      Seq(
        Activity(
          customer = "tanner",
          activityId = "activity1",
          personId = Some("person1"),
          batchId = "batch1",
          sourceRecordId = None,
          sourcePersonId = None,
          dateCreated = new Timestamp(System.currentTimeMillis()),
          activityDate = new Date(System.currentTimeMillis()),
          sg2 = Some(SG2(
            careGroupCode = Some("careGroupCode 1"),
            careFamily = Some("careFamily 1"),
            addictionAdult = Some("alcohol")
          ))
        ),
        Activity(
          customer = "tanner",
          activityId = "activity2",
          personId = Some("person1"),
          batchId = "batch1",
          sourceRecordId = None,
          sourcePersonId = None,
          dateCreated = new Timestamp(System.currentTimeMillis()),
          activityDate = new Date(System.currentTimeMillis()),
          sg2 = None
        )
      )
    ).toDS()

    databaseDao.savePersonsAndActivities(persons, activities)
    val savedActivities = databaseDao.getActivitiesByCustomer("tanner")
    savedActivities.count() shouldEqual 2
    databaseDao.getPersonsByCustomer("tanner").count() shouldEqual 1

    savedActivities.head().sg2.flatMap(_.careGroupCode).get shouldEqual "careGroupCode 1"
    savedActivities.head().sg2.flatMap(_.addictionAdult).get shouldEqual "alcohol"

    savedActivities.take(2).last.sg2.isEmpty shouldBe true
  }

  it should "save addresses into Postgres and fetch them using zip5" in {

    import spark.implicits._

    val addresses: Dataset[Address] = spark.createDataset(Seq(
      Address(
        customer = "tanner",
        addressId = "id1",
        address1 = "address1",
        city = "Atlanta",
        state = "GA",
        zip5 = "30309",
        addressCoordinates = Coordinates(lat = 38.8951f, lon = -77.0364f)
      ),
      Address(
        customer = "tanner",
        addressId = "id2",
        address1 = "address2",
        city = "Atlanta",
        state = "GA",
        zip5 = "30309",
        addressCoordinates = Coordinates(lat = 38.8951f, lon = -77.0364f)
      ),
      Address(
        customer = "tanner",
        addressId = "id3",
        address1 = "address3",
        city = "Atlanta",
        state = "GA",
        zip5 = "30312",
        addressCoordinates = Coordinates(lat = 38.8951f, lon = -77.0364f)
      ),
      Address(
        customer = "tanner",
        addressId = "id4",
        address1 = "address4",
        city = "Atlanta",
        state = "GA",
        zip5 = "30312",
        addressCoordinates = Coordinates(lat = 38.8951f, lon = -77.0364f)
      )
    ))

    databaseDao.saveAddresses(addresses)

    databaseDao.searchAddressesByZipCodes(Set.empty[String]).count() shouldEqual 0
    val savedAddresses = databaseDao.searchAddressesByZipCodes(Set("30309"))
    savedAddresses.count() shouldEqual 2
    databaseDao.searchAddressesByZipCodes(Set("30312")).count() shouldEqual 2
    databaseDao.searchAddressesByZipCodes(Set("30300")).count() shouldEqual 0

    savedAddresses.head().addressCoordinates.lat shouldEqual 38.8951f
    savedAddresses.head().addressCoordinates.lon shouldEqual -77.0364f
  }

  it should "save a record into jobHistory table in Postgres database once job is successful" in {
    val configCleanseDefaultReference: String =
      "src/test/resources/config/jobhistory.configuration/tanner-load-default.conf"

    var cleanseDefaultConfig: Config = ConfigFactory.parseFile(new File(configCleanseDefaultReference)).resolve()
    val cleanseConfig: CleanseJobConfig = CleanseJobConfig(cleanseDefaultConfig)

    val job = new TestApplication()

    val batchId = "tanner-callcenter-conifer-2017-12"

    job.saveJobResult(spark,
      databaseDao,
      timeStarted = new Timestamp(System.currentTimeMillis),
      jobConfig = cleanseConfig)

    val jobHistory = databaseDao.searchJobHistoryByBatchId(batchId)

    jobHistory.length shouldEqual 1
    jobHistory.head.jobStatus shouldEqual "COMPLETED"
    jobHistory.head.activityType shouldEqual "callcenter"
    jobHistory.head.customer shouldEqual "tanner"
    jobHistory.head.jobCommand shouldEqual
      "cdp load activitypipeline -p large -e test -c tanner -b 'tanner-callcenter-conifer-2017-12'"

  }

  class TestApplication extends BaldurApplication[CleanseJobConfig] {
    override def runJob(implicit sparkSession: SparkSession, cleanseJobConfig: CleanseJobConfig,
                        databaseDao: DatabaseDao) = {}
    override def buildConfig(appConfig: Config, lookupsClient: LookupsClient): CleanseJobConfig = {
      CleanseJobConfig(appConfig)
    }
    override def countInputRecords = {None}
    override def countOutputRecords = {None}
  }

}

