package com.influencehealth.edh.cleanse.employeeroster

import com.influencehealth.edh.dao.FileSystemDao
import com.influencehealth.edh.model.schema.EmployeeRosterSchema
import com.influencehealth.edh.test.spark.SparkSpecBase
import com.influencehealth.edh.{AppCleanser, Constants}
import org.apache.spark.sql.{DataFrame, Row}
import org.scalamock.scalatest.MockFactory
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}

class CleanseEmployeeRosterSpec extends FlatSpec with SparkSpecBase with BeforeAndAfter with Matchers with MockFactory {

  val InputDirectoryPath: String = "fixtures/cleanse/employeeroster/"
  val DateBatchReceived: String = "11/01/2017"
  val Customer: String = "chomp"
  val BatchId = "chomp-employeeroster-influencehealth-2017-11"

  var incomingEmployeeRosterRawRecordsDf: DataFrame = _
  var cleansedDataFrame: DataFrame = _
  var dirtyDataFrame: DataFrame = _

  it should "cleanse all data" in {

    // TODO: Add in test to check header is being removed
    // Row( "EMPLOYEE_ID" , "NPI" , "PREFIX" , "LAST_NAME" , "FIRST_NAME" , "MIDDLE_NAME" , "PERSONAL_SUFFIX" , "PROFESSIONAL_SUFFIX" , "ADDRESS1" , "ADDRESS2" , "CITY" , "STATE" , "ZIP" , "COUNTRY" , "SEX" , "DOB" , "HOME_PHONE" , "MOBILE_PHONE" , "WORK_PHONE" , "WORK_EMAIL" , "PERSONAL_EMAIL" , "RACE_CODE" , "RACE_DESC" , "HOSPITAL_ID" , "HOSPITAL_DESC" , "BUSINESS_UNIT" , "BUSINESS_UNIT_DESC" , "SITE_ID" , "SITE_DESC" , "CLINIC_ID" , "CLINIC_DESC" , "PRACTICE_LOCATION_ID" , "PRACTICE_LOCATION_DESC" , "JOB_TITLE_CODE" , "JOB_TITLE_DESC" , "JOB_FAMILY_CODE" , "JOB_FAMILY_DESC" , "STATUS_CODE" , "STATUS_DESC" , "DATE_HIRED" , "TERMINATION_DATE" ),
    val rawData: DataFrame = spark.createDataFrame(spark.sparkContext.parallelize(Seq(
        Row( "101593" ,null,null, "Silva" , "Andrea" , " " ,null,null, "123 Fire Ridge" , " " , "New Braunfels" , "TX" , "78130" , "US" , "F" , "03/16/1980" , "8303785826" ,null, "5972002   " , "e37440@sample.org" ,null, "1" , "Hispanic or Latino" , "670" , "Dedicated System Support Inc." ,null,null,null,null, "GK428702DS" , "CHRISTUS SR PASC-San Marcos" ,null,null, "301250" , "Endoscopy Tech" , "301" , "ORTECH" , "A" , "Active" , "01/03/2012 00:00:00" , "12/27/2012 00:00:00" ),
        Row( "104207" ,null,null, "F" , "Sylvia" , " " ,null,null, "345 Water Grove Drive" , " " , "San Antonio" , "TX" , "78245" , "US" , "F" , "08/08/1983" , "2109791258" ,null,null, "e37441@sample.org" ,null, "1" , "Hispanic or Latino" , "300" , "CHRISTUS Health Santa Rosa" ,null,null,null,null, "GC304202A" , "Rch Nicu Level Iii" ,null,null, "200000" , "Rn" , "200" , "BEDRN" , "A" , "Active" , "12/16/2013 00:00:00" ,null),
        Row( "104227" ,null,null, "Durastanti" , "M" , "M" ,null,null, "5959 Wanda Trail" , " " , "Ball" , "LA" , "71405" , "US" , "F" , "07/19/1984" , "3183211233" ,null,null, "e37442@sample.org" ,null, "1" , "Hispanic or Latino" , "400" , "CHRISTUS Health CLA" ,null,null,null,null, "CB451501A" , "Cfc Retail Pharmacy" ,null,null, "321010" , "Pharmacy Technician I Cert-Reg" , "321" , "PHRMTC" , "A" , "Active" , "12/09/2013 00:00:00" ,null),
        Row( "102017" ,null,null, "Sol" , "Guadalupe" , " " ,null,null, "100 Longmeadow" , " " , "Coppell" , "TX" , "75019" , "US" , "F" , "12/12/1960" , "2144190015" ,null,null, "e37443@sample.org" ,null, "1" , "Hispanic or Latino" , "001" , "CHRISTUS Health" ,null,null,null,null, "AB600115A" , "CRP Legal Services and Board S" ,null,null, "351550" , "Corp Paralegal II" , "351" , "RESSPT" , "A" , "Active" , "06/10/2013 00:00:00" ,null),
        Row( "102020" ,null,null, "Wagg" , "Amber" , "L" ,null,null, "7177 brookedge lane" , " " , "Corpus Christi" , "TX" , "78414" , "US" , "F" , "11/27/1988" , "3612151367" ,null,null, "e37444@sample.org" ,null, "1" , "Hispanic or Latino" , "250" , "CHRISTUS Health SPOHN" ,null,null,null,null, "HB301102A" , "Ssh Icu/Micu 3" ,null,null, "200000" , "Rn" , "200" , "BEDRN" , "A" , "Active" , "06/10/2013 00:00:00" ,null),
        Row( "102022" ,null,null, "G" , "Lucinda" , " " ,null,null, "600 N. Palo Blanco St." , " " , "Falfurrias" , "TX" , "78355" , "US" , "F" , "07/15/1983" , "3614067037" ,null,null, "e37445@sample.org" ,null, "1" , "Hispanic or Latino" , "250" , "CHRISTUS Health SPOHN" ,null,null,null,null, "HE310204A" , "Skm Med/Surg(Pedi/Adult)" ,null,null, "300010" , "Lvn" , "300" , "LPNLVN" , "A" , "Active" , "06/10/2013 00:00:00" ,null),
        Row( "102023" ,null,null, "TT" , "R" , " " ,null,null, "200 N. Co Rd 1035" , " " , "Kingsville" , "TX" , "78363" , "US" , "F" , "02/09/1977" , "3615526663" ,null,null, "e37446@sample.org" ,null, "1" , "Hispanic or Latino" , "250" , "CHRISTUS Health SPOHN" ,null,null,null,null, "HE301101A" , "Skm Icu/Micu" ,null,null, "200000" , "Rn" , "200" , "BEDRN" , "A" , "Active" , "06/10/2013 00:00:00" ,null),
        Row( "102041" ,null,null, "V" , "Lucia" , "V." ,null,null, "3250 Austin Street" , " " , "Corpus Christi" , "TX" , "78404" , "US" , "F" , "12/27/1954" , "3617394878" ,null,null, "e37447@sample.org" ,null, "1" , "Hispanic or Latino" , "250" , "CHRISTUS Health SPOHN" ,null,null,null,null, "HB458101A" , "Ssh Endoscopy /G.I." ,null,null, "200000" , "Rn" , "200" , "BEDRN" , "A" , "Active" , "04/22/1991 00:00:00" , "12/04/2013 00:00:00" ),
        Row( "102042" ,null,null, "Varnell" , "Margarita" , " " ,null,null, "190 county road 147" , " " , "alice" , "TX" , "78332" , "US" , "F" , "01/05/1991" , "3617778828" ,null,null, "e37448@sample.org" ,null, "1" , "Hispanic or Latino" , "250" , "CHRISTUS Health SPOHN" ,null,null,null,null, "HB428101A" , "Ssh Surgery-General" ,null,null, "200000" , "Rn" , "200" , "BEDRN" , "A" , "Active" , "06/10/2013 00:00:00" ,null),
        Row( "102039" ,null,null, "McClanahan" , "Jo" , " " ,null,null, "1910 Barlow Trail" , " " , "Corpus Christi" , "TX" , "78410" , "US" , "F" , "07/31/1987" , "3617379010" ,null,null, "e37449@sample.org" ,null, "1" , "Hispanic or Latino" , "250" , "CHRISTUS Health SPOHN" ,null,null,null,null, "HC400101A" , "Smh Emergency Room" ,null,null, "322200" , "Emergency Dept Tech" , "322" , "EMTECH" , "A" , "Active" , "06/10/2013 00:00:00" , "01/31/2016 00:00:00" ),
        Row( "104599" ,null,null, "An" , "Andrea" , "E" ,null,null, "21308 Encino Commons" , "2508" , "San Antonio" , "TX" , "78259" , "US" , "F" , "07/28/1988" , "2103248856" ,null,null, "e37450@sample.org" ,null, "1" , "Hispanic or Latino" , "300" , "CHRISTUS Health Santa Rosa" ,null,null,null,null, "GC314102A" , "Rch Pedi Acute 2" ,null,null, "200030" , "Rn Prn" , "200" , "RN" , "A" , "Active" , "01/27/2014 00:00:00" ,null),
        Row( "104609" ,null,null, "Kot" , "Christian" , "R" ,null,null, "5428 Chestnut View Dr" , " " , "San Antonio" , "TX" , "78247" , "US" , "M" , "01/23/1986" , "2106571510" ,null,null, "e37451@sample.org" ,null, "1" , "Hispanic or Latino" , "300" , "CHRISTUS Health Santa Rosa" ,null,null,null,null, "GI310401A" , "Rwh Surgical Care Unit" ,null,null, "200150" , "RN Charge Nurse" , "200" , "BEDRN" , "A" , "Active" , "01/27/2014 00:00:00" , "10/20/2014 00:00:00" ),
        Row( "103503" ,null,null, "Camp" , "Angelica" , " " ,null,null, "3333 scarlet ohara" , " " , "San Antonio" , "TX" , "78233" , "US" , "F" , "11/28/1975" ,null,null,null, "e37452@sample.org" ,null, "1" , "Hispanic or Latino" , "300" , "CHRISTUS Health Santa Rosa" ,null,null,null,null, "GO310101A" , "Ras Med/Surg-Surgry" ,null,null, "505000" , "Unit Secretary" , "505" , "UNTSEC" , "A" , "Active" , "09/23/2013 00:00:00" , "02/03/2015 00:00:00" ),
        Row( "103887" ,null,null, "Beran" , "P" , " " ,null,null, "1016 Fillmore Dr." , " " , "San Antonio" , "TX" , "78245" , "US" , "M" , "04/28/1977" ,null,null,null, "e37453@sample.org" ,null, "1" , "Hispanic or Latino" , "300" , "CHRISTUS Health Santa Rosa" ,null,null,null,null, "GC428101A" , "Rch Surgery-General" ,null,null, "301150" , "Surgical Technician Cert" , "301" , "ORTECH" , "A" , "Active" , "10/21/2013 00:00:00" ,null),
        Row( "102530" ,null,null, "Rodguez" , "Aida" , "M" ,null,null, "7508 Foxwood" , " " , "San Antonio" , "TX" , "78238" , "US" , "F" , "09/25/1988" , "2106471853" ,null,null, "e37454@sample.org" ,null, "1" , "Hispanic or Latino" , "300" , "CHRISTUS Health Santa Rosa" ,null,null,null,null, "GI310501A" , "Rwh Med/Surg E" ,null,null, "200000" , "Rn" , "200" , "BEDRN" , "A" , "Active" , "07/15/2013 00:00:00" ,null),
        Row( "100103" ,null,null, "Lael" , "Teresa" , " " ,null,null, "17224 Darien Wing" , " " , "San Antonio" , "TX" , "78247" , "US" , "F" , "09/10/1970" ,null,null,null, "e37455@sample.org" ,null, "1" , "Hispanic or Latino" , "300" , "CHRISTUS Health Santa Rosa" ,null,null,null,null, "GN840301A" , "Rfd Fund Raising" ,null,null, "134921" , "Dir Foundation Strat Mkg Comm" , "134" , "DIRCTR" , "A" , "Active" , "02/11/2013 00:00:00" ,null),
        Row( "103036" ,null,null, "Caano" , "E" , "B" ,null,null, "6612 Madeleine Dr" , " " , "San Antonio" , "TX" , "78229" , "US" , "F" , "06/15/1954" , "2108495807" ,null,null, "e37456@sample.org" ,null, "1" , "Hispanic or Latino" , "300" , "CHRISTUS Health Santa Rosa" ,null,null,null,null, "GC836401A" , "Rch Quality" ,null,null, "232011" , "Quality Analyst I" , "232" , "QASPEC" , "A" , "Active" , "09/09/2013 00:00:00" ,null),
        Row( "100166" ,null,null, "Jaes" , "K" , " " ,null,null, "13556 Thousand Oaks" , " " ,null, "TX" , "77713" , "US" , "F" , "02/14/1991" ,null,null,null, "e37457@sample.org" ,null, "1" , "Hispanic or Latino" , "005" , "CHRISTUS Health SETX" ,null,null,null,null, "FB428701A" , "Tel Ambultry Surg 2" ,null,null, "200030" , "Rn Prn" , "200" , "RN" , "A" , "Active" , "03/11/2013 00:00:00" ,null),
        Row( "100434" ,null,null, "Guerrez" , "R" , " " ,null,null, "2407 January Ln" , " " , "Grand Prairie" ,null, "75050" , "US" , "F" , "02/02/1976" ,null,null,null, "e37458@sample.org" ,null, "1" , "Hispanic or Latino" , "001" , "CHRISTUS Health" ,null,null,null,null, "AI678101A" , "CRP Business Office Financial" ,null,null, "511440" , "PFS Associate IV" , "511" , "PTFINS" , "A" , "Active" , "03/04/2013 00:00:00" ,null),
        Row( "100290" ,null,null,null, "Kathen" , " " ,null,null, "338 Cardinal Song" , " " , "San Antonio" , "TX" , "78253" , "US" , "N" , "08/09/1979" , "2106797112" , "210657151=CB" , "4200      " , "e37459@sample.org" ,null, "1" , "Hispanic or Latino" , "300" , "CHRISTUS Health Santa Rosa" ,null,null,null,null, "GI310501A" , "Rwh Med/Surg E" ,null,null, "200150" , "RN Charge Nurse" , "200" , "BEDRN" , "A" , "Active" , "02/11/2013 00:00:00" ,null),
        Row( "100313" ,null,null, "Domi" ,null, " " ,null,null, "9163 Ridge Breeze" , " " , "San Antonio" , "TX" , "78250" , "US" , "F" , "08/30/1990" ,null,null,null, "e37460@sample.org" ,null, "1" , "Hispanic or Latino" , "300" , "CHRISTUS Health Santa Rosa" ,null,null,null,null, "GI310501A" , "Rwh Med/Surg E" ,null,null, "900110" , "Cert Nurse Asst I" , "900" , "CLNAST" , "A" , "Active" , "02/25/2013 00:00:00" ,null)

    )), EmployeeRosterSchema.employeeRosterSchema)

    val mockFileSystemDao = mock[FileSystemDao]

    (mockFileSystemDao.readEmployeeRosterFile _).expects(false, Seq(InputDirectoryPath)).returns(rawData)

    val (cleansedDataFrame: DataFrame, dirtyDataFrame: DataFrame) = AppCleanser.cleanseData(
      Some(Customer), Constants.EmployeeRosterActivityType, BatchId, false, InputDirectoryPath,
      Constants.EmployeeRosterInfluenceHealthFormat, DateBatchReceived, mockFileSystemDao
    )

    cleansedDataFrame.count() shouldBe 19
    val data = cleansedDataFrame.select("zip5").collectAsList()
    data.get(0).getString(0) shouldBe "78130"
    data.get(1).getString(0) shouldBe "78245"
    data.get(2).getString(0) shouldBe "71405"

    cleansedDataFrame.count() shouldBe 19
    val firstNames = cleansedDataFrame.select("firstName").collectAsList()
    firstNames.get(0).getString(0) shouldBe "Andrea"
    val lastNames = cleansedDataFrame.select("lastName").collectAsList()
    lastNames.get(0).getString(0) shouldBe "Silva"
    val dateOfBirth = cleansedDataFrame.select("dateOfBirth").collectAsList()
    dateOfBirth.get(0).getDate(0).toString shouldBe "1980-03-16"
    val source = cleansedDataFrame.select("source").collectAsList()
    source.get(0).getString(0) shouldBe "EMPLOYEEROSTER"
    val sourceRecordId = cleansedDataFrame.select("sourceRecordId").collectAsList()
    sourceRecordId.get(0).getString(0) shouldBe "60716e96d8dbedbcaa09216d75e510d4"
    sourceRecordId.get(1).getString(0) shouldBe "782a17519b19a2375f76c708bd008e78"

    val workPhone = cleansedDataFrame.select("workPhone").collectAsList()
    workPhone.get(0).getString(0) shouldBe "5972002"



    dirtyDataFrame.count() shouldBe 2
    val dirtyData = dirtyDataFrame.select("lastName").collectAsList()
    dirtyData.get(0).getString(0) shouldBe null
    val mobilePhone = dirtyDataFrame.select("mobilePhone").collectAsList()
    assert(mobilePhone.get(0).getString(0) == "210657151=CB")
    val sourceSex = dirtyDataFrame.select("sourceSex").collectAsList()
    assert(sourceSex.get(0).getString(0) == "N")
    val dirtyWorkPhone = dirtyDataFrame.select("workPhone").collectAsList()
    // less than 10 digits
    dirtyWorkPhone.get(0).getString(0) shouldBe "4200      "

  }


}