package com.influencehealth.edh.enrich.person.location

import java.sql.Date
import java.time.LocalDate

import com.amazonaws.auth.{AWSCredentials, BasicAWSCredentials}
import com.amazonaws.services.s3.AmazonS3Client
import com.influencehealth.edh.Constants
import com.influencehealth.edh.config.EnrichJobConfig
import com.influencehealth.edh.model.Person
import com.influencehealth.edh.test.spark.SparkSpecBase
import org.apache.spark.sql.Dataset
import org.scalatest.{FlatSpec, Matchers}

class EnrichLocationStepSpec extends FlatSpec with Matchers with SparkSpecBase {

  val persons: List[Person] = List(
    EnrichLocationsTestData.person,
    EnrichLocationsTestData.person2,
    EnrichLocationsTestData.invalidMultiLocationPerson
  )

  var enrichedPersons: Seq[Person] = _
  var personsDf: Dataset[Person] = _

  var enrichLocationsStep: EnrichLocationStep = _

  override def beforeAll(): Unit = {
    super.beforeAll()

    import spark.implicits._

    // TODO refactor this out so it uses environment or user level AWS profiles
    val accessKey: String = "aws-accesskey"
    val secretKey: String = "aws-secretkey"
    val credentials: AWSCredentials = new BasicAWSCredentials(accessKey, secretKey)
    val s3Client = new AmazonS3Client(credentials)

    implicit val enrichJobConfig: EnrichJobConfig = new EnrichJobConfig(
      jobType = "",
      subJobType = "",
      customer = "testcustomer",
      customerId = 12,
      customerPafName = None,
      customerLocations = EnrichLocationsTestData.locations,
      customerServiceAreas = EnrichLocationsTestData.serviceAreas,
      activityType = None,
      batchId = None,
      batchFormat = "",
      bucketUrl = "",
      failOnError = true,
      allOrApplicable = "all",
      executorCores = 10,
      inputFilePath = None,
      databaseConfig = None,
      anchorConfig = None,
      sg2Config = None,
      user = "testuser",
      profile = "",
      environment = "",
      fullRefresh = false
    )

    enrichLocationsStep = new EnrichLocationStep("", None)(enrichJobConfig, spark)

    personsDf = spark.createDataset(persons)

    enrichedPersons = enrichLocationsStep.process(personsDf).collect()
  }


  "Persons going in for locations enrichment" should "be equal to the number of persons going out" in {
    persons.length shouldBe enrichedPersons.length
  }

  "Location metrics" should "calculate correct distance person" in {

    val locationMetric = enrichLocationsStep.buildLocationMetrics(
      EnrichLocationsTestData.locations,
      EnrichLocationsTestData.serviceAreas,
      EnrichLocationsTestData.person)

    val distanceForLocationName1: Double = 61476.4140625
    val distanceForLocationName2: Double = 30350.4765625
    val distanceForLocationName3: Double = 122746.125
    val distanceForLocationName4: Double = 7371.88427734375
    val distanceForLocationName5: Double = 57150.89453125

    val locationMetricForLocationName1 = locationMetric._2.find(_.location == "locationName1").get
    val locationMetricForLocationName2 = locationMetric._2.find(_.location == "locationName2").get
    val locationMetricForLocationName3 = locationMetric._2.find(_.location == "locationName3").get
    val locationMetricForLocationName4 = locationMetric._2.find(_.location == "locationName4").get
    val locationMetricForLocationName5 = locationMetric._2.find(_.location == "locationName5").get

    locationMetricForLocationName1.distance shouldBe distanceForLocationName1
    locationMetricForLocationName2.distance shouldBe distanceForLocationName2
    locationMetricForLocationName3.distance shouldBe distanceForLocationName3
    locationMetricForLocationName4.distance shouldBe distanceForLocationName4
    locationMetricForLocationName5.distance shouldBe distanceForLocationName5

  }

  it should "calculate correct distance for person2" in {

    val locationMetric = enrichLocationsStep.buildLocationMetrics(
      EnrichLocationsTestData.locations,
      EnrichLocationsTestData.serviceAreas,
      EnrichLocationsTestData.person2)

    val distanceForLocationName6: Double = 139883.0

    val locationMetricForLocationName6 = locationMetric._2.find(_.location == "locationName6").get

    locationMetricForLocationName6.distance shouldBe distanceForLocationName6
  }

  // Checking service area process
  it should "identify person as a part of Primary service area for person" in {
    val locationMetric = enrichLocationsStep.buildLocationMetrics(
      EnrichLocationsTestData.locations,
      EnrichLocationsTestData.serviceAreas,
      EnrichLocationsTestData.person)

    val locationMetricForLocationName4 = locationMetric._2.find(_.location == "locationName4").get

    locationMetricForLocationName4.serviceArea shouldBe "Primary"
  }

  it should "identify person as a part of Secondary service area for person" in {
    val locationMetric = enrichLocationsStep.buildLocationMetrics(
      EnrichLocationsTestData.locations,
      EnrichLocationsTestData.serviceAreas,
      EnrichLocationsTestData.person)

    val locationMetricForLocationName1 = locationMetric._2.find(_.location == "locationName1").get
    val locationMetricForLocationName2 = locationMetric._2.find(_.location == "locationName2").get

    locationMetricForLocationName1.serviceArea shouldBe "Secondary"
    locationMetricForLocationName2.serviceArea shouldBe "Secondary"
  }

  it should "not identify person as a part of any service area for person" in {
    val locationMetric = enrichLocationsStep.buildLocationMetrics(
      EnrichLocationsTestData.locations,
      EnrichLocationsTestData.serviceAreas,
      EnrichLocationsTestData.person)

    val locationMetricForLocationName3 = locationMetric._2.find(_.location == "locationName3").get
    val locationMetricForLocationName5 = locationMetric._2.find(_.location == "locationName5").get

    locationMetricForLocationName3.serviceArea shouldBe Constants.NoServiceArea
    locationMetricForLocationName5.serviceArea shouldBe Constants.NoServiceArea
  }

  it should "not identify person as a part of any service area for person2" in {
    val locationMetric = enrichLocationsStep.buildLocationMetrics(
      EnrichLocationsTestData.locations,
      EnrichLocationsTestData.serviceAreas,
      EnrichLocationsTestData.person2)

    val locationMetricForLocationName6 = locationMetric._2.find(_.location == "locationName6").get

    locationMetricForLocationName6.serviceArea shouldBe Constants.NoServiceArea
  }

  // utilCurrentZipVisits
  it should "calculate correct utilCurrentZip for person" in {
    val locationMetric = enrichLocationsStep.buildLocationMetrics(
      EnrichLocationsTestData.locations,
      EnrichLocationsTestData.serviceAreas,
      EnrichLocationsTestData.person)

    val locationMetricForLocationName2 = locationMetric._2.find(_.location == "locationName2").get

    locationMetricForLocationName2.utilCurrentZipVisits shouldBe 2
  }

  it should "not identify utilCurrentZip for person" in {

    val locationMetric = enrichLocationsStep.buildLocationMetrics(
      EnrichLocationsTestData.locations,
      EnrichLocationsTestData.serviceAreas,
      EnrichLocationsTestData.person)

    val locationMetricForLocationName3 = locationMetric._2.find(_.location == "locationName3").get
    val locationMetricForLocationName4 = locationMetric._2.find(_.location == "locationName4").get
    val locationMetricForLocationName5 = locationMetric._2.find(_.location == "locationName5").get

    locationMetricForLocationName3.utilCurrentZipVisits shouldBe 0
    locationMetricForLocationName4.utilCurrentZipVisits shouldBe 0
    locationMetricForLocationName5.utilCurrentZipVisits shouldBe 0
  }


  // utilCurrentZipMaxDate
  it should "calculate correct utilCurrentZipMaxDate for person" in {
    val locationMetric = enrichLocationsStep.buildLocationMetrics(
      EnrichLocationsTestData.locations,
      EnrichLocationsTestData.serviceAreas,
      EnrichLocationsTestData.person)

    val compDateInt = 20150215

    val locationMetricForLocationName2 = locationMetric._2.find(_.location == "locationName2").get

    locationMetricForLocationName2.utilCurrentZipMaxDate shouldEqual compDateInt
  }

  // utilSixMonthVisits
  it should "calculate correct utilSixMonthVisits for person" in {

    val locationMetric = enrichLocationsStep.buildLocationMetrics(
      EnrichLocationsTestData.locations,
      EnrichLocationsTestData.serviceAreas,
      EnrichLocationsTestData.person)

    val locationMetricForLocationName1 = locationMetric._2.find(_.location == "locationName1").get

    locationMetricForLocationName1.utilSixMonthVisits shouldBe 1
  }

  // utilSixMonthMaxDate
  it should "calculate correct utilSixMonthMaxDate for person" in {

    val locationMetric = enrichLocationsStep.buildLocationMetrics(
      EnrichLocationsTestData.locations,
      EnrichLocationsTestData.serviceAreas,
      EnrichLocationsTestData.person)

    val locationMetricForLocationName1 = locationMetric._2.find(_.location == "locationName1").get
    val locationMetricForLocationName2 = locationMetric._2.find(_.location == "locationName2").get
    val locationMetricForLocationName3 = locationMetric._2.find(_.location == "locationName3").get
    val locationMetricForLocationName4 = locationMetric._2.find(_.location == "locationName4").get
    val locationMetricForLocationName5 = locationMetric._2.find(_.location == "locationName5").get


    locationMetricForLocationName1.utilSixMonthMaxDate shouldBe Date.valueOf(LocalDate.now()).toString.replace("-", "").toInt
    locationMetricForLocationName2.utilSixMonthMaxDate shouldBe Constants.DefaultDate.toString.replace("-", "").toInt
    locationMetricForLocationName3.utilSixMonthMaxDate shouldBe Constants.DefaultDate.toString.replace("-", "").toInt
    locationMetricForLocationName4.utilSixMonthMaxDate shouldBe Constants.DefaultDate.toString.replace("-", "").toInt
    locationMetricForLocationName5.utilSixMonthMaxDate shouldBe Constants.DefaultDate.toString.replace("-", "").toInt

  }

  // utilOverallVisits
  it should "calculate correct utilOverallVisits for person" in {
    val locationMetric = enrichLocationsStep.buildLocationMetrics(
      EnrichLocationsTestData.locations,
      EnrichLocationsTestData.serviceAreas,
      EnrichLocationsTestData.person)

    val locationMetricForLocationName1 = locationMetric._2.find(_.location == "locationName1").get
    val locationMetricForLocationName2 = locationMetric._2.find(_.location == "locationName2").get

    locationMetricForLocationName1.utilOverallVisits shouldBe 2
    locationMetricForLocationName2.utilOverallVisits shouldBe 2

  }

  // utilOverallMaxDate
  it should "calculate correct utilOverallMaxDate for person" in {

    val locationMetric = enrichLocationsStep.buildLocationMetrics(
      EnrichLocationsTestData.locations,
      EnrichLocationsTestData.serviceAreas,
      EnrichLocationsTestData.person)

    val locationMetricForLocationName1 = locationMetric._2.find(_.location == "locationName1").get
    val locationMetricForLocationName2 = locationMetric._2.find(_.location == "locationName2").get
    val locationMetricForLocationName3 = locationMetric._2.find(_.location == "locationName3").get
    val locationMetricForLocationName4 = locationMetric._2.find(_.location == "locationName4").get
    val locationMetricForLocationName5 = locationMetric._2.find(_.location == "locationName4").get

    locationMetricForLocationName1.utilOverallMaxDate shouldBe Date.valueOf(LocalDate.now()).toString.replace("-", "").toInt
    locationMetricForLocationName2.utilOverallMaxDate shouldBe 20150215
    locationMetricForLocationName3.utilOverallMaxDate shouldBe Constants.DefaultDate.toString.replace("-", "").toInt
    locationMetricForLocationName4.utilOverallMaxDate shouldBe Constants.DefaultDate.toString.replace("-", "").toInt
    locationMetricForLocationName5.utilOverallMaxDate shouldBe Constants.DefaultDate.toString.replace("-", "").toInt

  }

  // nonUtilMaxDate
  it should "calculate correct nonUtilMaxDate for person" in {

    val locationMetric = enrichLocationsStep.buildLocationMetrics(
      EnrichLocationsTestData.locations,
      EnrichLocationsTestData.serviceAreas,
      EnrichLocationsTestData.person)

    val locationMetricForLocationName1 = locationMetric._2.find(_.location == "locationName1").get
    val locationMetricForLocationName3 = locationMetric._2.find(_.location == "locationName3").get
    val locationMetricForLocationName4 = locationMetric._2.find(_.location == "locationName3").get

    locationMetricForLocationName1.nonUtilMaxDate shouldBe Date.valueOf(LocalDate.now()).toString.replace("-", "").toInt
    locationMetricForLocationName3.nonUtilMaxDate shouldBe Constants.DefaultDate.toString.replace("-", "").toInt
    locationMetricForLocationName4.nonUtilMaxDate shouldBe Constants.DefaultDate.toString.replace("-", "").toInt
  }

  // nonUtilRecords
  it should "calculate correct nonUtilRecords for person" in {

    val locationMetric = enrichLocationsStep.buildLocationMetrics(
      EnrichLocationsTestData.locations,
      EnrichLocationsTestData.serviceAreas,
      EnrichLocationsTestData.person)

    val locationMetricForLocationName2 = locationMetric._2.find(_.location == "locationName2").get
    val locationMetricForLocationName3 = locationMetric._2.find(_.location == "locationName3").get
    val locationMetricForLocationName4 = locationMetric._2.find(_.location == "locationName3").get
    val locationMetricForLocationName5 = locationMetric._2.find(_.location == "locationName3").get


    locationMetricForLocationName2.nonUtilRecords shouldBe 2
    locationMetricForLocationName3.nonUtilRecords shouldBe 0
    locationMetricForLocationName4.nonUtilRecords shouldBe 0
    locationMetricForLocationName5.nonUtilRecords shouldBe 0
  }

  // Ranking locations
  "Location change" should "rank locations correctly for all persons" in {
    val personsDataFrame: Dataset[Person] = enrichLocationsStep.getLocationChangesForMultipleLocations(
      personsDf, "all", EnrichLocationsTestData.locations,
      EnrichLocationsTestData.serviceAreas
    )
    val locationsRankedForPerson1 =
      personsDataFrame.filter(_.personId == "PERSONID1").select("locations").collectAsList()
    val locationsRankedForPerson2 =
      personsDataFrame.filter(_.personId == "PERSONID2").select("locations").collectAsList()

    val locationsCompForPerson1 = Seq(
      ("locationName1", 0),
      ("locationName2", 1),
      ("locationName4", 2),
      ("locationName5", 3),
      ("locationName3", 4),
      ("locationName6", 5))
    val locationsCompForPerson2 = List("locationName6", 0)

    locationsRankedForPerson1.get(0).getList(0).equals(locationsCompForPerson1)
    locationsRankedForPerson2.get(0).getList(0).equals(locationsCompForPerson2)
  }

  it should "rank locations for applicable persons" in {
    val personsDataFrame: Dataset[Person] = enrichLocationsStep.getLocationChangesForMultipleLocations(
      personsDf, "applicable", EnrichLocationsTestData.locations,
      EnrichLocationsTestData.serviceAreas
    )

    val locationsRankedForPerson1 =
      personsDataFrame.filter(_.personId == "PERSONID1").select("locations").collectAsList()
    val locationsRankedForPerson2 =
      personsDataFrame.filter(_.personId == "PERSONID2").select("locations").collectAsList()

    val locationsCompForPerson1 = Seq(
      ("locationName1", 0),
      ("locationName2", 1),
      ("locationName4", 2),
      ("locationName5", 3),
      ("locationName3", 4),
      ("locationName6", 5))
    val locationsCompForPerson2 = List("locationName6", 0)

    locationsRankedForPerson1.get(0).getList(0).equals(locationsCompForPerson1)
    locationsRankedForPerson2.get(0).getList(0).equals(locationsCompForPerson2)
  }

}
