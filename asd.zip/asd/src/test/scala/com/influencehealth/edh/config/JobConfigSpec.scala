package com.influencehealth.edh.config

import java.io.File
import java.time.LocalDate

import com.amazonaws.auth.{AWSCredentials, BasicAWSCredentials}
import com.amazonaws.services.s3.AmazonS3Client
import com.influencehealth.edh.test.spark.SparkSpecBase
import com.typesafe.config.{Config, ConfigFactory}
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}

class JobConfigSpec extends FlatSpec with SparkSpecBase with BeforeAndAfter with Matchers {

  // TODO refactor this out so it uses environment or user level AWS profiles
  val accessKey: String = "aws-accesskey"
  val secretKey: String = "aws-secretkey"
  val credentials: AWSCredentials = new BasicAWSCredentials(accessKey, secretKey)
  val s3Client = new AmazonS3Client(credentials)

  val jobTypeCleanse: String = "cleanse"
  val jobTypeLoad: String = "load"
  val jobSubCommandLoadActivityPipeline: String = "activitypipeline"
  val jobSubCommandLoadActivities: String = "activities"
  val jobSubTypeCleanseCallcenter: String = "callcenter"
  val jobSubTypeCleanseEncounter: String = "encounter"
  val jobSubTypeCleanseNewmovers: String = "newmovers"
  val jobSubTypeCleanseMarketinglist: String = "marketinglist"

  val configCleanseDefaultReference: String = "src/test/resources/config/application.loader.configurations/cleanse-default.conf"
  val configCleanseInputfileReference: String = "src/test/resources/config/application.loader.configurations/cleanse-inputfile.conf"
  val configCleanseEmptyReference: String = "src/test/resources/config/application.loader.configurations/cleanse-empty.conf"
  val configLoadEmptyReference: String = "src/test/resources/config/application.loader.configurations/load-empty.conf"
  val configCleanseMonthsReference: String = "src/test/resources/config/application.loader.configurations/cleanse-months.conf"
  val configBatchidReference: String = "src/test/resources/config/application.loader.configurations/cleanse-batchid.conf"
  val configLoadDefaultReference: String = "src/test/resources/config/application.loader.configurations/load-default.conf"
  val configLoadDefaultActivityPipelineReference: String = "src/test/resources/config/application.loader.configurations/load-default-activitypipeline.conf"
  val configLoadInputfileReference: String = "src/test/resources/config/application.loader.configurations/load-inputfile.conf"
  val configLoadMonthsReference: String = "src/test/resources/config/application.loader.configurations/load-months.conf"
  val configLoadActivityTypeReference: String = "src/test/resources/config/application.loader.configurations/load-activitytype.conf"
  val configLoadFormatReference: String = "src/test/resources/config/application.loader.configurations/load-format.conf"
  val configLoadDaysReference: String = "src/test/resources/config/application.loader.configurations/load-days.conf"
  val configCleanseSinceDateReference: String = "src/test/resources/config/application.loader.configurations/cleanse-sincedate.conf"
  val configCleanseInputFileAndBatchIdReference: String = "src/test/resources/config/application.loader.configurations/cleanse-inputfile-batchid.conf"
  val configCleanseInputFileAndFormatReference: String = "src/test/resources/config/application.loader.configurations/cleanse-inputfile-format.conf"
  val configCleanseSinceDateAndFormatAndActivityTypeReference: String = "src/test/resources/config/application.loader.configurations/cleanse-since-date-format-activitytype.conf"
  val configCleanseMonthsAndFormatAndActivityTypeReference: String = "src/test/resources/config/application.loader.configurations/cleanse-months-format-activitytype.conf"
  val configCleanseFormatAndActivityTypeReference: String = "src/test/resources/config/application.loader.configurations/cleanse-format-activitytype.conf"
  val configLoadSinceDateAndFormatAndActivityTypeReference: String = "src/test/resources/config/application.loader.configurations/load-sincedate-format-activitytype-months.conf"
  val configLoadMonthsAndFormatAndActivityTypeReference: String = "src/test/resources/config/application.loader.configurations/load-months-format-activitytype-days.conf"

  val customer: String = "testcustomer"
  var cleanseDefaultConfig: Config = _
  var cleanseInputfileConfig: Config = _
  var commonCleanseMissingConfig: Config = _
  var commonLoadMissingConfig: Config = _
  var cleanseMonthsConfig: Config = _
  var cleanseSinceDateConfig: Config = _
  var commonBatchIdConfig: Config = _
  var loadDefaultConfig: Config = _
  var loadInputfileConfig: Config = _
  var loadMonthsConfig: Config = _
  var loadActivityTypeConfig: Config = _
  var loadFormatConfig: Config = _
  var loadDaysConfig: Config = _
  var cleanseInputfileWithBatchIdConf: Config = _
  var cleanseInputfileWithFormatConf: Config = _
  var cleanseSinceDateAndFormatAndActivityTypeReference: Config = _
  var cleanseMonthsAndFormatAndActivityTypeReference: Config = _
  var cleanseFormatAndActivityTypeReference: Config = _
  var loadSinceDateAndFormatAndActivityTypeReference: Config = _
  var loadMonthsAndFormatAndActivityTypeReference: Config = _
  var loadDefaultActivityPipelineReference: Config = _


  before {
    cleanseDefaultConfig = ConfigFactory.parseFile(new File(configCleanseDefaultReference)).resolve()
    cleanseInputfileConfig = ConfigFactory.parseFile(new File(configCleanseInputfileReference)).resolve()
    commonCleanseMissingConfig = ConfigFactory.parseFile(new File(configCleanseEmptyReference)).resolve()
    commonLoadMissingConfig = ConfigFactory.parseFile(new File(configLoadEmptyReference)).resolve()
    cleanseMonthsConfig = ConfigFactory.parseFile(new File(configCleanseMonthsReference)).resolve()
    commonBatchIdConfig = ConfigFactory.parseFile(new File(configBatchidReference)).resolve()
    loadDefaultConfig = ConfigFactory.parseFile(new File(configLoadDefaultReference)).resolve()
    loadInputfileConfig = ConfigFactory.parseFile(new File(configLoadInputfileReference)).resolve()
    loadMonthsConfig = ConfigFactory.parseFile(new File(configLoadMonthsReference)).resolve()
    loadActivityTypeConfig = ConfigFactory.parseFile(new File(configLoadActivityTypeReference)).resolve()
    loadFormatConfig = ConfigFactory.parseFile(new File(configLoadFormatReference)).resolve()
    loadDaysConfig = ConfigFactory.parseFile(new File(configLoadDaysReference)).resolve()
    cleanseSinceDateConfig = ConfigFactory.parseFile(new File(configCleanseSinceDateReference)).resolve()
    cleanseInputfileWithBatchIdConf = ConfigFactory.parseFile(new File(configCleanseInputFileAndBatchIdReference)).resolve()
    cleanseInputfileWithFormatConf = ConfigFactory.parseFile(new File(configCleanseInputFileAndFormatReference)).resolve()
    cleanseSinceDateAndFormatAndActivityTypeReference = ConfigFactory.parseFile(new File(configCleanseSinceDateAndFormatAndActivityTypeReference)).resolve()
    cleanseMonthsAndFormatAndActivityTypeReference = ConfigFactory.parseFile(new File(configCleanseMonthsAndFormatAndActivityTypeReference)).resolve()
    cleanseFormatAndActivityTypeReference = ConfigFactory.parseFile(new File(configCleanseFormatAndActivityTypeReference)).resolve()
    loadSinceDateAndFormatAndActivityTypeReference = ConfigFactory.parseFile(new File(configLoadSinceDateAndFormatAndActivityTypeReference)).resolve()
    loadMonthsAndFormatAndActivityTypeReference = ConfigFactory.parseFile(new File(configLoadMonthsAndFormatAndActivityTypeReference)).resolve()
    loadDefaultActivityPipelineReference = ConfigFactory.parseFile(new File(configLoadDefaultActivityPipelineReference)).resolve()
  }

  // Happy flow:
  "Cleanse encounter with format option" should "return the last default batch" in {

    val cleanseConfig: CleanseJobConfig = CleanseJobConfig(cleanseDefaultConfig)

    cleanseConfig.batchFormat shouldBe "influencehealth"

    cleanseConfig.activityType shouldBe "encounter"
  }

  "Cleanse callcenter with input file name option" should "return the specified s3 url's batch" in {

    val cleanseConfig: CleanseJobConfig = CleanseJobConfig(cleanseInputfileConfig)

    cleanseConfig.inputFilePath shouldBe Option("s3a://edh-data-test/customer/raw/encounter/influencehealth/2017-05/")

    cleanseConfig.activityType shouldBe "encounter"
  }

  "Cleanse newmovers with batch id option" should "return the specified s3 url's batch" in {
    val cleanseConfig: CleanseJobConfig = CleanseJobConfig(commonBatchIdConfig)
    cleanseConfig.batchId shouldBe Some("experian-newmovers-influencehealth-2017-06")
    cleanseConfig.activityType shouldBe "newmovers"
  }

  "Cleanse callcenter with months option" should "return the specified s3 url's batch" in {
    val cleanseConfig: CleanseJobConfig = CleanseJobConfig(cleanseMonthsConfig)
    cleanseConfig.batchMonth shouldBe Option(5)
    cleanseConfig.batchFormat shouldBe "beryl"
    cleanseConfig.activityType shouldBe "callcenter"
  }

  "Cleanse callcenter with since date option" should "return the specified s3 url's batch" in {

    val cleanseConfig: CleanseJobConfig = CleanseJobConfig(cleanseSinceDateConfig)
    cleanseConfig.sinceDate shouldBe Some(LocalDate.parse("2017-05-01"))
    cleanseConfig.batchFormat shouldBe "beryl"
    cleanseConfig.activityType shouldBe "callcenter"
  }

  // Exception flow
  "Cleanse marketinglist with no option" should "throw exception" in {
    val runtimeException = the[RuntimeException] thrownBy CleanseJobConfig(commonCleanseMissingConfig)
    runtimeException.getMessage shouldBe "Please provide input file path OR batch-id OR format"
  }

  // TODO: Ignored because null subjobtypes are not allowed in current version
  ignore should "throw exception when trying to cleanse marketinglist with days option" in {
    val runtimeException = the[Exception] thrownBy
      CleanseJobConfig(loadDaysConfig)
    runtimeException.getMessage shouldBe "Days option is currently not supported for cleanse jobs."
  }

  "Cleanse marketinglist with batch id and input file option" should "throw exception" in {
    val runtimeException = the[Exception] thrownBy CleanseJobConfig(cleanseInputfileWithBatchIdConf)
    runtimeException.getMessage shouldBe "Batch id can't be combined with " +
      "Options(input-file path, format, days, months, since date & activity type)"
  }

  "Cleanse marketinglist with input file and format option" should "throw exception" in {
    val runtimeException = the[Exception] thrownBy CleanseJobConfig(cleanseInputfileWithFormatConf)
    runtimeException.getMessage shouldBe "Input file path can't be combined with Options(format, days, months, since date & activity type)"
  }

  "Cleanse marketinglist with since date and format option" should "throw exception" in {
    val runtimeException = the[Exception] thrownBy CleanseJobConfig(
      cleanseSinceDateAndFormatAndActivityTypeReference)
    runtimeException.getMessage shouldBe "Since date with format can't be combined with Options(days, months & activity type)"
  }

  "Cleanse marketinglist with months and format option" should "throw exception" in {
    val runtimeException = the[Exception] thrownBy CleanseJobConfig(
      cleanseMonthsAndFormatAndActivityTypeReference)
    runtimeException.getMessage shouldBe "Months with format can't be combined with Options(days & activity type)"
  }

  "Cleanse marketinglist with format option" should "throw exception" in {
    val runtimeException = the[Exception] thrownBy CleanseJobConfig(cleanseFormatAndActivityTypeReference)
    runtimeException.getMessage shouldBe "Format can't be combined with Options(activity type)"
  }

  // TODO: Ignored because null subjobtypes are not allowed in current version
  ignore should "cleanse encounter with only format option throw exception" in {
    val runtimeException = the[RuntimeException] thrownBy CleanseJobConfig(cleanseDefaultConfig)
    runtimeException.getMessage shouldBe "Unable to derive activity type"
  }

  // Happy flow:
  "Load activities with format, activity type option" should "return the last default batch" in {
    val cleanseConfig = CleanseJobConfig(loadDefaultConfig)
    cleanseConfig.activityType shouldBe "encounter"
    cleanseConfig.batchFormat shouldBe "influencehealth"
  }

  it should "Load activities with input file name option return the specified s3 url's batch" in {
    val cleanseConfig = CleanseJobConfig(loadInputfileConfig)
    cleanseConfig.inputFilePath shouldBe Some("s3a://edh-data-test/experian/cleansed/newmovers/standard/2017-05.parquet/")
    cleanseConfig.activityType shouldBe "newmovers"
  }

  // TODO: Ignored because null subjobtypes are not allowed in current version
  ignore  should "load activities with months option return the specified s3 url's batch" in {
    val cleanseConfig = CleanseJobConfig(loadMonthsConfig)
    cleanseConfig.batchMonth shouldBe Option(5)
    cleanseConfig.batchFormat shouldBe Some("beryl")
    cleanseConfig.activityType shouldBe Some("callcenter")
    cleanseConfig.activityType shouldBe "callcenter"
  }

  "Load activities with days option" should "return the specified s3 url's batch" in {
    val cleanseConfig = CleanseJobConfig(loadDaysConfig)
    cleanseConfig.batchDays shouldBe Option(5)
    cleanseConfig.batchFormat shouldBe "beryl"
    cleanseConfig.activityType shouldBe "callcenter"
  }

  "Load activities with batch id option" should "return the specified s3 url's batch" in {
    val cleanseConfig = CleanseJobConfig(commonBatchIdConfig)
    cleanseConfig.batchId shouldBe Some("experian-newmovers-influencehealth-2017-06")
    cleanseConfig.activityType shouldBe "newmovers"
  }

  "Load activities with only format option" should "throw exception" in {
    val runtimeExceptionForActivityType = the[RuntimeException] thrownBy
      CleanseJobConfig(loadFormatConfig)
    runtimeExceptionForActivityType.getMessage shouldBe "Please provide activity type and format"
  }

  "Load activities with only activity type option" should "throw exception" in {
    val runtimeExceptionForFormat = the[RuntimeException] thrownBy
      CleanseJobConfig(loadActivityTypeConfig)
    runtimeExceptionForFormat.getMessage shouldBe "Please provide activity type and format"
  }

  // Exception flow
  "Load activities for marketinglist with no option" should "throw exception" in {
    val runtimeException = the[RuntimeException] thrownBy
      CleanseJobConfig(commonLoadMissingConfig)
    runtimeException.getMessage shouldBe "Please provide activity type and format"
  }

  "Load activities for marketinglist with batch id and input file option" should "throw exception" in {
    val runtimeException = the[Exception] thrownBy
      CleanseJobConfig(cleanseInputfileWithBatchIdConf)
    runtimeException.getMessage shouldBe "Batch id can't be combined with " +
      "Options(input-file path, format, days, months, since date & activity type)"
  }

  "Load activities for marketinglist with input file and format option" should "throw exception" in {
    val runtimeException = the[Exception] thrownBy
      CleanseJobConfig(cleanseInputfileWithFormatConf)
    runtimeException.getMessage shouldBe "Input file path can't be combined with Options(format, days, months, since date & activity type)"
  }

  "Load activities for marketinglist with since date, activity type and format option" should "throw exception" in {
    val runtimeException = the[Exception] thrownBy
      CleanseJobConfig(loadSinceDateAndFormatAndActivityTypeReference)
    runtimeException.getMessage shouldBe "Since date with format and activity type can't be combined with Options(days & months)"
  }

  "Load activities for marketinglist with months, activity type and format option" should "throw exception" in {
    val runtimeException = the[Exception] thrownBy
      CleanseJobConfig(loadMonthsAndFormatAndActivityTypeReference)
    runtimeException.getMessage shouldBe "Months with format and activity type can't be combined with Options(days)"
  }

  // Happy flow:
  "Load activitypipeline with format, activity type option" should "return the last default batch" in {
    val cleanseConfig = CleanseJobConfig(loadDefaultActivityPipelineReference)
    cleanseConfig.activityType shouldBe "encounter"
    cleanseConfig.batchFormat shouldBe "influencehealth"
    cleanseConfig.activityType shouldBe "encounter"
  }

  "Load activitypipeline with input file name option" should "return the specified s3 url's batch" in {
    val cleanseConfig = CleanseJobConfig(loadInputfileConfig)
    cleanseConfig.inputFilePath shouldBe Some("s3a://edh-data-test/experian/cleansed/newmovers/standard/2017-05.parquet/")
    cleanseConfig.activityType shouldBe "newmovers"
  }

}
