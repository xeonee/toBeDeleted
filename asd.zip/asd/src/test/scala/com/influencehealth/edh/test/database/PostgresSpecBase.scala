package com.influencehealth.edh.test.database

import com.influencehealth.edh.config.{ConfigLoader, DatabaseConfig, PostgresConfig}
import com.influencehealth.edh.dao.{DatabaseDao, PostgresDatabaseDao}
import com.influencehealth.edh.test.spark.SparkSpecBase
import org.flywaydb.core.Flyway
import org.scalatest.{BeforeAndAfterAll, FlatSpec}
import ru.yandex.qatools.embed.postgresql.EmbeddedPostgres
import ru.yandex.qatools.embed.postgresql.distribution.Version

trait PostgresSpecBase extends FlatSpec with BeforeAndAfterAll {

  self: SparkSpecBase =>

  private var _databaseDao: DatabaseDao = _
  private var _postgres: EmbeddedPostgres = _

  override def beforeAll(): Unit = {

    super.beforeAll()

    implicit val sparkSession = spark

    val appConfig = ConfigLoader.appConfig
    val dbConfig: DatabaseConfig = PostgresConfig(appConfig)

    val postgresVersion = Version.Main.V9_6
    _postgres  = new EmbeddedPostgres(postgresVersion)


    val url = _postgres.start(
      dbConfig.host,
      dbConfig.port,
      dbConfig.database,
      dbConfig.user,
      dbConfig.password,
      java.util.Collections.emptyList()
    )
    println(url)
    cleanAndMigrateDB(dbConfig)

    _databaseDao = new PostgresDatabaseDao(dbConfig)

  }

  override def afterAll(): Unit = _postgres.stop()

  private def cleanAndMigrateDB(dbConfig: DatabaseConfig): Unit = {

    val flyway: Flyway = new Flyway()

    flyway.setDataSource(
      s"jdbc:postgresql://${dbConfig.host}:${dbConfig.port}/${dbConfig.database}", dbConfig.user, dbConfig.password
    )
    flyway.setSchemas(dbConfig.schema)
    flyway.setLocations(s"classpath://postgres")
    flyway.clean()
    flyway.migrate()
  }

  lazy val databaseDao: DatabaseDao = _databaseDao

}