package com.influencehealth.edh.personmatching

import java.sql.{Date, Timestamp}
import java.time.LocalDate

import com.influencehealth.edh.Constants
import com.influencehealth.edh.model.PrimaryIdentity
import org.scalamock.scalatest.MockFactory
import org.scalatest.{FlatSpec, Matchers}

class PersonMatcherSpec extends FlatSpec with Matchers with MockFactory {

  it should "be true when everything matches" in {

    val identity1 = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val address2: Option[String] = Some("1800 Pennsylvania Avenue")
      override val mrids: Seq[String] = Seq("hospital.epic.source_person_id")
      override val sex: Option[String] = Some(Constants.SexMale)
      override val personalSuffix: Option[String] = Some("SR")
      override val dateOfBirth: Option[Date] = Some(new Date(Constants.Today.getMillis))
      override val sourceAge: Option[Int] = None
      override val middleName: Option[String] = Some("the great")
      override val streetSecondNumber: Option[String] = Some("Apt 137")
      override val firstName: Option[String] = Some("alex")
      override val lastName: Option[String] = Some("of Macedon")
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip5")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = Some("email@address.com")
      override val primaryPhoneNumber: Option[String] = Some("4042345678")
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }

    val identity2 = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val address2: Option[String] = Some("1800 Pennsylvania Avenue")
      override val mrids: Seq[String] = Seq("hospital.epic.source_person_id")
      override val sex: Option[String] = Some(Constants.SexMale)
      override val personalSuffix: Option[String] = Some("SR")
      override val dateOfBirth: Option[Date] = Some(new Date(Constants.Today.getMillis))
      override val sourceAge: Option[Int] = None
      override val middleName: Option[String] = Some("the great")
      override val streetSecondNumber: Option[String] = Some("Apt 137")
      override val firstName: Option[String] = Some("alex")
      override val lastName: Option[String] = Some("of Macedon")
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip5")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = Some("email@address.com")
      override val primaryPhoneNumber: Option[String] = Some("4042345678")
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }

    val outcome = PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.PerfectMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.EMailMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.PhoneMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.NickNameMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.LastNameChangeMatch)

    outcome shouldBe true
  }

  it should "be true when first name root does not match" in {

    val identity1 = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val address2: Option[String] = Some("1800 Pennsylvania Avenue")
      override val mrids: Seq[String] = Seq("hospital.epic.source_person_id")
      override val sex: Option[String] = Some(Constants.SexMale)
      override val personalSuffix: Option[String] = Some("SR")
      override val dateOfBirth: Option[Date] = Some(new Date(Constants.Today.getMillis))
      override val sourceAge: Option[Int] = None
      override val middleName: Option[String] = Some("the great")
      override val streetSecondNumber: Option[String] = Some("Apt 137")
      override val firstName: Option[String] = Some("alex")
      override val lastName: Option[String] = Some("of Macedon")
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip5")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = Some("email@address.com")
      override val primaryPhoneNumber: Option[String] = Some("4042345678")
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }
    val identity2 = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val address2: Option[String] = Some("1800 Pennsylvania Avenue")
      override val mrids: Seq[String] = Seq("hospital.epic.source_person_id")
      override val sex: Option[String] = Some(Constants.SexMale)
      override val personalSuffix: Option[String] = Some("SR")
      override val dateOfBirth: Option[Date] = Some(new Date(Constants.Today.getMillis))
      override val sourceAge: Option[Int] = None
      override val middleName: Option[String] = Some("the great")
      override val streetSecondNumber: Option[String] = Some("Apt 137")
      override val firstName: Option[String] = Some("alex")
      override val lastName: Option[String] = Some("of Macedon")
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip5")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = Some("email@address.com")
      override val primaryPhoneNumber: Option[String] = Some("4042345678")
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }

    val outcome = PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.PerfectMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.EMailMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.PhoneMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.NickNameMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.LastNameChangeMatch)

    outcome shouldBe true
  }

  it should "be true when dob matches" in {

    val identity1 = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val address2: Option[String] = Some("1800 Pennsylvania Avenue")
      override val mrids: Seq[String] = Seq("hospital.epic.source_person_id")
      override val sex: Option[String] = Some(Constants.SexMale)
      override val personalSuffix: Option[String] = Some("SR")
      override val dateOfBirth: Option[Date] = Some(new Date(Constants.Today.getMillis))
      override val sourceAge: Option[Int] = None
      override val middleName: Option[String] = Some("the great")
      override val streetSecondNumber: Option[String] = Some("Apt 137")
      override val firstName: Option[String] = Some("alex")
      override val lastName: Option[String] = Some("of Macedon")
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip5")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = Some("email@address.com")
      override val primaryPhoneNumber: Option[String] = Some("4042345678")
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }

    val identity2 = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val address2: Option[String] = Some("1800 Pennsylvania Avenue")
      override val mrids: Seq[String] = Seq("hospital.epic.source_person_id")
      override val sex: Option[String] = Some(Constants.SexMale)
      override val personalSuffix: Option[String] = Some("SR")
      override val dateOfBirth: Option[Date] = Some(new Date(Constants.Today.getMillis))
      override val sourceAge: Option[Int] = None
      override val middleName: Option[String] = Some("the great")
      override val streetSecondNumber: Option[String] = Some("Apt 137")
      override val firstName: Option[String] = Some("alex")
      override val lastName: Option[String] = Some("of Macedon")
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip5")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = Some("email@address.com")
      override val primaryPhoneNumber: Option[String] = Some("4042345678")
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }

    val outcome = PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.PerfectMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.EMailMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.PhoneMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.NickNameMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.LastNameChangeMatch)

    outcome shouldBe true
  }

  it should "be false when sex does not match" in {
    val identity1 = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val address2: Option[String] = Some("1800 Pennsylvania Avenue")
      override val mrids: Seq[String] = Seq("hospital.epic.source_person_id")
      override val sex: Option[String] = Some(Constants.SexMale)
      override val personalSuffix: Option[String] = None
      override val dateOfBirth: Option[Date]= Some(new Date(Constants.Today.getMillis))
      override val sourceAge: Option[Int] = None
      override val middleName: Option[String] = Some("the great")
      override val streetSecondNumber: Option[String] = Some("Apt 137")
      override val firstName: Option[String] = Some("alex")
      override val lastName: Option[String] = Some("of Macedon")
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip5")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = Some("email@address.com")
      override val primaryPhoneNumber: Option[String] = Some("4042345678")
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }
    val identity2 = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val address2: Option[String] = Some("1800 Pennsylvania Avenue")
      override val mrids: Seq[String] = Seq("hospital.someotherplace.source_person_id")
      override val sex: Option[String] = Some(Constants.SexFemale)
      override val personalSuffix: Option[String] = None
      override val dateOfBirth: Option[Date]= Some(new Date(Constants.Today.getMillis))
      override val sourceAge: Option[Int] = None
      override val middleName: Option[String] = Some("the great")
      override val streetSecondNumber: Option[String] = Some("Apt 137")
      override val firstName: Option[String] = Some("alex")
      override val lastName: Option[String] = Some("of Macedon")
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip5")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = Some("email@address.com")
      override val primaryPhoneNumber: Option[String] = Some("4042345678")
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }

    val outcome = PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.PerfectMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.EMailMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.PhoneMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.NickNameMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.LastNameChangeMatch)

    outcome shouldBe false
  }

  it should "be true when address2 does not match" in {
    val identity1 = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val address2: Option[String] = Some("1800 Pennsylvania Avenue")
      override val mrids: Seq[String] = Seq("hospital.epic.source_person_id")
      override val sex: Option[String] = Some(Constants.SexMale)
      override val personalSuffix: Option[String] = Some("SR")
      override val dateOfBirth: Option[Date]= Some(new Date(Constants.Today.getMillis))
      override val sourceAge: Option[Int] = None
      override val middleName: Option[String] = Some("the great")
      override val streetSecondNumber: Option[String] = Some("Apt 137")
      override val firstName: Option[String] = Some("alex")
      override val lastName: Option[String] = Some("of Macedon")
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip5")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = Some("email@address.com")
      override val primaryPhoneNumber: Option[String] = Some("4042345678")
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }
    val identity2 = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val address2: Option[String] = Some("Bourbon Street")
      override val mrids: Seq[String] = Seq("hospital.epic.source_person_id")
      override val sex: Option[String] = Some(Constants.SexMale)
      override val personalSuffix: Option[String] = Some("SR")
      override val dateOfBirth: Option[Date]= Some(new Date(Constants.Today.getMillis))
      override val sourceAge: Option[Int] = None
      override val middleName: Option[String] = Some("the great")
      override val streetSecondNumber: Option[String] = Some("Apt 137")
      override val firstName: Option[String] = Some("alex")
      override val lastName: Option[String] = Some("of Macedon")
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip5")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = Some("email@address.com")
      override val primaryPhoneNumber: Option[String] = Some("4042345678")
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }

    val outcome = PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.PerfectMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.EMailMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.PhoneMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.NickNameMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.LastNameChangeMatch)

    outcome shouldBe true
  }

  it should "be true when address_secondary_number does not match" in {
    val identity1 = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val address2: Option[String] = Some("1800 Pennsylvania Avenue")
      override val mrids: Seq[String] = Seq("hospital.epic.source_person_id")
      override val sex: Option[String] = Some(Constants.SexMale)
      override val personalSuffix: Option[String] = Some("SR")
      override val dateOfBirth: Option[Date]= Some(new Date(Constants.Today.getMillis))
      override val sourceAge: Option[Int] = None
      override val middleName: Option[String] = Some("the great")
      override val streetSecondNumber: Option[String] = Some("Apt 137")
      override val firstName: Option[String] = Some("alex")
      override val lastName: Option[String] = Some("of Macedon")
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip5")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = Some("email@address.com")
      override val primaryPhoneNumber: Option[String] = Some("4042345678")
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }
    val identity2 = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val address2: Option[String] = Some("1800 Pennsylvania Avenue")
      override val mrids: Seq[String] = Seq("hospital.epic.source_person_id")
      override val sex: Option[String] = Some(Constants.SexMale)
      override val personalSuffix: Option[String] = Some("SR")
      override val dateOfBirth: Option[Date]= Some(new Date(Constants.Today.getMillis))
      override val sourceAge: Option[Int] = None
      override val middleName: Option[String] = Some("the great")
      override val streetSecondNumber: Option[String] = Some("Apt 42")
      override val firstName: Option[String] = Some("alex")
      override val lastName: Option[String] = Some("of Macedon")
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip5")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = Some("email@address.com")
      override val primaryPhoneNumber: Option[String] = Some("4042345678")
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }

    val outcome = PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.PerfectMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.EMailMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.PhoneMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.NickNameMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.LastNameChangeMatch)

    outcome shouldBe true
  }

  it should "be true when middle_name does not mach" in {
    val identity1 = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val address2: Option[String] = Some("1800 Pennsylvania Avenue")
      override val mrids: Seq[String] = Seq("hospital.epic.source_person_id")
      override val sex: Option[String] = Some(Constants.SexMale)
      override val personalSuffix: Option[String] = Some("SR")
      override val dateOfBirth: Option[Date]= Some(new Date(Constants.Today.getMillis))
      override val sourceAge: Option[Int] = None
      override val middleName: Option[String] = Some("the great")
      override val streetSecondNumber: Option[String] = Some("Apt 137")
      override val firstName: Option[String] = Some("alex")
      override val lastName: Option[String] = Some("of Macedon")
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip5")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = Some("email@address.com")
      override val primaryPhoneNumber: Option[String] = Some("4042345678")
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }
    val identity2 = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val address2: Option[String] = Some("1800 Pennsylvania Avenue")
      override val mrids: Seq[String] = Seq("hospital.epic.source_person_id")
      override val sex: Option[String] = Some(Constants.SexMale)
      override val personalSuffix: Option[String] = Some("SR")
      override val dateOfBirth: Option[Date]= Some(new Date(Constants.Today.getMillis))
      override val sourceAge: Option[Int] = None
      override val middleName: Option[String] = Some("the not so great")
      override val streetSecondNumber: Option[String] = Some("Apt 137")
      override val firstName: Option[String] = Some("alex")
      override val lastName: Option[String] = Some("of Macedon")
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip5")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = Some("email@address.com")
      override val primaryPhoneNumber: Option[String] = Some("4042345678")
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }

    val outcome = PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.PerfectMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.EMailMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.PhoneMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.NickNameMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.LastNameChangeMatch)

    outcome shouldBe true
  }

  it should "be false when suffix does not match" in {

    val identity1 = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val address2: Option[String] = Some("1800 Pennsylvania Avenue")
      override val mrids: Seq[String] = Seq("hospital.epic.source_person_id")
      override val sex: Option[String] = Some(Constants.SexMale)
      override val personalSuffix: Option[String] = Some("SR")
      override val dateOfBirth: Option[Date]= Some(new Date(Constants.Today.getMillis))
      override val sourceAge: Option[Int] = None
      override val middleName: Option[String] = Some("the great")
      override val streetSecondNumber: Option[String] = Some("Apt 137")
      override val firstName: Option[String] = Some("alex")
      override val lastName: Option[String] = Some("of Macedon")
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip5")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = Some("email@address.com")
      override val primaryPhoneNumber: Option[String] = Some("4042345678")
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }
    val identity2 = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val address2: Option[String] = Some("1800 Pennsylvania Avenue")
      override val mrids: Seq[String] = Seq("hospital.epic.source_person_id")
      override val sex: Option[String] = Some(Constants.SexMale)
      override val personalSuffix: Option[String] = Some("JR")
      override val dateOfBirth: Option[Date]= Some(new Date(Constants.Today.getMillis))
      override val sourceAge: Option[Int] = None
      override val middleName: Option[String] = Some("the great")
      override val streetSecondNumber: Option[String] = Some("Apt 137")
      override val firstName: Option[String] = Some("alex")
      override val lastName: Option[String] = Some("of Macedon")
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip5")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = Some("email@address.com")
      override val primaryPhoneNumber: Option[String] = Some("4042345678")
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }

    val outcome = PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.PerfectMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.EMailMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.PhoneMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.NickNameMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.LastNameChangeMatch)

    outcome shouldBe true
  }

  it should "be false when rootFirstName and soundexLastName match and email and phone number do not" in {

    val identity1: PrimaryIdentity = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val streetSecondNumber: Option[String] = None
      override val dateOfBirth = Some(Date.valueOf(LocalDate.of(1995, 8, 1)))
      override val sourceAge: Option[Int] = None
      override val sex: Option[String] = Some("M")
      override val middleName: Option[String] = None
      override val mrids = Seq("different.mrid.one")
      override val address2: Option[String] = None
      override val personalSuffix: Option[String] = None
      override val firstName: Option[String] = Some("albert")
      override val lastName: Option[String] = Some("Waagenasz")
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip5")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = Some("email1@address.com")
      override val primaryPhoneNumber: Option[String] = Some("4042345678")
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }
    val identity2: PrimaryIdentity = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val firstName = Some("alexander")
      override val lastName = Some("Wachenhausen")
      override val streetSecondNumber: Option[String] = None
      override val dateOfBirth = Some(Date.valueOf(LocalDate.of(1995, 12, 1)))
      override val sourceAge: Option[Int] = None
      override val sex = Some("M")
      override val middleName: Option[String] = None
      override val mrids = Seq("different.mrid.two")
      override val address2: Option[String] = None
      override val personalSuffix: Option[String] = None
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip5")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = Some("email2@address.com")
      override val primaryPhoneNumber: Option[String] = Some("4042345679")
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }

    val outcome = PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.PerfectMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.EMailMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.PhoneMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.NickNameMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.LastNameChangeMatch)

    outcome shouldBe false
  }

  it should "be false when everything matches except dob" in {

    val identity1: PrimaryIdentity = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val lastName: Option[String] = Some("The Great")
      override val address2: Option[String] = Some("APT 1408")
      override val mrids: Seq[String] = Seq("mrid1")
      override val sex: Option[String] = Some("M")
      override val firstName: Option[String] = Some("Alex")
      override val personalSuffix: Option[String] = Some("JR")
      override val dateOfBirth: Option[Date] = Some(Date.valueOf(LocalDate.of(1921, 12, 1)))
      override val sourceAge: Option[Int] = None
      override val middleName: Option[String] = Some("Z")
      override val streetSecondNumber: Option[String] = Some("1600")
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip5")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = Some("email@address.com")
      override val primaryPhoneNumber: Option[String] = Some("4042345678")
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }

    val identity2: PrimaryIdentity = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val lastName: Option[String] = Some("The Great")
      override val address2: Option[String] = Some("APT 1408")
      override val mrids: Seq[String] = Seq("mrid2")
      override val sex: Option[String] = Some("M")
      override val firstName: Option[String] = Some("Alex")
      override val personalSuffix: Option[String] = Some("JR")
      override val dateOfBirth: Option[Date] = Some(Date.valueOf(LocalDate.of(1998, 5, 10)))
      override val sourceAge: Option[Int] = None
      override val middleName: Option[String] = Some("Z")
      override val streetSecondNumber: Option[String] = Some("1600")
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip5")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = Some("email@address.com")
      override val primaryPhoneNumber: Option[String] = Some("4042345678")
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }

    val outcome = PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.PerfectMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.EMailMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.PhoneMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.NickNameMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.LastNameChangeMatch)


    outcome shouldBe false

  }

  it should "be true when everything matches except day of date of birth" in {

    val identity1: PrimaryIdentity = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val lastName: Option[String] = Some("The Great")
      override val address2: Option[String] = Some("APT 1408")
      override val mrids: Seq[String] = Seq("mrid1")
      override val sex: Option[String] = Some("M")
      override val firstName: Option[String] = Some("Alex")
      override val personalSuffix: Option[String] = Some("JR")
      override val dateOfBirth: Option[Date] = Some(Date.valueOf(LocalDate.of(1980, 11, 1)))
      override val sourceAge: Option[Int] = None
      override val middleName: Option[String] = Some("Z")
      override val streetSecondNumber: Option[String] = Some("1600")
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip5")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = Some("email@address.com")
      override val primaryPhoneNumber: Option[String] = Some("4042345678")
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }

    val identity2: PrimaryIdentity = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val lastName: Option[String] = Some("The Great")
      override val address2: Option[String] = Some("APT 1408")
      override val mrids: Seq[String] = Seq("mrid2")
      override val sex: Option[String] = Some("M")
      override val firstName: Option[String] = Some("Alex")
      override val personalSuffix: Option[String] = Some("JR")
      override val dateOfBirth: Option[Date] = Some(Date.valueOf(LocalDate.of(1980, 11, 10)))
      override val sourceAge: Option[Int] = None
      override val middleName: Option[String] = Some("Z")
      override val streetSecondNumber: Option[String] = Some("1600")
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip5")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = Some("email@address.com")
      override val primaryPhoneNumber: Option[String] = Some("4042345678")
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }

    val outcome = PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.PerfectMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.EMailMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.PhoneMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.NickNameMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.LastNameChangeMatch)

    outcome shouldBe true

  }

  it should "be true when dob is empty and age difference <= 2 and has an empty email and phone" in {
    val identity1: PrimaryIdentity = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val lastName: Option[String] = Some("The Great")
      override val address2: Option[String] = Some("APT 1408")
      override val mrids: Seq[String] = Seq("mrid1")
      override val sex: Option[String] = Some("M")
      override val firstName: Option[String] = Some("Alex")
      override val personalSuffix: Option[String] = Some("JR")
      override val dateOfBirth: Option[Date] = None
      override val sourceAge: Option[Int] = Some(1998)
      override val middleName: Option[String] = Some("Z")
      override val streetSecondNumber: Option[String] = Some("1600")
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip5")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = None
      override val primaryPhoneNumber: Option[String] = None
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }

    val identity2: PrimaryIdentity = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val lastName: Option[String] = Some("The Great")
      override val address2: Option[String] = Some("APT 1408")
      override val mrids: Seq[String] = Seq("mrid2")
      override val sex: Option[String] = Some("M")
      override val firstName: Option[String] = Some("Alex")
      override val personalSuffix: Option[String] = Some("JR")
      override val dateOfBirth: Option[Date] = None
      override val sourceAge: Option[Int] = Some(1997)
      override val middleName: Option[String] = Some("Z")
      override val streetSecondNumber: Option[String] = Some("1600")
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip5")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = None
      override val primaryPhoneNumber: Option[String] = None
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }

    val outcome = PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.PerfectMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.EMailMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.PhoneMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.NickNameMatch) ||
      PersonMatcher.isSamePerson(identity1, identity2, PersonMatcher.LastNameChangeMatch)

    outcome shouldBe true

  }

}
