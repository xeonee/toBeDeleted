package com.influencehealth.edh.enrich.address

import com.influencehealth.edh.enrich.address._
import com.influencehealth.edh.enrich.activity.address.EnrichAddressHelper
import com.influencehealth.edh.test.spark.SparkSpecBase
import org.apache.spark.sql.Row
import org.apache.spark.sql.types._
import org.scalatest.FlatSpec
import org.apache.spark.sql.functions._

class EnrichAddressProcessSpec extends FlatSpec with SparkSpecBase {


  it should "Correctly filterout moved away records for PROSPECT" in {

    val p1 = Row(20004, "person_id_1", "PROSPECT", "12345")
    val p2 = Row(20004, "person_id_2", "PROSPECT", "12346")
    val p3 = Row(20004, "person_id_3", "PROSPECT", "98765")
    val p4 = Row(20004, "person_id_4", "PROSPECT", null)

    val setOfCustomerServicingZipCodes: Set[String] = Set("12345", "12346")

    val p = spark.sparkContext.parallelize(Seq(p1, p2, p3, p4))

    import spark.sqlContext.implicits._

    val personSchema = StructType(List(
      StructField("customer_id", IntegerType, false),
      StructField("person_id", StringType, false),
      StructField("source_type", StringType, true),
      StructField("zip5", StringType, true)
    ))

    val personData = spark.createDataFrame(p, personSchema)

    val updatedPerson = personData
      .withColumn("hasMovedAway",
        EnrichAddressHelper.checkMovedAway(setOfCustomerServicingZipCodes) (col("zip5"), col("source_type")))

    assert(updatedPerson.where(s"person_id='person_id_1'").select("hasMovedAway").first.getBoolean(0) == false)
    assert(updatedPerson.where(s"person_id='person_id_2'").select("hasMovedAway").first.getBoolean(0) == false)
    assert(updatedPerson.where(s"person_id='person_id_3'").select("hasMovedAway").first.getBoolean(0) == true)
    assert(updatedPerson.where(s"person_id='person_id_4'").select("hasMovedAway").first.getBoolean(0) == true)

  }

}
