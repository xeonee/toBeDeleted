package com.influencehealth.edh.cleanse.referral

import com.influencehealth.edh.dao.FileSystemDao
import com.influencehealth.edh.model.schema.ReferralSchema
import com.influencehealth.edh.test.spark.SparkSpecBase
import com.influencehealth.edh.{AppCleanser, Constants}
import org.apache.spark.sql.{DataFrame, Row}
import org.scalamock.scalatest.MockFactory
import org.scalatest.{FlatSpec, Matchers}

class CleanseReferralSpec extends FlatSpec with SparkSpecBase with Matchers with MockFactory {

  val InputDirectoryPath: String = "fixtures/cleanse/referral/referralFixture.txt"
  val DateBatchReceived: String = "08/01/2018"
  val Customer: String = "chomp"
  val BatchId = "chomp-referral-influencehealth-2018-05"

  it should "cleanse all data" in {

    val rawData = spark.createDataFrame(spark.sparkContext.parallelize(Seq(
      Row("31441561", "1", "2018-01-01 13:58:25.390000000", "12345678", "Chand", null, " ", "    ", "                                   ", "                                   ", "Jack         ", "TX", "75766", "903", "284", "6348", "   ", "   ", "    ", "      ", "M", null, null, "N", null, "0", "SVC_REF     ", null, "12460", "SAMPLE Health System", null, null, "0", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, "72962", "**Health Insurance Help Service"),
      Row("31443344", "1", "2018-01-02 09:16:21.650000000", "17237357", null, "Desrree", " ", "    ", "                                   ", "                                   ", "Christi       ", "TX", "78414", "361", "696", "5968", "   ", "   ", "    ", "      ", " ", null, null, "N", null, "0", "SVC_REF     ", null, "12460", "SAMPLE Health System", null, null, "0", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, "70249", "Physician Not Listed"),
      Row("31444435", "1", "2018-01-02 10:50:48.697000000", "17777777", null, null, " ", "    ", "                                   ", "                                   ", "Corpus       ", "TX", "78414", "225", "802", "0729", "   ", "   ", "    ", "      ", "F", null, null, "N", null, "0", "SVC_REF     ", null, "12460", "SAMPLE Health System", null, null, "0", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, "69463", "*YourSAMPLE Portal"),
      Row("31444859", "1", "2018-01-02 11:27:41.350000000", "17272727", "M", "Kimberly", " ", "    ", "                                   ", "                                   ", "Lake View         ", "LA", "70629", "337", "540", "2259", "   ", "   ", "    ", "      ", "F", null, null, "N", null, "0", "SVC_REF     ", null, "12460", "SAMPLE Health System", null, null, "0", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, "76256", ".Outbound Online Appointment Request")
    )), ReferralSchema.referralSchemaV1)

    val mockFileSystemDao = mock[FileSystemDao]

    (mockFileSystemDao.readReferralFile _).expects(false, Seq(InputDirectoryPath)).returns(rawData)

    val (cleansedDataFrame: DataFrame, dirtyDataFrame: DataFrame) = AppCleanser.cleanseData(
      Some(Customer), Constants.ReferralActivityType, BatchId, false, InputDirectoryPath,
      Constants.ReferralInfluenceHealthFormat, DateBatchReceived, mockFileSystemDao
    )

    cleansedDataFrame.count() shouldBe 1
    val firstNames = cleansedDataFrame.select("firstName").collectAsList()
    firstNames.get(0).getString(0) shouldBe "Kimberly"
    val lastNames = cleansedDataFrame.select("source").collectAsList()
    lastNames.get(0).getString(0) shouldBe "REFERRAL"

    val homeArea = cleansedDataFrame.select("homeArea").collectAsList()
    homeArea.get(0).getString(0) shouldEqual "337"
    val homePrefix = cleansedDataFrame.select("homePrefix").collectAsList()
    homePrefix.get(0).getString(0) shouldEqual "540"
    val homeSuffix = cleansedDataFrame.select("homeSuffix").collectAsList()
    homeSuffix.get(0).getString(0) shouldEqual "2259"
    val phoneNumbers = cleansedDataFrame.select("phoneNumbers").collectAsList()
    phoneNumbers.get(0).getSeq[String](0).head shouldEqual "3375402259"


    dirtyDataFrame.count() shouldBe 3
    val dirtyDateOfDeath = dirtyDataFrame.select("firstName").collectAsList()
    dirtyDateOfDeath.get(0).getString(0) shouldBe null
  }



}
