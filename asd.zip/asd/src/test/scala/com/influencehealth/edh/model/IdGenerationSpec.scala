package com.influencehealth.edh.model

import java.sql.{Date, Timestamp}

import com.influencehealth.edh.Constants
import org.scalamock.scalatest.MockFactory
import org.scalatest.{FlatSpec, Matchers}

class IdGenerationSpec extends FlatSpec with Matchers with MockFactory {

  it should "generate the same person id" in {

    val firstId: String = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val address2: Option[String] = Some("1800 Pennsylvania Avenue")
      override val mrids: Seq[String] = Seq("testcustomer.hospital.epic.source_person_id")
      override val sex: Option[String] = Some(Constants.SexMale)
      override val personalSuffix: Option[String] = Some("SR")
      override val dateOfBirth: Option[Date] = Some(new Date(Constants.Today.getMillis))
      override val sourceAge: Option[Int] = None
      override val middleName: Option[String] = Some("the great")
      override val streetSecondNumber: Option[String] = Some("Apt 137")
      override val firstName: Option[String] = Some("alex")
      override val lastName: Option[String] = Some("of Macedon")
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip4")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = Some("email@address.com")
      override val primaryPhoneNumber: Option[String] = Some("4042345678")
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }.generatePersonId()

    val secondId: String = new PrimaryIdentity {
      override val customer: String = "testcustomer"
      override val address2: Option[String] = Some("1800 Pennsylvania Avenue")
      override val mrids: Seq[String] = Seq("testcustomer.hospital.epic.source_person_id")
      override val sex: Option[String] = Some(Constants.SexMale)
      override val personalSuffix: Option[String] = Some("SR")
      override val dateOfBirth: Option[Date] = Some(new Date(Constants.Today.getMillis))
      override val sourceAge: Option[Int] = None
      override val middleName: Option[String] = Some("the great")
      override val streetSecondNumber: Option[String] = Some("Apt 137")
      override val firstName: Option[String] = Some("alex")
      override val lastName: Option[String] = Some("of Macedon")
      override val address1: Option[String] = Some("address1")
      override val zip5: Option[String] = Some("zip5")
      override val dateCreated: Timestamp = new Timestamp(1525656823)
      override val primaryEmail: Option[String] = Some("email@address.com")
      override val primaryPhoneNumber: Option[String] = Some("4042345678")
      override val primaryPhoneNumberType: Option[String] = Some("HOME")
    }.generatePersonId()

    firstId shouldBe secondId

  }

  it should "generate the same address id" in {

    val firstId: String = new AddressIdentity {
      override val customer: String = "testcustomer"
      override val address1: String = "APT. 1408"
      override val address2: Option[String] = Some("1414 Andrew Young International Blvd")
      override val city: String = "ATLANTA"
      override val state: String = "GA"
      override val zip5: String = "30313"
      override val zip4: Option[String] = Some("4444")
      override val addressCoordinates: Coordinates = Coordinates(lat = 36.333333f, lon = -36.333333f)
    }.generateAddressId

    val secondId: String = new AddressIdentity {
      override val customer: String = "testcustomer"
      override val address1: String = "APT. 1408"
      override val address2: Option[String] = Some("1414 Andrew Young International Blvd")
      override val city: String = "ATLANTA"
      override val state: String = "GA"
      override val zip5: String = "30313"
      override val zip4: Option[String] = Some("4444")
      override val addressCoordinates: Coordinates = Coordinates(lat = 36.333333f, lon = -36.333333f)
    }.generateAddressId

    firstId shouldBe secondId

  }

}
