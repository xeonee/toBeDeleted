package com.influencehealth.edh.demofy

import com.influencehealth.edh.model.Coordinates
import org.apache.spark.storage.StorageLevel
import com.influencehealth.edh.demofy.DemoDataGenerator.deIdentifyingColumns
import com.influencehealth.edh.model.Activity
import com.influencehealth.edh.test.spark.SparkSpecBase
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset}
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}

class DemofySpec extends FlatSpec with SparkSpecBase with BeforeAndAfter with Matchers {

  var initializedDataFrames: Map[String, Any] = _
  before {
    import spark.sqlContext.implicits._

    val fakePersonDemographics = Seq(
      ("1","", "Benoite", "Jilli", "Illiston","jilliston0@rediff.com","404-456-2585","F","6640 AKERS MILL RD SE",
        "APT 5423","ATLANTA","GA","30339","2736",Coordinates(lat = 33.8971f, lon = -84.4467f),"13067","734"
        ),
      ("2","Dr", "Fancy", "Evita", "Kemitt","ekemitt1@photobucket.com","404-113-3551","F","401 EILEEN CIR",
        "","CANTON","GA","30114","8410",Coordinates(lat = 34.2103f, lon = -84.5626f),"13057","17"
      )
    ).toDF("seqNo", "prefix","firstName","middleName", "lastName", "email","homePhone","sex","address1","address2",
      "city","state","zip5","zip4","addressCoordinates","countyCode","deliveryPointCode")

    val loadRealPersonActivities = Seq(
      ("SURESH","BIXBY","","+11234567890","112 SOME DR","30116","F","tanner","473ca57a-518e-4454-b4f4-5c12daccf206","b9ca7f1bf2202004f3dcea9d79e6e750","tanner-encounter-influencehealth-2018-01","2018-08-13 20:00:00.0","2018-08-14 20:00:00.0","11/9/1964","MEDITECH","2","1236","PATIENTADMIN","false"),
      ("BHAVIN","BARKER","bhavin.barker@gmail.com","1234567890","112 SOME DR","30116","F","tanner","2426872d-cd67-44ac-ae2f-103ef3f6d32d","9a8aa44cda576dc721b32b3963bdcf65","tanner-encounter-influencehealth-2018-03","2018-08-13 20:00:00.0","2018-08-14 20:00:00.0","11/9/1964","MEDITECH","60580","","HOSPTIAL","false")
    ).toDF("firstName", "lastName","email", "homePhone", "address1", "zip5", "sex",
      "customer", "activityId", "personId", "batchId", "dateCreated", "dateModified",
      "dateOfBirth", "source", "sourcePersonId", "sourceRecordId", "sourceType", "validAddressFlag")

    /**
      * Converts the DataFrame to the Activity Schema by looking at the differences in the columns
      * and adding empty columns until the schemas match.
      *
      * @param inputDataFrame the input loadRealPersonActivities data
      * @return the loadRealPersonActivities mapped to the ActivitySchema
      */
    def mapDataToActivitySchema(inputDataFrame: DataFrame): DataFrame = {
      Activity.transformToActivitySchema(inputDataFrame)
    }

    val realPersonActivities = mapDataToActivitySchema(loadRealPersonActivities).persist(StorageLevel.MEMORY_AND_DISK)

    initializedDataFrames = Map("realPersonActivities" -> realPersonActivities,
      "fakePersonDemographics" -> fakePersonDemographics,
      "originalCustomer" -> "tanner",
      "demoCustomer" -> "peachtree")
  }

  "fakePersonDemographics" should "contain expected fake activities" in {

    val fakePersonDemographics = initializedDataFrames("fakePersonDemographics").asInstanceOf[DataFrame]

    val firstNames = fakePersonDemographics.select("firstName").collectAsList()
    assert(firstNames.get(0).getString(0).equals("Benoite"))
    assert(firstNames.get(1).getString(0).equals("Fancy"))

    val lastNames = fakePersonDemographics.select("lastName").collectAsList()
    assert(lastNames.get(0).getString(0).equals("Illiston"))
    assert(lastNames.get(1).getString(0).equals("Kemitt"))

    val primaryEmail = fakePersonDemographics.select("email").collectAsList()
    assert(primaryEmail.get(0).getString(0).equals("jilliston0@rediff.com"))
    assert(primaryEmail.get(1).getString(0).equals("ekemitt1@photobucket.com"))

    val primaryPhoneNumber = fakePersonDemographics.select("homePhone").collectAsList()
    assert(primaryPhoneNumber.get(0).getString(0).equals("404-456-2585"))
    assert(primaryPhoneNumber.get(1).getString(0).equals("404-113-3551"))

    val sex = fakePersonDemographics.select("sex").collectAsList()
    assert(sex.get(0).getString(0).equals("F"))
    assert(sex.get(1).getString(0).equals("F"))

    val city = fakePersonDemographics.select("city").collectAsList()
    assert(city.get(0).getString(0).equals("ATLANTA"))
    assert(city.get(1).getString(0).equals("CANTON"))

    val zip5 = fakePersonDemographics.select("zip5").collectAsList()
    assert(zip5.get(0).getString(0).equals("30339"))
    assert(zip5.get(1).getString(0).equals("30114"))
  }

  "realPersonActivities" should "contain expected real activities" in {

    val realPersonActivities = initializedDataFrames("realPersonActivities").asInstanceOf[DataFrame]
    assert(realPersonActivities.count().equals(2.toLong))

    val allPersons = realPersonActivities.select("personId").distinct().collectAsList()
    assert(allPersons.size().equals(2))
    assert(allPersons.get(0).getString(0).equals("b9ca7f1bf2202004f3dcea9d79e6e750"))
    assert(allPersons.get(1).getString(0).equals("9a8aa44cda576dc721b32b3963bdcf65"))

    val firstNames = realPersonActivities.select("firstName").collectAsList()
    assert(firstNames.get(0).getString(0).equals("SURESH"))
    assert(firstNames.get(1).getString(0).equals("BHAVIN"))

    val lastNames = realPersonActivities.select("lastName").collectAsList()
    assert(lastNames.get(0).getString(0).equals("BIXBY"))
    assert(lastNames.get(1).getString(0).equals("BARKER"))

    val primaryEmail = realPersonActivities.select("email").collectAsList()
    assert(primaryEmail.get(1).getString(0).equals("bhavin.barker@gmail.com"))

    val primaryPhoneNumber = realPersonActivities.select("homePhone").collectAsList()
    assert(primaryPhoneNumber.get(0).getString(0).equals("+11234567890"))
    assert(primaryPhoneNumber.get(1).getString(0).equals("1234567890"))

    val sex = realPersonActivities.select("sex").collectAsList()
    assert(sex.get(0).getString(0).equals("F"))
    assert(sex.get(1).getString(0).equals("F"))

    val zip5 = realPersonActivities.select("zip5").collectAsList()
    assert(zip5.get(0).getString(0).equals("30116"))
    assert(zip5.get(1).getString(0).equals("30116"))

    val demoCustomer = realPersonActivities.select("customer").collectAsList()
    assert(demoCustomer.get(0).getString(0).equals("tanner"))
    assert(demoCustomer.get(1).getString(0).equals("tanner"))
  }

  "Demo Activities" should "be generated" in {

    val demoDataFrame: Dataset[Activity] = DemoDataGenerator.buildDemoDataset(initializedDataFrames)
    val allPersons = demoDataFrame.select("personId").distinct().collectAsList()
    assert(allPersons.size().equals(2))
    assert(allPersons.get(0).getString(0).equals("b9ca7f1bf2202004f3dcea9d79e6e750"))
    assert(allPersons.get(1).getString(0).equals("9a8aa44cda576dc721b32b3963bdcf65"))

    val batchId = demoDataFrame.select("batchId").collectAsList()
    assert(batchId.get(0).getString(0).equals("peachtree-encounter-influencehealth-2018-03"))
    assert(batchId.get(1).getString(0).equals("peachtree-encounter-influencehealth-2018-03"))

    val firstNames = demoDataFrame.select("firstName").collectAsList()
    assert(firstNames.get(0).getString(0).equals("Benoite"))
    assert(firstNames.get(1).getString(0).equals("Fancy"))

    val lastNames = demoDataFrame.select("lastName").collectAsList()
    assert(lastNames.get(0).getString(0).equals("Illiston"))
    assert(lastNames.get(1).getString(0).equals("Kemitt"))

    val primaryEmail = demoDataFrame.select("email").collectAsList()
    assert(primaryEmail.get(0).getString(0).equals("jilliston0@rediff.com"))
    assert(primaryEmail.get(1).getString(0).equals("ekemitt1@photobucket.com"))

    val primaryPhoneNumber = demoDataFrame.select("homePhone").collectAsList()
    assert(primaryPhoneNumber.get(0).getString(0).equals("4044562585"))
    assert(primaryPhoneNumber.get(1).getString(0).equals("4041133551"))

    val city = demoDataFrame.select("city").collectAsList()
    assert(city.get(0).getString(0).equals("ATLANTA"))
    assert(city.get(1).getString(0).equals("CANTON"))

    val sex = demoDataFrame.select("sex").collectAsList()
    assert(sex.get(0).getString(0).equals("F"))
    assert(sex.get(1).getString(0).equals("F"))

    val zip5 = demoDataFrame.select("zip5").collectAsList()
    assert(zip5.get(0).getString(0).equals("30339"))
    assert(zip5.get(1).getString(0).equals("30114"))

    val demoCustomer = demoDataFrame.select("customer").collectAsList()
    assert(demoCustomer.get(0).getString(0).equals("peachtree"))
    assert(demoCustomer.get(1).getString(0).equals("peachtree"))

  }

  "Demo data" should "pass validation (replace realPersonActivities with fakePersonDemographics data)" in {

    val fakePersonDemographics = initializedDataFrames("fakePersonDemographics").asInstanceOf[DataFrame].select(deIdentifyingColumns.map(c => col(c)): _*)
    val realPersonActivities = initializedDataFrames("realPersonActivities").asInstanceOf[DataFrame].select(deIdentifyingColumns.map(c => col(c)): _*)
    val demoDataFrame: Dataset[Activity] = DemoDataGenerator.buildDemoDataset(initializedDataFrames)

    val fakePerson1 = fakePersonDemographics.select(deIdentifyingColumns.map(c => col(c)): _*).where("seqNo == 1")
    val fakePerson2 = fakePersonDemographics.select(deIdentifyingColumns.map(c => col(c)): _*).where("seqNo == 2")

    val realPerson1 = realPersonActivities.select(deIdentifyingColumns.map(c => col(c)): _*).where("personId == 'b9ca7f1bf2202004f3dcea9d79e6e750'")
    val realPerson2 = realPersonActivities.select(deIdentifyingColumns.map(c => col(c)): _*).where("personId == '9a8aa44cda576dc721b32b3963bdcf65'")

    val demoPerson1 = demoDataFrame.select(deIdentifyingColumns.map(c => col(c)): _*).where("personId == 'b9ca7f1bf2202004f3dcea9d79e6e750'")
    val demoPerson2 = demoDataFrame.select(deIdentifyingColumns.map(c => col(c)): _*).where("personId == '9a8aa44cda576dc721b32b3963bdcf65'")

    assert(fakePerson1.select("firstName").collectAsList().get(0).get(0).equals("Benoite")
      && realPerson1.select("firstName").collectAsList().get(0).get(0).equals("SURESH")
      && demoPerson1.select("firstName").collectAsList().get(0).get(0).equals("Benoite"))

    assert(fakePerson1.select("lastName").collectAsList().get(0).get(0).equals("Illiston")
      && realPerson1.select("lastName").collectAsList().get(0).get(0).equals("BIXBY")
      && demoPerson1.select("lastName").collectAsList().get(0).get(0).equals("Illiston"))

    assert(fakePerson1.select("homePhone").collectAsList().get(0).get(0).equals("404-456-2585")
      && realPerson1.select("homePhone").collectAsList().get(0).get(0).equals("+11234567890")
      && demoPerson1.select("homePhone").collectAsList().get(0).get(0).equals("4044562585"))

    assert(fakePerson1.select("sex").collectAsList().get(0).get(0).equals("F")
      && realPerson1.select("sex").collectAsList().get(0).get(0).equals("F")
      && demoPerson1.select("sex").collectAsList().get(0).get(0).equals("F"))

    assert(fakePerson1.select("zip5").collectAsList().get(0).get(0).equals("30339")
      && realPerson1.select("zip5").collectAsList().get(0).get(0).equals("30116")
      && demoPerson1.select("zip5").collectAsList().get(0).get(0).equals("30339"))

    assert(fakePerson2.select("firstName").collectAsList().get(0).get(0).equals("Fancy")
      && realPerson2.select("firstName").collectAsList().get(0).get(0).equals("BHAVIN")
      && demoPerson2.select("firstName").collectAsList().get(0).get(0).equals("Fancy"))

    assert(fakePerson2.select("lastName").collectAsList().get(0).get(0).equals("Kemitt")
      && realPerson2.select("lastName").collectAsList().get(0).get(0).equals("BARKER")
      && demoPerson2.select("lastName").collectAsList().get(0).get(0).equals("Kemitt"))

    assert(fakePerson2.select("middleName").collectAsList().get(0).get(0).equals("Evita")
      && demoPerson2.select("middleName").collectAsList().get(0).get(0).equals("Evita"))

    assert(fakePerson2.select("email").collectAsList().get(0).get(0).equals("ekemitt1@photobucket.com")
      && realPerson2.select("email").collectAsList().get(0).get(0).equals("bhavin.barker@gmail.com")
      && demoPerson2.select("email").collectAsList().get(0).get(0).equals("ekemitt1@photobucket.com"))
  }

}