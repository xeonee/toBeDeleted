package com.influencehealth.edh.refresh.elasticsearch

import java.sql.{Date, Timestamp}
import java.time.{LocalDate, LocalDateTime}

import com.google.gson.{JsonObject, JsonParser}
import com.influencehealth.edh.model.{Activity, Person}
import com.influencehealth.edh.test.spark.SparkSpecBase
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Dataset}
import org.scalatest.Matchers

class ElasticsearchDaoSpec extends SparkSpecBase with Matchers {

  it should "correctly map the data to provided es schema" in {

    import spark.implicits._

    val persons: Dataset[Person] = spark.createDataset(Seq(
      Person(
        customer = "somecustomer",
        personId = "12345",
        dateCreated = Timestamp.valueOf(LocalDateTime.now()),
        dateOfBirth = Some(Date.valueOf(LocalDate.now())),
        occupation = Some("")
      )
    ))
    val activities: Dataset[Activity] = spark.createDataset(Seq(
      Activity(
        customer = "somecustomer",
        activityId = "23456",
        batchId = "34567",
        personId = Some("12345"),
        activityDate = Date.valueOf(LocalDate.now()),
        dateCreated = Timestamp.valueOf(LocalDateTime.now()),
        providers = Seq("1669811246;1815", "NULL;1805")
      )
    ))
    val complexColumnsToPreserve: Seq[String] = Seq("addressCoordinates")
    val columnsToIgnore: Seq[String] = Seq("lists")
    val parser = new JsonParser()
    val personMappingJson: JsonObject = parser.parse(
      """
        |{
        |   "dynamic": "strict",
        |   "properties": {
        |     "personId": {
        |       "type": "keyword",
        |       "doc_values": true
        |     },
        |    "dateOfBirth": {
        |      "type": "date",
        |      "doc_values": true
        |    },
        |    "addressCoordinates": {
        |      "type": "geo_point",
        |      "doc_values": true
        |    },
        |    "occupation": {
        |      "type": "integer",
        |      "doc_values": true
        |    },
        |    "lists": {
        |      "type": "nested",
        |      "properties": {
        |        "createdAt": {
        |          "type": "date",
        |          "doc_values": true
        |        },
        |        "id": {
        |          "type": "integer",
        |          "doc_values": true
        |        },
        |        "seg": {
        |          "type": "integer",
        |          "doc_values": true
        |        }
        |      }
        |    },
        |    "phoneNumbers": {
        |      "type": "nested",
        |      "properties": {
        |        "phone": {
        |          "type": "keyword",
        |          "doc_values": true
        |        },
        |        "phoneType": {
        |          "type": "keyword",
        |          "doc_values": true
        |        }
        |      }
        |    },
        |    "estimatedHomeValue": {
        |      "type": "keyword"
        |    },
        |    "hasDonatedToCharity": {
        |      "type": "boolean",
        |      "doc_values": true
        |    },
        |    "activities": {
        |      "type": "nested",
        |      "properties": {
        |        "activityId": {
        |          "type": "keyword"
        |        },
        |        "dateCreated": {
        |          "type": "date",
        |          "doc_values": true
        |        },
        |        "isErPatient": {
        |          "type": "boolean",
        |          "doc_values": true
        |        },
        |        "dischargeStatus": {
        |          "type": "keyword"
        |        },
        |        "charges": {
        |          "type": "scaled_float",
        |          "scaling_factor": 100
        |        },
        |        "procedureCodes": {
        |          "type": "nested",
        |          "properties": {
        |            "medicalCode": {
        |              "type": "keyword"
        |            },
        |            "medicalCodeType": {
        |              "type": "keyword"
        |            },
        |            "sequenceNumber": {
        |              "type": "integer"
        |            }
        |          }
        |        },
        |        "providers": {
        |          "type": "nested",
        |          "properties": {
        |            "npi": {
        |              "type": "keyword",
        |              "doc_values": true
        |            },
        |            "type": {
        |              "type": "keyword",
        |              "doc_values": true
        |            }
        |          }
        |        }
        |      }
        |    }
        |   }
        |}
      """.stripMargin).getAsJsonObject

    val transformer: ElasticsearchTransformer = new ElasticsearchTransformer()

    val outputDataFrame: DataFrame = transformer.transformToElasticsearchIndex(
      persons,
      activities,
      complexColumnsToPreserve,
      columnsToIgnore,
      personMappingJson
    )

    outputDataFrame.schema shouldBe StructType(Seq(
      StructField("personId", StringType, true),
      StructField("phoneNumbers", ArrayType(StructType(Seq(
        StructField("phone", StringType, true),
        StructField("phoneType", StringType, true)
      )), true), true),
      StructField("estimatedHomeValue", StringType, true),
      StructField("hasDonatedToCharity", BooleanType, true),
      StructField("occupation", StringType, true),
      StructField("addressCoordinates", StructType(Seq(
        StructField("lat", FloatType, false),
        StructField("lon", FloatType, false)
      )), true),
      StructField("dateOfBirth", DateType, true),
      StructField("activities", ArrayType(
        StructType(Seq(
          StructField("activityId", StringType, true),
          StructField("dischargeStatus", StringType, true),
          StructField("isErPatient", BooleanType, true),
          StructField("dateCreated", TimestampType, true),
          StructField("procedureCodes", ArrayType(StructType(Seq(
            StructField("medicalCode", StringType, true),
            StructField("medicalCodeType", StringType, true),
            StructField("sequenceNumber", IntegerType, false)
          ))), true),
          StructField("providers", ArrayType(MapType(
            StringType, StringType, true), true), true),
          StructField("charges", FloatType, true)
        ))
      ), true)
    ))

  }

}
