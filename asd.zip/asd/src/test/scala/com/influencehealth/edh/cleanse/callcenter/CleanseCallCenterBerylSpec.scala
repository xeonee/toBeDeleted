package com.influencehealth.edh.cleanse.callcenter

import com.influencehealth.edh.dao.FileSystemDao
import com.influencehealth.edh.model.schema.CallCenterSchema
import com.influencehealth.edh.test.spark.SparkSpecBase
import com.influencehealth.edh.{AppCleanser, Constants}
import org.apache.spark.sql.{DataFrame, Row}
import org.scalamock.scalatest.MockFactory
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}

class CleanseCallCenterBerylSpec
  extends FlatSpec with SparkSpecBase with BeforeAndAfter with Matchers with MockFactory {

  val InputDirectoryPath: String = "fixtures/cleanse/callcenter/beryl/callcenter.txt"
  val DateBatchReceived: String = "11/01/2017"
  val Customer = "chomp"
  val BatchId = "chomp-callcenter-beryl-2017-11"

  var incomingRawCallcenterRecordsDf: DataFrame = _
  var cleansedDataFrame: DataFrame = _
  var dirtyDataFrame: DataFrame = _

  it should "correctly cleanse beryl call center persons file" in {
    val rawData = spark.createDataFrame(
      spark.sparkContext.parallelize(Seq(
          Row( "31442613" , "2018-01-02 07:59:37.850000000" , "11111111" , "Will" , "Bet" ,null,null, "20 Post" ,null, "Lumb" , "TX" , "77657" , "517" , "243" , "1508" ,null,null,null, "123456789" , "F" , "01/01/1989" , "abc@test.com" , "N" ,null, "Hospital Website" , " www.hospital.org" ,null,null,null, "01" , "0" , "12734" , "CHRISTUS Physician Group" ),
          Row( "31447116" , "2018-01-02 14:43:38.173000000" , "22222222" , "Gri" ,null,null,null, "20 Post" ,null, "scott" , "AR" , "71857" , "870" , "703" , "3779" ,null,null,null, "123456789" , "F" ,null, "abc@test.com" , "N" ,null, "Internet" , "No Media Source" ,null,null,null, "01" , "0" , "12734" , "CHRISTUS Physician Group" ),
          Row( "31442614" , "18-02-03 08:59:37.850000000" , "33333333" , "ams" , "Bet" ,null,null, "20 Post" ,null, "Luton" , "TX" , "77657" , "517" , "243" , "1508" ,null,null,null, "123456789" , "F" , "12/21/89" , "abc@test.com" , "N" ,null, "Hospital Website" , " www.hospital.org" ,null,null,null, "01" , "0" , "12734" , "CHRISTUS Physician Group" )      )),
      CallCenterSchema.callCenterBerylSchema
    )

    val mockFileSystemDao = mock[FileSystemDao]

    (mockFileSystemDao.readCallCenterFile _).expects(false, Constants.CallCenterBerylFormat, Seq(InputDirectoryPath)).returns(rawData)


    val (cleansedDataFrame: DataFrame, dirtyDataFrame: DataFrame) = AppCleanser.cleanseData(
      Some(Customer), Constants.CallCenterActivityType, BatchId, false, InputDirectoryPath,
      Constants.CallCenterBerylFormat, "11/01/2017", mockFileSystemDao
    )

    cleansedDataFrame.count() shouldBe 2
    cleansedDataFrame.select("firstName").collectAsList().get(0).getString(0) shouldBe "Bet"
    cleansedDataFrame.select("source").collectAsList().get(0).getString(0) shouldBe Constants.CallCenterActivityType
    cleansedDataFrame.
      select("sourceRecordId").collectAsList().get(0).getString(0) shouldBe "a57de63da5fbda6d602d710354fbe712"
    val dateOfBirth = cleansedDataFrame.select("dateOfBirth").collectAsList()
    dateOfBirth.get(0).getDate(0).toString shouldBe "1989-01-01"
    dateOfBirth.get(1).getDate(0).toString shouldBe "1989-12-21"
    val activityDate = cleansedDataFrame.select("activityDate").collectAsList()
    activityDate.get(0).getString(0) shouldBe "2018-01-02 07:59:37"
    activityDate.get(1).getString(0) shouldBe "2018-02-03 08:59:37"

    cleansedDataFrame.select("lastName").collectAsList().get(0).getString(0) shouldBe "Will"

    dirtyDataFrame.count() shouldBe 1
    dirtyDataFrame.select("firstName").collectAsList().get(0).getString(0) shouldBe null

  }


}