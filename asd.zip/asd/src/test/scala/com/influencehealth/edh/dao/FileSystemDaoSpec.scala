package com.influencehealth.edh.dao

import org.scalamock.scalatest.MockFactory
import org.scalatest.{FlatSpec, Matchers}

class FileSystemDaoSpec extends FlatSpec with Matchers with MockFactory {


  // TODO: DNS Header Test Case
  // Row( "LAST_NAME" , "FIRST_NAME" , "MIDDLE_NAME" , "ADDRESS1" , "ADDRESS2" , "CITY" , "STATE" , "ZIP" , "GENDER" , "BIRTHDATE" , "PHONE" , "EMAIL" , "DO_NOT_SOLICIT_REASON" )


  // TODO: DONOR LIST Header Test Case
  // Row( "SOURCE_TYPE" , "SOURCE" , "ID" , "PREFIX" , "LAST_NAME" , "FIRST_NAME" , "MIDDLE_NAME" , "PERSONAL_SUFFIX" , "PROFESSIONAL_SUFFIX" , "ADDRESS_TYPE" , "ADDRESS_STATUS" , "ADDRESS1" , "ADDRESS2" , "CITY" , "STATE" , "ZIP" , "SEX" , "DOB" , "PHONE" , "EMAIL" )


  // TODO: Marketing List Header Test Case
  // Row( "CLIENT" , "LAST_NAME" , "FIRST_NAME" , "MIDDLE_NAME" , "ADDRESS1" , "ADDRESS2" , "CITY" , "STATE" , "ZIP" , "GENDER" , "DOB" , "PHONE" , "EMAIL" , "LIST_NAME" , "EVENT DATE" )

  // TODO: New Movers Header Test Case
  // Row( "PREFIX" , "FIRST_NAME" , "MIDDLE_NAME" , "LAST_NAME" , "SUFFIX" , "ADDRESS2" , "ADDRESS1" , "CITY" , "STATE" , "ZIP" , "PRIOR_ZIP" , "GENDER" , "AGE" , "ESTHOUSEHOLDINCOMEV5" , "MARITAL_STAT" , "POC" )

  // TODO: Referral Header Test Case
  // Row("cc_call_no", "seq_no", "created_date_time", "cc_person_no", "lastname", "firstname", "mi", "gq", "address1", "address2", "city", "state", "zip5", "home_area", "home_prefix", "home_suffix", "work_area", "work_prefix", "work_suffix", "work_ext", "gender", "birth_date", "email_address", "no_mail_flag", "spanish_req_flag", "warm_trans_flag", "referral_type_code", "referral_type_code_sub", "cc_fac_no", "fac_name", "topic", "sub_topic", "cc_phys_no", "phys_last_name", "phys_first_name", "phys_mi", "specialty", "office_name", "office_address1", "office_address2", "office_city", "office_state", "office_zip", "Appt_made_flag", "Appt_date_time", "Appt_office_name", "appt_office_address1", "Appt_office_city", "Appt_office_state", "Appt_office_zip", "Alt_phys_name", "appt_not_made_reason", "cc_reg_no", "class_name", "Class_Date_Time", "cc_svc_no", "svc_name"),


  // TODO: Unit tests to confirm DAO is removing empty lines from fixed width files

}
