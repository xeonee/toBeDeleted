package com.influencehealth.edh.linker

import java.sql.{Date, Timestamp}

import com.influencehealth.edh.Constants
import com.influencehealth.edh.identity.EnrichIdentity
import com.influencehealth.edh.model.Person
import com.influencehealth.edh.test.spark.SparkSpecBase
import org.apache.spark.sql._
import org.apache.spark.util.LongAccumulator
import org.scalatest.{Ignore, Matchers}

@Ignore
class SparkIdentityLinkerSpec extends SparkSpecBase with Matchers {

  val CustomerValue = "testcustomer"

  it should "identify duplicate records" in {

    val person1AId = "8d663d5a-4fb1-4032-81d9-6cf72ba42db9"
    val person1BId = "4545099e-37bb-4eb1-a4cf-a1e55fd8f9b3"

    val person1A: Person = Person(
      customer = CustomerValue,
      personId = person1AId,
      zip5 = Some("90210"),
      firstName = Some("Phillip"),
      middleName = Some("Zeke"),
      lastName = Some("Banks"),
      personalSuffix = Some("SR"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1945-01-30")),
      primaryEmail = Some("phillip.banks@gmail.com"),
      primaryPhoneNumber = Some("5555555555"),
      mrids = Seq("phillip.banks.mrid"),
      address1 = Some("address1"),
      address2 = Some("address2"),
      streetSecondNumber = Some("streetsecondnumber"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    val person1B: Person = Person(
      customer = CustomerValue,
      personId = person1BId,
      zip5 = Some("90210"),
      firstName = Some("Phillip"),
      middleName = Some("Zeke"),
      lastName = Some("Banks"),
      personalSuffix = Some("SR"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1945-01-30")),
      primaryEmail = Some("phillip.banks@gmail.com"),
      primaryPhoneNumber = Some("5555555555"),
      mrids = Seq("phillip.banks.mrid"),
      address1 = Some("address1"),
      address2 = Some("address2"),
      streetSecondNumber = Some("streetsecondnumber"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    import spark.implicits._

    val duplicates: Dataset[Person] = spark.createDataset(Seq(person1A,person1B))
    val accum: LongAccumulator = spark.sparkContext.longAccumulator("person collapse accumulator")
    val inMemoryPersonLinker = new PersonLinker(accum, null, CustomerValue, "activityId")
      with PersonLinkerImpl with PersonInMemoryEntityDB

    val results = EnrichIdentity.linkPersons(duplicates, inMemoryPersonLinker)

    results.count shouldBe 1

  }

  it should "collapse to one person" in {

    val person1AId = "98cde29f-dea6-4a15-a0da-37cfccda81a3"
    val person1BId = "837ecb68-105f-43fa-b85b-595df2f9f3ae"

    val person1A: Person = Person(
      customer = CustomerValue,
      personId = person1AId,
      zip5 = Some("90210"),
      firstName = Some("Phillip"),
      middleName = Some("Zeke"),
      lastName = Some("Banks"),
      personalSuffix = Some("SR"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1945-1-30")),
      primaryEmail = Some("phillip.banks@gmail.com"),
      primaryPhoneNumber = Some("5555555555"),
      mrids = Seq("phillip.banks.mrid"),
      address1 = Some("address1"),
      address2 = Some("address2"),
      streetSecondNumber = Some("streetsecondnumber"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    val person1B: Person = Person(
      customer = CustomerValue,
      personId = person1BId,
      zip5 = Some("90210"),
      firstName = Some("Phillip"),
      middleName = Some("Zeke"),
      lastName = Some("Banks"),
      personalSuffix = Some("SR"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1945-1-30")),
      primaryEmail = Some("phillip.banks@gmail.com"),
      primaryPhoneNumber = Some("5555555555"),
      mrids = Seq("phillip.banks.mrid"),
      address1 = Some("address1"),
      address2 = Some("address2"),
      streetSecondNumber = Some("streetsecondnumber"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    val person1C: Person = Person(
      customer = CustomerValue,
      personId = "6c2b2380-7867-48e9-bd2c-fe35d4ea8470",
      zip5 = Some("90210"),
      firstName = Some("Phillip"),
      middleName = Some("Zeke"),
      lastName = Some("Banks"),
      personalSuffix = Some("SR"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1945-1-30")),
      primaryEmail = Some("phillip.banks@gmail.com"),
      primaryPhoneNumber = Some("5555555555"),
      mrids = Seq("phillip.banks.mrid"),
      address1 = Some("address1"),
      address2 = Some("address2"),
      streetSecondNumber = Some("streetsecondnumber"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    import spark.implicits._

    val duplicates: Dataset[Person] = spark.sparkContext.parallelize(Seq(person1A,person1B,person1C)).toDS()
    val accum: LongAccumulator = spark.sparkContext.longAccumulator("person collapse accumulator")
    val inMemoryPersonLinker = new PersonLinker(accum, null, CustomerValue, "personId")
      with PersonLinkerImpl with PersonInMemoryEntityDB

    val results = EnrichIdentity.linkPersons(duplicates, inMemoryPersonLinker)

    results.count shouldBe 1

  }

  it should "ignore invalid record" in {

    val person1AId = "6461adac-8f7b-4a06-a051-5f7ad3ae1cfb"
    val person1BId = "b4daf537-d63d-42f4-98c9-cf8dbfcd652f"

    val person1A: Person = Person(
      customer = CustomerValue,
      personId = person1AId,
      zip5 = Some("90210"),
      firstName = Some("Phillip"),
      middleName = Some("Zeke"),
      lastName = Some("Banks"),
      personalSuffix = Some("SR"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1945-1-30")),
      primaryEmail = Some("phillip.banks@gmail.com"),
      primaryPhoneNumber = Some("5555555555"),
      mrids = Seq("phillip.banks.mrid"),
      address1 = Some("address1"),
      address2 = Some("address2"),
      streetSecondNumber = Some("streetsecondnumber"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    val person1B: Person = Person(
      customer = CustomerValue,
      personId = person1BId,
      zip5 = Some("90210"),
      firstName = Some("Phillip"),
      middleName = Some("Zeke"),
      lastName = Some("Banks"),
      personalSuffix = Some("SR"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1945-1-30")),
      primaryEmail = Some("phillip.banks@gmail.com"),
      primaryPhoneNumber = Some("5555555555"),
      mrids = Seq("phillip.banks.mrid"),
      address1 = Some("address1"),
      address2 = Some("address2"),
      streetSecondNumber = Some("streetsecondnumber"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    val person2A: Person = Person(
      customer = CustomerValue,
      personId = "39f67ba3-607a-42f7-8e4e-8ff158d86e8b",
      zip5 = Some("90210"),
      firstName = Some("Fred"),
      lastName = Some("Flintstone"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1900-1-1")),
      mrids = Seq("fred.flintstore.mrid"),
      address1 = Some("another address1"),
      address2 = Some("another address2"),
      streetSecondNumber = Some("another streetsecondnumber"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    import spark.implicits._

    val duplicates: Dataset[Person] = spark.sparkContext.parallelize(Seq(person1A,person1B,person2A)).toDS()
    val accum: LongAccumulator = spark.sparkContext.longAccumulator("person collapse accumulator")
    val inMemoryPersonLinker = new PersonLinker(accum, null, CustomerValue, "personId")
      with PersonLinkerImpl with PersonInMemoryEntityDB

    val results = EnrichIdentity.linkPersons(duplicates, inMemoryPersonLinker)

    results.count shouldBe 2
  }

  it should "identify duplicate records with change of address" in {

    val person1AId = "6461adac-8f7b-4a06-a051-5f7ad3ae1cfb"
    val person1BId = "b4daf537-d63d-42f4-98c9-cf8dbfcd652f"

    val person1A: Person = Person(
      customer = CustomerValue,
      personId = person1AId,
      firstName = Some("Rick"),
      middleName = None,
      lastName = Some("Sanchez"),
      personalSuffix = Some("SR"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1947-1-30")),
      primaryEmail = Some("rick.sanchez@gmail.com"),
      primaryPhoneNumber = Some("5555555555"),
      mrids = Seq("rick.sanchez.mrid"),
      address1 = Some("address1"),
      address2 = Some("address2"),
      streetSecondNumber = Some("C137"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    val person1B: Person = Person(
      customer = CustomerValue,
      personId = person1BId,
      firstName = Some("Rick"),
      middleName = None,
      lastName = Some("Sanchez"),
      personalSuffix = Some("SR"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1947-1-30")),
      primaryEmail = Some("rick.sanchez@gmail.com"),
      primaryPhoneNumber = Some("5555555555"),
      mrids = Seq("rick.sanchez.mrid"),
      address1 = Some("another address1"),
      address2 = Some("another address2"),
      streetSecondNumber = Some("C138"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )


    import spark.implicits._

    val duplicates: Dataset[Person] = spark.sparkContext.parallelize(Seq(person1A,person1B)).toDS()
    val accum: LongAccumulator = spark.sparkContext.longAccumulator("person collapse accumulator")
    val inMemoryPersonLinker = new PersonLinker(accum, null, CustomerValue, "personId")
      with PersonLinkerImpl with PersonInMemoryEntityDB

    val results = EnrichIdentity.linkPersons(duplicates, inMemoryPersonLinker)

    results.count() shouldBe 1
  }

  // temporary
  ignore should "identify duplicate records with last name change" in {

    import spark.implicits._

    val duplicates: Dataset[Person] = spark.createDataset(Seq(
      Person(
        customer = "testcustomer",
        personId = "6461adac-8f7b-4a06-a051-5f7ad3ae1cfb",
        dateModified = Some(Timestamp.valueOf("2018-10-19 20:00:00.0")),
        dateCreated = Timestamp.valueOf("2018-10-19 20:00:00.0"),
        firstName = Some("Vivian"),
        lastName = Some("Smith"),
        sex = Some(Constants.SexFemale),
        dateOfBirth = Some(Date.valueOf("1947-01-30")),
        primaryPhoneNumber = Some("5555555555"),
        primaryEmail = Some("vivian@gmail.com"),
        address1 = Some("address1"),
        address2 = Some("address2"),
        zip5 = Some("90210"),
        streetSecondNumber = Some("C137"),
        isValidAddress = Some(true)
      ),
      Person(
        customer = "testcustomer",
        personId = "b4daf537-d63d-42f4-98c9-cf8dbfcd652f",
        dateModified = Some(Timestamp.valueOf("2018-10-19 20:00:00.0")),
        dateCreated = Timestamp.valueOf("2018-10-19 20:00:00.0"),
        firstName = Some("Vivian"),
        lastName = Some("Banks"),
        sex = Some(Constants.SexFemale),
        dateOfBirth = Some(Date.valueOf("1947-01-30")),
        primaryPhoneNumber = Some("5555555555"),
        primaryEmail = Some("vivian@gmail.com"),
        address1 = Some("address1"),
        address2 = Some("address2"),
        zip5 = Some("90210"),
        streetSecondNumber = Some("C137"),
        isValidAddress = Some(true)
      )
    ))

    val accum: LongAccumulator = spark.sparkContext.longAccumulator("person collapse accumulator")
    val inMemoryPersonLinker = new PersonLinker(accum, null, CustomerValue, "personId")
      with PersonLinkerImpl with PersonInMemoryEntityDB

    val results = EnrichIdentity.linkPersons(duplicates, inMemoryPersonLinker)

    results.count() shouldBe 1
  }

  ignore should "identify duplicate records with last name and address change" in {
    import spark.implicits._

    val duplicates: Dataset[Person] = spark.createDataset(Seq(
      Person(
        customer = "testcustomer",
        personId = "6461adac-8f7b-4a06-a051-5f7ad3ae1cfb",
        dateModified = Some(Timestamp.valueOf("2018-10-19 20:00:00.0")),
        dateCreated = Timestamp.valueOf("2018-10-19 20:00:00.0"),
        firstName = Some("Vivian"),
        lastName = Some("Smith"),
        sex = Some("FEMALE"),
        dateOfBirth = Some(Date.valueOf("1947-01-30")),
        primaryPhoneNumber = Some("5555555555"),
        primaryEmail = Some("vivian@gmail.com"),
        address1 = Some("address1"),
        address2 = Some("address2"),
        zip5 = Some("90210"),
        streetSecondNumber = Some("C137"),
        isValidAddress = Some(true)
      ),

      Person(
        customer = "testcustomer",
        personId = "b4daf537-d63d-42f4-98c9-cf8dbfcd652f",
        dateModified = Some(Timestamp.valueOf("2018-10-19 20:00:00.0")),
        dateCreated = Timestamp.valueOf("2018-10-19 20:00:00.0"),
        firstName = Some("Vivian"),
        lastName = Some("Banks"),
        sex = Some("FEMALE"),
        dateOfBirth = Some(Date.valueOf("1947-01-30")),
        primaryPhoneNumber = Some("5555555555"),
        primaryEmail = Some("vivian@gmail.com"),
        address1 = Some("address1"),
        address2 = Some("address2"),
        zip5 = Some("90210"),
        streetSecondNumber = Some("C137"),
        isValidAddress = Some(true)
      )
    ))

    val accum: LongAccumulator = spark.sparkContext.longAccumulator("person collapse accumulator")
    val inMemoryPersonLinker = new PersonLinker(accum, null, CustomerValue, "personId")
      with PersonLinkerImpl with PersonInMemoryEntityDB

    val results = EnrichIdentity.linkPersons(duplicates, inMemoryPersonLinker)

    results.count shouldBe 2

    results.select("personId").distinct().count() shouldBe 1
  }

  it should "identify duplicate records with nick names" in {
    val person1AId = "6461adac-8f7b-4a06-a051-5f7ad3ae1cfb"
    val person1BId = "b4daf537-d63d-42f4-98c9-cf8dbfcd652f"

    val person1A: Person = Person(
      customer = CustomerValue,
      personId = person1AId,
      zip5 = Some("90210"),
      firstName = Some("Phillip"),
      middleName = Some("Zeke"),
      lastName = Some("Banks"),
      personalSuffix = Some("SR"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1945-1-30")),
      primaryEmail = Some("phillip.banks@gmail.com"),
      primaryPhoneNumber = Some("5555555555"),
      mrids = Seq("phillip.banks.mrid"),
      address1 = Some("address1"),
      address2 = Some("address2"),
      streetSecondNumber = Some("streetsecondnumber"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    val person1B: Person = Person(
      customer = CustomerValue,
      personId = person1BId,
      zip5 = Some("90210"),
      firstName = Some("Phillip"),
      middleName = Some("Zeke"),
      lastName = Some("Banks"),
      personalSuffix = Some("SR"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1945-1-30")),
      primaryEmail = Some("phillip.banks@gmail.com"),
      primaryPhoneNumber = Some("5555555555"),
      mrids = Seq("phillip.banks.mrid"),
      address1 = Some("address1"),
      address2 = Some("address2"),
      streetSecondNumber = Some("streetsecondnumber"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    import spark.implicits._

    val duplicates: Dataset[Person] = spark.createDataset(Seq(person1A, person1B))

    val accum: LongAccumulator = spark.sparkContext.longAccumulator("person collapse accumulator")
    val inMemoryPersonLinker = new PersonLinker(accum, null, CustomerValue, "personId")
      with PersonLinkerImpl with PersonInMemoryEntityDB

    val results = EnrichIdentity.linkPersons(duplicates, inMemoryPersonLinker)

    results.count shouldBe 1
  }

  it should "identify duplicate records with same email" in {

    val person1AId = "6461adac-8f7b-4a06-a051-5f7ad3ae1cfb"
    val person1BId = "b4daf537-d63d-42f4-98c9-cf8dbfcd652f"


    val person1A: Person = Person(
      customer = CustomerValue,
      personId = person1AId,
      firstName = Some("Phillip"),
      middleName = None,
      lastName = Some("Banks"),
      personalSuffix = None,
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1945-1-30")),
      primaryEmail = Some("phillip.banks@gmail.com"),
      mrids = Seq("phillip.banks.mrid"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    val person1B: Person = Person(
      customer = CustomerValue,
      personId = person1BId,
      firstName = Some("Phillip"),
      middleName = None,
      lastName = Some("Banks"),
      personalSuffix = None,
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1945-1-30")),
      primaryEmail = Some("phillip.banks@gmail.com"),
      mrids = Seq("phillip.banks.mrid"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    import spark.implicits._

    val duplicates: Dataset[Person] = spark.createDataset(Seq(person1A, person1B))
    val accum: LongAccumulator = spark.sparkContext.longAccumulator("person collapse accumulator")
    val inMemoryPersonLinker = new PersonLinker(accum, null, CustomerValue, "personId")
      with PersonLinkerImpl with PersonInMemoryEntityDB

    val results = EnrichIdentity.linkPersons(duplicates, inMemoryPersonLinker)

    results.count shouldBe 1

  }

  it should "identify duplicate records with same phone number" in {

    val person1AId = "6461adac-8f7b-4a06-a051-5f7ad3ae1cfb"
    val person1BId = "b4daf537-d63d-42f4-98c9-cf8dbfcd652f"

    val person1A: Person = Person(
      customer = CustomerValue,
      personId = person1AId,
      firstName = Some("Phillip"),
      lastName = Some("Banks"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1945-01-30")),
      primaryPhoneNumber = Some("5555555555"),
      mrids = Seq("phillip.banks.mrid"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    val person1B: Person = Person(
      customer = CustomerValue,
      personId = person1BId,
      firstName = Some("Phillip"),
      lastName = Some("Banks"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1945-01-30")),
      primaryPhoneNumber = Some("5555555555"),
      mrids = Seq("phillip.banks.mrid"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    import spark.implicits._

    val duplicates: Dataset[Person] = spark.createDataset(Seq(person1A, person1B))
    val accum: LongAccumulator = spark.sparkContext.longAccumulator("person collapse accumulator")
    val inMemoryPersonLinker = new PersonLinker(accum, null, CustomerValue, "personId")
      with PersonLinkerImpl with PersonInMemoryEntityDB

    val results = EnrichIdentity.linkPersons(duplicates, inMemoryPersonLinker)

    results.count() shouldBe 1

  }

  it should "ignore records from son and father" in {

    val person1AId = "6461adac-8f7b-4a06-a051-5f7ad3ae1cfb"
    val person2AId = "b4daf537-d63d-42f4-98c9-cf8dbfcd652f"

    val person1A: Person = Person(
      customer = CustomerValue,
      personId = person1AId,
      zip5 = Some("90210"),
      firstName = Some("Phillip"),
      middleName = Some("Zeke"),
      lastName = Some("Banks"),
      personalSuffix = Some("SR"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1945-01-30")),
      primaryEmail = Some("phillip.banks@gmail.com"),
      primaryPhoneNumber = Some("5555555555"),
      mrids = Seq("phillip.banks.mrid"),
      address1 = Some("address1"),
      address2 = Some("address2"),
      streetSecondNumber = Some("streetsecondnumber"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    val person2A: Person = Person(
      customer = CustomerValue,
      personId = person2AId,
      zip5 = Some("90210"),
      firstName = Some("Phillip"),
      middleName = Some("Elliot"),
      lastName = Some("Banks"),
      personalSuffix = Some("JR"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1980-12-01")),
      primaryEmail = Some("phillip.banks.jr@gmail.com"),
      primaryPhoneNumber = Some("5555555555"),
      mrids = Seq("phillip.banks.jr.mrid"),
      address1 = Some("address1"),
      address2 = Some("address2"),
      streetSecondNumber = Some("streetsecondnumber"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )


    import spark.implicits._

    val duplicates: Dataset[Person] = spark.createDataset(Seq(person1A, person2A))
    val accum: LongAccumulator = spark.sparkContext.longAccumulator("person collapse accumulator")
    val inMemoryPersonLinker = new PersonLinker(accum, null, CustomerValue, "personId")
      with PersonLinkerImpl with PersonInMemoryEntityDB

    val results = EnrichIdentity.linkPersons(duplicates, inMemoryPersonLinker)

    results.count shouldBe 2

  }

  it should "ignore records from son and father with no suffix" in {

    val person1AId = "6461adac-8f7b-4a06-a051-5f7ad3ae1cfb"
    val person2AId = "b4daf537-d63d-42f4-98c9-cf8dbfcd652f"

    val person1A: Person = Person(
      customer = CustomerValue,
      personId = person1AId,
      zip5 = Some("90210"),
      firstName = Some("Phillip"),
      middleName = Some("Zeke"),
      lastName = Some("Banks"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1945-01-30")),
      primaryEmail = Some("phillip.banks@gmail.com"),
      primaryPhoneNumber = Some("5555555555"),
      mrids = Seq("phillip.banks.mrid"),
      address1 = Some("address1"),
      address2 = Some("address2"),
      streetSecondNumber = Some("streetsecondnumber"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    val person2A: Person = Person(
      customer = CustomerValue,
      personId = person2AId,
      zip5 = Some("90210"),
      firstName = Some("Phillip"),
      middleName = Some("Elliot"),
      lastName = Some("Banks"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1980-12-01")),
      primaryEmail = Some("phillip.banks.jr@gmail.com"),
      primaryPhoneNumber = Some("5555555555"),
      mrids = Seq("phillip.banks.jr.mrid"),
      address1 = Some("address1"),
      address2 = Some("address2"),
      streetSecondNumber = Some("streetsecondnumber"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    import spark.implicits._

    val duplicates: Dataset[Person] = spark.createDataset(Seq(person1A, person2A))
    val accum: LongAccumulator = spark.sparkContext.longAccumulator("person collapse accumulator")
    val inMemoryPersonLinker = new PersonLinker(accum, null, CustomerValue, "personId")
      with PersonLinkerImpl with PersonInMemoryEntityDB

    val results = EnrichIdentity.linkPersons(duplicates, inMemoryPersonLinker)

    results.count() shouldBe 2
  }

  it should "ignore records from married couple" in {

    val person1AId = "6461adac-8f7b-4a06-a051-5f7ad3ae1cfb"
    val person1BId = "b4daf537-d63d-42f4-98c9-cf8dbfcd652f"

    val person1A: Person = Person(
      customer = CustomerValue,
      personId = person1AId,
      zip5 = Some("5555"),
      firstName = Some("Chris"),
      middleName = Some("middlename"),
      lastName = Some("Smith"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1980-12-01")),
      primaryEmail = Some("thesmithhousehold@gmail.com"),
      primaryPhoneNumber = Some("5555555555"),
      primaryPhoneNumberType = Some("HOME"),
      mrids = Seq("chris.smith.mrid"),
      address1 = Some("address1"),
      address2 = Some("address2"),
      streetSecondNumber = Some("streetsecondnumber"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    val person1B: Person = Person(
      customer = CustomerValue,
      personId = person1BId,
      zip5 = Some("55555"),
      firstName = Some("Christine"),
      middleName = Some("middlename"),
      lastName = Some("Smith"),
      sex = Some(Constants.SexFemale),
      dateOfBirth = Some(Date.valueOf("1983-12-01")),
      primaryEmail = Some("thesmithhousehold@gmail.com"),
      primaryPhoneNumber = Some("5555555555"),
      mrids = Seq("christine.smith.mrid"),
      address1 = Some("address1"),
      address2 = Some("address2"),
      streetSecondNumber = Some("streetsecondnumber"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    import spark.implicits._

    val duplicates: Dataset[Person] = spark.createDataset(Seq(person1A, person1B))

    val accum: LongAccumulator = spark.sparkContext.longAccumulator("person collapse accumulator")
    val inMemoryPersonLinker = new PersonLinker(accum, null, CustomerValue, "personId")
      with PersonLinkerImpl with PersonInMemoryEntityDB

    val results = EnrichIdentity.linkPersons(duplicates, inMemoryPersonLinker)

    results.count() shouldBe 2
  }

  it should "ignore records from married couple with the same dob" in {

    val person1AId = "6461adac-8f7b-4a06-a051-5f7ad3ae1cfb"
    val person1BId = "b4daf537-d63d-42f4-98c9-cf8dbfcd652f"

    val person1A: Person = Person(
      customer = CustomerValue,
      personId = person1AId,
      zip5 = Some("5555"),
      firstName = Some("Chris"),
      middleName = Some("middlename"),
      lastName = Some("Smith"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1980-12-01")),
      primaryEmail = Some("thesmithhousehold@gmail.com"),
      primaryPhoneNumber = Some("5555555555"),
      primaryPhoneNumberType = Some("HOME"),
      mrids = Seq("chris.smith.mrid"),
      address1 = Some("address1"),
      address2 = Some("address2"),
      streetSecondNumber = Some("streetsecondnumber"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    val person1B: Person = Person(
      customer = CustomerValue,
      personId = person1BId,
      zip5 = Some("55555"),
      firstName = Some("Christy"),
      middleName = Some("middlename"),
      lastName = Some("Smith"),
      sex = Some(Constants.SexFemale),
      dateOfBirth = Some(Date.valueOf("1980-12-01")),
      primaryEmail = Some("thesmithhousehold@gmail.com"),
      primaryPhoneNumber = Some("5555555555"),
      mrids = Seq("christine.smith.mrid"),
      address1 = Some("address1"),
      address2 = Some("address2"),
      streetSecondNumber = Some("streetsecondnumber"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    import spark.implicits._

    val duplicates: Dataset[Person] = spark.createDataset(Seq(person1A, person1B))

    val accum: LongAccumulator = spark.sparkContext.longAccumulator("person collapse accumulator")
    val inMemoryPersonLinker = new PersonLinker(accum, null, CustomerValue, "personId")
      with PersonLinkerImpl with PersonInMemoryEntityDB

    val results = EnrichIdentity.linkPersons(duplicates, inMemoryPersonLinker)

    results.count() shouldBe 2
  }

  it should "ignore records that match on rootFirstName and soundexLastName with empty email and empty phone" in {

    val person1AId = "6461adac-8f7b-4a06-a051-5f7ad3ae1cfb"
    val person1BId = "b4daf537-d63d-42f4-98c9-cf8dbfcd652f"

    val person1A: Person = Person(
      customer = CustomerValue,
      personId = person1AId,
      zip5 = Some("55555"),
      firstName = Some("albert"),
      lastName = Some("Waagenasz"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1955-08-01")),
      mrids = Seq("different.mrid.one"),
      address1 = Some("Some address1 for person1"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    val person1B: Person = Person(
      customer = CustomerValue,
      personId = person1BId,
      zip5 = Some("66666"),
      firstName = Some("alexander"),
      lastName = Some("Wachenhausen"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1995-12-01")),
      mrids = Seq("different.mrid.two"),
      address1 = Some("A completely different address1 for person2"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    import spark.implicits._

    val duplicates: Dataset[Person] = spark.createDataset(Seq(person1A, person1B))

    val accum: LongAccumulator = spark.sparkContext.longAccumulator("person collapse accumulator")
    val inMemoryPersonLinker = new PersonLinker(accum, null, CustomerValue, "personId")
      with PersonLinkerImpl with PersonInMemoryEntityDB

    val results = EnrichIdentity.linkPersons(duplicates, inMemoryPersonLinker)

    results.count() shouldBe 2
  }

  it should "ignore records that match on everything except dob with empty email and phone" in {

    val person1AId = "6461adac-8f7b-4a06-a051-5f7ad3ae1cfb"
    val person1BId = "b4daf537-d63d-42f4-98c9-cf8dbfcd652f"

    val person1A: Person = Person(
      customer = CustomerValue,
      personId = person1AId,
      zip5 = Some("66666"),
      firstName = Some("Alex"),
      middleName = Some("Z"),
      lastName = Some("The Great"),
      personalSuffix = Some("JR"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1921-12-01")),
      mrids = Seq("mrid1"),
      address1 = Some("Some address1 for person1"),
      address2 = Some("APT 1408"),
      streetSecondNumber = Some("1600"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    val person1B: Person = Person(
      customer = CustomerValue,
      personId = person1AId,
      zip5 = Some("66666"),
      firstName = Some("Alex"),
      middleName = Some("Z"),
      lastName = Some("The Great"),
      personalSuffix = Some("JR"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1998-05-10")),
      mrids = Seq("mrid2"),
      address1 = Some("Some address1 for person1"),
      address2 = Some("APT 1408"),
      streetSecondNumber = Some("1600"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    import spark.implicits._

    val duplicates: Dataset[Person] = spark.createDataset(Seq(person1A, person1B))

    val accum: LongAccumulator = spark.sparkContext.longAccumulator("person collapse accumulator")
    val inMemoryPersonLinker = new PersonLinker(accum, null, CustomerValue, "personId")
      with PersonLinkerImpl with PersonInMemoryEntityDB

    val results = EnrichIdentity.linkPersons(duplicates, inMemoryPersonLinker)

    results.count() shouldBe 2

  }

  it should "collapse records that match on everything except day in dob with empty email and phone" in {

    val person1AId = "6461adac-8f7b-4a06-a051-5f7ad3ae1cfb"
    val person1BId = "b4daf537-d63d-42f4-98c9-cf8dbfcd652f"

    val person1A: Person = Person(
      customer = CustomerValue,
      personId = person1AId,
      zip5 = Some("66666"),
      firstName = Some("Alex"),
      middleName = Some("Z"),
      lastName = Some("The Great"),
      personalSuffix = Some("JR"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1998-05-01")),
      mrids = Seq("mrid1"),
      address1 = Some("Some address1 for person1"),
      address2 = Some("APT 1408"),
      streetSecondNumber = Some("1600"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    val person1B: Person = Person(
      customer = CustomerValue,
      personId = person1AId,
      zip5 = Some("66666"),
      firstName = Some("Alex"),
      middleName = Some("Z"),
      lastName = Some("The Great"),
      personalSuffix = Some("JR"),
      sex = Some(Constants.SexMale),
      dateOfBirth = Some(Date.valueOf("1998-05-10")),
      mrids = Seq("mrid2"),
      address1 = Some("Some address1 for person1"),
      address2 = Some("APT 1408"),
      streetSecondNumber = Some("1600"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    import spark.implicits._

    val duplicates: Dataset[Person] = spark.createDataset(Seq(person1A, person1B))

    val accum: LongAccumulator = spark.sparkContext.longAccumulator("person collapse accumulator")
    val inMemoryPersonLinker = new PersonLinker(accum, null, CustomerValue, "personId")
      with PersonLinkerImpl with PersonInMemoryEntityDB

    val results = EnrichIdentity.linkPersons(duplicates, inMemoryPersonLinker)

    results.count() shouldBe 1

  }

  it should "collapse records when dob is empty and age difference <= 2 and has an empty email and phone" in {

    val person1AId = "6461adac-8f7b-4a06-a051-5f7ad3ae1cfb"
    val person1BId = "b4daf537-d63d-42f4-98c9-cf8dbfcd652f"

    val person1A: Person = Person(
      customer = CustomerValue,
      personId = person1AId,
      zip5 = Some("66666"),
      firstName = Some("Alex"),
      middleName = Some("Z"),
      lastName = Some("The Great"),
      personalSuffix = Some("JR"),
      sex = Some(Constants.SexMale),
      sourceAge = Some(30),
      mrids = Seq("mrid1"),
      address1 = Some("Some address1 for person1"),
      address2 = Some("APT 1408"),
      streetSecondNumber = Some("1600"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    val person1B: Person = Person(
      customer = CustomerValue,
      personId = person1AId,
      zip5 = Some("66666"),
      firstName = Some("Alex"),
      middleName = Some("Z"),
      lastName = Some("The Great"),
      personalSuffix = Some("JR"),
      sex = Some(Constants.SexMale),
      sourceAge = Some(29),
      mrids = Seq("mrid2"),
      address1 = Some("Some address1 for person1"),
      address2 = Some("APT 1408"),
      streetSecondNumber = Some("1600"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    import spark.implicits._

    val duplicates: Dataset[Person] = spark.createDataset(Seq(person1A, person1B))

    val accum: LongAccumulator = spark.sparkContext.longAccumulator("person collapse accumulator")
    val inMemoryPersonLinker = new PersonLinker(accum, null, CustomerValue, "personId")
      with PersonLinkerImpl with PersonInMemoryEntityDB

    val results = EnrichIdentity.linkPersons(duplicates, inMemoryPersonLinker)

    results.count() shouldBe 1

  }

  it should "collapse records when dob is empty and age is empty and has an empty email and phone" in {

    val person1AId = "6461adac-8f7b-4a06-a051-5f7ad3ae1cfb"
    val person1BId = "b4daf537-d63d-42f4-98c9-cf8dbfcd652f"

    val person1A: Person = Person(
      customer = CustomerValue,
      personId = person1AId,
      zip5 = Some("66666"),
      firstName = Some("Alex"),
      middleName = Some("Z"),
      lastName = Some("The Great"),
      personalSuffix = Some("JR"),
      sex = Some(Constants.SexMale),
      mrids = Seq("mrid1"),
      address1 = Some("Some address1 for person1"),
      address2 = Some("APT 1408"),
      streetSecondNumber = Some("1600"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    val person1B: Person = Person(
      customer = CustomerValue,
      personId = person1AId,
      zip5 = Some("66666"),
      firstName = Some("Alex"),
      middleName = Some("Z"),
      lastName = Some("The Great"),
      personalSuffix = Some("JR"),
      sex = Some(Constants.SexMale),
      mrids = Seq("mrid2"),
      address1 = Some("Some address1 for person1"),
      address2 = Some("APT 1408"),
      streetSecondNumber = Some("1600"),
      isValidAddress = Some(true),
      dateCreated = new Timestamp(Constants.Today.getMillis),
      dateModified = Some(new Timestamp(Constants.Today.getMillis))
    )

    import spark.implicits._

    val duplicates: Dataset[Person] = spark.createDataset(Seq(person1A, person1B))

    val accum: LongAccumulator = spark.sparkContext.longAccumulator("person collapse accumulator")
    val inMemoryPersonLinker = new PersonLinker(accum, null, CustomerValue, "personId")
      with PersonLinkerImpl with PersonInMemoryEntityDB

    val results = EnrichIdentity.linkPersons(duplicates, inMemoryPersonLinker)

    results.count() shouldBe 1

  }

}
