package com.influencehealth.edh.cleanse.hra

import com.influencehealth.edh.dao.{FileSystemDao, HRADetailV1, HRAHeaderV1}
import com.influencehealth.edh.model.schema.HraSchema
import com.influencehealth.edh.test.spark.SparkSpecBase
import com.influencehealth.edh.{AppCleanser, Constants}
import org.apache.spark.sql.{DataFrame, Row}
import org.scalamock.scalatest.MockFactory
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}

class CleanseHraSpec extends FlatSpec with SparkSpecBase with BeforeAndAfter with Matchers with MockFactory {

  val InputDirectoryPath: String = "fixtures/cleanse/hra/medicom/"
  val DateBatchReceived: String = "11/01/2017"
  val Customer: String = "chomp"
  val BatchId = "chomp-hra-medicom-2017-11"

  it should "cleanse hra file" in {

    val rawData = Map(
      HRAHeaderV1 -> spark.createDataFrame(spark.sparkContext.parallelize(Seq(
        Row("50297345178740EF814406E908A47EAC", "2017-10-01 14:58:34 +0000", null, "R", "Hawkins", "4465 Woodlawn", null, "Beaumont", "TX", "77703", "FEMALE", "1982-11-23", "4094661920", "missHawkins@gmail.com", "1423", "Weight-Loss Surgery Profiler(SETX )", "Map(normalWeightHigh -> 140.0, existingWeightConditions_ohs -> false, triglyceridesFactor -> UNKNOWN, smokerRisk -> LOW, existingWeightConditions_arthritis -> false, extremeObeseWeightLow -> 226.0, weight -> 275.0, triglycerides_estimate -> null, healthConditions -> YES, summaryMessage -> SURGERY, weeklyExercise_vigorous -> 0, medications_bloodPressure -> false, bullet4 -> UNKNOWN, ldlCholesterol_value -> null, hdlCholesterol_value -> null, diabetes -> PRE, dbpRisk -> UNKNOWN, medications_none -> true, ldlCholesterol_estimate -> null, sbp_value -> null, ethnicity_ethnicity -> AFRICAN, existingWeightConditions_none -> true, bmi -> 48.7087427563618, insurance -> PRIVATE INSURER, diabetesRisk -> MODERATE, obeseIIWeightHigh -> 225.0, existingWeightConditions_liverDisease -> false, dbp_value -> null, idealWeightUpper -> 140, hdlCholesterol_known -> false, hdlFactor -> UNKNOWN, triglycerides_known -> false, riskFactorCount -> 2, diabetesFactor -> YES, existingWeightConditions_sleepApnea -> false, waistMeasurementRisk -> HIGH, height -> 63.0, normalWeightLow -> 105.0, existingWeightConditions_vsDisease -> false, dbp_known -> false, waistMeasurement_asianEthnicity -> false, bullet1 -> SURGERY, idealWeightLossAmount -> 135, abnormalCholesterolFactor -> UNKNOWN, idealWeightGainAmount -> -170, assessmentCode -> 1423, fbsRisk -> UNKNOWN, obeseIWeightHigh -> 197.0, weightLossSurgeryRecommendation -> YES, weightCategory -> EXTREME_OBESE, age -> 34, weightLossRecomendation -> RECOMMENDED, existingWeightConditions_asthma -> false, qolImpaired -> YES, fastingBloodSugar_value -> null, hdlCholesterol_estimate -> null, qol -> YES, hdlRisk -> UNKNOWN, bullet2 -> OVERWEIGHT, activityFactor -> YES, fastingBloodSugar_known -> false, obeseIWeightLow -> 170.0, updated -> Sun Oct 01 14:58:34 UTC 2017, existingWeightConditions_psuedotumorCerebri -> false, medications_other -> false, smokingFactor -> NO, bloodPressureFactor -> UNKNOWN, totalCholesterolRisk -> UNKNOWN, totalCholesterol_value -> null, overweightWeightLow -> 141.0, fastingBloodSugar_estimate -> null, medications_diabetes -> false, hasUnknownRisks -> true, existingWeightConditions_gerd -> false, created_at -> 2017-10-01 14:58:34 +0000, totalCholesterol_known -> false, medications_cholesterol -> false, primaryCarePhysician_has -> false, idealWeightLower -> 105, dbp_estimate -> null, existingWeightConditions_incontinence -> false, primaryCarePhysician_visited -> null, exerciseRisk -> HIGH, triglyceridesRisk -> UNKNOWN, ldlFactor -> UNKNOWN, weeklyExercise_moderate -> 0, obeseIIWeightLow -> 198.0, sbpRisk -> UNKNOWN, updated_at -> 2017-10-01 14:58:34 +0000, overweightWeightHigh -> 169.0, heardAbout -> 15, sbp_estimate -> null, triglycerides_value -> null, totalCholesterol_estimate -> null, existing_patient -> false, sbp_known -> false, waistMeasurement_measurement -> 56, smoker -> FORMER_MORE, ldlCholesterol_known -> false, created -> Sun Oct 01 14:56:54 UTC 2017, ldlRisk -> UNKNOWN, gender -> FEMALE, ethnicity_preferNotToSay -> false)", "2018-12-13T01:31:36.692Z", "50297345178740EF814406E908A47EAC", "HRA"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "2017-10-01 14:54:51 +0000", "Steven", "J", "Hawkins", "4465 woodlawn", null, "Beaumont", "TX", "77703", "MALE", "1992-05-18", "4094668189", "3456@gmail.com", "1423", "Weight-Loss Surgery Profiler(SETX )", "Map(normalWeightHigh -> 194.0, existingWeightConditions_ohs -> false, triglyceridesFactor -> UNKNOWN, smokerRisk -> LOW, existingWeightConditions_arthritis -> false, extremeObeseWeightLow -> 312.0, weight -> 270.0, triglycerides_estimate -> null, healthConditions -> YES, summaryMessage -> WEIGHTLOSS, weeklyExercise_vigorous -> 0, medications_bloodPressure -> false, bullet4 -> UNKNOWN, ldlCholesterol_value -> null, hdlCholesterol_value -> null, diabetes -> PRE, dbpRisk -> UNKNOWN, medications_none -> false, ldlCholesterol_estimate -> null, sbp_value -> null, ethnicity_ethnicity -> AFRICAN, existingWeightConditions_none -> true, bmi -> 34.66216216216216, insurance -> PRIVATE INSURER, diabetesRisk -> MODERATE, obeseIIWeightHigh -> 311.0, existingWeightConditions_liverDisease -> false, dbp_value -> null, idealWeightUpper -> 194, hdlCholesterol_known -> false, hdlFactor -> UNKNOWN, triglycerides_known -> false, riskFactorCount -> 2, diabetesFactor -> YES, existingWeightConditions_sleepApnea -> false, waistMeasurementRisk -> HIGH, height -> 74.0, normalWeightLow -> 144.0, existingWeightConditions_vsDisease -> false, dbp_known -> false, waistMeasurement_asianEthnicity -> false, bullet1 -> SURGERY_NO, idealWeightLossAmount -> 76, abnormalCholesterolFactor -> UNKNOWN, idealWeightGainAmount -> -126, assessmentCode -> 1423, fbsRisk -> UNKNOWN, obeseIWeightHigh -> 272.0, weightLossSurgeryRecommendation -> NO, weightCategory -> OBESE1, age -> 25, weightLossRecomendation -> RECOMMENDED, existingWeightConditions_asthma -> false, qolImpaired -> YES, fastingBloodSugar_value -> null, hdlCholesterol_estimate -> null, qol -> YES, hdlRisk -> UNKNOWN, bullet2 -> OVERWEIGHT, activityFactor -> YES, fastingBloodSugar_known -> false, obeseIWeightLow -> 234.0, updated -> Sun Oct 01 14:54:52 UTC 2017, existingWeightConditions_psuedotumorCerebri -> false, medications_other -> false, smokingFactor -> NO, bloodPressureFactor -> UNKNOWN, totalCholesterolRisk -> UNKNOWN, totalCholesterol_value -> null, overweightWeightLow -> 195.0, fastingBloodSugar_estimate -> null, medications_diabetes -> true, hasUnknownRisks -> true, existingWeightConditions_gerd -> false, created_at -> 2017-10-01 14:54:51 +0000, totalCholesterol_known -> false, medications_cholesterol -> false, primaryCarePhysician_has -> false, idealWeightLower -> 144, dbp_estimate -> null, existingWeightConditions_incontinence -> false, primaryCarePhysician_visited -> null, exerciseRisk -> HIGH, triglyceridesRisk -> UNKNOWN, ldlFactor -> UNKNOWN, weeklyExercise_moderate -> 0, obeseIIWeightLow -> 273.0, sbpRisk -> UNKNOWN, updated_at -> 2017-10-01 14:54:51 +0000, overweightWeightHigh -> 233.0, heardAbout -> 15, sbp_estimate -> null, triglycerides_value -> null, totalCholesterol_estimate -> null, existing_patient -> false, sbp_known -> false, waistMeasurement_measurement -> 41, smoker -> NEVER, ldlCholesterol_known -> false, created -> Sun Oct 01 14:52:26 UTC 2017, ldlRisk -> UNKNOWN, gender -> MALE, ethnicity_preferNotToSay -> false)", "2018-12-13T01:31:36.692Z", "FBDEF92D82A442ED8CE982FE9E8972E1", "HRA")
      )), HraSchema.hraHeaderSchema),
      //         Row( "TRANSACTION_ID" , "ASSESSMENT_CODE" , "ASSESSMENT_DESC" , "VARIABLE" , "VALUE" )
      HRADetailV1 -> spark.createDataFrame(spark.sparkContext.parallelize(Seq(
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "id", "fbdef92d-82a4-42ed-8ce9-82fe9e8972e1"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "email", "94854DA4615DBF17ED2A6CBDBB02F3ED41E6C77172A70016AE4160AE429229B9"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "date_of_birth", "CEB63FDB052056C44B43AC2F77E450EA"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "first_name", "CADF8A87AC91CC38DDE80BEEA1468229"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "middle_initial", "2ECB9BF7B57F5DA6A230FF51C92EB3F0"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "last_name", "8DB31AFCF900B75287F65E414BD40C6E"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "address_1", "E768C537D438BD46DDCD0DFCA3B0DE58"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "address_2", null),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "city", "509F24CED53A1477D9624D5259E611E9"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "state", "B7E2E259ED5EF3AA0D8F7A28410437B3"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "zip_code", "AE81F4D60BE0FCFB63324AD1701E373F"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "phone_1", "E7287ED89FC45656C223E602493E3E02"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "special_offer", null),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "iv_legacy", null),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "created_at", "2017-10-01 14:54:51 +0000"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "updated_at", "2017-10-01 14:54:51 +0000"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "marketing_opt_in", null),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "existing_patient", "false"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "insurance", "PRIVATE INSURER"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "age", "25"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "bmi", "34.66216216216216"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "qol", "YES"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "gender", "MALE"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "height", "74.0"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "smoker", "NEVER"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "weight", "270.0"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "bullet1", "SURGERY_NO"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "bullet2", "OVERWEIGHT"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "bullet4", "UNKNOWN"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "created", "Sun Oct 01 14:52:26 UTC 2017"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "dbpRisk", "UNKNOWN"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "fbsRisk", "UNKNOWN"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "hdlRisk", "UNKNOWN"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "ldlRisk", "UNKNOWN"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "sbpRisk", "UNKNOWN"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "updated", "Sun Oct 01 14:54:52 UTC 2017"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "diabetes", "PRE"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "dbp_known", "false"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "dbp_value", "null"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "hdlFactor", "UNKNOWN"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "ldlFactor", "UNKNOWN"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "sbp_known", "false"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "sbp_value", "null"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "heardAbout", "15"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "smokerRisk", "LOW"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "qolImpaired", "YES"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "dbp_estimate", "null"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "diabetesRisk", "MODERATE"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "exerciseRisk", "HIGH"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "sbp_estimate", "null"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "smokingFactor", "NO"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "activityFactor", "YES"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "diabetesFactor", "YES"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "summaryMessage", "WEIGHTLOSS"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "weightCategory", "OBESE1"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "hasUnknownRisks", "true"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "normalWeightLow", "144.0"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "obeseIWeightLow", "234.0"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "riskFactorCount", "2"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "healthConditions", "YES"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "idealWeightLower", "144"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "idealWeightUpper", "194"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "medications_none", "false"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "normalWeightHigh", "194.0"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "obeseIIWeightLow", "273.0"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "obeseIWeightHigh", "272.0"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "medications_other", "false"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "obeseIIWeightHigh", "311.0"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "triglyceridesRisk", "UNKNOWN"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "bloodPressureFactor", "UNKNOWN"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "ethnicity_ethnicity", "AFRICAN"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "overweightWeightLow", "195.0"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "triglyceridesFactor", "UNKNOWN"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "triglycerides_known", "false"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "triglycerides_value", "null"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "hdlCholesterol_known", "false"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "hdlCholesterol_value", "null"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "ldlCholesterol_known", "false"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "ldlCholesterol_value", "null"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "medications_diabetes", "true"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "overweightWeightHigh", "233.0"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "totalCholesterolRisk", "UNKNOWN"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "waistMeasurementRisk", "HIGH"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "extremeObeseWeightLow", "312.0"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "idealWeightGainAmount", "-126"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "idealWeightLossAmount", "76"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "totalCholesterol_known", "false"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "totalCholesterol_value", "null"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "triglycerides_estimate", "null"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "fastingBloodSugar_known", "false"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "fastingBloodSugar_value", "null"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "hdlCholesterol_estimate", "null"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "ldlCholesterol_estimate", "null"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "medications_cholesterol", "false"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "weeklyExercise_moderate", "0"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "weeklyExercise_vigorous", "0"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "weightLossRecomendation", "RECOMMENDED"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "ethnicity_preferNotToSay", "false"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "primaryCarePhysician_has", "false"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "abnormalCholesterolFactor", "UNKNOWN"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "medications_bloodPressure", "false"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "totalCholesterol_estimate", "null"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "fastingBloodSugar_estimate", "null"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "existingWeightConditions_ohs", "false"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "primaryCarePhysician_visited", "null"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "waistMeasurement_measurement", "41"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "existingWeightConditions_gerd", "false"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "existingWeightConditions_none", "true"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "existingWeightConditions_asthma", "false"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "waistMeasurement_asianEthnicity", "false"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "weightLossSurgeryRecommendation", "NO"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "existingWeightConditions_arthritis", "false"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "existingWeightConditions_vsDisease", "false"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "existingWeightConditions_sleepApnea", "false"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "existingWeightConditions_incontinence", "false"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "existingWeightConditions_liverDisease", "false"),
        Row("FBDEF92D82A442ED8CE982FE9E8972E1", "1423", "Weight-Loss Surgery Profiler(SETX )", "existingWeightConditions_psuedotumorCerebri", "false"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "id", "50297345-1787-40ef-8144-06e908a47eac"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "email", "DC77C49CE64409767741A6212E454EAD836020CBA2FA5C3FD4BB2BFF4BEC2C45"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "date_of_birth", "0BCAB9C3BC052D7A1CDD84D03A099C9D"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "first_name", "4C989DE8788A87998BF0AC8B06BCB69B"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "middle_initial", "19C9AE44389F0518F6FA5DAEA4118F53"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "last_name", "7BB1929C9758AEF2E12FFA9E0FCC89D3"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "address_1", "D0630933ED7FAB6530902C871072CD43"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "address_2", null),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "city", "F89E0C25F9B99A5661EE04E5055EEA30"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "state", "52EF0DE3C90F06C3A21EB688DE7A7D4C"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "zip_code", "FBE743DF2A2014D6BE23C059115F2FD4"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "phone_1", "F077937510FECAAE5BF0DE73E332949A"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "special_offer", null),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "iv_legacy", null),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "created_at", "2017-10-01 14:58:34 +0000"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "updated_at", "2017-10-01 14:58:34 +0000"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "marketing_opt_in", null),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "existing_patient", "false"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "insurance", "PRIVATE INSURER"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "age", "34"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "bmi", "48.7087427563618"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "qol", "YES"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "gender", "FEMALE"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "height", "63.0"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "smoker", "FORMER_MORE"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "weight", "275.0"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "bullet1", "SURGERY"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "bullet2", "OVERWEIGHT"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "bullet4", "UNKNOWN"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "created", "Sun Oct 01 14:56:54 UTC 2017"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "dbpRisk", "UNKNOWN"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "fbsRisk", "UNKNOWN"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "hdlRisk", "UNKNOWN"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "ldlRisk", "UNKNOWN"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "sbpRisk", "UNKNOWN"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "updated", "Sun Oct 01 14:58:34 UTC 2017"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "diabetes", "PRE"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "dbp_known", "false"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "dbp_value", "null"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "hdlFactor", "UNKNOWN"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "ldlFactor", "UNKNOWN"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "sbp_known", "false"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "sbp_value", "null"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "heardAbout", "15"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "smokerRisk", "LOW"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "qolImpaired", "YES"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "dbp_estimate", "null"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "diabetesRisk", "MODERATE"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "exerciseRisk", "HIGH"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "sbp_estimate", "null"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "smokingFactor", "NO"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "activityFactor", "YES"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "diabetesFactor", "YES"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "summaryMessage", "SURGERY"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "weightCategory", "EXTREME_OBESE"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "hasUnknownRisks", "true"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "normalWeightLow", "105.0"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "obeseIWeightLow", "170.0"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "riskFactorCount", "2"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "healthConditions", "YES"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "idealWeightLower", "105"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "idealWeightUpper", "140"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "medications_none", "true"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "normalWeightHigh", "140.0"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "obeseIIWeightLow", "198.0"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "obeseIWeightHigh", "197.0"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "medications_other", "false"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "obeseIIWeightHigh", "225.0"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "triglyceridesRisk", "UNKNOWN"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "bloodPressureFactor", "UNKNOWN"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "ethnicity_ethnicity", "AFRICAN"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "overweightWeightLow", "141.0"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "triglyceridesFactor", "UNKNOWN"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "triglycerides_known", "false"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "triglycerides_value", "null"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "hdlCholesterol_known", "false"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "hdlCholesterol_value", "null"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "ldlCholesterol_known", "false"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "ldlCholesterol_value", "null"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "medications_diabetes", "false"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "overweightWeightHigh", "169.0"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "totalCholesterolRisk", "UNKNOWN"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "waistMeasurementRisk", "HIGH"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "extremeObeseWeightLow", "226.0"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "idealWeightGainAmount", "-170"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "idealWeightLossAmount", "135"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "totalCholesterol_known", "false"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "totalCholesterol_value", "null"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "triglycerides_estimate", "null"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "fastingBloodSugar_known", "false"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "fastingBloodSugar_value", "null"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "hdlCholesterol_estimate", "null"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "ldlCholesterol_estimate", "null"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "medications_cholesterol", "false"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "weeklyExercise_moderate", "0"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "weeklyExercise_vigorous", "0"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "weightLossRecomendation", "RECOMMENDED"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "ethnicity_preferNotToSay", "false"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "primaryCarePhysician_has", "false"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "abnormalCholesterolFactor", "UNKNOWN"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "medications_bloodPressure", "false"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "totalCholesterol_estimate", "null"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "fastingBloodSugar_estimate", "null"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "existingWeightConditions_ohs", "false"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "primaryCarePhysician_visited", "null"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "waistMeasurement_measurement", "56"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "existingWeightConditions_gerd", "false"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "existingWeightConditions_none", "true"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "existingWeightConditions_asthma", "false"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "waistMeasurement_asianEthnicity", "false"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "weightLossSurgeryRecommendation", "YES"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "existingWeightConditions_arthritis", "false"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "existingWeightConditions_vsDisease", "false"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "existingWeightConditions_sleepApnea", "false"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "existingWeightConditions_incontinence", "false"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "existingWeightConditions_liverDisease", "false"),
        Row("50297345178740EF814406E908A47EAC", "1423", "Weight-Loss Surgery Profiler(SETX )", "existingWeightConditions_psuedotumorCerebri", "false")
      )), HraSchema.hraDetailSchema)
    )

    val mockFileSystemDao = mock[FileSystemDao]

    (mockFileSystemDao.readHRAFile _).expects(false, Constants.HraMedicomFormat, Seq(InputDirectoryPath)).returns(rawData)

    val (cleansedDataFrame: DataFrame, dirtyDataFrame: DataFrame) = AppCleanser.cleanseData(
      Some(Customer), Constants.HraActivityType, BatchId, false, InputDirectoryPath,
      Constants.HraMedicomFormat, DateBatchReceived, mockFileSystemDao
    )


    val cityData = cleansedDataFrame.select("city").collectAsList()
    cityData.get(0).getString(0) shouldBe "Beaumont"
    val data = cleansedDataFrame.select("city").collectAsList()
    data.get(0).getString(0) shouldBe "Beaumont"
    val firstNames = cleansedDataFrame.select("firstName").collectAsList()
    firstNames.get(0).getString(0) shouldBe "Steven"
    val lastNames = cleansedDataFrame.select("lastName").collectAsList()
    lastNames.get(0).getString(0) shouldBe "Hawkins"
    val dateOfBirth = cleansedDataFrame.select("dateOfBirth").collectAsList()
    dateOfBirth.get(0).getDate(0).toString shouldBe "1992-05-18"
    val source = cleansedDataFrame.select("source").collectAsList()
    source.get(0).getString(0) shouldBe "HRA"
    val sourceRecordId = cleansedDataFrame.select("sourceRecordId").collectAsList()
    sourceRecordId.get(0).getString(0) shouldBe "FBDEF92D82A442ED8CE982FE9E8972E1"

    dirtyDataFrame.count() shouldBe 1
    val dirtyFirstName = dirtyDataFrame.select("firstName").collectAsList()
    dirtyDataFrame.select("city").collectAsList().get(0).getString(0) shouldBe "Beaumont"

    dirtyFirstName.get(0).getString(0) shouldBe null


  }


}