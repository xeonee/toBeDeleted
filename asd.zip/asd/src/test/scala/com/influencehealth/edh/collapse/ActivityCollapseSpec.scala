package com.influencehealth.edh.collapse

import java.sql.{Date, Timestamp}

import com.influencehealth.edh.Constants
import com.influencehealth.edh.model.{Activity, ActivityMedicalCode, SG2}
import com.influencehealth.edh.updater.ActivityUpdaterImpl
import com.influencehealth.edh.test.spark.SparkSpecBase
import org.scalatest.Matchers

class ActivityCollapseSpec extends SparkSpecBase with Matchers {

  it should "not update an activity when the activityType of the new activity  is " +
    "< than the activityType of the old activity" in {

    val oldestActivity = Activity(
      customer = "tanner",
      activityId = "activity1",
      personId = Some("person1"),
      batchId = "batch1",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      activityDate = new Date(System.currentTimeMillis()),
      activityType = Some(Constants.EncounterActivityType),
      firstName = Some("James"),
      optOutDirectMailReasons = Seq("test1", "test2", "test3")
    )

    val newestActivity = Activity(
      customer = "tanner",
      activityId = "activity2",
      personId = Some("person1"),
      batchId = "batch1",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      activityDate = new Date(System.currentTimeMillis()),
      activityType = Some(Constants.ProspectActivityType),
      firstName = Some("Phill")
    )

    val updatedActivity = ActivityUpdaterImpl.updateActivity(oldestActivity, newestActivity)

    updatedActivity.firstName.get.shouldEqual("James")
    updatedActivity.optOutDirectMailReasons shouldEqual Seq("test1", "test2", "test3")

  }

  it should "not update SG2 will null value" in {

    val oldestActivity = Activity(
      customer = "tanner",
      activityId = "activity1",
      personId = Some("person1"),
      batchId = "batch1",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      activityDate = new Date(System.currentTimeMillis()),
      activityType = Some(Constants.EncounterActivityType),
      sg2 = Some(SG2(
        careGroupCode = Some("careGroupCode 1"),
        careFamily = Some("careFamily 1"),
        addictionAdult = Some("alcohol")
      ))
    )

    val newestActivity = Activity(
      customer = "tanner",
      activityId = "activity2",
      personId = Some("person1"),
      batchId = "batch1",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      activityDate = new Date(System.currentTimeMillis()),
      activityType = Some(Constants.EncounterActivityType),
      sg2 = None
    )

    val updatedActivity = ActivityUpdaterImpl.updateActivity(oldestActivity, newestActivity)

    updatedActivity.sg2.flatMap(_.careGroupCode).get shouldEqual "careGroupCode 1"

  }

  it should "update all SG2 fields" in {

    val oldestActivity = Activity(
      customer = "tanner",
      activityId = "activity1",
      personId = Some("person1"),
      batchId = "batch1",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      activityDate = new Date(System.currentTimeMillis()),
      activityType = Some(Constants.EncounterActivityType),
      sg2 = Some(SG2(
        careGroupCode = Some("careGroupCode 1"),
        careFamily = Some("careFamily 1"),
        addictionAdult = Some("alcohol")
      ))
    )

    val newestActivity = Activity(
      customer = "tanner",
      activityId = "activity2",
      personId = Some("person1"),
      batchId = "batch1",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      activityDate = new Date(System.currentTimeMillis()),
      activityType = Some(Constants.EncounterActivityType),
      sg2 = Some(SG2(
        mentalHealthConditions = Some("condition 1"),
        procedure = Some("procedure 1")
      ))
    )

    val updatedActivity = ActivityUpdaterImpl.updateActivity(oldestActivity, newestActivity)

    updatedActivity.sg2.flatMap(_.careGroupCode).isEmpty shouldEqual true
    updatedActivity.sg2.flatMap(_.careFamily).isEmpty shouldEqual true
    updatedActivity.sg2.flatMap(_.addictionAdult).isEmpty shouldEqual true

    updatedActivity.sg2.flatMap(_.mentalHealthConditions).get shouldEqual "condition 1"
    updatedActivity.sg2.flatMap(_.procedure).get shouldEqual "procedure 1"

  }

  it should "populate mergedBatchIds when activity collapse or merged" in {

    val oldestActivity = Activity(
      customer = "tanner",
      activityId = "activity1",
      personId = Some("person1"),
      batchId = "batch1",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      activityDate = new Date(System.currentTimeMillis()),
      activityType = Some(Constants.ProspectActivityType),
      firstName = Some("James")
    )

    val newestActivity = Activity(
      customer = "tanner",
      activityId = "activity2",
      personId = Some("person1"),
      batchId = "batch2",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      activityDate = new Date(System.currentTimeMillis()),
      activityType = Some(Constants.EncounterActivityType),
      firstName = Some("Phill"),
      mergedBatchIds = Seq("tanner-encounter-batch1")
    )

    val updatedActivity = ActivityUpdaterImpl.updateActivity(oldestActivity, newestActivity)

    updatedActivity.mergedBatchIds.contains("tanner-encounter-batch1")
    updatedActivity.mergedBatchIds.contains("batch1")
    updatedActivity.mergedBatchIds.contains("batch2")

    updatedActivity.mergedActivityIds.contains("activity1")
    updatedActivity.mergedActivityIds.contains("activity2")

  }

  it should "correctly update activity medical codes" in {

    val oldestActivity = Activity(
      customer = "tanner",
      activityId = "activity1",
      personId = Some("person1"),
      batchId = "batch1",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      activityDate = new Date(System.currentTimeMillis()),
      activityType = Some(Constants.ProspectActivityType),
      firstName = Some("James"),
      currentProceduralTerminologyCodes = Seq(
        ActivityMedicalCode(
          medicalCode = "1",
          medicalCodeType = "2",
          sequenceNumber = 1
        )
      ),
      diagnosisCodes = Seq(
        ActivityMedicalCode(
          medicalCode = "1",
          medicalCodeType = "2",
          sequenceNumber = 1
        )
      ),
      procedureCodes = Seq(
        ActivityMedicalCode(
          medicalCode = "1",
          medicalCodeType = "2",
          sequenceNumber = 1
        )
      )
    )

    val newestActivity = Activity(
      customer = "tanner",
      activityId = "activity2",
      personId = Some("person1"),
      batchId = "batch1",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      activityDate = new Date(System.currentTimeMillis()),
      activityType = Some(Constants.EncounterActivityType),
      firstName = Some("Phill"),
      currentProceduralTerminologyCodes = Seq(
        ActivityMedicalCode(
          medicalCode = "1",
          medicalCodeType = "2",
          sequenceNumber = 1
        ),
        ActivityMedicalCode(
          medicalCode = "2",
          medicalCodeType = "2",
          sequenceNumber = 2
        )
      ),
      diagnosisCodes = Seq(
        ActivityMedicalCode(
          medicalCode = "1",
          medicalCodeType = "2",
          sequenceNumber = 1
        ),
        ActivityMedicalCode(
          medicalCode = "2",
          medicalCodeType = "2",
          sequenceNumber = 2
        )
      ),
      procedureCodes = Seq(
        ActivityMedicalCode(
          medicalCode = "1",
          medicalCodeType = "2",
          sequenceNumber = 1
        ),
        ActivityMedicalCode(
          medicalCode = "2",
          medicalCodeType = "2",
          sequenceNumber = 2
        )
      )
    )

    val updatedActivity: Activity = ActivityUpdaterImpl.updateActivity(oldestActivity, newestActivity)

    updatedActivity.currentProceduralTerminologyCodes shouldBe Seq(
      ActivityMedicalCode(
        medicalCode = "1",
        medicalCodeType = "2",
        sequenceNumber = 1
      ),
      ActivityMedicalCode(
        medicalCode = "2",
        medicalCodeType = "2",
        sequenceNumber = 2
      ))

    updatedActivity.diagnosisCodes shouldBe Seq(
      ActivityMedicalCode(
        medicalCode = "1",
        medicalCodeType = "2",
        sequenceNumber = 1
      ),
      ActivityMedicalCode(
        medicalCode = "2",
        medicalCodeType = "2",
        sequenceNumber = 2
      ))

    updatedActivity.procedureCodes shouldBe Seq(
      ActivityMedicalCode(
        medicalCode = "1",
        medicalCodeType = "2",
        sequenceNumber = 1
      ),
      ActivityMedicalCode(
        medicalCode = "2",
        medicalCodeType = "2",
        sequenceNumber = 2
      ))

  }

  it should "not update activity medical codes" in {

    val oldestActivity = Activity(
      customer = "tanner",
      activityId = "activity1",
      personId = Some("person1"),
      batchId = "batch1",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      activityDate = new Date(System.currentTimeMillis()),
      activityType = Some(Constants.ProspectActivityType),
      firstName = Some("James"),
      currentProceduralTerminologyCodes = Seq(
        ActivityMedicalCode(
          medicalCode = "1",
          medicalCodeType = "2",
          sequenceNumber = 1
        )
      ),
      diagnosisCodes = Seq(
        ActivityMedicalCode(
          medicalCode = "1",
          medicalCodeType = "2",
          sequenceNumber = 1
        )
      ),
      procedureCodes = Seq(
        ActivityMedicalCode(
          medicalCode = "1",
          medicalCodeType = "2",
          sequenceNumber = 1
        )
      )
    )

    val newestActivity = Activity(
      customer = "tanner",
      activityId = "activity2",
      personId = Some("person1"),
      batchId = "batch1",
      dateCreated = new Timestamp(System.currentTimeMillis()),
      activityDate = new Date(System.currentTimeMillis()),
      activityType = Some(Constants.EncounterActivityType),
      firstName = Some("Phill"),
      mergedBatchIds = Seq("tanner-encounter-batch1")
    )

    val updatedActivity: Activity = ActivityUpdaterImpl.updateActivity(oldestActivity, newestActivity)

    updatedActivity.currentProceduralTerminologyCodes shouldBe Seq(ActivityMedicalCode(
      medicalCode = "1",
      medicalCodeType = "2",
      sequenceNumber = 1
    ))

    updatedActivity.diagnosisCodes shouldBe Seq(ActivityMedicalCode(
      medicalCode = "1",
      medicalCodeType = "2",
      sequenceNumber = 1
    ))

    updatedActivity.procedureCodes shouldBe Seq(ActivityMedicalCode(
      medicalCode = "1",
      medicalCodeType = "2",
      sequenceNumber = 1
    ))

  }

}
