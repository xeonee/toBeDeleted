package com.influencehealth.edh.load.cleanse.activities

import com.influencehealth.edh.load.activities.ActivityLoader
import com.influencehealth.edh.test.spark.SparkSpecBase
import org.scalatest.{BeforeAndAfter, FlatSpec}

class LoadActivitiesSpec extends FlatSpec with SparkSpecBase with BeforeAndAfter {

  val filePathForNonExperian: String = "fixtures/load/activities/utilization.parquet/"
  val filePathForExperian: String = "fixtures/load/activities/experian.parquet/"
  val filePathForRedox: String = "fixtures/load/activities/redox/"
  val filePathForDnsEmails: String = "fixtures/load/activities/dnsemail.parquet/"
  val batchId = "chomp_deidentified-utilization-2017-09"
  val batchIdForRedox = "chomp_deidentified-utilization-2017-09"
  val setOfZipCodesCustomersService: Set[String] = Set("93955")
  val ProspectDataSource = "prospect"
  val EncounterDataSource = "encounter"
  val DnsEmailDataSource = "dns"
  val emailId = "ash311hanson@yahoo.com"
  val customerName = "CHOMP"
  val customerId: Int = 128

  "Parquet file for utilization datasource" should "contain required number of records" in {
    val activitiesDataFrame = ActivityLoader.
      readActivityFiles(spark, filePathForNonExperian, EncounterDataSource, customerName, Set(), "dummyBatchId")
    assert(activitiesDataFrame.count() == 2)
  }

  "Parquet file for prospect datasource" should "not contain required number of records" in {
    val activitiesDataFrame = ActivityLoader.readActivityFiles(spark, filePathForExperian, ProspectDataSource,
      customerName, Set("10000"), "dummyBatchId")
    assert(activitiesDataFrame.count() == 0)
  }

  "Parquet file for prospect datasource" should "contain required number of records" in {
    val activitiesDataFrame = ActivityLoader.readActivityFiles(spark, filePathForExperian, ProspectDataSource,
      customerName, setOfZipCodesCustomersService, "dummyBatchId")
    assert(activitiesDataFrame.count() == 1)
    val data = activitiesDataFrame.select("customer").collectAsList()
    assert(data.get(0).getString(0).equals(customerName))
  }

  "Parquet file for dnsemail datasource" should "contain required number of records" in {
    val activitiesDataFrame = ActivityLoader.
      readActivityFiles(spark, filePathForDnsEmails, DnsEmailDataSource, customerName, Set(), "dummyBatchId")
    assert(activitiesDataFrame.count() == 19)
  }

  "DNSEmail dataFrame" should "alias dataFrame columns" in {
    val activitiesDataFrame = ActivityLoader.readActivityFiles(spark, filePathForDnsEmails,
      DnsEmailDataSource, customerName, Set(), "dummyBatchId")
    val aliasedDataFrame = ActivityLoader.aliasDataFrameColumns(activitiesDataFrame)
    val updatedDataFrame = ActivityLoader.generateNewActivityColumns(aliasedDataFrame, batchId, spark)
    assert(updatedDataFrame.columns.contains("sourceRecordId"))
    assert(updatedDataFrame.columns.contains("email"))
    assert(updatedDataFrame.columns.contains("source"))
  }

  "Aliased dataFrame" should "alias dataFrame columns" in {
    val activitiesDataFrame = ActivityLoader.readActivityFiles(spark, filePathForNonExperian,
      EncounterDataSource, customerName, Set(), "dummyBatchId")
    val aliasedDataFrame = ActivityLoader.aliasDataFrameColumns(activitiesDataFrame)
    val updatedDataFrame = ActivityLoader.generateNewActivityColumns(aliasedDataFrame, batchId, spark)

    assert(updatedDataFrame.columns.contains("sourcePersonId"))
    assert(updatedDataFrame.columns.contains("dateOfBirth"))
    assert(updatedDataFrame.columns.contains("activityId"))
    val data = updatedDataFrame.select("batchId").collectAsList()
    assert(data.get(0).getString(0).equals(batchId))
  }

  "Redox Encounter dataFrame" should "update dataFrame columns" in {
    val activitiesDataFrame = ActivityLoader.readActivityFiles(spark, filePathForNonExperian,
      EncounterDataSource, customerName, Set(), "dummyBatchId")
    val aliasedDataFrame = ActivityLoader.aliasDataFrameColumns(activitiesDataFrame)
    val updatedDataFrame = ActivityLoader.generateNewActivityColumns(aliasedDataFrame, batchIdForRedox, spark)

    val data = updatedDataFrame.select("batchId").collectAsList()
    assert(data.get(0).getString(0).equals(batchIdForRedox))
  }

}