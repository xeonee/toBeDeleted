package com.influencehealth.edh.enrich.activitypipeline

import com.influencehealth.edh.load.activities.ActivityLoader
import com.influencehealth.edh.test.spark.SparkSpecBase
import com.influencehealth.edh.{ActivityPipeline, Constants}
import org.apache.spark.sql.functions.col
import org.scalatest.{FlatSpec, Matchers}

class EnrichActivityPipelineSpec extends FlatSpec with Matchers with SparkSpecBase {

  val filePathForNewMover: String = "fixtures/load/activities/newmover.parquet/"
  val batchId = "experian-newmovers-standard-2019-01"
  val setOfZipCodesCustomersService: Set[String] = Set("95043","75650","75605","75604","75672",
    "75602","75644","75662","75601","75693","75606","75608","75640","75638","75607","75645",
    "75656","75647","75683","75603","75666")

  val customerName = "christus"
  val moveMonth = "201812"
  val moveType = "U"

  "Parquet file for newmover datasource" should "contain required number of records" in {
    val activitiesDataFrame = ActivityLoader.readActivityFiles(spark, filePathForNewMover,
      Constants.NewMoverActivityType, customerName, setOfZipCodesCustomersService, "dummyBatchId")
    assert(activitiesDataFrame.count() == 130)
  }

  "newmover datasource" should "contain move month and move type" in {
    val activitiesDataFrame = ActivityLoader.readActivityFiles(spark, filePathForNewMover,
      Constants.NewMoverActivityType, customerName, setOfZipCodesCustomersService, "dummyBatchId")

    val dataMoveMonth = activitiesDataFrame.select("experianMoveMonth").collectAsList
    assert(dataMoveMonth.get(0).getString(0).contains(moveMonth))

    val activitiesWithMoveType = activitiesDataFrame.withColumn("experianMoveType",
      ActivityPipeline.checkNewMoverType(setOfZipCodesCustomersService)(col("zip5"), col("movedFromZip5")))

    val dataMoveType = activitiesWithMoveType.select("experianMoveType").collectAsList
    assert(dataMoveType.get(0).getString(0).contains(moveType))
  }
}
