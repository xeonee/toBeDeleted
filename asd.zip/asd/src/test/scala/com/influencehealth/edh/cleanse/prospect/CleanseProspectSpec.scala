package com.influencehealth.edh.cleanse.prospect

import com.influencehealth.edh.dao.FileSystemDao
import com.influencehealth.edh.model.Activity
import com.influencehealth.edh.model.schema.ProspectSchema
import com.influencehealth.edh.test.spark.SparkSpecBase
import com.influencehealth.edh.{AppCleanser, Constants}
import org.apache.spark.sql.{DataFrame, Row}
import org.scalamock.scalatest.MockFactory
import org.scalatest.{BeforeAndAfter, FlatSpec, Ignore, Matchers}

@Ignore
class CleanseProspectSpec extends FlatSpec with SparkSpecBase with BeforeAndAfter with Matchers with MockFactory {

  val InputDirectoryPath: String = "fixtures/cleanse/experian/"
  val DateBatchReceived: String = "2017-11"
  val Customer: String = "tanner"
  val BatchId = "tanner-prospect-standard-2017-11"

  it should "cleanse all data" in {

    val rawData: DataFrame = spark.createDataFrame(spark.sparkContext.parallelize(Seq(
      Row("0000900531", "25", "MA", "93924", null, null, null, "AGAWAM", "AGAWAM", null, null, null, null, null, null, null, null, null, null, null, "N", "013", "HAMPDEN", null, "042096510", "-072634663", "R", null, null, 1, "1024000696", null, null, null, null, "A", "S", null, "014", "T", null, "B", null, "2", "20170722", 4, null, "Y", null, "U", 46, 1, 1, 2, "20090501", "2024001222", "P", "JACK", "E", "DEMARAIS", null, "MR", null, "17", null, "C", "8G", "K", "00", "I8", "M", "19310101", 87, null, "I87", "54", "5S", null, "00", "U", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 0, null, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0.0f, null, null, 0.0f, 0, null, 0.0f, null, null, 5, 1971, 3, 9, 9, 9, 8, null, "U", null, "U", null, "U", null, "U", null, "U", null, "U", null, null, null, "L42", null, "I", null, "B", null, null, null, null, "44140", "A", null, "5U", null, "5N", "002", null, "5N", "007", null, "5N", "007", null, "5U", "006", null, "5Y", "002", null, "5Y", "001", null, "8132090", 4800.0f, 150.0f, 850.0f, 286.0f, 932.0f, 20.0f, 23.0f, 37.0f, 199.0f, 199.0f, 343.0f, 186.0f, 117.0f, 227.0f, 24.0f, 125.0f, 199269.0f, 0.0f, 52.0f, 703.0f, 297.0f, 3522, "4", 2, 72958.0f, null, null),
      Row("0330879103", "10", "DE", "93940", "4547", "014", "R306", "BRIDGEVILLE", "BRIDGEVILLE", "21001", null, "SANFILIPPO", "RD", null, null, null, null, "21001 SANFILIPPO RD", null, null, "E", "005", "SUSSEX", null, "038692291", "-075564189", "R", null, null, 1, "2571890149", null, null, null, null, "A", "S", null, "058", "7", null, "G", null, "2", "20170722", 1, null, "U", null, "U", 1, 1, 1, 2, "20170202", "4220037541", "P", "GEORGIA", null, "CLAYTON", null, "MS", null, "E5", null, "P", "8G", "A", "00", "I3", "F", "19430101", 75, null, "I75", "55", "5M", null, "00", "U", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 0, null, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.0f, null, 2004, 6.0f, 1, null, 262556.0f, null, null, 1, 2004, 9, 5, 7, 5, 3, null, "U", null, "U", null, "U", null, "U", null, "U", null, "U", null, null, null, "N48", null, "I", null, "A", null, null, null, null, "41540", "A", null, "5Y", null, "5Y", "007", null, "5U", "013", null, "5U", "017", null, "5U", "007", null, "5Y", "004", null, "5N", "004", null, "0504072", 4300.0f, 220.0f, 780.0f, 143.0f, 246.0f, 664.0f, 6.0f, 94.0f, 292.0f, 292.0f, 415.0f, 343.0f, 145.0f, 270.0f, 68.0f, 116.0f, 166666.0f, 266.0f, 23.0f, 657.0f, 343.0f, 3077, "2", 3, 66874.0f, null, null))), ProspectSchema.prospectSchema)

    val mockFileSystemDao = mock[FileSystemDao]

    (mockFileSystemDao.readProspectFile _).expects(false, Seq(InputDirectoryPath)).returns(rawData)

    val (cleansedDataFrame: DataFrame, dirtyDataFrame: DataFrame) = AppCleanser.cleanseData(
      Some(Customer), Constants.ProspectActivityType, BatchId, false, InputDirectoryPath,
      Constants.ProspectExperianFormat, DateBatchReceived, mockFileSystemDao
    )

    cleansedDataFrame.count() shouldBe 1
    val data = cleansedDataFrame.select("city").collectAsList()
    data.get(0).getString(0) shouldBe "BRIDGEVILLE"
    val address1 = cleansedDataFrame.select("addressId").collectAsList()
    address1.get(0).getString(0) shouldBe "0330879103"
    val source = cleansedDataFrame.select("source").collectAsList()
    source.get(0).getString(0) shouldBe "EXPERIAN"
    val sourceRecordId = cleansedDataFrame.select("sourceRecordId").collectAsList()
    sourceRecordId.get(0).getString(0) shouldBe "4220037541"
    val customer = cleansedDataFrame.select("customer").collectAsList()
    customer.get(0).getString(0) shouldBe "tanner"

    val isChildPresent = cleansedDataFrame.select("isChildPresent").collectAsList()
    isChildPresent.get(0).getBoolean(0) shouldBe true
    val hasChildZeroToThree = cleansedDataFrame.select("hasChildZeroToThree").collectAsList()
    hasChildZeroToThree.get(0).getBoolean(0) shouldBe true
    val hasChildFourToSix = cleansedDataFrame.select("hasChildFourToSix").collectAsList()
    hasChildFourToSix.get(0).getBoolean(0) shouldBe false
    val hasChildThirteenToFifteen = cleansedDataFrame.select("hasChildThirteenToFifteen").collectAsList()
    hasChildThirteenToFifteen.get(0).getBoolean(0) shouldBe true


    val activityDate = cleansedDataFrame.select("activityDate").collectAsList()
    activityDate.get(0).getString(0) shouldBe "2017-11-01"

    val isoLanguageDesc = cleansedDataFrame.select("isoLanguageDesc").collectAsList()
    isoLanguageDesc.get(0).getString(0) shouldBe "tibetan" // input language code is "8G" which was mapped to tibetan

    val isoLanguageCode = cleansedDataFrame.select("isoLanguageCode").collectAsList()
    isoLanguageCode.get(0).getString(0) shouldBe "tib"

    // TODO: Figure out why there are no errors being returned here
    // dirtyDataFrame.select("city").collectAsList().get(0).getString(0) shouldBe "AGAWAM"

    import spark.implicits._
    val activityDF = Activity.transformToActivitySchema(cleansedDataFrame).map(Activity.buildFromRow)
    activityDF.count() shouldBe 1
  }

}