package com.influencehealth.edh.model.activitytype

import com.influencehealth.edh.Constants

trait DonorList extends ActivityType {

  override val formatType: String = Constants.DonorListInfluenceHealthFormat
  override val defaultSource: String = Constants.DonorListInfluenceHealthDefaultSource
  override val defaultMessageType: String = Constants.DonorListDefaultMessageType
  override val defaultSourceType: String = Constants.DonorListDefaultSourceType
  override val defaultAddressType: String = Constants.DonorListDefaultAddressType
  override val defaultActivityType: String = Constants.DonorListActivityType
  override val defaultPersonType: String = Constants.DonorListPersonType

  override val cleanseStringColumnNames: Seq[String] = Seq(
    "sourceType",
    "source",
    "prefix",
    "lastName",
    "firstName",
    "middleName",
    "personalSuffix",
    "professionalSuffix",
    "address1",
    "address2",
    "addressType",
    "addressStatus",
    "city",
    "state",
    "zip5",
    "sourceSex"
  )

  override val nullColumnNames: Seq[String] = Seq("sourceType", "source")

  override val mandatoryContactColumnsNames: Seq[String] = Seq("emails", "phoneNumbers", "address1")

  override val zipColumnNames: Seq[String] = Seq.empty

}