//package com.influencehealth.edh.load.epdblists
//
//import com.influencehealth.edh.BaldurJob
//import com.influencehealth.edh.config.{BaldurAppConfig, CassandraAppConfig}
//import com.influencehealth.edh.dao.cassandra.CassandraDatahubDao
//import com.influencehealth.edh.dao.redshift.RedshiftDataWarehouseDao
//import com.influencehealth.edh.dao.{DataWarehouseDao, DatahubDao}
//import com.influencehealth.edh.model.Activity
//import com.influencehealth.edh.newlinker.{PersonCassandraEntityDB, PersonLinker, PersonLinkerImpl}
//import com.influencehealth.edh.refresh.redshift.transformer.PersonTransformer
//import mojolly.inflector.Inflector
//import org.apache.spark.sql.functions._
//import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
//import org.apache.spark.util.LongAccumulator
//
//object LoadEpdbListsApp extends BaldurJob with BaldurAppConfig with CassandraAppConfig {
//
//
//  def main(args: Array[String]): Unit = {
//
//    val listName: String = appConfig.getString("app.load.list-name")
//
//    val s3Bucket: String = appConfig.getString("s3.datalake.bucket")
//
//    val userHasOptedToForceListLoad: Boolean = if (appConfig.hasPath("app.load.force")) {
//      appConfig.getBoolean("app.load.force")
//    } else {
//      false
//    }
//
//    logger.info(s"Loading EPDB List: $listName")
//
//    val sparkSession = SparkSession.builder().getOrCreate()
//
//    s3Config.configureS3(sparkSession.sparkContext.hadoopConfiguration)
//
//    val customerId: Int = getEdhCustomer.customerId
//
//    val customer: String = getEdhCustomer.customerKey
//
//    val keyspace: String = cassandraDatahubKeyspace
//
//    val accumulator: LongAccumulator = sparkSession.sparkContext.longAccumulator("Collapse Accumulator")
//
//    loadList(
//      userHasOptedToForceListLoad, sparkSession, customerId, customer, listName, s3Bucket, keyspace, accumulator)
//  }
//
//  private def loadList(
//                        userHasOptedToForceListLoad: Boolean,
//                        sparkSession: SparkSession,
//                        customerId: Int,
//                        customer: String,
//                        listName: String,
//                        s3Bucket: String,
//                        keyspace: String,
//                        accumulator: LongAccumulator): Unit = {
//
//    val kebabCaseListName: String = Inflector.dasherize(listName.trim)
//
//    val inputCleansedS3Path = s"$s3Bucket/$customer/epdb-list/$kebabCaseListName.parquet"
//
//    val personSnapshotData: DataFrame = sparkSession.read.parquet(inputCleansedS3Path).
//      transform(df => prepareListPersonsForIdentification(df, customerId, customer)).
//      persist() // Forcing spark to load the data into memory before switching credentials a different account
//
//    val personSnapshotDataCount: Long = personSnapshotData.count()
//
//    val datahubDao: DatahubDao = new CassandraDatahubDao(keyspace, sparkSession)
//
//    val identityLinker: PersonLinker = new PersonLinker(accumulator, datahubDao, customerId, "epdbPersonId")
//      with PersonLinkerImpl with PersonCassandraEntityDB
//
//    val linkedRecords: DataFrame = linkListPersonsWithCustomerData(personSnapshotData, identityLinker).
//      persist()
//
//    linkedRecords.head // Forcing spark to load the data into memory before switching credentials a different account
//
//    val datawarehouseDAO: DataWarehouseDao = new RedshiftDataWarehouseDao(appConfig, sparkSession)
//
//    datawarehouseDAO.cleanUpListByName(kebabCaseListName)
//    datawarehouseDAO.cleanUpErrorListByName(kebabCaseListName)
//
//    verifyAllRecordsWereMatched(
//      userHasOptedToForceListLoad,
//      linkedRecords,
//      personSnapshotDataCount,
//      datawarehouseDAO)
//
//    verifyNoDuplicateLinkedRecords(
//      userHasOptedToForceListLoad, linkedRecords, personSnapshotDataCount, datawarehouseDAO)
//
//    val personTransformer = buildPersonTransformer(personSnapshotData)
//
//    if (userHasOptedToForceListLoad) logger.info("Data is being written to redshift with the --force option")
//
//    saveListData(datawarehouseDAO,
//      personTransformer.persons.withColumn("list_name", lit(kebabCaseListName)),
//      personTransformer.personEmails.withColumn("list_name", lit(kebabCaseListName)),
//      personTransformer.personPhoneNumbers.withColumn("list_name", lit(kebabCaseListName)))
//
//    logger.info("Data successfully written")
//
//  }
//
//  private def verifyNoDuplicateLinkedRecords(
//                                              userHasOptedToForceListLoad: Boolean,
//                                              linkedRecords: DataFrame,
//                                              personSnapshotDataCount: Long,
//                                              datawarehouseDAO: DataWarehouseDao
//                                            ): Unit = {
//
//    val duplicatedIds: DataFrame = linkedRecords.groupBy("personId").
//      count().alias("counts").
//      select("personId").dropDuplicates().
//      where(!col("personId").contains("EPDB-"))
//
//    val distinctLinkedIdCount: Long = duplicatedIds.count()
//    val differenceInCounts = personSnapshotDataCount - distinctLinkedIdCount
//
//    logger.info(
//      s"Out of the $personSnapshotDataCount incoming records from the list there are $distinctLinkedIdCount distinct persons in the customer database")
//
//    if (differenceInCounts != 0) {
//
//      val duplicateRecords = duplicatedIds.join(linkedRecords, "personId")
//      val personTransfomer = buildPersonTransformer(duplicateRecords)
//      saveToErrorTables(
//        datawarehouseDAO,
//        personTransfomer.persons,
//        personTransfomer.personEmails,
//        personTransfomer.personPhoneNumbers)
//      if (!userHasOptedToForceListLoad) {
//        throw new Exception(s"Failed to create unique links. Check the epdb list error tables for more details")
//      }
//    }
//  }
//
//  private def verifyAllRecordsWereMatched(
//                                           userHasOptedToForceListLoad: Boolean,
//                                           linkedRecords: DataFrame,
//                                           personSnapshotDataCount: Long,
//                                           datawarehouseDAO: DataWarehouseDao): Unit = {
//
//    val recordsWithoutAMatch = linkedRecords.
//      where(col("personId").contains("EPDB-"))
//
//    val recordsWithoutAMatchCount = recordsWithoutAMatch.count()
//
//    logger.info(
//      s"Out of the $personSnapshotDataCount incoming records from the list there are $recordsWithoutAMatchCount records without a match in the customer database")
//
//    if (recordsWithoutAMatchCount > 0) {
//      val personTransfomer = buildPersonTransformer(recordsWithoutAMatch)
//      saveToErrorTables(
//        datawarehouseDAO,
//        personTransfomer.persons,
//        personTransfomer.personEmails,
//        personTransfomer.personPhoneNumbers)
//
//      if (!userHasOptedToForceListLoad) {
//        throw new Exception(s"Not all records were matched. Check the epdb list error tables for more details")
//      }
//    }
//
//  }
//
//  private def linkListPersonsWithCustomerData(
//                                               personSnapshotData: DataFrame,
//                                               identityLinker: PersonLinker): DataFrame = {
//    identityLinker.linkRecords(personSnapshotData).
//      drop("dateCreated").
//      withColumnRenamed("originalDateCreated", "dateCreated")
//  }
//
//  def prepareListPersonsForIdentification(dataFrame: DataFrame, customerId: Int, customer: String): DataFrame = {
//    dataFrame.
//      withColumnRenamed("created_at", "date_created").
//      withColumnRenamed("dob", "date_of_birth").
//      transform(Activity.transformSnakeCaseToActivitySchema).
//      drop("customerId").
//      withColumn("customerId", lit(customerId)).
//      withColumn("customer", lit(customer)).
//      withColumn("epdbPersonId", col("personId")).
//      withColumn("personId", concat(lit("EPDB-"), col("personId"))).
//      withColumn("mrids", array().cast("array<string>")).
//      withColumn("primaryEmail", upper(col("emails").getItem(0))).
//      withColumn("primaryPhoneNumbers", col("phoneNumbers").getItem(0)).
//      withColumnRenamed("dateCreated", "originalDateCreated").
//      withColumn("dateCreated", to_utc_timestamp(lit("3000-01-01 00:00:00"), "UTC"))
//  }
//
//  def buildPersonTransformer(personSnapshotData: DataFrame): PersonTransformer = {
//
//    val snakeCase = personSnapshotData.
//      drop("dateCreated").
//      withColumnRenamed("originalDateCreated", "dateCreated").
//      transform(Activity.transformActivityDFtoSnakeCaseDF)
//
//    val personTransformer: PersonTransformer = new PersonTransformer(
//      snakeCase,
//      snakeCase.sparkSession.emptyDataFrame,
//      snakeCase.sparkSession.emptyDataFrame,
//      snakeCase.sparkSession)
//
//    personTransformer
//  }
//
//  def saveToErrorTables(
//                         datawarehouseDAO: DataWarehouseDao,
//                         persons: DataFrame,
//                         personEmails: DataFrame,
//                         personPhoneNumbers: DataFrame): Unit = {
//    datawarehouseDAO.saveTable("error_epdb_list_persons", persons, SaveMode.Append)
//    datawarehouseDAO.saveTable("error_epdb_list_person_emails", personEmails, SaveMode.Append)
//    datawarehouseDAO.saveTable("error_epdb_list_person_phone_numbers", personPhoneNumbers, SaveMode.Append)
//  }
//
//  def saveListData(
//                    datawarehouseDAO: DataWarehouseDao,
//                    persons: DataFrame,
//                    personEmails: DataFrame,
//                    personPhoneNumbers: DataFrame): Unit = {
//    datawarehouseDAO.saveTable("epdb_list_persons", persons, SaveMode.Append)
//    datawarehouseDAO.saveTable("epdb_list_person_emails", personEmails, SaveMode.Append)
//    datawarehouseDAO.saveTable("epdb_list_person_phone_numbers", personPhoneNumbers, SaveMode.Append)
//  }
//
//}
