package com.influencehealth.edh.refresh.redshift

import com.influencehealth.edh.model.Person
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.apache.spark.storage.StorageLevel

class PersonTransformer(
                         personsData: Dataset[Person],
                         sparkSession: SparkSession
                       ) extends BaseTransformer with Serializable {

  import sparkSession.implicits._

  val columnsWithSizeMoreThan256: Map[String, Int] = Map(
    "mrids" -> 1024,
    "phone_numbers" -> 1024,
    "emails" -> 1024,
    "locations" -> 1024,
    "opt_out_direct_mail_reasons" -> 1024,
    "opt_out_call_reasons" -> 1024,
    "opt_out_email_reasons" -> 1024,
    "opt_out_text_reasons" -> 1024)

  val deNormalizedPersons: DataFrame = personsData.
    withColumn("personRecordId", concat_ws("::", $"customer", $"personId")).
    withColumn("mrids",  convertSequenceStringToString(personsData("mrids"))).
    withColumn("phoneNumbers",  convertSequencePhoneNumbersToString(personsData("phoneNumbers"))).
    withColumn("emails",  convertSequenceStringToString(personsData("emails"))).
    withColumn("addressCoordinates",  to_json($"addressCoordinates").cast(StringType)).
    withColumn("locations",  convertSequencePersonLocationToString(personsData("locations"))).
    withColumn("optOutDirectMailReasons",  convertSequenceStringToString(personsData("optOutDirectMailReasons"))).
    withColumn("optOutCallReasons",  convertSequenceStringToString(personsData("optOutCallReasons"))).
    withColumn("optOutEmailReasons",  convertSequenceStringToString(personsData("optOutEmailReasons"))).
    withColumn("optOutTextReasons",  convertSequenceStringToString(personsData("optOutTextReasons")))


  val persons: DataFrame = deNormalizedPersons.
    drop("activities").
    transform(dropComplexTypes).
    transform(aliasColumnsToSnakeCase).
    transform(applyMetadataToTempTables(columnsWithSizeMoreThan256, _)).
    persist(StorageLevel.MEMORY_ONLY)

  val close: Unit = persons.unpersist()

}
