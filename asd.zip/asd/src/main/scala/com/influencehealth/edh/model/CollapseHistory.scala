package com.influencehealth.edh.model

import java.sql.{Date, Timestamp}

import org.apache.spark.sql.Row

import scala.util.Try

case class CollapseHistory (
                           customer: String,
                           deletedPersonId: String,
                           currentPersonId: String,
                           deletedAt: Date,
                           CollapseReason: String
                           )


object CollapseHistory {

  def buildFromRow(row: Row): CollapseHistory = {
    CollapseHistory(
      customer = row.getAs[String]("customer"),
      deletedPersonId = row.getAs[String]("deletedPersonId"),
      currentPersonId = row.getAs[String]("currentPersonId"),
      deletedAt = Try(row.getAs[Date]("deletedAt"))
        .getOrElse(new java.sql.Date(row.getAs[Timestamp]("deletedAt").getTime())),
      CollapseReason = row.getAs[String]("collapseReason")
    )
  }
}