package com.influencehealth.edh.config

import java.io.File

import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.SparkFiles

import scala.util.{Failure, Success, Try}

object ConfigLoader {

  // If no environment is provided (such as in a unit test) do not load environment specific properties
  private val EdhEnvironment = sys.env.getOrElse("EDH_ENV", None)

  def loadConfigFile(filepath: String): Config = {
    val file = new File(filepath)
    if (file.exists()) {
      ConfigFactory.parseFile(file)
    } else {
      throw new RuntimeException(s"Configuration not found at $filepath")
    }
  }

  val appConfig: Config = {

    val configPath = Try(SparkFiles.get(s"$EdhEnvironment.conf")) match {
      case Success(path) => path
      case Failure(e) =>
        throw new RuntimeException("Unable to access spark context to load configuration files", e)
    }
    val defaultConfigPath = SparkFiles.get("application.conf")

    ConfigFactory
      .load(loadConfigFile(configPath))
      .withFallback(loadConfigFile(defaultConfigPath))
  }
}
