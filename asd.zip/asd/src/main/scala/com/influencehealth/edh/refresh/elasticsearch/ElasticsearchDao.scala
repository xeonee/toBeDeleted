package com.influencehealth.edh.refresh.elasticsearch

import com.google.gson.JsonObject
import com.influencehealth.edh.config.ElasticsearchConfig
import com.influencehealth.edh.model.{Activity, Person}
import com.typesafe.scalalogging.LazyLogging
import org.apache.spark.sql.Dataset
import org.elasticsearch.spark.sql._

class ElasticsearchDao(elasticsearchConfig: ElasticsearchConfig, personMapping: JsonObject) extends LazyLogging {

  val transformer: ElasticsearchTransformer = new ElasticsearchTransformer()

  /**
    * 1. Apply create es.write.operation config
    * 2. transform to elasticsearch index and save
    *
    * @param persons
    * @param activities
    * @param indexName
    */
  def insertPersons(persons: Dataset[Person], activities: Dataset[Activity], indexName: String): Unit = {
    val bulkLoadOptions: Map[String, String] = buildBaseOptions(elasticsearchConfig) ++
      Map("es.write.operation" -> "create")

    val esPersons = transformer.transformToElasticsearchIndex(
      persons,
      activities,
      elasticsearchConfig.complexColumnsToPreserve, // specify complex columns to preserve
      elasticsearchConfig.columnsToIgnore, // Specify columns to ignore
      personMapping)

    esPersons.saveToEs(indexName, bulkLoadOptions)
  }

  /**
    * 1. Apply upsert es.write.operation configuration
    * 2. transform to elasticsearch index and save
    *
    * @param persons
    * @param activities
    * @param indexName
    */
  def upsertPersons(persons: Dataset[Person], activities: Dataset[Activity], indexName: String): Unit = {
    val incrementalOptions: Map[String, String] = buildBaseOptions(elasticsearchConfig) ++
      Map("es.write.operation" -> "upsert")

    val esPersons = transformer.transformToElasticsearchIndex(
      persons,
      activities,
      elasticsearchConfig.complexColumnsToPreserve,
      elasticsearchConfig.columnsToIgnore,
      personMapping)

    esPersons.
      saveToEs(indexName, incrementalOptions)
  }

  /**
    * @param elasticsearchConfig
    * @return a map of Elastic Search configurations
    */
  def buildBaseOptions(elasticsearchConfig: ElasticsearchConfig): Map[String, String] = {
    Map("es.mapping.id" -> "personId") +
      ("es.nodes" -> elasticsearchConfig.node) +
      ("es.net.ssl" -> "true") +
      ("es.net.ssl.truststore.type" -> "JKS") +
      ("es.net.ssl.truststore.protocol" -> "TLS") +
      ("es.net.http.auth.user" -> elasticsearchConfig.user) +
      ("es.net.http.auth.pass" -> elasticsearchConfig.password) ++
      elasticsearchConfig.keyStorePath.map(path => "es.net.ssl.truststore.location" -> s"file://$path").toSeq ++
      elasticsearchConfig.keystorePass.map(path => "es.net.ssl.truststore.pass" -> path).toSeq
  }

}
