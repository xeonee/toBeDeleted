package com.influencehealth.edh.model.address

import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.types.{IntegerType, StringType, StructField, StructType}

object AnchorOutputData {

  val schema: StructType = StructType(
    Array(
      StructField("activityId", StringType, false),
      StructField("customer", StringType, false),
      StructField("batchId", StringType, false),
      StructField("bucketNumber", IntegerType, false),
      StructField("source", StringType, false),
      StructField("sourceType", StringType, false),
      StructField("sourceRecordId", StringType, false),
      StructField("sourcePersonId", StringType, true),
      StructField("firstName", StringType, true),
      StructField("middleName", StringType, true),
      StructField("lastName", StringType, true),
      StructField("originalAddress1", StringType, true),
      StructField("originalAddress2", StringType, true),
      StructField("originalCity", StringType, true),
      StructField("originalState", StringType, true),
      StructField("originalZip5", StringType, true),
      StructField("address1", StringType, true),
      StructField("address2", StringType, true),
      StructField("city", StringType, true),
      StructField("state", StringType, true),
      StructField("zip5", StringType, true),
      StructField("zip", StringType, true), // zip
      StructField("zip4", StringType, true), // zip4
      StructField("streetPreDirection", StringType, true),
      StructField("streetName", StringType, true),
      StructField("streetPostDirection", StringType, true),
      StructField("streetSuffix", StringType, true),
      StructField("streetSecondNumber", StringType, true),
      StructField("streetSecondUnit", StringType, true),
      StructField("latitude", StringType, true),
      StructField("longitude", StringType, true),
      StructField("metropolitanStatisticalArea", StringType, true),
      StructField("primaryMetropolitanStatisticalArea", StringType, true),
      StructField("deliveryPointBarcode", StringType, true),
      StructField("deliveryPointValidation", StringType, true),
      StructField("countyCode", StringType, true),
      StructField("countyFederalInformationProcessingStandards", StringType, true),
      StructField("carrierRoute", StringType, true),
      StructField("censusBlock", StringType, true),
      StructField("censusTract", StringType, true),
      StructField("enhancedLineOfTravel", StringType, true),
      StructField("streetHouseNumber", StringType, true),
      StructField("ncoaActionCode", StringType, true),
      StructField("ncoaAnklinkCode", StringType, true),
      StructField("ncoaMoveType", StringType, true),
      StructField("ncoaMoveDate", StringType, true),
      StructField("llkFootnote", StringType, true),
      StructField("barcode", StringType, true),
      StructField("lacs", StringType, true),
      StructField("cassStand", StringType, true),
      StructField("deliveryPointValidationFootnote", StringType, true)
    )
  )

  def stripStringLocation: UserDefinedFunction = udf((stringValue: String) => {
    if (stringValue != null && !stringValue.isEmpty) {
      val isPositive: Boolean = stringValue.last.equals('N') || stringValue.last.equals('E')

      val converted = if (isPositive) {
        stringValue.substring(0, stringValue.length - 2).toFloat
      } else {
        -stringValue.substring(0, stringValue.length - 2).toFloat
      }
      Some(converted)
    }
    else None
  })
}
