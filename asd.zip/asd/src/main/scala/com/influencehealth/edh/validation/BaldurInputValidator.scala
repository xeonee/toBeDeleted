package com.influencehealth.edh.validation

import java.time.Year

import com.influencehealth.edh.dataframe.columns._
import com.influencehealth.edh.implicits.DateTimeParseError
import com.influencehealth.edh.utils.{CleanseUtils, DateTimeUtilities}
import com.influencehealth.edh.{Constants, CustomLazyLogging}
import org.apache.commons.validator.routines.EmailValidator
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.{DateTime, DateTimeZone, LocalDate}

class BaldurInputValidator(activities: DataFrame) extends Serializable with CustomLazyLogging {

  def printErrorStats(invalidRecords: DataFrame) = {
    import invalidRecords.sparkSession.implicits._
    // TODO: Add extract the dataframe select, groupby, agg, orderby, and select to a function and add a test case around it
    invalidRecords.
      select(explode($"errors") as "error").
      groupBy(regexp_extract($"error", "([a-zA-Z0-9]+)$", 0) as "column_name").
      agg(expr("count(*) as errors_per_column")).
      orderBy(desc("errors_per_column"), asc("column_name")).
      select($"column_name" as "Column Name", $"errors_per_column" as "Errors Per Column").
      show(400, false)
  }


  val sparkSession: SparkSession = activities.sparkSession

  /**
    * Validates an incoming dataframe of activities and throws an exception if any errors are found
    *
    * @param activities the incoming dataframe of activities
    */
  def splitInvalidData(): (DataFrame, DataFrame) = {

    import sparkSession.implicits._

    // TODO activity_date, date_created, date_modified, admit_date
    val columnsNamesToBeValidated: Seq[String] = Seq(
      // Emails,
      HomePhone,
      MobilePhone,
      WorkPhone,
      DateOfBirth,
      DateOfDeath,
      DischargeDate,
      FinalBillDate,
      NcoaMoveDate,
      SourceAge,
      IsoLanguageCode,
      Sex,
      State,
      County,
      Zip4,
      Zip5,
      GuarantorState,
      GuarantorZip5,
      EstimatedHomeValue,
      HomeLandValue,
      Charges,
      GrossMargin,
      ContributionMargin,
      Profit,
      LengthOfResidence,
      HomeYearBuilt,
      InferredPayerType,
      PayerType,
      PayerTypeDescription,
      OccupationGroup,
      Occupation,
      PortalStatus,
      PrimaryCarePhysician,
      BeehiveCluster,
      WealthRating,
      AdultsInLivingUnit,
      Race,
      Religion,
      FinancialClass,
      CombinedOwner,
      DwellType,
      MaritalStatus,
      DonatesToCharity,
      Education,
      MosaicGlobalZip4,
      MosaicZip4,
      ActivityDate,
      SourcePatientType
    )

    var columnList: List[String] = List()
    columnsNamesToBeValidated.foreach(columnName => {
      if (activities.schema.fieldNames.contains(columnName)) {
        columnList = columnList :+ columnName
      }
    })

    // TODO: Add dashboard with counts around parquet files

    val validActivities: DataFrame = columnList.foldLeft(activities)({ case (df, columnName) =>
      columnName match {
        // case Emails => df.withColumn(columnName, validateEmails(columnName)(col(columnName)))
        case MobilePhone | HomePhone | WorkPhone =>
          df.withColumn(s"${columnName}Errors", validatePhone(columnName)(col(columnName)))
        case ActivityDate | AdmitDate | DateOfBirth | DateOfDeath | DischargeDate | FinalBillDate | NcoaMoveDate =>
          df.withColumn(s"${columnName}Errors", validateDate(columnName)(col(columnName)))
        case SourceAge =>
          df.withColumn(s"${columnName}Errors", validateAge(columnName)(col(columnName)))
        case IsoLanguageCode =>
          df.withColumn(s"${columnName}Errors", validateIsoLanguageCode(columnName)(col(columnName)))
        case Sex | SourceSex =>
          df.withColumn(s"${columnName}Errors", validateSex(columnName)(col(columnName)))
        case State | GuarantorState =>
          df.withColumn(s"${columnName}Errors", validateState(columnName)(col(columnName)))
        case County =>
          df.withColumn(s"${columnName}Errors", validateCounty(columnName)(col(columnName)))
        case Zip5 | GuarantorZip5 =>
          df.withColumn(s"${columnName}Errors", validateZip5(columnName)(col(columnName)))
        case Zip4 =>
          df.withColumn(s"${columnName}Errors", validateZip4(columnName)(col(columnName)))
        case HomeLandValue | Charges | GrossMargin | ContributionMargin | Cost | Profit | HomeYearBuilt =>
          df.withColumn(s"${columnName}Errors", validateAmount(columnName)(col(columnName)))
        case LengthOfResidence =>
          df.withColumn(s"${columnName}Errors", validateLengthOfResidence(columnName)(col(columnName)))
        case EstimatedHomeValue =>
          df.withColumn(s"${columnName}Errors", validateEstimatedHomeValue(columnName)(col(columnName)))
        case PersonType =>
          df.withColumn(s"${columnName}Errors", validatePersonType(columnName)(col(columnName)))
        case InferredPayerType | PayerType | PayerTypeDescription =>
          df.withColumn(s"${columnName}Errors", validatePayerType(columnName)(col(columnName)))
        case OccupationGroup =>
          df.withColumn(s"${columnName}Errors", validateOccupationGroup(columnName)(col(columnName)))
        case Occupation =>
          df.withColumn(s"${columnName}Errors", validateOccupation(columnName)(col(columnName)))
        case PortalStatus =>
          df // .withColumn(s"${columnName}Errors", validatePortalStatus(columnName)(col(columnName)))
        case PrimaryCarePhysician =>
          df.withColumn(s"${columnName}Errors", validatePrimaryCarePhysician(columnName)(col(columnName)))
        case BeehiveCluster =>
          df.withColumn(s"${columnName}Errors", validateBeehiveCluster(columnName)(col(columnName)))
        case WealthRating =>
          df.withColumn(s"${columnName}Errors", validateWealthRating(columnName)(col(columnName)))
        case AdultsInLivingUnit =>
          df.withColumn(s"${columnName}Errors", validateAdultsInLivingUnit(columnName)(col(columnName)))
        case Religion =>
          df.withColumn(s"${columnName}Errors", validateReligion(columnName)(col(columnName)))
        case Race =>
          df.withColumn(s"${columnName}Errors", validateRace(columnName)(col(columnName)))
        case FinancialClass =>
          df.withColumn(s"${columnName}Errors", validateFinancialClass(columnName)(col(columnName)))
        case CombinedOwner =>
          df.withColumn(s"${columnName}Errors", validateCombinedOwner(columnName)(col(columnName)))
        case DwellType =>
          df.withColumn(s"${columnName}Errors", validateDwellType(columnName)(col(columnName)))
        case MaritalStatus =>
          df.withColumn(s"${columnName}Errors", validateMaritalStatus(columnName)(col(columnName)))
        case DonatesToCharity =>
          df.withColumn(s"${columnName}Errors", validateDonatesToCharity(columnName)(col(columnName)))
        case Education =>
          df.withColumn(s"${columnName}Errors", validateEducation(columnName)(col(columnName)))
        case MosaicGlobalZip4 =>
          df.withColumn(s"${columnName}Errors", validateMosaicGlobalZip4(columnName)(col(columnName)))
        case MosaicZip4 =>
          df.withColumn(s"${columnName}Errors", validateMosaicZip4(columnName)(col(columnName)))
        case SourcePatientType =>
          df.withColumn(s"${columnName}Errors", validateSourcePatientType(columnName)(col(columnName)))

      }
    })

    val errorColumns = validActivities.columns.filter(_.endsWith("Errors"))

    val resultDf = validActivities.
      withColumn("errors", array(errorColumns.map(col): _*)).
      drop(errorColumns: _*).
      withColumn("errors", CleanseUtils.remove_null_from_seq(col("errors")))

    val gatedData = resultDf.where(size($"errors") > 0)

    val validData = resultDf.where(size($"errors") === 0)

    (gatedData, validData)
  }

  def addErrorMessage(inputValue: String, colName: String) = {
    "[" + inputValue + "]" + " is not valid value for column: " + colName
  }

  def validateEmails(colName: String): UserDefinedFunction = udf((inputEmail: String) => {
    Option(inputEmail).foreach { email =>
      if (!EmailValidator.getInstance().isValid(email)) {
        println(email)
        Some(addErrorMessage(email, colName))
      } else {
        None
      }
    }
  })

  def validatePhone(colName: String): UserDefinedFunction = udf((phone: String) => {
    phone match {
      case x if x == null || x.isEmpty => None
      case y if !y.equalsIgnoreCase(phone.trim.replaceAll("[^0-9]", "")) ||
        !y.equalsIgnoreCase(phone.replaceAll("[\\.|,|\\-|;|\\(|\\)|']", "")) => {
        Some(addErrorMessage(y, colName))
      }
      case _ => None
    }
  })

  def validateSex(colName: String): UserDefinedFunction = udf((inputSex: String) => {
    inputSex match {
      case x if x == null || x.isEmpty => None
      case y if !Constants.DefinedSex.contains(y.toUpperCase) => {
        Some(addErrorMessage(y, colName))
      }
      case _ => None
    }
  })

  def validateState(colName: String): UserDefinedFunction = udf((inputState: String) => {
    inputState match {
      case x if x == null || x.isEmpty => None
      case y if !Constants.DefinedState.contains(y.toUpperCase) => {
        Some(addErrorMessage(y, colName))
      }
      case _ => None
    }
  })


  def validateIsoLanguageCode(colName: String): UserDefinedFunction = udf((inputIsoLanguageCode: String) => {
    inputIsoLanguageCode match {
      case x if x == null || x.isEmpty => None
      case y if !Constants.StandardLanguageMap.mapValues(_._2).valuesIterator.contains(y) => {
        Some(addErrorMessage(y, colName))
      }
      case _ => None
    }
  })

  def validatePersonType(colName: String): UserDefinedFunction = udf((inputPersonType: String) => {
    inputPersonType match {
      case x if x == null || x.isEmpty => None
      case y if !Constants.DefinedPersonTypes.contains(y.trim.toUpperCase) => {
        Some(addErrorMessage(y, colName))
      }
      case _ => None
    }
  })

  def validatePayerType(colName: String): UserDefinedFunction = udf((inputPayerType: String) => {
    inputPayerType match {
      case x if x == null || x.isEmpty => None
      case y if !Constants.DefinedPayerTypes.contains(y.toUpperCase) => {
        Some(addErrorMessage(y, colName))
      }
      case _ => None
    }
  })

  def validatePortalStatus(colName: String): UserDefinedFunction = udf((inputPortalStatus: String) => {
    inputPortalStatus match {
      case x if x == null || x.isEmpty => None
      case y if !Constants.DefinedPortalStatus.contains(y) => {
        Some(addErrorMessage(y, colName))
      }
      case _ => None
    }
  })

  def validateFinancialClass(colName: String): UserDefinedFunction = udf((financialClass: String) => {
    financialClass match {
      case x if x == null || x.isEmpty => None
      case y if !Constants.DefinedFinancialClass.contains(y) => {
        Some(addErrorMessage(y, colName))
      }
      case _ => None
    }
  })

  def validateOccupationGroup(colName: String): UserDefinedFunction = udf((occupationGroup: String) => {
    occupationGroup match {
      case x if x == null || x.isEmpty => None
      case y if !Constants.listOccupationValidValues.contains(y) => {
        Some(addErrorMessage(y, colName))
      }
      case _ => None
    }
  })

  def validateCombinedOwner(colName: String): UserDefinedFunction = udf((combinedOwner: String) => {
    combinedOwner match {
      case x if x == null || x.isEmpty => None
      case y if !Constants.DefinedCombinedOwner.contains(y) => {
        Some(addErrorMessage(y, colName))
      }
      case _ => None
    }
  })

  def validateReligion(colName: String): UserDefinedFunction = udf((religion: String) => {
    religion match {
      case x if x == null || x.isEmpty => None
      case y if !Constants.DefinedReligion.contains(y.toUpperCase) => {
        Some(addErrorMessage(y, colName))
      }
      case _ => None
    }
  })

  def validateDwellType(colName: String): UserDefinedFunction = udf((dwellType: String) => {
    dwellType match {
      case x if x == null || x.isEmpty => None
      case y if !Constants.listDwellValidValues.contains(y.toUpperCase) => {
        Some(addErrorMessage(y, colName))
      }
      case _ => None
    }
  })

  def validateRace(colName: String): UserDefinedFunction = udf((race: String) => {
    Option(race) match {
      case Some(y) if !Constants.DefinedRace.contains(y.trim.toUpperCase) => {
        Some(addErrorMessage(y, colName))
      }
      case _ => None
    }
  })

  def validateMaritalStatus(colName: String): UserDefinedFunction = udf((maritalStatus: String) => {
    maritalStatus match {
      case x if x == null || x.isEmpty => None
      case x if x == null || x.isEmpty => None
      case y if !Constants.listMaritalStatusValidValues.contains(y.toUpperCase) => {
        Some(addErrorMessage(y, colName))
      }
      case _ => None
    }
  })

  def validateDonatesToCharity(colName: String): UserDefinedFunction = udf((donatesToCharity: String) => {
    donatesToCharity match {
      case x if x == null || x.isEmpty => None
      case y if !Constants.DefinedDonateToCharity.contains(y.toUpperCase) => {
        Some(addErrorMessage(y, colName))
      }
      case _ => None
    }
  })

  def validateEducation(colName: String): UserDefinedFunction = udf((education: String) => {
    education match {
      case x if x == null || x.isEmpty => None
      case y if !Constants.listEducationValidValues.contains(y) => {
        Some(addErrorMessage(y, colName))
      }
      case _ => None
    }
  })

  def validateMosaicGlobalZip4(colName: String): UserDefinedFunction = udf((mosaicGlobalZip4: String) => {
    mosaicGlobalZip4 match {
      case x if x == null || x.isEmpty => None
      case y if !Constants.DefinedMosaicGlobalZip4Types.contains(y.toUpperCase) => {
        Some(addErrorMessage(y, colName))
      }
      case _ => None
    }
  })

  def validateEstimatedHomeValue(colName: String): UserDefinedFunction = udf((estimatedHomeValue: String) => {
    estimatedHomeValue match {
      case x if x == null || x.isEmpty => None
      case y if !Constants.DefinedEstimatedHomeValueTypes.contains(y.toUpperCase) => {
        Some(addErrorMessage(y, colName))
      }
      case _ => None
    }
  })

  def validateMosaicZip4(colName: String): UserDefinedFunction = udf((mosaicZip4: String) => {
    mosaicZip4 match {
      case x if x == null || x.isEmpty => None
      case y if !Constants.DefinedMosaicZip4.contains(y) => {
        Some(addErrorMessage(y, colName))
      }
      case _ => None
    }
  })

  def validateSourcePatientType(colName: String): UserDefinedFunction = udf((sourcePatientType: String) => {
    sourcePatientType match {
      case x if x == null || x.isEmpty => None
      case y if !Constants.DefinedSourcePatientType.contains(y.toUpperCase) => {
        Some(addErrorMessage(y, colName))
      }
      case _ => None
    }
  })

  def validateDate(colName: String): UserDefinedFunction = udf((str: String) => {
    val Today: DateTime = LocalDate.now(DateTimeZone.UTC).
      toDateTimeAtStartOfDay(DateTimeZone.UTC)

    if (str != null && !str.isEmpty) {
      try {
        var cleanseStr = ""
        val currentYear = Year.now.getValue
        if (str.length.equals(4)) {
          val strYear = DateTime.parse(str).getYear
          if (strYear <= currentYear) {
            cleanseStr = str.concat("0101")
          }
        }
        else if (str.length.equals(6)) {
          val strYear = DateTime.parse(str.substring(0, 4)).getYear
          val strMonth = str.substring(4, 6).toInt
          if (strYear <= currentYear && (strMonth >= 1 && strMonth <= 12)) {
            cleanseStr = str.concat("01")
          }
        }
        else {
          val inputDate = DateTimeUtilities.convertToDateTime(str).toLocalDate
          if (inputDate.compareTo(Today.toDateTime.toLocalDate) > 0) {
            addErrorMessage(str, colName)
          }
        }
        None
      }
      catch {
        case _: DateTimeParseError => Some(s"$str : Date is not valid")
      }
    } else if (colName.equalsIgnoreCase("activityDate")) {
      Some(addErrorMessage(str, colName))
      } else None
  })

  def validateZip4(colName: String): UserDefinedFunction = udf((zip4: String) => {
    zip4 match {
      case x if x == null || x.isEmpty => None
      case x if !CleanseUtils.isAllDigits(x) || x.length != 4 => {
        Some(addErrorMessage(x.toString, colName))
      }
      case _ => None
    }
  })

  def validateZip5(colName: String): UserDefinedFunction = udf((zip5: String) => {
    zip5 match {
      case x if x == null || x.isEmpty => None
      case x if !CleanseUtils.isAllDigits(x) || x.length != 5 => {
        Some(addErrorMessage(x.toString, colName))
      }
      case _ => None
    }
  })

  def validateAge(colName: String): UserDefinedFunction = udf((age: String) => {
    age match {
      case x if x == null || x.isEmpty => None
      case x if !(x.toInt >= 0 && x.toInt <= 125) => {
        Some(addErrorMessage(x.toString, colName))
      }
      case _ => None
    }
  })

  def validateLengthOfResidence(colName: String): UserDefinedFunction = udf((lengthOfResidence: String) => {
    lengthOfResidence match {
      case x if x == null || x.isEmpty => None
      case x if !(x.toInt >= 0) => {
        Some(addErrorMessage(x.toString, colName))
      }
      case _ => None
    }
  })

  def validateAmount(colName: String): UserDefinedFunction = udf((amount: String) => {
    amount match {
      case x if x == null || x.isEmpty => None
      case x if !CleanseUtils.isPositiveNumeric(x.toDouble.toString) => {
        Some(addErrorMessage(x.toString, colName))
        Some(amount)
      }
      case _ => None
    }
  })

  def validateOccupation(colName: String): UserDefinedFunction = udf((occupation: String) => {
    occupation match {
      case x if x == null || x.isEmpty => None
      case x if !(x.toInt >= 0 && x.toInt <= 54) => {
        Some(addErrorMessage(x.toString, colName))
      }
      case _ => None
    }
  })

  def validatePrimaryCarePhysician(colName: String): UserDefinedFunction = udf((primaryCarePhysician: String) => {
    primaryCarePhysician match {
      case x if x == null || x.isEmpty => None
      case x if x.length != 10 => {
        Some(addErrorMessage(x, colName))
      }
      case _ => None
    }
  })

  def validateBeehiveCluster(colName: String): UserDefinedFunction = udf((beehiveCluster: String) => {
    beehiveCluster match {
      case x if x == null || x.isEmpty => None
      case x if !(x.toInt < 0 || x.toInt > 30) => {
        Some(addErrorMessage(x.toString, colName))
      }
      case _ => None
    }
  })

  def validateWealthRating(colName: String): UserDefinedFunction = udf((wealthRating: String) => {
    wealthRating match {
      case x if x == null || x.isEmpty => None
      case x if !(x.toInt >= 0 && x.toInt <= 9) =>
        Some(addErrorMessage(x, colName))
      case _ => None
    }
  })

  def validateAdultsInLivingUnit(colName: String): UserDefinedFunction = udf((adultsInLivingUnit: String) => {
    adultsInLivingUnit match {
      case x if x == null || x.isEmpty => None
      case x if !(x.toInt >= 0 && x.toInt <= 50) => {
        Some(addErrorMessage(x.toString, colName))
      }
      case _ => None
    }
  })

  def validateCounty(colName: String): UserDefinedFunction = udf((county: String) => {
    county match {
      case x if x == null || x.isEmpty => None
      case x if !(x.toInt > 999 && x.toInt <= 99999) => {
        Some(addErrorMessage(x.toString, colName))
      }
      case _ => None
    }
  })
}
