package com.influencehealth.edh.cleanse

import com.influencehealth.edh.Constants
import com.influencehealth.edh.model.activitytype._
import com.influencehealth.edh.utils.CleanseUtils
import com.influencehealth.edh.utils.CleanseUtils.remove_null_from_seq
import com.typesafe.scalalogging.LazyLogging
import mojolly.inflector.Inflector
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

trait DataCleanser extends Serializable with LazyLogging {

  val dateBatchReceived: String

  def cleanseData(df: DataFrame, customer: Option[String], batchId: String): (DataFrame, DataFrame)

  def formatDateColumns(df: DataFrame): DataFrame

  def cleanseStringColumns(df: DataFrame, stringColumnsToBeCleansed: Seq[String]): DataFrame

  def aliasData(df: DataFrame, customer: Option[String]): DataFrame = {
    df
      .withColumn("dateCreated", lit(Constants.Now.toString))
      .withColumn("customer", lit(customer.orNull))
  }

  def assignDefaultValuesForRequiredColumnsContainingNulls(df: DataFrame): DataFrame

  def addSourceRecordId(joinedAllDataFrames: DataFrame, batchId: String): DataFrame = {
    val addUniqueId = joinedAllDataFrames.withColumn("uniqueId", monotonically_increasing_id())
    // As monotonically_increasing_id() method generates guaranteed monotonically increasing and unique,
    // but not consecutive, hence added below logic to generate consecutive row_numbers based on unique ids.
    val addRowId = addUniqueId.withColumn("rowId", row_number().over(Window.orderBy("uniqueId"))).
      drop("uniqueId")

    addRowId.
      withColumn("sourceRecordId", CleanseUtils.generateSourceRecordId(col("rowId"), lit(batchId))).
      drop("rowId")
  }

  def getStringToArray = udf((str: String) => {
    Option(str) match {
      case None => null
      case Some(y) => y.split(",")
    }

  })

  // return languageDesc null if languageCode is invalid (not present in StandardLanguageMap)
  val mapIsoLanguageDesc = udf(
    (inputIsoLanguageCode: String) => Constants.StandardLanguageMap.getOrElse(inputIsoLanguageCode, (null, null))._1)
  val mapIsoLanguageCode = udf(
    (inputIsoLanguageCode: String) => Constants.StandardLanguageMap.getOrElse(inputIsoLanguageCode, (null, null))._2)

  /**
    * map incoming language codes to Alpha-3 codes from ISO-639-5 (EDH-2095)
    *
    * @param df
    * @return
    */
  def mapLanguageCodes(df: DataFrame): DataFrame = {
    if (df.columns.contains("isoLanguageCode")) {
      df.withColumn("isoLanguageDesc", mapIsoLanguageDesc(df("isoLanguageCode")))
        .withColumn("isoLanguageCode", mapIsoLanguageCode(df("isoLanguageCode")))
    } else df
  }

  def filterRequiredColumnsContainingInvalidValues(
                                                    df: DataFrame,
                                                    nullValueColumns: Seq[String],
                                                    methodOfContactNulls: Seq[String]
                                                  ): (DataFrame, DataFrame) = {

    import df.sqlContext.implicits._

    val standardErrorDf = (nullValueColumns).foldLeft(df) { (df, columnName) =>
      df.
        withColumn(s"errors${Inflector.pascalize(columnName)}",
          when(is_empty($"$columnName"), s"$columnName is empty"))
    }

    val methodOfContactErrorDf = if (methodOfContactNulls.nonEmpty) {
      val containsValidMethodOfContact = methodOfContactNulls.
        map(s => is_empty(col(s))).reduce(_ && _)

      standardErrorDf.withColumn("errorsMethodOfContact", when(
        containsValidMethodOfContact, s"Method of contacts columns are null: ${methodOfContactNulls.mkString(", ")}"
      ))
    } else {
      standardErrorDf
    }

    val errorColumns = methodOfContactErrorDf.columns.filter(_.startsWith("errors"))

    val dfWithErrorColumns = methodOfContactErrorDf.
      withColumn("errors", remove_null_from_seq(array(errorColumns.map(col): _*)))

    val finalCleansedDataFrame = dfWithErrorColumns.
      where(size($"errors") === 0).
      select(df.columns.map(col): _*)

    val finalErrorDataFrame = dfWithErrorColumns.where(size($"errors") > 0)

    (finalCleansedDataFrame, finalErrorDataFrame)
  }

  val is_empty = udf((string: String) => {
    Option(string) match {
      case Some(str) if str.equalsIgnoreCase("NULL") => true
      case Some("") => true
      case None => true
      case _ => false
    }
  })

  val is_valid_us_state = udf((state: String) => {
    Option(state).forall(s => Constants.DefinedState.exists(_.equalsIgnoreCase(s.trim)))
  })

}

object DataCleanser {

  def apply(activityType: String, formatType: String, dateBatchReceived: String): DataCleanser = {

    activityType.toUpperCase() match {
      case Constants.CallCenterActivityType
        if formatType.toUpperCase() == Constants.CallCenterConiferFormat =>
        new ConiferCallCenterCleanser(dateBatchReceived) with ConfierCallCenter
      case Constants.CallCenterActivityType
        if formatType.toUpperCase() == Constants.CallCenterBerylFormat |
          formatType.toUpperCase() == Constants.CallCenterSteriCycleFormat =>
        new BerylCallCenterCleanser(dateBatchReceived) with BerylCallCenter
      case Constants.DeceasedActivityType => new DeceasedCleanser(dateBatchReceived) with Deceased
      case Constants.DonorListActivityType => new DonorListCleanser(dateBatchReceived) with DonorList
      case Constants.DoNotSolicitActivityType => new DoNotSolicitCleanser(dateBatchReceived) with DoNotSolicit
      case Constants.DoNotSolicitUpdateActivityType =>
        new DoNotSolicitUpdateCleanser(dateBatchReceived) with DoNotSolicitUpdate
      case Constants.EmployeeRosterActivityType => new EmployeeRosterCleanser(dateBatchReceived) with EmployeeRoster
      case Constants.EncounterActivityType => new EncounterCleanser(dateBatchReceived) with Encounter
      case Constants.HraActivityType => new HraCleanser(dateBatchReceived) with HRA
      case Constants.MarketingListActivityType => new MarketingListCleanser(dateBatchReceived) with MarketingList
      case Constants.NewMoverActivityType => new NewMoversCleanser(dateBatchReceived) with NewMover
      case Constants.ProspectActivityType => new ProspectCleanser(dateBatchReceived) with Prospect
      case Constants.ReferralActivityType => new ReferralCleanser(dateBatchReceived) with Referral
      case _ => throw new RuntimeException(s"No class found for activity type: $activityType")

    }
  }
}
