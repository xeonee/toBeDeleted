package com.influencehealth.edh.model.activitytype

import com.influencehealth.edh.Constants

trait Encounter extends ActivityType {

  override val formatType: String = Constants.EncounterInfluenceHealthFormat
  override val defaultSource: String = Constants.EncounterInfluenceHealthDefaultSource
  override val defaultMessageType: String = Constants.EncounterDefaultMessageType
  override val defaultSourceType: String = Constants.EncounterDefaultSourceType
  override val defaultAddressType: String = Constants.EncounterDefaultAddressType
  override val defaultActivityType: String = Constants.EncounterActivityType
  override val defaultPersonType: String = Constants.EncounterPersonType
  override val cleanseStringColumnNames: Seq[String] = Seq(

    // COMMON
    "sourcePersonId",
    "sourceRecordId",
    "primaryCarePhysicianId",

    // DEMOGRAPHIC
    "lastName",
    "firstName",
    "middleName",
    "prefix",
    "personalSuffix",
    "professionalSuffix",
    "address1",
    "address2",
    "city",
    "state",
    "zip5",
    "country",
    "sourceSex",
    "sourceExclusionFlag",
    "sourceMaritalStatus",
    "sourceRace",
    "employer",
    "portalStatus",

    // VISIT
    "sourceType",
    "source",
    "lengthOfStay",
    "sourceDischargeStatus",
    "sourcePatientType",
    "sourceErPatient",
    "medicalSeverityDiagnosisRelatedGroup",
    "sourceFinancialClassId",
    "sourceFinancialClass",
    "insuranceId",
    "insurance",
    "visitTotalCharges",
    "attendingId",
    "referencingId",

    // FACILITY
    "hospitalId",
    "hospital",
    "businessUnitId",
    "businessUnit",
    "siteId",
    "site",
    "clinicId",
    "clinic",
    "practiceLocationId",
    "practiceLocation",
    "locationCode",
    "sourceLocationDesc"

  )

  override val nullColumnNames: Seq[String] = Seq(

    // DEMOGRAPHIC
    "firstName",
    "lastName",

    // VISIT
    "sourceType",
    "source",
    "sourceRecordId"

  )

  override val zipColumnNames: Seq[String] = Seq.empty

  override val mandatoryContactColumnsNames: Seq[String] = Seq.empty

}
