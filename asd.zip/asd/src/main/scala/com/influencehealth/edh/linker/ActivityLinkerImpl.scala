package com.influencehealth.edh.linker

import com.influencehealth.edh.model.Activity
import com.influencehealth.edh.updater.ActivityUpdaterImpl

trait ActivityLinkerImpl extends Serializable {

  /**
    * Merges candidates confirmed as duplicates with most recent information except for some fields.
    *
    * @param candidate1
    * @param candidate2
    * @return
    */
  def mergeCandidates(
                       candidate1: IdentityEntity[Activity],
                       candidate2: IdentityEntity[Activity]
                     ): IdentityEntity[Activity] = {

    /**
      * When two candidates come from person_activity, then we use activity date to determine the older one
      * When one candidate comes from cleansed activities and the other one from person_activity, then the
      * latter is the older one
      * When two candidates come from cleansed activities, then the older one is the one that has already a PersonId
      * If both cleansed activities have Empty/Non Empty personId, then we use activity date to determine the older one
      */


    val Seq(oldestCandidate, newestCandidate) =
      if (candidate1.origin == "db_activity") {
        if (candidate2.origin == "db_activity") {
          Seq(candidate1, candidate2).
            sortBy(_.entity.activityDate.getTime)
        } else {
          Seq(candidate1, candidate2)
        }
      } else {
        if (candidate2.origin == "db_activity") {
          Seq(candidate2, candidate1)
        } else {
          if (candidate1.entity.personId.isEmpty && candidate2.entity.personId.isEmpty ||
            (candidate1.entity.personId.nonEmpty && candidate2.entity.personId.nonEmpty)) {
            Seq(candidate1, candidate2).sortBy(_.entity.activityDate.getTime)
          } else {
            Seq(candidate1, candidate2).filter(r => r.entity.personId.nonEmpty) ++
              Seq(candidate1, candidate2).filter(r => r.entity.personId.isEmpty)
          }
        }
      }

    val oldestActivity = oldestCandidate.entity
    val newestActivity = newestCandidate.entity

    oldestCandidate.copy(
      origin = newestCandidate.origin,
      entity = ActivityUpdaterImpl.updateActivity(oldestActivity, newestActivity)
    )

    /* if (newestCandidate.entity.isValidAddress.exists(x => x)) {
      newestCandidate
    } else {
      oldestCandidate
    } */

  }

}
