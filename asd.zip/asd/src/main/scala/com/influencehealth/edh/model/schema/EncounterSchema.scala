package com.influencehealth.edh.model.schema

import org.apache.spark.sql.types.{StringType, StructField, StructType}

object EncounterSchema {

  val isNullable: Boolean = true
  val nonNullable: Boolean = false

  val demographicSchema : StructType = StructType(
    Array(
      StructField("sourcePersonId", StringType, nonNullable),
      StructField("lastName", StringType, isNullable),
      StructField("firstName", StringType, isNullable),
      StructField("middleName", StringType, isNullable),
      StructField("prefix", StringType, isNullable),
      StructField("personalSuffix", StringType, isNullable),
      StructField("professionalSuffix", StringType, isNullable),
      StructField("address1", StringType, isNullable),
      StructField("address2", StringType, isNullable),
      StructField("city", StringType, isNullable),
      StructField("state", StringType, isNullable),
      StructField("zip5", StringType, isNullable),
      StructField("country", StringType, isNullable),
      StructField("sourceSex", StringType, isNullable),
      StructField("dateOfBirth", StringType, isNullable),
      StructField("dateOfDeath", StringType, isNullable),
      StructField("sourceExclusionFlag", StringType, isNullable), // DNS trueFlag with a text value
      StructField("homePhone", StringType, isNullable),
      StructField("mobilePhone", StringType, isNullable),
      StructField("workPhone", StringType, isNullable),
      StructField("email", StringType, isNullable),
      StructField("sourceMaritalStatus", StringType, isNullable),
      StructField("sourceRace", StringType, isNullable),
      StructField("employer", StringType, isNullable),
      StructField("portalStatus", StringType, isNullable)
    )
  )

  val currentProceduralTerminologySchema : StructType = StructType(
    Array(
      StructField("sourcePersonId", StringType, nonNullable),
      StructField("sourceRecordId", StringType, nonNullable),
      StructField("currentProceduralTerminologyPriorityNo", StringType, isNullable),
      StructField("currentProceduralTerminologyMxVersion", StringType, isNullable),
      StructField("currentProceduralTerminologyMxCode", StringType, isNullable)
    )
  )

  val diagnosisSchema : StructType = StructType(
    Array(
      StructField("sourcePersonId", StringType, nonNullable),
      StructField("sourceRecordId", StringType, nonNullable),
      StructField("diagnosisPriorityNo", StringType, isNullable),
      StructField("diagnosisMxVersion", StringType, isNullable),
      StructField("diagnosisMxCode", StringType, isNullable)
    )
  )

  val prognosisSchema : StructType = StructType(
    Array(
      StructField("sourcePersonId", StringType, nonNullable),
      StructField("sourceRecordId", StringType, nonNullable),
      StructField("prognosisPriorityNo", StringType, isNullable),
      StructField("prognosisMxVersion", StringType, isNullable),
      StructField("prognosisMxCode", StringType, isNullable)
    )
  )

  val facilitySchema : StructType = StructType(
    Array(
      StructField("sourcePersonId", StringType, nonNullable),
      StructField("sourceRecordId", StringType, nonNullable),
      StructField("hospitalId", StringType, isNullable),
      StructField("hospital", StringType, isNullable),
      StructField("businessUnitId", StringType, isNullable),
      StructField("businessUnit", StringType, isNullable),
      StructField("siteId", StringType, isNullable),
      StructField("site", StringType, isNullable),
      StructField("clinicId", StringType, isNullable),
      StructField("clinic", StringType, isNullable),
      StructField("practiceLocationId", StringType, isNullable),
      StructField("practiceLocation", StringType, isNullable)
    )
  )

  val visitSchema : StructType = StructType(
    Array(
      StructField("sourceType", StringType, isNullable),
      StructField("source", StringType, isNullable),
      StructField("sourcePersonId", StringType, nonNullable),
      StructField("sourceRecordId", StringType, nonNullable),
      StructField("admitDate", StringType, isNullable),
      StructField("dischargeDate", StringType, isNullable),
      StructField("finalBillDate", StringType, isNullable),
      StructField("lengthOfStay", StringType, isNullable),
      StructField("sourceDischargeStatus", StringType, isNullable),
      StructField("sourcePatientType", StringType, isNullable),
      StructField("sourceErPatient", StringType, isNullable),
      StructField("medicalSeverityDiagnosisRelatedGroup", StringType, isNullable),
      StructField("sourceFinancialClassId", StringType, isNullable),
      StructField("sourceFinancialClass", StringType, isNullable),
      StructField("insuranceId", StringType, isNullable),
      StructField("insurance", StringType, isNullable),
      StructField("visitTotalCharges", StringType, isNullable),
      StructField("attendingId", StringType, isNullable),
      StructField("referencingId", StringType, isNullable),
      StructField("primaryCarePhysicianId", StringType, nonNullable)
    )
  )

  val guarantorSchema : StructType = StructType(
    Array(
      StructField("sourceRecordId", StringType, nonNullable),
      StructField("sourcePersonId", StringType, nonNullable),
      StructField("guarantorLastName", StringType, isNullable),
      StructField("guarantorFirstName", StringType, isNullable),
      StructField("guarantorMiddleName", StringType, isNullable),
      StructField("guarantorFullName", StringType, isNullable),
      StructField("guarantorAddress1", StringType, isNullable),
      StructField("guarantorAddress2", StringType, isNullable),
      StructField("guarantorCity", StringType, isNullable),
      StructField("guarantorState", StringType, isNullable),
      StructField("guarantorZip5", StringType, isNullable),
      StructField("guarantorCountry", StringType, isNullable)
    )
  )

  val biometricSchema : StructType = StructType(
    Array(
      StructField("sourceRecordId", StringType, nonNullable),
      StructField("sourcePersonId", StringType, nonNullable),
      StructField("systolic", StringType, isNullable),
      StructField("diastolic", StringType, isNullable),
      StructField("height", StringType, isNullable),
      StructField("weight", StringType, isNullable),
      StructField("bodyMassIndex", StringType, isNullable)
    )
  )

  val physicianSchema : StructType = StructType(
    Array(
      StructField("primaryCarePhysicianId", StringType, nonNullable),
      StructField("physicianNationalProviderIdentifier", StringType, isNullable),
      StructField("physicianLastName", StringType, isNullable),
      StructField("physicianFirstName", StringType, isNullable),
      StructField("physicianMiddleName", StringType, isNullable),
      StructField("physicianFullName", StringType, isNullable),
      StructField("physicianPersonalSuffix", StringType, isNullable),
      StructField("physicianProfessionalSuffix", StringType, isNullable),
      StructField("physicianPrimarySpecialityCode", StringType, isNullable),
      StructField("physicianPrimarySpeciality", StringType, isNullable)
    )
  )

  val financialSchema : StructType = StructType(
    Array(
      StructField("sourceRecordId", StringType, nonNullable),
      StructField("sourcePersonId", StringType, nonNullable),
      StructField("charges", StringType, isNullable),
      StructField("cost", StringType, isNullable),
      StructField("grossMargin", StringType, isNullable),
      StructField("contributionMargin", StringType, isNullable),
      StructField("profit", StringType, isNullable)
    )
  )
}
