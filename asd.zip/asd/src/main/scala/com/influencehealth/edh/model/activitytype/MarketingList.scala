package com.influencehealth.edh.model.activitytype

import com.influencehealth.edh.Constants

trait MarketingList extends ActivityType {

  override val formatType: String = Constants.MarketingListInfluenceHealthFormat
  override val defaultSource: String = Constants.MarketingListDefaultSourceType
  override val defaultMessageType: String = Constants.MarketingListDefaultMessageType
  override val defaultSourceType: String = Constants.MarketingListDefaultSourceType
  override val defaultAddressType: String = Constants.MarketingListDefaultAddressType
  override val defaultActivityType: String = Constants.MarketingListActivityType
  override val defaultPersonType: String = Constants.MarketingListPersonType

  override val cleanseStringColumnNames: Seq[String] = Seq(

    // Marketing List
    "lastName",
    "firstName",
    "middleName",
    "address1",
    "address2",
    "city",
    "state",
    "zip5",
    "sourceSex",
    "listName"
  )

  override val nullColumnNames: Seq[String] = Seq(

    // Marketing List
    "firstName",
    "lastName",
    "listName",
    "source",
    "sourceRecordId"
  )

  override val mandatoryContactColumnsNames = Seq("emails", "phoneNumbers", "address1")

  override val zipColumnNames: Seq[String] = Seq.empty

}