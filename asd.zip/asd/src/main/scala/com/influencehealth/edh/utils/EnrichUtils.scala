package com.influencehealth.edh.utils

import com.influencehealth.edh.model.Activity

object EnrichUtils {

  def isInvalidAddress(activity: Activity): Boolean = !activity.isValidAddress.getOrElse(false)

  def hasNoPhoneNumber(activity: Activity): Boolean =
    activity.homePhone.isEmpty && activity.mobilePhone.isEmpty && activity.workPhone.isEmpty

  def isInvalidActivity(activity: Activity): Boolean = activity.firstName.isEmpty || activity.lastName.isEmpty ||
    (isInvalidAddress(activity) && activity.email.isEmpty && hasNoPhoneNumber(activity))
}