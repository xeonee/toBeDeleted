package com.influencehealth.edh.utils

import com.amazonaws.services.s3.AmazonS3
import com.amazonaws.services.s3.model._
import com.influencehealth.edh.Constants._
import com.typesafe.scalalogging.LazyLogging
import org.joda.time.{DateTimeZone, Days, LocalDate, Months}

import scala.collection.JavaConversions._
import scala.util.{Failure, Success, Try}

object S3Utilities extends LazyLogging {

  /**
    * Gets the list if invalid S3 URLs for all options (monthly, input file and default)
    *
    * @param cliJobName   CLI main job command eg: cleanse, load
    * @param bucketKeys   eg: s3a://bucketName comes from application conf(s)
    * @param customer     customer name
    * @param activityType activity type eg: encounter, dns etc
    * @return
    */
  def printLoggerInfoForS3UrlsScanned(
                                       inputFilePath: Option[String],
                                       inputMonths: Option[Int],
                                       inputDays: Option[Int],
                                       inputFormat: Option[String],
                                       inputBatchId: Option[String],
                                       cliJobName: String,
                                       bucketKeys: String,
                                       customer: String,
                                       activityType: String
                                     ): Unit = {
    val dataSource: String = if (activityType == ProspectActivityType || activityType == NewMoverActivityType) {
      "experian"
    }
    else if (activityType == DeceasedActivityType) {
      "social_security_administration"
    }
    else {
      customer
    }

    val inputFilePathExists = inputFilePath.nonEmpty
    val monthsExists = inputMonths.nonEmpty
    val daysExists = inputDays.nonEmpty
    var filePath = ""
    val currentDate: LocalDate = LocalDate.now(DateTimeZone.UTC)
    if (inputFilePathExists) {
      val batchDate = DataLakeUtilities.extractBatchNameFromS3RawBatchUrl(inputFilePath.get)
      val format = DataLakeUtilities.extractFormatFromS3Url(inputFilePath.get)
      filePath = s"$dataSource/cleansed/$activityType/$format/$batchDate"
      logger.info(s"No files found for $dataSource at '$filePath'")
    } else if (monthsExists) {
      val months: Int = inputMonths.get
      for (m <- months to 1 by -1) {
        val dateSplit = currentDate.minusMonths(m).toString.split("-")
        val batchDate = dateSplit(0).concat("-").concat(dateSplit(1))
        val format = inputFormat.get
        cliJobName match {
          case "cleanse" =>
            filePath = s"$bucketKeys/$dataSource/raw/$activityType/$format/$batchDate/"
          case "load" =>
            filePath = s"$bucketKeys/$dataSource/cleansed/$activityType/$format/$batchDate.parquet/"
        }
        logger.info(s"No files found for $dataSource at '$filePath'")
      }
    } else if (daysExists) {
      val format = inputFormat.get
      val days = inputDays.get
      for (d <- days to 1 by -1) {
        val dateSplit = currentDate.minusDays(d).toString.split("-")
        val batchDate = dateSplit(0).concat("-").concat(dateSplit(1)).concat("-").concat(dateSplit(2))
        cliJobName match {
          case "cleanse" => filePath = s"$bucketKeys/$dataSource/raw/$activityType/$format/$batchDate/"
          case "load" => filePath = s"$bucketKeys/$dataSource/cleansed/$activityType/$format/$batchDate.parquet/"
        }
        logger.error(s"No files found for $dataSource at '$filePath'")
      }
    } else {
      val batchId = inputBatchId.get
      val format = DataLakeUtilities.extractFormatFromBatchId(batchId)
      val batchDate = DataLakeUtilities.extractBatchDateFromBatchId(batchId)
      cliJobName match {
        case "cleanse" => filePath = s"$bucketKeys/$dataSource/raw/$activityType/$format/$batchDate/"
        case "load" => filePath = s"$bucketKeys/$dataSource/cleansed/$activityType/$format/$batchDate.parquet/"
      }
      logger.error(s"No files found for $dataSource at '$filePath'")
    }
  }

  /**
    * Returns the list of all S3 batch URls since for loading all the files from last number of months provided in CLI
    *
    * @param months         CLI provided month values to load data onwards those months
    * @param cliMainCommand CLI main command, eg: cleanse/load
    * @param bucketKeys     Getting the S3 bucket URL from configurations
    * @param s3Client       Amazon S3 client
    * @param source         Name of the customer
    * @param activityType   Activity type eg: encounter, marketinglist etc
    * @return
    */
  def getListOfS3urlsForMonthsOption(months: Int, cliMainCommand: String, bucketKeys: String,
                                     s3Client: AmazonS3, source: String, activityType: String,
                                     format: String): List[String] = {
    var listOfS3ObjectKeys: List[String] = List()
    val urlPrefix = cliMainCommand match {
      case "cleanse" => s"$source/raw/$activityType/$format/"
      case "load" => s"$source/cleansed/$activityType/$format/"
    }

    for (m <- months to 1 by -1) {
      val s3Url =
        getS3UrlsForEachMonth(s3Client, source, m, bucketKeys, cliMainCommand, activityType, format, urlPrefix)
      s3Url.foreach(x => {
        listOfS3ObjectKeys = listOfS3ObjectKeys :+ x
      })
    }

    listOfS3ObjectKeys.distinct
  }

  /**
    * Returns the list of all S3 batch URls since for loading all the files from last number of months provided in CLI
    *
    * @param sinceDate      CLI provided month values to load data onwards those months
    * @param cliMainCommand CLI main command, eg: cleanse/load
    * @param bucketKeys     Getting the S3 bucket URL from configurations
    * @param s3Client       Amazon S3 client
    * @param source         Name of the customer
    * @param activityType   Activity type eg: encounter, marketinglist etc
    * @return
    */
  def getListOfS3UrlsForSinceDateOption(sinceDate: String, cliMainCommand: String, bucketKeys: String,
                                        s3Client: AmazonS3, source: String, activityType: String,
                                        format: String): List[String] = {
    var listOfS3ObjectKeys: List[String] = List()
    val urlPrefix = cliMainCommand match {
      case "cleanse" => s"$source/raw/$activityType/$format/"
      case "load" => s"$source/cleansed/$activityType/$format/"
    }
    val currentDate: LocalDate = LocalDate.now(DateTimeZone.UTC)
    val sinceDateInLocalTime: LocalDate = LocalDate.parse(sinceDate)
    val differenceInMonths: Int = Months.monthsBetween(sinceDateInLocalTime, currentDate).getMonths
    val differenceInDays: Int = Days.daysBetween(sinceDateInLocalTime, currentDate).getDays

    format match {
      case "redox" =>
        // This will not run today's batch coz the batch can be incomplete.
        for (d <- differenceInDays to 1 by -1) {
          val s3Url = getS3UrlForEachDay(s3Client, source, d, bucketKeys, cliMainCommand,
              activityType, format, urlPrefix)
          s3Url.foreach(x => {
            listOfS3ObjectKeys = listOfS3ObjectKeys :+ x
          })
        }

      case _ =>
        for (m <- differenceInMonths to 1 by -1) {
          val s3Url =
            getS3UrlsForEachMonth(s3Client, source, m, bucketKeys, cliMainCommand, activityType, format, urlPrefix)
          s3Url.foreach(x => {
            listOfS3ObjectKeys = listOfS3ObjectKeys :+ x
          })
        }
    }
    listOfS3ObjectKeys.distinct
  }

  /**
    * Returns the list of all S3 batch URls since for loading all the files from last number of months provided in CLI
    *
    * @param days           CLI provided month values to load data onwards those months
    * @param cliMainCommand CLI main command, eg: cleanse/load
    * @param bucketKeys     Getting the S3 bucket URL from configurations
    * @param s3Client       Amazon S3 client
    * @param customer       Name of the customer
    * @param activityType   Activity type eg: encounter, marketinglist etc
    * @return
    */
  def getListOfS3UrlsForDaysOption(days: Int, cliMainCommand: String, bucketKeys: String,
                                   s3Client: AmazonS3, customer: String, activityType: String,
                                   format: String): List[String] = {
    var listOfS3ObjectKeys: List[String] = List()
    val urlPrefix = cliMainCommand match {
      case "load" => s"$customer/cleansed/$activityType/$format/"
    }
    for (d <- days to 1 by -1) {
      val s3Url =
        getS3UrlForEachDay(s3Client, customer, d, bucketKeys, cliMainCommand,
          activityType, format, urlPrefix)
      s3Url.foreach(x => {
        listOfS3ObjectKeys = listOfS3ObjectKeys :+ x
      })
    }
    listOfS3ObjectKeys.distinct
  }

  /**
    * Returns the list of Available S3 URLS for a given ANY bucket URL & Object name
    *
    * @param s3Client   Amazon S3 client
    * @param bucketKeys S3 bucket URL
    * @param objectName The S3 path that begins after the bucket name
    *                   Eg: S3 Path: s3a://bucketName/folder1/folder2/folder3/xyz.txt
    *                   bucketKeys: s3a://bucketName/
    *                   objectName: folder1/ or folder1/folder2/ or folder1/folder2/folder3/
    * @return
    */
  def getAvailableS3Urls(s3Client: AmazonS3, bucketKeys: String, objectName: String): List[String] = {
    var listOfKeys: List[String] = List()
    val bucketName: String = DataLakeUtilities.getS3BucketName(bucketKeys)
    Try {
      val objectListing: ObjectListing = s3Client.listObjects(new ListObjectsRequest().withBucketName(bucketName).
        withPrefix(objectName))
      for (objectSummary <- objectListing.getObjectSummaries) {
        val s3Url = bucketKeys + "/" + objectSummary.getKey
        listOfKeys = listOfKeys :+ s3Url
      }
    }
    match {
      case Success(x) =>
      case Failure(e) => logger.warn("No object found under: " + bucketKeys + "/" + objectName)
    }
    listOfKeys
  }

  /**
    * Returns the list of Available S3 URLS for a given ANY bucket URL & Object name
    *
    * @param s3Client   Amazon S3 client
    * @param bucketKeys S3 bucket URL
    * @param objectName The S3 path that begins after the bucket name
    *                   Eg: S3 Path: s3a://bucketName/folder1/folder2/folder3/xyz.txt
    *                   bucketKeys: s3a://bucketName/
    *                   objectName: folder1/ or folder1/folder2/ or folder1/folder2/folder3/
    * @return
    */
  def getAvailableBatchDirectoryUrlsForInputBatchId(s3Client: AmazonS3, bucketKeys: String,
                                                    objectName: String): List[String] = {
    var listOfKeys: List[String] = List()
    val bucketName: String = DataLakeUtilities.getS3BucketName(bucketKeys)

    Try {
      var objectListing: ObjectListing = s3Client.listObjects(bucketName, objectName)
      for (objectSummary <- objectListing.getObjectSummaries) {
        val s3Url = bucketKeys + "/" + objectSummary.getKey
        listOfKeys = listOfKeys :+ s3Url
      }
      // s3Client.listObjects returns at most 1000 objects at a time, so we need to check
      // ObjectListing's isTruncated() method to determine if there are more records and then use
      // s3Client.listNextBatchOfObjects to get the remaining object records.
      while (objectListing.isTruncated) {
        objectListing = s3Client.listNextBatchOfObjects(objectListing)
        for (objectSummary <- objectListing.getObjectSummaries) {
          val s3Url = bucketKeys + "/" + objectSummary.getKey
          listOfKeys = listOfKeys :+ s3Url
        }
      }
    }
    match {
      case Success(x) => listOfKeys
      case Failure(e) => throw new Exception(s"No object found under:$bucketKeys/$objectName", e)
    }
    listOfKeys
  }

  /**
    * Finds and returns a list of S3 batch Urls that are present in given list of Urls for a given cli main command
    *
    * @param s3Client       Amazon s3 client
    * @param customer       customer name
    * @param monthsCounter  counter to decrement number of months
    * @param s3BucketURL    s3 bucket url s3a://bucketName
    * @param cliMainCommand eg: cleanse / load
    * @param dataSource     eg: encounter, newmovers, marketing list, prospect
    * @return
    */
  private def getS3UrlsForEachMonth(s3Client: AmazonS3, customer: String, monthsCounter: Int, s3BucketURL: String,
                                    cliMainCommand: String, dataSource: String,
                                    format: String, urlPrefix: String): List[String] = {

    var s3Url: List[String] = List()
    val currentDate: LocalDate = LocalDate.now(DateTimeZone.UTC)
    val dateSplit = currentDate.minusMonths(monthsCounter).toString.split("-")
    val urlPrefixWithBatchForCleanse = s"$urlPrefix${dateSplit(0)}-${dateSplit(1)}/"
    val urlPrefixWithBatchForLoad = s"$urlPrefix${dateSplit(0)}-${dateSplit(1)}.parquet/"

    cliMainCommand match {
      case "cleanse" =>
        val listOfFolders = getAvailableS3Urls(s3Client, s3BucketURL, urlPrefixWithBatchForCleanse).distinct
        var listOfBatchUrls: List[String] = List()
        listOfFolders.foreach(x => {
          if (x.contains(".")) {
            val fileSplitter = x.split("/").last
            val folderName = x.replace(fileSplitter, "")
            listOfBatchUrls = listOfBatchUrls :+ folderName
          }
        })
        s3Url = listOfBatchUrls.distinct

      case "load" =>
        val listOfFolders = getAvailableS3Urls(s3Client, s3BucketURL, urlPrefixWithBatchForLoad).distinct
        var listOfBatchUrls: List[String] = List()
        listOfFolders.foreach(x => {
          if (x.endsWith(".parquet")) {
            val fileSplitter = x.split("/").last
            val folderName = x.replace(fileSplitter, "")
            listOfBatchUrls = listOfBatchUrls :+ folderName
          }
        })
        s3Url = listOfBatchUrls.distinct
    }
    s3Url
  }

  /**
    * Finds and returns a list of S3 batch Urls that are present in given list of Urls for a given cli main command
    *
    * @param s3Client       Amazon s3 client
    * @param source         customer name
    * @param s3BucketURL    s3 bucket url s3a://bucketName
    * @param cliMainCommand eg: cleanse / load
    * @param activityType   eg: encounter, newmovers, marketing list, prospect
    * @return
    */
  def getListOfS3UrlsForBatchAndFormatOptions(s3Client: AmazonS3, source: String, batchDate: String,
                                              s3BucketURL: String, cliMainCommand: String, activityType: String,
                                              format: String): List[String] = {
    var s3Url: List[String] = List()
    val urlPrefix = cliMainCommand match {
      case "cleanse" => s"$source/raw/$activityType/$format/$batchDate"
      case "load" => s"$source/cleansed/$activityType/$format/$batchDate"
    }
    val listOfFolders = getAvailableS3Urls(s3Client, s3BucketURL, urlPrefix).distinct
    cliMainCommand match {
      case "cleanse" =>
        var listOfBatchUrls: List[String] = List()
        listOfFolders.foreach(x => {
          if (x.contains(".")) {
            val fileSplitter = x.split("/").last
            val folderName = x.replace(fileSplitter, "")
            listOfBatchUrls = listOfBatchUrls :+ folderName
          }
        })
        s3Url = listOfBatchUrls.distinct

      case "load" =>
        var listOfBatchUrls: List[String] = List()
        listOfFolders.foreach(x => {
          if (x.endsWith(".parquet")) {
            val fileSplitter = x.split("/").last
            val folderName = x.replace(fileSplitter, "")
            listOfBatchUrls = listOfBatchUrls :+ folderName
          }
        })
        s3Url = listOfBatchUrls.distinct
    }
    s3Url.distinct
  }

  /**
    * Finds and returns a list of S3 batch Urls that are present in given list of Urls for a given cli main command
    *
    * @param s3Client       Amazon s3 client
    * @param customer       customer name
    * @param daysCounter    counter to decrement number of months
    * @param s3BucketURL    s3 bucket url s3a://bucketName
    * @param cliMainCommand eg: cleanse / load
    * @param dataSource     eg: encounter, newmovers, marketing list, prospect
    * @return
    */
  private def getS3UrlForEachDay(s3Client: AmazonS3, customer: String, daysCounter: Int,
                                 s3BucketURL: String, cliMainCommand: String, dataSource: String,
                                 format: String, urlPrefix: String): List[String] = {
    var s3Url: List[String] = List()
    val currentDate: LocalDate = LocalDate.now(DateTimeZone.UTC)
    val dateSplit = currentDate.minusDays(daysCounter).toString.split("-")
    val urlPrefixWithBatch = s"$urlPrefix${dateSplit(0)}-${dateSplit(1)}-${dateSplit(2)}.parquet/"
    val listOfFolders = getAvailableS3Urls(s3Client, s3BucketURL, urlPrefixWithBatch).distinct
    cliMainCommand match {
      case "load" => var listOfBatchUrls: List[String] = List()
        listOfFolders.foreach(x => {
          if (x.endsWith(".parquet")) {
            val fileSplitter = x.split("/").last
            val folderName = x.replace(fileSplitter, "")
            listOfBatchUrls = listOfBatchUrls :+ folderName
          }
        })
        s3Url = listOfBatchUrls.distinct
    }
    s3Url
  }

  /**
    * Returns the S3 Url for the most recent monthly load for a given cli main command
    *
    * @param cliMainCommand eg: cleanse / load
    * @param bucketUrl      s3 bucket url s3a://bucketName
    * @param s3Client       Amazon s3 client
    * @param customer       customer name
    * @param dataSource     eg: encounter, newmovers, marketing list, experian
    * @return
    */
  def getS3UrlForMonthlyDefault(cliMainCommand: String, bucketUrl: String, s3Client: AmazonS3,
                                customer: String, dataSource: String, format: String): List[String] = {
    var listOfS3ObjectKeys: List[String] = List()
    var count = 0
    val urlPrefix = cliMainCommand match {
      case "cleanse" => s"$customer/raw/$dataSource/$format/"
      case "load" => s"$customer/cleansed/$dataSource/$format/"
    }
    do {
      val s3Urls: List[String] = getS3UrlsForEachMonth(s3Client, customer, count, bucketUrl,
        cliMainCommand, dataSource, format, urlPrefix)
      if (s3Urls.nonEmpty) {
        s3Urls.foreach(x => {
          listOfS3ObjectKeys = listOfS3ObjectKeys :+ x
        })
      }
      count += 1
    } while (listOfS3ObjectKeys.isEmpty)
    listOfS3ObjectKeys.distinct
  }

  /**
    * Returns the S3 Url for the most recent daily load for a given cli main command
    *
    * @param cliMainCommand eg: cleanse / load
    * @param bucketUrl      s3 bucket url s3a://bucketName
    * @param s3Client       Amazon s3 client
    * @param customer       customer name
    * @param dataSource     eg: encounter, newmovers, marketing list, experian
    * @return
    */
  def getS3UrlForDailyDefault(cliMainCommand: String, bucketUrl: String, s3Client: AmazonS3,
                              customer: String, dataSource: String, format: String): List[String] = {
    var listOfS3ObjectKeys: List[String] = List()
    var count = 0
    val urlPrefix = cliMainCommand match {
      case "cleanse" => s"$customer/raw/$dataSource/$format/"
      case "load" => s"$customer/cleansed/$dataSource/$format/"
    }
    do {
      val s3Url: List[String] = getS3UrlForEachDay(s3Client, customer, count, bucketUrl,
        cliMainCommand, dataSource, format, urlPrefix)
      s3Url.foreach(x => {
        listOfS3ObjectKeys = listOfS3ObjectKeys :+ x
      })
      count += 1
    } while (listOfS3ObjectKeys.size != 1)
    listOfS3ObjectKeys
  }

  /**
    * Returns the list of Available S3 URLS for a given ANY bucket URL & Object name
    *
    * @param s3Client   Amazon S3 client
    * @param bucketKeys S3 bucket URL
    * @param objectName The S3 path that begins after the bucket name
    *                   Eg: S3 Path: s3a://bucketName/folder1/folder2/folder3/xyz.txt
    *                   bucketKeys: s3a://bucketName/
    *                   objectName: folder1/ or folder1/folder2/ or folder1/folder2/folder3/
    * @return
    */
  def getAcceptableBatchDirectoryUrls(s3Client: AmazonS3, bucketKeys: String, objectName: String): List[String] = {
    val bucketName: String = DataLakeUtilities.getS3BucketName(bucketKeys)

    val objectListing: Try[ObjectListing] = Try(s3Client.listObjects(new ListObjectsRequest().
      withBucketName(bucketName).withPrefix(objectName)))
    objectListing match {
      case Success(x) =>
        x.getObjectSummaries.filterNot(y => s"$bucketKeys/${y.getKey}".endsWith("done")).map { objectSummary =>
          s"$bucketKeys/${objectSummary.getKey}"
        }.toList
      case Failure(e) => logger.warn("No object found under: " + bucketKeys + "/" + objectName + e.getMessage)
        List()
    }
  }

}
