package com.influencehealth.edh.model.activitytype

import com.influencehealth.edh.Constants

trait EmployeeRoster extends ActivityType {

  override val formatType: String = Constants.EmployeeRosterInfluenceHealthFormat
  override val defaultSource: String = Constants.EmployeeRosterDefaultSource
  override val defaultMessageType: String = Constants.EmployeeRosterDefaultMessageType
  override val defaultSourceType: String = Constants.EmployeeRosterDefaultSourceType
  override val defaultAddressType: String = Constants.EmployeeRosterDefaultAddressType
  override val defaultActivityType: String = Constants.EmployeeRosterActivityType
  override val defaultPersonType: String = Constants.EmployeeRosterDefaultPersonType

  override val cleanseStringColumnNames: Seq[String] = Seq(
    "lastName",
    "firstName",
    "middleName",
    "address1",
    "address2",
    "city",
    "state",
    "zip5",
    "country",
    "sourceSex",
    "raceDesc",
    "hospitalDesc",
    "businessUnit",
    "businessUnitDesc",
    "siteDesc",
    "clinicDesc",
    "practiceLocationDesc",
    "jobTitleDesc",
    "jobFamilyDesc",
    "statusCode",
    "statusCodeDesc"
  )

  override val nullColumnNames: Seq[String] = Seq(
    "firstName",
    "lastName",
    "source",
    "sourceRecordId"
  )

  override val zipColumnNames: Seq[String] = Seq.empty

  override val mandatoryContactColumnsNames: Seq[String] = Seq("workEmail", "homePhone", "address1")

}