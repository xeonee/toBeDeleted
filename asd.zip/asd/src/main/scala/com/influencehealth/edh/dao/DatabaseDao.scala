package com.influencehealth.edh.dao

import java.time.LocalDate

import com.influencehealth.edh.model._
import org.apache.spark.sql.Dataset

import scala.reflect.ClassTag

trait DatabaseDao extends Serializable {

  def getAddressesByCustomer(customer: String): Dataset[Address]

  def getPersonArchivesByCustomer(customer: String): Dataset[Person]

  def getCollapseHistory(customer: String): Dataset[CollapseHistory]

  def deleteEpdbListPersons(customer: String): Unit

  def deleteDoNotSolicitEmails(customer: String): Unit

  def getDoNotSolicitEmailsByCustomer(customer: String): Dataset[DoNotSolicitEmail]

  def getDoNotSolicitEmailsByBatchId(customer: String, batchId: String): Dataset[DoNotSolicitEmail]

  def deleteCustomersPersons(customer: String): Unit

  def deleteCustomersPersonArchives(customer: String): Unit

  def deleteCustomersCollapseHistory(customer: String): Unit

  def deleteCustomersAddresses(customer: String): Unit

  def deleteCustomersActivities(customer: String): Unit

  def truncateDB(): Unit

  def deleteCustomersUnidentifiedActivities(customer: String): Unit

  def savePersonsAndActivities(persons: Dataset[Person], personActivities: Dataset[Activity]): Unit

  def getActivitiesByCustomer(customer: String): Dataset[Activity]

  def saveUnidentifiableActivities(invalidAddressRecords: Dataset[UnIdentifiableActivity])

  def getPersonsByCustomer(customer: String, full: Boolean = true): Dataset[Person]

  def getPersonsByBatchId(batchId: String, full: Boolean = true): Dataset[Person]

  def getActivitiesByBatchId(batchId: String): Dataset[Activity]

  def getUnidentifiableActivitiesByBatchId(batchId: String): Dataset[Activity]

  def getUngroupableActivitiesByBatchId(batchId: String): Dataset[Activity]

  def searchAddressesByZipCodes(distinctZipCodes: Set[String]): Dataset[Address]

  def saveAddresses(addresses: Dataset[Address]): Unit

  def savePersons(enrichedPersons: Dataset[Person]): Unit

  def collapsePersons(persons: Dataset[Person], deletedPersons: Dataset[Person]): Unit

  def transactionalSaveTable[T](dataset: Dataset[T], table: String, unloggedTable: String, primaryKey: String): Unit

  def saveTable[T](dataset: Dataset[T], table: String): Unit

  def saveActivities(linkedActivities: Dataset[Activity]): Unit

  def loadTable[T: ClassTag](table: String): Dataset[T]

  def saveJobHistory(dataset: Dataset[JobHistory]): Unit

  def searchJobHistoryByBatchId(batchId: String): List[JobHistory]

  def saveIdentifiedLeads(matchedLeads: Dataset[IdentifiedLead]): Unit

  def getPersonsUpdatedSince(since: LocalDate, customer: String, full: Boolean = true): Dataset[Person]

  def getActivitiesRelatedToUpdatedSince(since: LocalDate, customer: String): Dataset[Activity]

  def getActivitiesRelatedToBatchUpdate(batchId: String): Dataset[Activity]

  def saveUngroupableActivities(unGroupableRecords: Dataset[UnIdentifiableActivity]): Unit

  def saveDoNotSolicitEmails(dnsemails: Dataset[DoNotSolicitEmail]): Unit

}
