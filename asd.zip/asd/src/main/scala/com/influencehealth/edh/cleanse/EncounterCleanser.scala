package com.influencehealth.edh.cleanse

import com.influencehealth.edh.Constants
import com.influencehealth.edh.dataframe.columns._
import com.influencehealth.edh.enrich.activity.crosswalks.helper.{CrosswalkData, CrosswalkDerivatives}
import com.influencehealth.edh.model.activitytype.ActivityType
import com.influencehealth.edh.utils.{CleanseUtils, PersonUtils}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{ArrayType, StringType}


class EncounterCleanser(val dateBatchReceived: String) extends DataCleanser {

  this: ActivityType =>


  override def cleanseData(
                            df: DataFrame,
                            customer: Option[String],
                            batchId: String
                          ): (DataFrame, DataFrame) = {

    import df.sparkSession.implicits._

    // Split df into persons with activities and persons without activities
    val (personsWithActivities, personsWithoutActivities) = splitDataFrameBasedOnAvailabilityOfActivities(df.
      withColumn("state", get_valid_state($"state")), customer.get)

    // Apply default values for Required Columns if found NULL
    val defaultCodeForRequiredColumnsContainingNulls =
      assignDefaultValuesForRequiredColumnsContainingNulls(personsWithActivities)

    // cleanses & filters Date column
    val dataFrameContainingValidDateColumns = formatDateColumns(
      defaultCodeForRequiredColumnsContainingNulls.union(personsWithoutActivities))

    // filters required columns that are not null
    val (dataFrameContainingNonNullColumns, dataFrameContainingNullColumns) =
      filterRequiredColumnsContainingInvalidValues(
        dataFrameContainingValidDateColumns, nullColumnNames, mandatoryContactColumnsNames)

    logger.info(s"Records left after filter: ${dataFrameContainingNonNullColumns.count()}")

    // Cleanses String Column
    val dataFrameContainingCleansedStringColumns = cleanseStringColumns(dataFrameContainingNonNullColumns, cleanseStringColumnNames)

    // Cleanses Columns that have Amount values
    val dataFrameContainingCleansedAmountColumns = cleanseAmountColumns(dataFrameContainingCleansedStringColumns)

    // Cleanses Contact details: Phone numbers and emails
    val dataFrameContainingCleansedContactDetails = cleanseContactDetails(dataFrameContainingCleansedAmountColumns)

    // Cleanse zip5 column
    val cleansedZips = cleanseAddress(dataFrameContainingCleansedContactDetails)

    // Aliases Data
    val aliasedData = aliasData(cleansedZips, customer)

    val sourceData = populateSourceColumns(aliasedData)

    (sourceData, dataFrameContainingNullColumns)
  }

  override def formatDateColumns(df: DataFrame): DataFrame = {
    import df.sqlContext.implicits._
    // Convert string date into Date type columns after validating the dates, known behavior
    val formattedDatesDataFrame = df.withColumn("dateReceived", lit(dateBatchReceived)).
      withColumn("dateOfBirth", date_format(unix_timestamp($"dateOfBirth", "MM/dd/yyyy").
        cast("timestamp"), "MM/dd/yyyy")).
      withColumn("dateOfDeath", date_format(unix_timestamp($"dateOfDeath", "MM/dd/yyyy").
        cast("timestamp"), "MM/dd/yyyy")).
      withColumn("admitDate", date_format(unix_timestamp($"admitDate", "MM/dd/yyyy").cast("timestamp"), "MM/dd/yyyy")).
      withColumn("dischargeDate", date_format(unix_timestamp($"dischargeDate", "MM/dd/yyyy").
        cast("timestamp"), "MM/dd/yyyy"))

    // Get difference in dates
    val dataFrameContainingDifferenceBetweenTwoDates = formattedDatesDataFrame.
      withColumn("daysBetweenDateOfDeathAndBirth",
        datediff(date_format(unix_timestamp($"dateOfDeath", "MM/dd/yyyy").cast("timestamp"), "yyyy-MM-dd"),
          date_format(unix_timestamp($"dateOfBirth", "MM/dd/yyyy").cast("timestamp"), "yyyy-MM-dd"))).
      // Re-Assignment for length of stay from string to integer
      withColumn("lengthOfStay",
      datediff(date_format(unix_timestamp($"dischargeDate", "MM/dd/yyyy").cast("timestamp"), "yyyy-MM-dd"),
        date_format(unix_timestamp($"admitDate", "MM/dd/yyyy").cast("timestamp"), "yyyy-MM-dd")))

    // filter day differences between two dates greater than -1
    val dataFrameContainingValidDateColumns = dataFrameContainingDifferenceBetweenTwoDates.withColumn("dateOfDeath",
      getDate(dataFrameContainingDifferenceBetweenTwoDates("daysBetweenDateOfDeathAndBirth"),
        dataFrameContainingDifferenceBetweenTwoDates("dateOfDeath"))).
      withColumn("dischargeDate", getDate(dataFrameContainingDifferenceBetweenTwoDates("lengthOfStay"),
        dataFrameContainingDifferenceBetweenTwoDates("dischargeDate"))).
      withColumn("lengthOfStay",
        getValidDifferenceBetweenDates(dataFrameContainingDifferenceBetweenTwoDates("lengthOfStay"))).
      drop("daysBetweenDateOfDeathAndBirth")

    // Activity Date
    val dfWithActivityDate = dataFrameContainingValidDateColumns.
      withColumn("activityDate",
        getActivityDate(
          dataFrameContainingValidDateColumns("dischargeDate"),
          dataFrameContainingValidDateColumns("finalBillDate"),
          dataFrameContainingValidDateColumns("admitDate"),
          dataFrameContainingValidDateColumns("dateReceived"))).
      drop("dateReceived")

    dfWithActivityDate.withColumn("dateOfBirth",
      date_format(unix_timestamp($"dateOfBirth", "MM/dd/yyyy").cast("timestamp"), "yyyy-MM-dd"))
      .withColumn("dateOfDeath",
        date_format(unix_timestamp($"dateOfDeath", "MM/dd/yyyy").cast("timestamp"), "yyyy-MM-dd"))
      .withColumn("admitDate",
        date_format(unix_timestamp($"admitDate", "MM/dd/yyyy").cast("timestamp"), "yyyy-MM-dd"))
      .withColumn("dischargeDate",
        date_format(unix_timestamp($"dischargeDate", "MM/dd/yyyy").cast("timestamp"), "yyyy-MM-dd"))
      .withColumn("finalBillDate",
        date_format(unix_timestamp($"finalBillDate", "MM/dd/yyyy").cast("timestamp"), "yyyy-MM-dd"))
      .withColumn("activityDate",
        date_format(unix_timestamp($"activityDate", "MM/dd/yyyy").cast("timestamp"), "yyyy-MM-dd"))

  }

  override def cleanseStringColumns(df: DataFrame, stringColumnsToBeCleansed: Seq[String]): DataFrame = {

    import df.sparkSession.implicits._

    val returnDataFrame = stringColumnsToBeCleansed.foldLeft(df)((df, column) => {
      df.withColumn(s"$column", CleanseUtils.cleanseStringColumns(df(s"$column")))
    }).withColumn("state", upper($"state"))

    returnDataFrame.transform { df =>
      if (df.columns.contains("guarantorLastName")) {
        // GUARANTOR
        df.
          withColumn("guarantorLastName", CleanseUtils.cleanseStringColumns(df("guarantorLastName"))).
          withColumn("guarantorFirstName", CleanseUtils.cleanseStringColumns(df("guarantorFirstName"))).
          withColumn("guarantorMiddleName", CleanseUtils.cleanseStringColumns(df("guarantorMiddleName"))).
          withColumn("guarantorFullName", CleanseUtils.cleanseStringColumns(df("guarantorFullName"))).
          withColumn("guarantorAddress1", CleanseUtils.cleanseStringColumns(df("guarantorAddress1"))).
          withColumn("guarantorAddress2", CleanseUtils.cleanseStringColumns(df("guarantorAddress2"))).
          withColumn("guarantorCity", CleanseUtils.cleanseStringColumns(df("guarantorCity"))).
          withColumn("guarantorState", CleanseUtils.cleanseStringColumns(df("guarantorState"))).
          withColumn("guarantorZip5", CleanseUtils.get_zip5(df("guarantorZip5"))).
          withColumn("guarantorCountry", CleanseUtils.cleanseStringColumns(df("guarantorCountry")))
      } else {
        df
      }
    }.transform { df =>
      if (df.columns.contains("physicianFirstName")) {
        df.
          withColumn("physicianFirstName", CleanseUtils.cleanseStringColumns(df("physicianFirstName"))).
          withColumn("physicianLastName", CleanseUtils.cleanseStringColumns(df("physicianLastName"))).
          withColumn("physicianMiddleName", CleanseUtils.cleanseStringColumns(df("physicianMiddleName"))).
          withColumn("physicianFullName", CleanseUtils.cleanseStringColumns(df("physicianFullName"))).
          withColumn("physicianPersonalSuffix", CleanseUtils.cleanseStringColumns(df("physicianPersonalSuffix"))).
          withColumn("physicianProfessionalSuffix",
            CleanseUtils.cleanseStringColumns(df("physicianProfessionalSuffix"))).
          withColumn("physicianPrimarySpecialityCode",
            CleanseUtils.cleanseStringColumns(df("physicianPrimarySpecialityCode"))).
          withColumn("physicianPrimarySpeciality",
            CleanseUtils.cleanseStringColumns(df("physicianPrimarySpeciality")))
      } else df

    }

  }

  override def aliasData(df: DataFrame, customer: Option[String]): DataFrame = {
    super.aliasData(df, customer).
      withColumn("addressType", lit(defaultAddressType)).
      withColumn("sourceActivityType", lit(defaultActivityType)).
      withColumn("activityType", lit(defaultActivityType)).
      withColumn("sex", PersonUtils.sex(df("sourceSex")))

  }

  override def filterRequiredColumnsContainingInvalidValues(
                                                             df: DataFrame,
                                                             nullValueColumns: Seq[String],
                                                             methodOfContactNulls: Seq[String]
                                                           ): (DataFrame, DataFrame) = {
    import df.sparkSession.implicits._

    val evaluatedDataFrame = df.withColumn("errors", array()).transform { df =>
      df.withColumn("medicalErrors",
        when(
          df("currentProceduralTerminologyCodes").isNull &&
            df("diagnosisCodes").isNull, "medical codes(cp/dx) are missing")).
        withColumn("facilityErrors",
          when((df("hospitalId").isNull && df("hospital").isNull) &&
            (df("clinicId").isNull && df("clinic").isNull), "Hospital/Clinic (Ids & Desc) are missing")).
        withColumn("stateErrors", validateState(df("state")))
    }.transform { df =>
      nullValueColumns.foldLeft(df) { (d, col) =>
        d.withColumn(s"${col}Errors", when(d(col).isNull, s"$col is null"))
      }
    }.transform { df =>
      df.withColumn("locationCodeErrors",
        when($"locationCode".isNull, s"Input HOSPITAL_ID is not matching with customer hospital locations"))
    }.transform { df =>
      df.withColumn("contactErrors",
        when($"email".isNull &&
          $"homePhone".isNull &&
          $"address1".isNull,
          "Must contain at least one of the following: email, homePhone, or address1"))
    }.transform(mapToErrorsDataFrame)

    val validData = evaluatedDataFrame.where(size($"errors") === 0).drop("errors")

    val invalidData = evaluatedDataFrame.where(size($"errors") > 0)

    (validData, invalidData)
  }

  private def mapToErrorsDataFrame(dataFrame: DataFrame): DataFrame = {
    val errorsColumns = dataFrame.schema.filter(_.name.endsWith("Errors")).map(_.name)

    dataFrame.
      withColumn("errors", removeNull(array(errorsColumns.map(c => col(c)): _*).cast(ArrayType(StringType))))
      .drop(errorsColumns: _*)
  }

  def removeNull = udf((array: Seq[String]) => array.filterNot(_ == null))

  // Validates the input state and guarantorState values by using the defined states in the Constants.
  // If the input values are not present in the defined states, will send these records to error file.
  private def validateState: UserDefinedFunction = udf((inputState: String) => {
    inputState match {
      case x if x == null || x.isEmpty || Constants.DefinedState.contains(x.toUpperCase) => None
      case _ => Some(s"Input State value is not matching with defined state values")
    }
  })


  val is_valid_monetary_column = udf[Boolean, String](amount =>
    Option(amount).forall { a =>
      val regex = "(?=.*?\\d)^\\$?(([1-9]\\d{0,2}(,\\d{3})*)|\\d+)?(\\.\\d{1,2})?$".r
      regex.pattern.matcher(a).matches
    }
  )

  /** coding values for columns (exclusion flag, source patient type, er patients) that require have null values
    *
    * @param df
    * @return
    **/
  override def assignDefaultValuesForRequiredColumnsContainingNulls(df: DataFrame): DataFrame = {
    import df.sparkSession.implicits._

    df.
      withColumn("sourceExclusionFlagColumnName", lit(SourceExclusionFlagIdentifier)).
      withColumn("sourcePatientTypeColumnName", lit(SourcePatientTypeIdentifier)).
      withColumn("sourceErPatientColumnName", lit(SourceErPatientIdentifier)).
      withColumn("sourceExclusionFlag",
        defaultCodingForNullColumns($"sourceExclusionFlag", $"sourceExclusionFlagColumnName")).
      withColumn("sourcePatientType",
        defaultCodingForNullColumns($"sourcePatientType", $"sourcePatientTypeColumnName")).
      withColumn("sourceErPatient",
        defaultCodingForNullColumns($"sourceErPatient", $"sourceErPatientColumnName")).
      drop("sourceExclusionFlagColumnName",
        "sourcePatientTypeColumnName",
        "sourceErPatientColumnName")
  }


  /**
    * Cleanses the Amount column by removing special characters like $
    * @param df
    * @return
    */
  private def cleanseAmountColumns(df: DataFrame): DataFrame = {
    df.columns.contains(Charges) match {
      case true =>
        val dfWithCharges = df.withColumn(Charges, when(col("visitTotalCharges").isNotNull,
        CleanseUtils.cleanseAmountColumns(df("visitTotalCharges"))).otherwise(null))

        dfWithCharges
          .withColumn(ContributionMargin, when(col(Charges).isNotNull && col(ContributionMargin).isNull, null).otherwise(CleanseUtils.cleanseAmountColumns(col(ContributionMargin))))
          .withColumn(Cost, when(col(Charges).isNotNull && col(Cost).isNull, null).otherwise(CleanseUtils.cleanseAmountColumns(col(Cost))))
          .withColumn(Profit, when(col(Charges).isNotNull && col(Profit).isNull, null).otherwise(CleanseUtils.cleanseAmountColumns(col(Profit))))

      case false  => df
    }

  }

  /** Validates the email and phone number columns
    *
    * @param df
    * @return
    **/
  private def cleanseContactDetails(df: DataFrame): DataFrame = {
    // VISIT
    val updatedDf = df.withColumn("email", CleanseUtils.cleanseAndValidateEmail(df("email"))).
      withColumn("homePhone", CleanseUtils.cleanseAndParsePhone(df("homePhone"))).
      withColumn("mobilePhone", CleanseUtils.cleanseAndParsePhone(df("mobilePhone"))).
      withColumn("workPhone", CleanseUtils.cleanseAndParsePhone(df("workPhone")))
    val finalDf = updatedDf.
      withColumn("emails", getStringToArray(col("email"))).
      withColumn("phoneNumbers",
        CleanseUtils.cleanseAndConcatePhoneNumbers(
          col("homePhone"),
          col("workPhone"),
          col("mobilePhone")))
    finalDf
  }

  /** If the difference between the end date is before the before date is < 0 then return null */
  private def getDate: UserDefinedFunction = udf((value: Int, date: String) => {
    if (value >= 0) {
      date
    } else null
  })

  /** If the length of stay is < 0 then return null */
  private def getValidDifferenceBetweenDates: UserDefinedFunction = udf((value: Int) => {
    if (value >= 0) {
      value
    } else 0
  })


  private def cleanseAddress(df: DataFrame): DataFrame = {
    val updatedAddressDf = df.
      withColumn("zip4", CleanseUtils.get_zip4(df("zip5"))).
      withColumn("zip5", CleanseUtils.get_zip5(df("zip5")))
    updatedAddressDf.columns.contains("guarantorState") match {
      case true => updatedAddressDf.withColumn("guarantorState", get_valid_state(df("guarantorState"))).
        withColumn("guarantorZip5", CleanseUtils.get_zip5(df("guarantorZip5")))
      case _ => updatedAddressDf
    }
  }

  private def standardize(string: String) = string.replaceAll("[^a-zA-Z]", "").toUpperCase

  /** Get valid State Values  */
  private def get_valid_state: UserDefinedFunction = udf((state: String) => {
    getValidState(Option(state))
  })

  def getValidState(state: Option[String]): Option[String] = {
    state.map(_.toUpperCase).flatMap { s =>
      if (Constants.DefinedState.contains(s)) {
        Some(s.toUpperCase())
      } else {
        Constants.DefinedFullTextStateMapping.map { case (k, v) =>
          (standardize(k), v)
        }.get(standardize(s)).map(_.toUpperCase)
      }
    }
  }

  private def splitDataFrameBasedOnAvailabilityOfActivities(df: DataFrame, customer: String): (DataFrame, DataFrame) = {

    val crosswalkDataContext: CrosswalkData = CrosswalkData(df.sparkSession)
    val crosswalkDerivatives = CrosswalkDerivatives(crosswalkDataContext)

    val updatedDf = df.
      withColumn("locationCode", crosswalkDerivatives.clientLocation(
        df("hospitalId"), df("clinicId"), lit(customer), df("source"), df("sourceType")))
      .withColumn("sourceLocationDesc",  when(col("hospital").isNotNull, df("hospital")).otherwise(df("clinic")))
    val personsWithActivities = updatedDf.where("sourceRecordId is not null")
    val personsWithoutActivities = updatedDf.where("sourceRecordId is null")

    (personsWithActivities, personsWithoutActivities)
  }

  private def getActivityDate: UserDefinedFunction = udf((dischargeDate: String, finalBillDate: String,
                                                          admitDate: String, dateReceived: String) =>
    if (dischargeDate != null && dischargeDate != "NULL") {
      dischargeDate
    }
    else if (finalBillDate != null && finalBillDate != "NULL") {
      finalBillDate
    }
    else if (admitDate != null && admitDate != "NULL") {
      admitDate
    }
    else if (dateReceived != null && dateReceived != "NULL") {
      dateReceived
    }
    else {
      throw new RuntimeException("Discharge date, Final bill date, admit date are all null.")
    }
  )

  private def populateSourceColumns(df: DataFrame): DataFrame = {
    df.
      withColumn("sourceRecordId", populate_source_record_id(df("sourcePersonId"), df("sourceRecordId"))).
      withColumn("source", populate_source(df("source"))).
      withColumn("sourceType", lit(defaultSourceType)).
      withColumn("activityType", lit(defaultActivityType)).
      withColumn("addressType", lit(defaultAddressType)).
      withColumn("messageType", lit(defaultMessageType))
  }

  val populate_source_record_id: UserDefinedFunction = udf((sourcePersonId: String, sourceRecordId: String) => {
    if (sourceRecordId == null || sourceRecordId.isEmpty || sourceRecordId == "") {
      sourcePersonId
    }
    else {
      sourceRecordId
    }
  })

  val populate_source: UserDefinedFunction = udf((source: String) => {
    if (source == null || source.isEmpty || source == "") {
      defaultSource
    }
    else {
      source
    }
  })

  /** Codes column with default values if found null
    * Columns: Exclusion flag, Patient type, ER Patient
    */
  private def defaultCodingForNullColumns: UserDefinedFunction = udf((stringValue: String, columnName: String) => {

    if (stringValue == null || stringValue.isEmpty || stringValue == "") {
      columnName match {
        case SourceExclusionFlagIdentifier => SourceExclusionFlagDefault
        case SourcePatientTypeIdentifier => SourcePatientTypeDefault
        case SourceErPatientIdentifier => SourceErPatientDefault
      }

    }
    else {
      columnName match {
        case SourceExclusionFlagIdentifier => if (!ValidBooleanType.contains(stringValue)) {
          SourceExclusionFlagDefault
        }
        else stringValue
        case SourcePatientTypeIdentifier => if (!ValidPatientType.contains(stringValue) || stringValue == "O") {
          SourcePatientTypeDefault
        }
        else "INPATIENT"
        case SourceErPatientIdentifier => if (!ValidERPatientType.contains(stringValue)) {
          SourceErPatientDefault
        }
        else stringValue
      }

    }
  })

}
