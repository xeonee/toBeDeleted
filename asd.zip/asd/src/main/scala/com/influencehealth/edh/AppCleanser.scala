package com.influencehealth.edh

import java.net.URI
import java.util.Calendar

import com.influencehealth.edh.cleanse.DataCleanser
import com.influencehealth.edh.cleanse.normalizers.{EncounterNormalizer, HraNormalizer}
import com.influencehealth.edh.config.{CleanseJobConfig, JobConfigHelper}
import com.influencehealth.edh.dao.{DatabaseDao, FileSystemDao, S3FileSystemDao}
import com.influencehealth.edh.lookups.client.LookupsClient
import com.influencehealth.edh.model.Activity
import com.influencehealth.edh.utils.filesystem.PathInfo
import com.influencehealth.edh.utils.{CleanseUtils, DataLakeUtilities}
import com.influencehealth.edh.validation.BaldurInputValidator
import com.typesafe.config.Config
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.util.parsing.json.JSONObject

object AppCleanser extends BaldurApplication[CleanseJobConfig] {

  var inputRecordCount: Option[Long] = None
  var outputRecordCount: Option[Long] = None

  override def runJob(implicit sparkSession: SparkSession, cleanseJobConfig: CleanseJobConfig,
                      databaseDao: DatabaseDao) = {

    val customer: Option[String] = JobConfigHelper.optConfig(appConfig, "app.customer")

    val fileSystemDao: FileSystemDao = new S3FileSystemDao(sparkSession, appConfig, s3client)

    logger.info(s"Reading data from: ${cleanseJobConfig.inputFilePath.get}")

    val inputFolderPaths: List[String] = fileSystemDao.getInputFolderPaths(cleanseJobConfig)

    val inputBatchLevelFolderPaths: List[String] =
      inputFolderPaths.map(x => DataLakeUtilities.buildBatchLevelInputPaths(x)).distinct

    if (inputBatchLevelFolderPaths.isEmpty) {
      throw new RuntimeException(s"No input files are present at: ${cleanseJobConfig.inputFilePath.get}")
      // throw new RuntimeException(s"Found no input files use: $cleanseJobConfig")
    }

    // Iterate over each input folder and call processRawRecords method to get the input and output records count.
    // processRawRecords method returns the tuple of number of input records (records read from S3) and
    // number of output records (total records - invalid records).
    // Values of this tuple is used to populated jobHisstory table.
    val (inputRecords, outputRecords) = inputBatchLevelFolderPaths.foldLeft((0L, 0L)){
      (acc, folderPath) => val res =
        processRawRecords(customer, folderPath, cleanseJobConfig, fileSystemDao, inputFolderPaths)
        (acc._1 + res._1, acc._2 + res._2)
    }

    inputRecordCount = Some(inputRecords)
    outputRecordCount = Some(outputRecords)
  }

  def processRawRecords(customer: Option[String], folderPath: String, cleanseJobConfig: CleanseJobConfig,
                        fileSystemDao: FileSystemDao, allInputFolderPaths: List[String]): (Long, Long) = {

    val startTime: String = Constants.Now.toString

    val outputCleansedS3Path = DataLakeUtilities.
      buildS3PathForCleansedOutput(s"$folderPath")

    val gatedErrors = DataLakeUtilities.
      buildS3PathForErrorOutput(s"$folderPath", "gated-records.csv")

    val invalidErrors = DataLakeUtilities.
      buildS3PathForErrorOutput(s"$folderPath", "invalid-records.csv")

    if (cleanseJobConfig.force) {
        fileSystemDao.deleteFiles(gatedErrors)
        fileSystemDao.deleteFiles(invalidErrors)
        fileSystemDao.deleteFiles(outputCleansedS3Path)
    }

    var totalCountInputRecord: Long = 0L
    var totalCountOutputRecord: Long = 0L

    val pathInfo: PathInfo = PathInfo(s"$folderPath", Constants.batchRawPhase)

    val dateBatchReceived: String =
      s"${pathInfo.batchYear.get}-${pathInfo.batchMonth.get}${pathInfo.batchDay.map(d => s"-d").getOrElse("")}"

    val batchId: String = s"${pathInfo.source}-${pathInfo.activityType}-${pathInfo.activityFormat}-$dateBatchReceived"

    logger.info(s"Cleansing using activity type: ${cleanseJobConfig.activityType}")
    logger.info(s"Cleansing using format: ${cleanseJobConfig.batchFormat}")
    logger.info(s"Cleansing using date batch received: $dateBatchReceived")
    logger.info(s"Cleansing using batch id $batchId")

    allInputFolderPaths.foreach(path => {
      if (path.contains(folderPath) && fileSystemDao.isFilePresentInTheFolder(path)) {
        logger.info(s"Cleansing file at: $path")

        val (cleansedDataFrame: DataFrame, errorsDataFrame: DataFrame) = cleanseData(
          customer,
          cleanseJobConfig.activityType,
          batchId,
          cleanseJobConfig.force,
          s"$path",
          cleanseJobConfig.batchFormat,
          dateBatchReceived,
          fileSystemDao)

        // Map data to Activity schema
        val mappedDataFrame: DataFrame = Activity.transformToActivitySchema(cleansedDataFrame).drop("sg2")

        val validator = new BaldurInputValidator(mappedDataFrame)
        val (invalidRecords, validRecords) = validator.splitInvalidData()

        if (invalidRecords.count() > 0) {

          validator.printErrorStats(invalidRecords)

          logger.error(s"Baldur input validation failed. Please see logs above for error details.")

          fileSystemDao.saveErrorFile(invalidRecords, gatedErrors)
          logger.info(s"Invalid records have been saved at $gatedErrors")
        }

        val errorsActivityDataFrame: DataFrame = Activity.
          transformToErrorActivitySchema(CleanseUtils.checkPhonenumberEmailColumn(errorsDataFrame))
          .drop("sg2")

        if (errorsDataFrame.head(1).nonEmpty) {

          fileSystemDao.saveErrorFile(errorsActivityDataFrame, invalidErrors)
          logger.info(s"Invalid records have been saved at $invalidErrors")
        } else {
          logger.info("No invalid records found while running the cleanse process.")
        }

        // check the max allowed error records count for encounter locations mismatch
        if (cleanseJobConfig.subJobType == "encounter") {
          import errorsActivityDataFrame.sqlContext.implicits._
          val errorsActivityDataFrameCount = errorsActivityDataFrame.filter(
            array_contains($"errors", "Input HOSPITAL_ID is not matching with customer hospital locations")
          ).count()

          val logMessage =
            s"There are total $errorsActivityDataFrameCount records in the error file where input " +
              s"HOSPITAL_ID is not matching with the customer existing hospital locations, where maximum error " +
              s"records allowed count is ${cleanseJobConfig.maxAllowedLocationsMismatchCount}."
          if (errorsActivityDataFrameCount > cleanseJobConfig.maxAllowedLocationsMismatchCount) {
            throw new Exception(logMessage)
          } else {
            logger.info(logMessage)
          }
        }

        // Save cleansed data to S3 (Data Lake)
        if (validRecords.head(1).nonEmpty) {
          fileSystemDao.saveCleansedFile(validRecords, outputCleansedS3Path)
          logger.info(s"Saved cleansed jobs to location: $outputCleansedS3Path")
        } else {
          logger.info(s"No cleansed records generated while running the cleanse " +
            s"process for files at: ${cleanseJobConfig.inputFilePath.get}")
        }
        totalCountInputRecord =  validRecords.count + errorsDataFrame.count
        totalCountOutputRecord =  validRecords.count
      }
    })

    generateMetaDataForCleansedBatch(cleanseJobConfig, folderPath, startTime)

    (totalCountInputRecord, totalCountOutputRecord)
  }

  /**
    * Creates a metadata file and saves it to the raw S3 batch URL
    *
    * @param cleanseJobConfig
    * @param inputFilePath
    * @param startTime
    */
  def generateMetaDataForCleansedBatch(cleanseJobConfig: CleanseJobConfig,
                                       inputFilePath: String, startTime: String): Unit = {

    val endTime = Constants.Now.toString
    val now = Calendar.getInstance
    val batchId: String = cleanseJobConfig.batchId.getOrElse(
      DataLakeUtilities.getBatchIdFromS3Url(
        inputFilePath, cleanseJobConfig.activityType, cleanseJobConfig.customer.get))

    val jsonData: Map[String, String] = Map(
      "batch-id" -> batchId,
      "source" -> cleanseJobConfig.source,
      "activity-type" -> cleanseJobConfig.activityType,
      "job-command" -> jobCommand,
      "input-file-location" -> inputFilePath,
      "job-start-time" -> startTime,
      "job-end-time" -> endTime,
      "user-who-triggered-the-job" -> cleanseJobConfig.user)

    val jsonObj: JSONObject = JSONObject(jsonData)
    val currentDate = java.time.LocalDate.now.toString.concat("T").concat(now.get(Calendar.HOUR_OF_DAY).toString).
      concat("-").concat(now.get(Calendar.MINUTE).toString).concat("-").concat(now.get(Calendar.SECOND).toString)
    val fileSystem = FileSystem.get(new URI(s"$inputFilePath$batchId".concat(s"_$currentDate.done")),
      sparkSession.sparkContext.hadoopConfiguration)
    val outputFile = fileSystem.create(new Path(s"$inputFilePath$batchId".concat(s"_$currentDate.done")), true)
    outputFile.writeBytes(jsonObj.toString())
    outputFile.close()
  }


  def cleanseData(
                   customer: Option[String],
                   activityType: String,
                   batchId: String,
                   force: Boolean,
                   folder: String,
                   format: String,
                   dateBatchReceived: String,
                   fileSystemDao: FileSystemDao
                 ) = {

    val rawRecordsFromSource: DataFrame = readRawFiles(force, folder, activityType, format, fileSystemDao)

    val activityTypeCleanser: DataCleanser = DataCleanser(activityType, format, dateBatchReceived)

    // Cleanse Data
    activityTypeCleanser.cleanseData(rawRecordsFromSource, customer, batchId)
  }

  def readRawFiles(
                            force: Boolean,
                            folder: String,
                            activityType: String,
                            format: String,
                            fileSystemDao: FileSystemDao
                          ) = {

    activityType.toUpperCase() match {
      case Constants.EncounterActivityType =>
        val encounterFiles = fileSystemDao.readEncounterFiles(force, folder)
        EncounterNormalizer.normalizeEncounterFiles(encounterFiles)
      case Constants.DoNotSolicitActivityType =>
        fileSystemDao.readDoNotSolicitFile(force, folder)
      case Constants.DonorListActivityType =>
        fileSystemDao.readDonorListFile(force, folder)
      case Constants.EmployeeRosterActivityType =>
        fileSystemDao.readEmployeeRosterFile(force, folder)
      case Constants.MarketingListActivityType =>
        fileSystemDao.readMarketingListFile(force, folder)
      case Constants.ReferralActivityType =>
        fileSystemDao.readReferralFile(force, folder)
      case Constants.HraActivityType =>
        val hraFiles = fileSystemDao.readHRAFile(force, format, folder)
        HraNormalizer.joinAllHraDataFrames(hraFiles, format)
      case Constants.NewMoverActivityType =>
        fileSystemDao.readNewMoverFile(force, folder)
      case Constants.ProspectActivityType =>
        fileSystemDao.readProspectFile(force, folder)
      case Constants.DeceasedActivityType =>
        fileSystemDao.readDeceasedFile(force, folder)
      case Constants.CallCenterActivityType =>
        fileSystemDao.readCallCenterFile(force, format, folder)
      case _ =>
        throw new RuntimeException(s"$format is an invalid format for input files at $folder")
    }
  }

  override def buildConfig(appConfig: Config, lookupsClient: LookupsClient): CleanseJobConfig = {
    CleanseJobConfig(appConfig)
  }

  override def countInputRecords = {
    inputRecordCount
  }

  override def countOutputRecords = {
    outputRecordCount
  }
}