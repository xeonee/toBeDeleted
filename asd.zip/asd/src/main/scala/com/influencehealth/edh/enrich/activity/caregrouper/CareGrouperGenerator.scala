package com.influencehealth.edh.enrich.activity.caregrouper

import com.influencehealth.edh.CustomLazyLogging
import com.influencehealth.edh.model.Activity
import com.influencehealth.edh.utils.PersonUtils
import org.apache.spark.sql.expressions.{UserDefinedFunction, Window}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}

object CareGrouperGenerator extends CustomLazyLogging {

  /**
    * Transform dataframe to generate sg2 input format related columns
    *
    * @param activities
    * @param customer
    * @param batchId
    * @return
    */
  def generateSg2InputFile(
                            activities: Dataset[Activity],
                            customer: String,
                            batchId: String
                          )(implicit sparkSession: SparkSession): Map[String, DataFrame] = {

    import activities.sparkSession.implicits._

    val selectedColumnsForCareGrouper: DataFrame = activities.select(
      $"customer",
      $"batchId",
      $"activityId",
      $"sex",
      $"currentProceduralTerminologyCodes",
      $"diagnosisCodes",
      $"procedureCodes",
      $"medicalSeverityDiagnosisRelatedGroup",
      $"sourcePatientType",
      $"dateOfBirth",
      $"sourceAge",
      $"activityDate"
    ).where($"activityType" === "ENCOUNTER"
      && (size($"diagnosisCodes") > 0 ||
      (size($"currentProceduralTerminologyCodes") > 0 || size($"diagnosisCodes") > 0 || size($"procedureCodes") > 0)))
        .withColumn("age", PersonUtils.compute_age($"dateOfBirth", $"sourceAge", $"activityDate"))
      .drop("dateOfBirth", "sourceAge", "activityDate")

    val personActivitiesWithSg2Columns: DataFrame = selectedColumnsForCareGrouper.
      withColumn("uniqueId", monotonically_increasing_id()).
      withColumn("recordId", row_number().over(Window.orderBy("uniqueId"))).
      drop("uniqueId").
      withColumn("icdVersion", getICDVersion(col("diagnosisCodes"), col("procedureCodes"))).
      withColumn("cpt", getIndividualCodes(1)(col("currentProceduralTerminologyCodes"))).
      withColumnRenamed("sex", "gender").
      withColumnRenamed("medicalSeverityDiagnosisRelatedGroup", "drg").
      withColumnRenamed("batchId", "batch_id").
      withColumnRenamed("activityId", "activity_id")

    var flattenedMedicalCodes = personActivitiesWithSg2Columns
    for(i <- 1 to 15){
      flattenedMedicalCodes = flattenedMedicalCodes.
        withColumn(s"diag$i", getIndividualCodes(i)(col("diagnosisCodes"))).
        withColumn(s"proc$i", getIndividualCodes(i)(col("procedureCodes")))
    }

    val individualICDsDataFrame = flattenedMedicalCodes.where("icdVersion != 'MULTIPLE_ICD'")

    val multipleICDsDataFrame = flattenedMedicalCodes.where("icdVersion = 'MULTIPLE_ICD'").
      withColumn("errorReasons", array(lit("Multiple ICD types (9/10) found for this record")))

    val ungroupableSourcePatientTypeEncounters = individualICDsDataFrame.
      where("sourcePatientType not in ('I', 'Inpatient', 'INPATIENT', 'O', 'Outpatient', 'OUTPATIENT')").
      withColumn("errorReasons",
        array(lit("sourcePatientType not in ('I', 'Inpatient', 'INPATIENT', 'O', 'Outpatient', 'OUTPATIENT')")))

    val inPatientEncountersWithNoProcedureCodes = individualICDsDataFrame.
      where("sourcePatientType in ('I', 'Inpatient', 'INPATIENT')").
      withColumn("errorReasons", array(lit("Inpatient record missing procedure codes")))

    val outPatientEncountersWithNoCptCodes = individualICDsDataFrame.
      where("sourcePatientType in ('O', 'Outpatient', 'OUTPATIENT') AND cpt is null").
      withColumn("errorReasons", array(lit("outPatient record missing cpt code")))


    // Ungroupable records
    val ungroupableRecords = multipleICDsDataFrame.union(ungroupableSourcePatientTypeEncounters).
      union(inPatientEncountersWithNoProcedureCodes).union(outPatientEncountersWithNoCptCodes).
      select("customer", "batch_id", "activity_id", "errorReasons").
      withColumnRenamed("batch_id","batchId").
      withColumnRenamed("activity_id", "activityId")

    val ungroupableActivities = ungroupableRecords.join(activities, Seq("activityId", "customer", "batchId"), "inner")

    val columns: Seq[String] = Seq("customer", "batch_id", "activity_id", "recordId", "age",
      "gender", "drg", "sourcePatientType", "icdVersion", "diag1", "diag2", "diag3", "diag4", "diag5", "diag6",
      "diag7", "diag8", "diag9", "diag10", "diag11", "diag12", "diag13", "diag14", "diag15", "proc1", "proc2",
      "proc3", "proc4", "proc5", "proc6", "proc7", "proc8", "proc9", "proc10", "proc11", "proc12", "proc13",
      "proc14", "proc15", "cpt")


    val inpatients = individualICDsDataFrame.select(columns.map(c => col(c)): _*).
      where("sourcePatientType in ('I', 'Inpatient', 'INPATIENT') AND size(procedureCodes) > 0")

    val outpatients = individualICDsDataFrame.select(columns.map(c => col(c)): _*).
      where("sourcePatientType in ('O', 'Outpatient', 'OUTPATIENT') AND cpt is not null")

    Map("outpatients" -> outpatients, "inpatients" -> inpatients, "ungroupableActivities" -> ungroupableActivities)
  }

  /**
    * Extracts the ICD codes and sorts them based on Priority Number, returning the smallest sequence numbered ICD code
    *
    * @return
    */
  def getICDVersion: UserDefinedFunction = udf((diagnosisCodes: Seq[Row], procedureCodes: Seq[Row]) => {

    val icdCode: List[String] =
      Option(diagnosisCodes).getOrElse(Seq.empty).flatMap(row => {
        Option(row.getAs[String]("medicalCodeType"))
      }).toList ++ Option(procedureCodes).getOrElse(Seq.empty).flatMap(row => {
        Option(row.getAs[String]("medicalCodeType"))
      }).toList

    if (icdCode.isEmpty) {
      None
    } else if (icdCode.distinct.length == 1) {
      Some(icdCode.head)
    } else {
      Some("MULTIPLE_ICD")
    }

  })

  /**
    * Returns extracted ICD codes based on index value to populate per sg2 priority column
    *
    * @param index
    * @return
    */
  def getIndividualCodes(index: Int): UserDefinedFunction = udf((codes: Seq[Row]) => {
    Option(codes).getOrElse(Seq.empty).find { row =>
      row.getAs[Int]("sequenceNumber") == index
    }.map { row =>
      row.getAs[String]("medicalCode")
    }
  })

}
