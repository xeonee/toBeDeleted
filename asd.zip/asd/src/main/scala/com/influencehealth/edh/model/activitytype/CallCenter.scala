package com.influencehealth.edh.model.activitytype

import com.influencehealth.edh.Constants

trait CallCenter extends ActivityType {

  override val defaultMessageType: String = Constants.CallCenterDefaultMessageType
  override val defaultSourceType: String = Constants.CallCenterDefaultSourceType
  override val defaultAddressType: String = Constants.CallCenterDefaultAddressType
  override val defaultActivityType: String = Constants.CallCenterActivityType
  override val defaultPersonType: String = Constants.CallCenterPersonType

}

trait BerylCallCenter extends CallCenter {

  override val formatType: String = Constants.CallCenterBerylFormat
  override val defaultSource: String = Constants.CallCenterBerylDefaultSource

  override val cleanseStringColumnNames: Seq[String] = Seq(
    "lastName",
    "firstName",
    "address1",
    "address2",
    "city",
    "state",
    "zip5",
    "ClientName",
    "isoLanguageCode",
    "nonReferralReasonOther",
    "nonReferralReason",
    "mediaTypeOtherDesc",
    "mediaSourceDesc",
    "mediaTypeDesc",
    "phoneNumber",
    "sourceSex"
  )

  override val nullColumnNames: Seq[String] = Seq(
    "firstName",
    "lastName",
    "zip5",
    "source",
    "sourceRecordId"
  )

  // mandatory column combination for null check
  override val mandatoryContactColumnsNames: Seq[String] = Seq(
    "phoneNumber",
    "address1"
  )

  // zip columns in beryl schema
  override val zipColumnNames: Seq[String] = Seq(
    "zip5"
  )

}


trait ConfierCallCenter extends CallCenter {

  override val formatType: String = Constants.CallCenterConiferFormat
  override val defaultSource: String = Constants.CallCenterConiferDefaultSource

  override val cleanseStringColumnNames: Seq[String] = Seq(
    "lastName",
    "firstName",
    "address1",
    "apt",
    "city",
    "state",
    "zip5",
    "sourceSex",
    "referralType",
    "disposition",
    "incomingLine",
    "howHeard",
    "hospital",
    "emailConsent",
    "appointmentMade",
    "physicianName",
    "insurance",
    "areaOfInterest",
    "reasonForReferral",
    "serviceLine",
    "className",
    "sectionName"
  )


  override val nullColumnNames: Seq[String] = Seq(
    "firstName",
    "lastName",
    "address1",
    "zip5",
    "source",
    "sourceRecordId"
  )

  // mandatory column combination for null check
  override val mandatoryContactColumnsNames: Seq[String] = Seq(
    "emails",
    "phoneNumber",
    "address1"
  )

  // zip columns in conifer schema
  override val zipColumnNames: Seq[String] = Seq(
    "zip5"
  )

}
