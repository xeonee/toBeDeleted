package com.influencehealth.edh.linker

import com.influencehealth.edh.dao.DatabaseDao
import com.influencehealth.edh.model.Person
import com.typesafe.scalalogging.LazyLogging
import org.apache.spark.sql._
import org.apache.spark.storage.StorageLevel
import org.apache.spark.util.LongAccumulator

import scala.util.control.Breaks._

class PersonLinker(
                    val accumulator: LongAccumulator,
                    val databaseDao: DatabaseDao,
                    val customer: String,
                    val uniqueIdColumn: String
                  ) extends EntityLinker[Person] with LazyLogging with Serializable {

  this: EntityDB[Person] =>

  override def linkRecords(inputDF: Dataset[Person]): Dataset[Person] = {

    val transformedDF = transformInput(inputDF)
      .persist(StorageLevel.MEMORY_ONLY_SER)

    val linkedDF = linkingLoop(transformedDF, MAX_ITERATION)

    prepareOutputData(inputDF, linkedDF)

  }

  override def transformInput(inputDF: Dataset[Person]): Dataset[IdentityEntity[Person]] = {

    import inputDF.sparkSession.implicits._

    get(inputDF.map(IdentityEntity[Person]("in_memory_activity", _)))
  }

  override def prepareOutputData(
                                  candidatesForLinkage: => Dataset[Person],
                                  linkedDF: Dataset[IdentityEntity[Person]]
                                ): Dataset[Person] = {

    import linkedDF.sparkSession.implicits._

    linkedDF.map(_.entity)
  }

  private def linkingLoop(
                           inputDF: Dataset[IdentityEntity[Person]],
                           maxIteration: Int
                         ): Dataset[IdentityEntity[Person]] = {

    var intermediateResult: Dataset[IdentityEntity[Person]] = inputDF

    intermediateResult.head()
    breakable {
      for (_ <- 1 to maxIteration) {
        accumulator.reset()
        val currentResult: Dataset[IdentityEntity[Person]] = mergeCandidatesOnBlockingKeys(intermediateResult)
        currentResult.head()

        if (accumulator.value == 0) {
          intermediateResult = currentResult.persist(StorageLevel.MEMORY_ONLY_SER)
          break
        }
        intermediateResult = currentResult.persist(StorageLevel.MEMORY_ONLY_SER)
      }
    }
    intermediateResult
  }

}
