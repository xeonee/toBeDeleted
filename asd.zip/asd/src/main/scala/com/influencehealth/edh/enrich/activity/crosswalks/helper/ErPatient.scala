package com.influencehealth.edh.enrich.activity.crosswalks.helper

case class ErPatient(
  customer: String,
  source: String,
  sourceType: String,
  sourceErPatient: String,
  erPatient: Boolean
) extends Serializable

object ErPatient {

  val Default: String = "default"

  val erPatientCw: Seq[ErPatient] = Seq(
    ErPatient("default", Default, Default, "E", true),
    ErPatient("default", Default, Default, "e", true),
    ErPatient("default", Default, Default, "N", false),
    ErPatient("default", Default, Default, "n", false)
  )

}

case class ErPatientCwCreationException(exc: Throwable)
  extends Exception("Unable to create er patient crosswalk", exc)

case class InvalidErPatientValue(value: String)
  extends Exception(s"The following value does not match any standard er patient value: '$value'")