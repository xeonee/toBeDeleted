package com.influencehealth.edh.enrich.activity.crosswalks.helper

case class ExclusionFlag(
  customer: String,
  source: String,
  sourceType: String,
  sourceExclusionFlag: String,
  exclusionFlag: Int
) extends Serializable

object ExclusionFlag {
  val exclusionFlagCw: Seq[ExclusionFlag] = Seq(
    ExclusionFlag("default", "default", "default", "1", 1),
    ExclusionFlag("default", "default", "default", "2", 2),
    ExclusionFlag("default", "default", "default", "3", 3),
    ExclusionFlag("default", "default", "default", "4", 4)
  )
}

case class ExclusionFlagCwCreationException(exc: Throwable)
  extends Exception("Unable to create exclusion flag crosswalk", exc)

case class InvalidExclusionFlagValue(value: Int)
  extends Exception(s"The following value does not match any standard exclusion flag value: '$value'")