package com.influencehealth.edh.model.crosswalk

case class ActivityType(
  customer: String,
  source: String,
  sourceType: String,
  sourceActivityType: String,
  activityType: String
) extends Serializable

object ActivityType {

  val activityTypeCw: Seq[ActivityType] = Seq(
    ActivityType("default", "lvm", "call center", "CLASS", "class"),
    ActivityType("default", "lvm", "call center", "LIT", "literature"),
    ActivityType("default", "lvm", "call center", "MEMBR", "membership"),
    ActivityType("default", "lvm", "call center", "PHY", "physician referral"),
    ActivityType("default", "lvm", "call center", "SERV", "service")
  )
  
}

case class ActivityTypeCwCreationException(exc: Throwable)
  extends Exception("Unable to create activity type crosswalk", exc)

case class ActivityTypeLookupException(activityType: String)
  extends Exception(s"ActivityType in activity_type crosswalk not recognized: $activityType")