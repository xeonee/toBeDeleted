package com.influencehealth.edh.cleanse

import com.influencehealth.edh.model.activitytype.ActivityType
import com.influencehealth.edh.utils.{CleanseUtils, PersonUtils}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._

class ReferralCleanser(val dateBatchReceived: String) extends DataCleanser {

  this: ActivityType =>


  override def cleanseData(
                            df: DataFrame,
                            customer: Option[String],
                            batchId: String
                          ): (DataFrame, DataFrame) = {

    // Apply default values for Required Columns if found NULL
    val defaultCodeForRequiredColumnsContainingNulls = assignDefaultValuesForRequiredColumnsContainingNulls(df).
      withColumn("sourceRecordId", get_source_record_id(col("ccCallNo"), col("seqNo")))

    // filters required columns that are not null
    val (dataFrameContainingNonNullColumns, dataFrameContainingNullColumns) =
      filterRequiredColumnsContainingInvalidValues(defaultCodeForRequiredColumnsContainingNulls, nullColumnNames,
        mandatoryContactColumnsNames)

    // cleanses & filters Date column
    val dataFrameContainingValidDateColumns = formatDateColumns(dataFrameContainingNonNullColumns)

    // Cleanses String Column
    val dataFrameContainingCleansedStringColumns = cleanseStringColumns(dataFrameContainingValidDateColumns, cleanseStringColumnNames)

    // Cleanses Contact details: Phone numbers and emails
    val dataFrameContainingCleansedContactDetails = cleanseContactDetails(dataFrameContainingCleansedStringColumns)

    // Cleanse zip5 column
    val cleansedZips = cleanseZips(dataFrameContainingCleansedContactDetails, zipColumnNames)

    // alias data
    val cleanDf = aliasData(cleansedZips, customer)

    (cleanDf, dataFrameContainingNullColumns)

  }

  override def formatDateColumns(df: DataFrame): DataFrame = {
    // Convert string date into Date type columns after validating the dates, known behavior
    val formattedDatesDataFrame = df
      .withColumn("dateOfBirth", CleanseUtils.timestamp_to_date(PersonUtils.validateInputDate(
        date_format(unix_timestamp(df("dateOfBirth"), "MM/dd/yyyy").cast("timestamp"), "yyyy-MM-dd"))))

    formattedDatesDataFrame
  }

  override def cleanseStringColumns(df: DataFrame, stringColumnsToBeCleansed: Seq[String]): DataFrame = {
    stringColumnsToBeCleansed.foldLeft(df)((curr, n) => curr.withColumn(n, CleanseUtils.cleanseStringColumns(curr(n))))
  }

  /** coding values for columns (exclusion flag, patient type, er patients) that require have null values
    *
    * @param df
    * @return dataFrame
    * */
  override def assignDefaultValuesForRequiredColumnsContainingNulls(df: DataFrame): DataFrame = {

    df.
      withColumn("sourceRecordId", concat(col("ccCallNo"), col("seqNo"))).
      withColumn("source", lit(defaultSource)).
      withColumn("sourceType", lit(defaultSourceType)).
      withColumn("addressType", lit(defaultAddressType))
  }


  override def aliasData(df: DataFrame, customer: Option[String]): DataFrame = {
    super.aliasData(df, customer).
      withColumn("activityType", lit(defaultActivityType)).
      withColumn("activityDate", lit(CleanseUtils.parseStringToDate(dateBatchReceived))).
      withColumn("sourcePersonId", df("ccPersonNo")).
      withColumn("middleName", df("mi")).
      withColumn("doNotSolicit", df("noMailFlag")).
      withColumn("activityLocationId", df("ccFacNo")).
      withColumn("activityLocation", df("facName")).
      withColumn("reason", df("apptNotMadeReason")).
      withColumn("activityGroup", df("svcName")).
      withColumn("activityGroupId", df("ccSvcNo"))
  }

  /** Validates the email and phone number columns
    *
    * @param df
    * @return formated coloumn
    * */
  private def cleanseContactDetails(df: DataFrame): DataFrame = {
    df
      .withColumn("emails", getStringToArray(CleanseUtils.cleanseAndValidateEmail(df("emailAddress"))))
      .withColumn("phoneNumbers", getStringToArray(concat(df("homeArea"), df("homePrefix"), df("homeSuffix"))))
  }

  /** Cleanse zip values
    *
    * @param df
    * @return
    */
  private def cleanseZips(df: DataFrame, zipColumns: Seq[String]): DataFrame = {
    zipColumns.foldLeft(df)((curr, n) => curr.withColumn(n, CleanseUtils.get_zip5(curr(n))))
  }

  // e.g. (123) 456-7890
  val getPhoneNumber = udf((areaCode: String, prefix: String, suffix: String) => {
    s"($areaCode) $prefix-$suffix"
  })

  /**
    * Concatinate callNumber and seqNumber
    *
    * @return
    */
  val get_source_record_id: UserDefinedFunction = udf((callNo: String, seqNo: String) => {
    callNo.concat(seqNo)
  })

}
