package com.influencehealth.edh.model

import java.sql.Timestamp

import org.apache.spark.sql.{Column, DataFrame, Row}

import scala.util.Try

case class DoNotSolicitEmail(
                             customer: String,
                             source: Option[String] = None,
                             dateCreated: Timestamp,
                             dateModified: Option[Timestamp],
                             email: String,
                             reason: Option[String] = None,
                             batchId: String
                             )

object DoNotSolicitEmail{

  def buildDoNotSolicitEmailsFromRow(row: Row): DoNotSolicitEmail = {
    DoNotSolicitEmail(
      customer = row.getAs[String]("customer"),
      source = cleanseRowField[String](row, "source"),
      email = row.getAs[String]( "email"),
      dateCreated = row.getAs[Timestamp]("dateCreated"),
      dateModified = cleanseRowField[Timestamp](row, "dateModified"),
      reason = cleanseRowField[String](row, "reason"),
      batchId = row.getAs[String]("batchId"))
  }

  def cleanseRowField[T](row: Row, fieldName: String): Option[T] = {
    Try(row.getAs[T](fieldName)).toOption.flatMap(Option(_))
  }

}

