//package com.influencehealth.edh.cleanse.epdblists
//
//import com.influencehealth.edh.BaldurJob
//import com.influencehealth.edh.config.BaldurAppConfig
//import com.influencehealth.edh.dao.DataWarehouseDao
//import com.influencehealth.edh.dao.redshift.RedshiftDataWarehouseDao
//import com.influencehealth.edh.utils.SparkOptimizer
//import mojolly.inflector.Inflector
//import org.apache.spark.sql.functions._
//import org.apache.spark.sql.{DataFrame, SparkSession}
//
//object ExtractEPDBListsApp extends BaldurJob with BaldurAppConfig {
//
//  val JoinColumns: Seq[String] = Seq(
//    "list_id", "person_id", "person_record_id", "customer_id", "customer_key", "customer_list_person_id")
//
//  def main(args: Array[String]): Unit = {
//
//    val listName: String = appConfig.getString("app.extract.list-name")
//
//    logger.info(s"Extracting List: $listName")
//
//    val sparkSession = SparkSession.builder().getOrCreate()
//
//    val s3Bucket: String = appConfig.getString("s3.datalake.bucket")
//
//    val customer: String = customerKey
//
//    val dataWarehouseDao: DataWarehouseDao = new RedshiftDataWarehouseDao(appConfig, sparkSession)
//
//    extractEPDBListData(dataWarehouseDao, s3Bucket, customer, listName)
//
//  }
//
//  def extractEPDBListData(
//                           dataWarehouseDao: DataWarehouseDao,
//                           s3Bucket: String,
//                           customer: String,
//                           listName: String): DataFrame = {
//
//    val (listPersons, listPersonEmails, listPersonPhoneNumbers) =
//      retrieveEPDBListData(dataWarehouseDao: DataWarehouseDao, listName: String)
//
//    val aggregatedData = denormalizeEPDBListData(
//      listPersons,
//      listPersonEmails,
//      listPersonPhoneNumbers)
//
//    persistEPDBListDataToS3(s3Bucket, customer, listName, aggregatedData)
//
//    aggregatedData
//
//  }
//
//  def retrieveEPDBListData(dataWarehouseDao: DataWarehouseDao, listName: String): (DataFrame, DataFrame, DataFrame) = {
//
//    dataWarehouseDao.validateEpdbListIsUnique(listName)
//
//    val listPersons: DataFrame = dataWarehouseDao.getPersonSnapshotData(listName)
//
//    val listPersonEmails: DataFrame = dataWarehouseDao.getPersonSnapshotEmailData(listName)
//
//    val listPersonPhoneNumbers: DataFrame = dataWarehouseDao.getPersonSnapshotPhoneData(listName)
//
//    (listPersons, listPersonEmails, listPersonPhoneNumbers)
//  }
//
//  def denormalizeEPDBListData(
//                               listPersons: DataFrame,
//                               listPersonEmails: DataFrame,
//                               listPersonPhoneNumbers: DataFrame): DataFrame = {
//    listPersons.
//      join(listPersonEmails, JoinColumns, "left_outer").
//      join(listPersonPhoneNumbers, JoinColumns, "left_outer").
//      groupBy(listPersons.columns.map(col): _*).
//      agg(
//        collect_list("phone_number") as "phone_numbers",
//        collect_list("email") as "emails")
//  }
//
//  def persistEPDBListDataToS3(s3Bucket: String, customer: String, listName: String, snapshotData: DataFrame): Unit = {
//    val kebabCaseListName: String = Inflector.dasherize(listName.trim)
//
//    val outputCleansedS3Path = s"$s3Bucket/$customer/epdb-list/$kebabCaseListName"
//
//    val csvOutputPath = s"$outputCleansedS3Path.csv"
//
//    logger.info(s"Writing CSV file to $csvOutputPath")
//
//    // Forcing spark to load the data into memory before switching credentials to write to a different bucket
//    snapshotData.persist()
//
//    val maxParquetPartitions : Int = appConfig.getInt("app.maxParquetPartitions")
//
//    SparkOptimizer.repartitionDataFrames(snapshotData, maxParquetPartitions, executorCores)
//
//    s3Config.configureS3(snapshotData.sparkSession.sparkContext.hadoopConfiguration)
//
//    snapshotData.
//      withColumn("emails", to_json(struct("emails"))).
//      withColumn("phone_numbers", to_json(struct("phone_numbers"))).
//      write.mode("overwrite").csv(csvOutputPath)
//
//    val parquetOutputPath = s"$outputCleansedS3Path.parquet"
//
//    logger.info(s"Writing Parquet file to $parquetOutputPath")
//
//    snapshotData.write.mode("overwrite").parquet(parquetOutputPath)
//  }
//
//}
