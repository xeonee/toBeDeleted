package com.influencehealth.edh

import java.sql.Timestamp
import java.time.{Duration, LocalDate}

import com.amazonaws.auth.{AWSCredentials, BasicAWSCredentials}
import com.amazonaws.services.s3.{AmazonS3, AmazonS3Client}
import com.github.seratch.jslack.Slack
import com.github.seratch.jslack.api.methods.request.channels.ChannelsListRequest
import com.github.seratch.jslack.api.methods.request.chat.ChatPostMessageRequest
import com.influencehealth.edh.aws.s3.S3Config
import com.influencehealth.edh.config._
import com.influencehealth.edh.dao.{DatabaseDao, PostgresDatabaseDao}
import com.influencehealth.edh.lookups.client.{AmqpLookupsClient, LookupsClient}
import com.influencehealth.edh.model.{Activity, JobHistory, Person}
import com.influencehealth.edh.utils.DataLakeUtilities
import com.typesafe.config.Config
import com.typesafe.scalalogging.LazyLogging
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession

import scala.collection.JavaConverters._
import scala.util.Try

sealed trait JobStatus

object SuccessfulBaldurJob extends JobStatus {
  override def toString: String = Constants.JobCompletedMessage
}

object FailedBaldurJob extends JobStatus {
  override def toString: String = Constants.JobFailureMessage
}

abstract class BaldurApplication[T <: JobConfig] extends App with LazyLogging {

  logger.info("Start pipeline")
  protected val currentDateTimeStarted = new Timestamp(System.currentTimeMillis)
  protected val currentLocalDate: LocalDate = LocalDate.now()

  protected val sparkConf: SparkConf = buildSparkConfig()

  implicit val sparkSession: SparkSession = SparkSession.builder()
    .config(sparkConf)
    .getOrCreate()

  /** The implicit typesafe configuration object to be used throughout this spark job */
  protected implicit val appConfig: Config = ConfigLoader.appConfig

  /**
    * Loading in standard application config used across all apps
    */
  protected val accessKey: String = appConfig.getString("aws-accesskey")
  protected val secretKey: String = appConfig.getString("aws-secretkey")
  protected val bucketUrl: String = appConfig.getString("s3.datalake.bucket")
  protected val jobType = appConfig.getString("app.main.command")
  protected val subJobType: String = appConfig.getString("app.sub.command")
  protected val jobUser: String = appConfig.getString("app.current.user")
  protected val jobProfile: String = appConfig.getString("app.load.profile")
  protected val environment: String = appConfig.getString("app.load.environment")
  protected val jobCommand: String = appConfig.getString("app.job.full.command")

  protected var inputJobRecords:Option[Long] = None
  protected var outputJobRecords:Option[Long] = None
  protected var jobStatus: JobStatus = SuccessfulBaldurJob
  /**
    * Configuring application access to AWS S3 Buckets
    */
  S3Config(accessKey, secretKey).configureS3(sparkSession.sparkContext.hadoopConfiguration)

  /**
    * Instantiating S3Client for use in validating file locations in cleanse and load jobs
    */
  protected lazy val s3client: AmazonS3 = initS3Client(appConfig)


  private val databaseConfig: DatabaseConfig = PostgresConfig(appConfig)

  private val databaseDao: DatabaseDao = new PostgresDatabaseDao(databaseConfig)

  val lookupsClient: LookupsClient = AmqpLookupsClient(appConfig)

  val config: T = buildConfig(appConfig, lookupsClient)

  val jobConfig = config.asInstanceOf[JobConfig]

  try {

    runJob(sparkSession, config, databaseDao)
    inputJobRecords = countInputRecords
    outputJobRecords = countOutputRecords

  } catch {
    case e: Exception =>

      // update jobStatus as failed job.
      jobStatus = FailedBaldurJob
      throw new Exception(s"Job $jobType-$subJobType failed to complete", e)

  } finally {
    saveJobResult(sparkSession, databaseDao, currentDateTimeStarted, jobConfig)
  }

  /**
    *
    */

  def buildSparkConfig(): SparkConf = {
    val conf = new SparkConf()
    conf.set("mapreduce.input.fileinputformat.input.dir.recursive", "true")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")

    conf.registerKryoClasses(
      Array(
        classOf[Activity],
        classOf[Person]
      )
    )
  }

  /**
    * Method run after config validation. Provides access to the sparkSession to create spark jobs and
    * pipelines
    *
    * @param sparkSession
    * @param config
    * @param databaseDao
    * @return
    */
  def runJob(implicit sparkSession: SparkSession, config: T, databaseDao: DatabaseDao)

  def buildConfig(appConfig: Config, lookupsClient: LookupsClient): T

  def countInputRecords: Option[Long]

  def countOutputRecords: Option[Long]

  private def initS3Client(config: Config) = {
    // TODO refactor this out so it uses environment or user level AWS profiles
    val credentials: AWSCredentials = new BasicAWSCredentials(accessKey, secretKey)
    new AmazonS3Client(credentials)
  }

  /**
    * writes the spark job metadata to jobHistory table
    *
    * @param sparkSession
    * @param databaseDao
    * @param timeStarted
    * @param jobConfig
    * @return
    */
  def saveJobResult(
                     sparkSession: SparkSession,
                     databaseDao: DatabaseDao,
                     timeStarted: Timestamp,
                     jobConfig: JobConfig
                   ) = {


    val (customer: String, batchId: Option[String], activityType: Option[String], user: String,
    inputFile: Option[String], sinceDate: Option[LocalDate]) = jobConfig match {

      case cleanseJobConfig: CleanseJobConfig => (cleanseJobConfig.customer.get, cleanseJobConfig.batchId,
        Some(cleanseJobConfig.activityType), cleanseJobConfig.user, cleanseJobConfig.inputFilePath,
        cleanseJobConfig.sinceDate)

      case enrichJobConfig:EnrichJobConfig => (enrichJobConfig.customer, enrichJobConfig.batchId,
        enrichJobConfig.activityType, enrichJobConfig.user, enrichJobConfig.inputFilePath, None)

      case checkHealthConfig:CheckHealthConfig => (checkHealthConfig.customer, None,
        None, checkHealthConfig.user, None, None)

      case dataScienceConfig:DataScienceConfig => (dataScienceConfig.customer, None,
        None, dataScienceConfig.user, None, None)

      case loadJobConfig:LoadJobConfig => (loadJobConfig.customer, Some(loadJobConfig.batchId),
        Some(loadJobConfig.activityType), loadJobConfig.user, None, None)

      case refreshJobConfig:RefreshJobConfig => (refreshJobConfig.customer, refreshJobConfig.batchId,
        None, refreshJobConfig.user, None, refreshJobConfig.sinceDate)

      case demoJobConfig:DemoJobConfig => (demoJobConfig.customer, None,
        None, demoJobConfig.user, None, None)

      case checkLoadConfig:CheckLoadConfig => (checkLoadConfig.customer, Some(checkLoadConfig.batchId),
        None, checkLoadConfig.user, None, None)
    }

    val inputActivityType = jobType match {
      case "load" => {
        if(subJobType == "personpipeline" && jobCommand.contains("--full")){
          Option(subJobType)
        }
        else
        {
          Some(DataLakeUtilities.extractActivityTypeFromBatchId(batchId.get))
        }
      }
      case _ => activityType
    }

    val jobHistory: JobHistory = JobHistory(
      customer,
      inputActivityType,
      batchId,
      Try{java.sql.Date.valueOf(sinceDate.get)}.toOption,
      jobType,
      jobCommand,
      inputFile,
      timeStarted,
      new Timestamp(System.currentTimeMillis),
      user,
      inputJobRecords,
      outputJobRecords,
      jobStatus.toString
    )

    import sparkSession.implicits._
    databaseDao.saveJobHistory(Seq(jobHistory).toDS)

    logger.info(s"Saved $jobType-$subJobType job metadata to jobHistory table.")
  }

  def sendJobResultsToSlack(
                             jobType: String,
                             jobSubType: String,
                             customer: String,
                             user: String,
                             totalExecutionTime: Duration,
                             jobStatus: JobStatus
                           ) = {

    val slackToken = appConfig.getString("app.slack-token")
    val jobsStatsChannel = appConfig.getString("app.job-stats-channel")

    val slack = Slack.getInstance

    val channelsResponse = slack.methods.channelsList(ChannelsListRequest.builder.token(slackToken).build)
    require(channelsResponse.isOk)

    val general = channelsResponse.getChannels.asScala.
      find(c => c.getName == jobsStatsChannel).
      get

    val postResponse = slack.methods.chatPostMessage(
      ChatPostMessageRequest.builder.
        token(slackToken).
        channel(general.getId).
        text("Hello World!").
        build)

    require(postResponse.isOk)
  }


}

