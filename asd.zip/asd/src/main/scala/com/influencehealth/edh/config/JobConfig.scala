package com.influencehealth.edh.config


import java.time.LocalDate
import java.time.format.DateTimeFormatterBuilder
import java.time.temporal.ChronoField

import com.influencehealth.edh.Constants
import com.influencehealth.edh.config.CleanseJobConfig.{getActivityType, getBatchFormat}
import com.influencehealth.edh.lookup_clients.support.ServiceArea
import com.influencehealth.edh.lookups.client.{AmqpLookupsClient, LookupsClient}
import com.influencehealth.edh.lookups.messages.{Customer, Location}
import com.influencehealth.edh.utils.DataLakeUtilities
import com.typesafe.config.Config

import scala.collection.JavaConverters._
import scala.language.higherKinds
import scala.reflect.runtime.universe._

sealed trait JobConfig

class JobConfigFactory[T <: JobConfig](f: (Config, LookupsClient) => T) {
  def buildConfig(appConfig: Config, lookupsClient: LookupsClient): T = f(appConfig, lookupsClient)
}

object JobConfigFactory {


  implicit val LoadJobConfigFactory: JobConfigFactory[LoadJobConfig] = new JobConfigFactory[LoadJobConfig](
    (appConfig: Config, _: LookupsClient) => LoadJobConfig(appConfig, "", "")
  )

  implicit val RefreshJobConfigFactory: JobConfigFactory[RefreshJobConfig] = new JobConfigFactory[RefreshJobConfig](
    (appConfig: Config, _: LookupsClient) => {
      RefreshJobConfig(appConfig)
    }
  )

  implicit val CheckHealthConfigFactory: JobConfigFactory[CheckHealthConfig] = new JobConfigFactory[CheckHealthConfig](
    (appConfig: Config, _: LookupsClient) => {
      CheckHealthConfig(appConfig)
    }
  )

  implicit val CheckLoadConfigFactory: JobConfigFactory[CheckLoadConfig] = new JobConfigFactory[CheckLoadConfig](
    (appConfig: Config, _: LookupsClient) => {
      CheckLoadConfig(appConfig)
    }
  )

  implicit val DataSciencePipelineConfigFactory: JobConfigFactory[DataScienceConfig] =
    new JobConfigFactory[DataScienceConfig](
      (appConfig: Config, _: LookupsClient) => {
        DataScienceConfig(appConfig)
      }
    )

  implicit val DemoJobConfigFactory: JobConfigFactory[DemoJobConfig] = new JobConfigFactory[DemoJobConfig](
    (appConfig: Config, _: LookupsClient) => {
      DemoJobConfig(appConfig)
    }
  )


}

object JobConfigHelper {
  def optConfig[T: TypeTag](appConfig: Config, path: String): Option[T] = {
    if (appConfig.hasPath(path)) {
      path match {
        case _ if typeOf[T] <:< typeOf[String] =>
          Some(appConfig.getString(path)).asInstanceOf[Option[T]]

        case _ if typeOf[T] =:= typeOf[Double] =>
          Some(appConfig.getDouble(path)).asInstanceOf[Option[T]]

        case _ if typeOf[T] =:= typeOf[Int] =>
          Some(appConfig.getInt(path)).asInstanceOf[Option[T]]
        case _ if typeOf[T] =:= typeOf[LocalDate] =>
          val dateTimeFormatter = new DateTimeFormatterBuilder().
          appendPattern("yyyy-M[-d]").
          parseDefaulting(ChronoField.DAY_OF_MONTH, 1).
          toFormatter()
          val date = LocalDate.parse(appConfig.getString(path), dateTimeFormatter)
          Some(date).asInstanceOf[Option[T]]
        case _ if typeOf[T] =:= typeOf[Boolean] =>
          Some(appConfig.getBoolean(path)).asInstanceOf[Option[T]]
        case _ =>
          throw new RuntimeException("Can not map to requested type")
      }
    } else {
      None
    }
  }

  def deriveBatchId(
                     subJobType: String,
                     customer: String,
                     activityType: String,
                     inputFilePath: Option[String],
                     batchFormat: Option[String],
                     batchMonth: Option[Int]
                   ): String = {
    subJobType match {

      case _ if inputFilePath.nonEmpty =>
        DataLakeUtilities.buildBatchIdFromS3Url(customer, activityType, inputFilePath.get)
      case "activitypipeline" | "activities" if batchFormat.nonEmpty =>
        val now = LocalDate.now()
        val month = batchMonth.getOrElse(now.getMonthValue)
        f"$customer-$activityType-${batchFormat.get}-${now.getYear}-$month%02d".toLowerCase()
      case "encounter" | "callcenter" if batchFormat.nonEmpty =>
        val now = LocalDate.now()
        val month = batchMonth.getOrElse(now.getMonthValue)
        f"$customer-$subJobType-${batchFormat.get}-${now.getYear}-$month%02d".toLowerCase()
      case _ => throw new RuntimeException(s"Job sub command, $subJobType, doesn't match.")
    }
  }
}

case class CleanseJobConfig(
                             customer: Option[String],
                             source: String,
                             jobType: String,
                             subJobType: String,
                             activityType: String,
                             batchId: Option[String],
                             batchMonth: Option[Int],
                             batchDays: Option[Int],
                             batchFormat: String,
                             sinceDate: Option[LocalDate],
                             bucketUrl: String,
                             inputFilePath: Option[String],
                             maxParquetPartitions: Int,
                             executorCores: Int,
                             maxAllowedLocationsMismatchCount: Int,
                             failOnError: Boolean,
                             isCleansePartitionOptimization: Boolean,
                             force: Boolean,
                             user: String,
                             profile: String,
                             environment: String
                           ) extends JobConfig

object CleanseJobConfig {

  def apply(appConfig: Config): CleanseJobConfig = {

    val customer: Option[String] = JobConfigHelper.optConfig[String](appConfig, "app.customer")

    val bucketUrl: String = appConfig.getString("s3.datalake.bucket")

    val jobType = appConfig.getString("app.main.command")

    val subJobType: String = appConfig.getString("app.sub.command")

    val inputFilePath: Option[String] = JobConfigHelper.optConfig(appConfig, "app.load.file-path")

    val batchId: Option[String] = JobConfigHelper.optConfig[String](appConfig, "app.batch-id")

    val batchMonth: Option[Int] = JobConfigHelper.optConfig[Int](appConfig, "app.load.input-months")

    val batchFormat: Option[String] = JobConfigHelper.optConfig[String](appConfig, "app.load.input-format")

    val batchDays: Option[Int] = JobConfigHelper.optConfig[Int](appConfig, "app.load.input-days")

    val sinceDate: Option[LocalDate] = JobConfigHelper.optConfig[LocalDate](appConfig, "app.load.since-date")

    val inputActivityType: Option[String] = JobConfigHelper.optConfig[String](appConfig, "app.load.input-activity-type")

    validateCleanseConfig(
      jobType,
      Some(subJobType),
      inputActivityType,
      inputFilePath,
      batchId,
      batchMonth,
      batchFormat,
      batchDays,
      sinceDate
    )

    val activityType: String = inputActivityType.getOrElse(getActivityType(
      jobType, subJobType, inputFilePath, batchId, batchMonth, batchDays, batchFormat))

    val source: String = DataLakeUtilities.getSourceFromActivityType(activityType, customer.get)

    val finalBatchFormat: String = batchFormat.getOrElse(getBatchFormat(batchId, inputFilePath))

    val finalSinceDate: Option[LocalDate] = getFinalSinceDate(sinceDate, batchMonth, batchDays)

    val user: String = appConfig.getString("app.current.user")
    val profile: String = appConfig.getString("app.load.profile")
    val environment: String = appConfig.getString("app.load.environment")

    new CleanseJobConfig(
      customer = customer,
      source = source,
      jobType = jobType,
      subJobType = subJobType,
      activityType = activityType,
      batchId = batchId,
      batchMonth = batchMonth,
      batchDays = batchDays,
      sinceDate = finalSinceDate,
      batchFormat = finalBatchFormat,
      bucketUrl = bucketUrl,
      inputFilePath = inputFilePath,
      maxParquetPartitions = appConfig.getInt("app.maxParquetPartitions"),
      executorCores = appConfig.getInt("app.executor-cores"),
      maxAllowedLocationsMismatchCount = appConfig.getInt("app.maxAllowedLocationsMismatchCount"),
      failOnError = appConfig.getBoolean("app.validation.failOnError"),
      isCleansePartitionOptimization = appConfig.getBoolean("app.cleanse.partitionOptimization.enabled"),
      force = JobConfigHelper.optConfig[Boolean](appConfig, "app.cleanse.force").getOrElse(false),
      user = user,
      profile = profile,
      environment = environment
    )
  }

  def getFinalSinceDate(sinceDate: Option[LocalDate], batchMonth: Option[Int],
                        batchDays: Option[Int]): Option[LocalDate] = {

    if (sinceDate.nonEmpty) {
      Some(sinceDate.get)
    }
    else if (batchMonth.nonEmpty) {
      Some(LocalDate.now.minusMonths(batchMonth.get))
    }
    else if (batchDays.nonEmpty) {
      Some(LocalDate.now.minusDays(batchDays.get))
    }
    else None
  }

  def validateCleanseConfig(
                             jobType: String,
                             subJobType: Option[String],
                             inputActivityType: Option[String],
                             inputFilePath: Option[String],
                             batchId: Option[String],
                             batchMonth: Option[Int],
                             batchFormat: Option[String],
                             batchDays: Option[Int],
                             sinceDate: Option[LocalDate]
                           ): Unit = {

    if (jobType == "cleanse" && inputFilePath.isEmpty && batchId.isEmpty && batchFormat.isEmpty) {
      throw new RuntimeException("Please provide input file path OR batch-id OR format")
    }

    if (jobType == "load" && inputFilePath.isEmpty && batchId.isEmpty && (inputActivityType.isEmpty
      || batchFormat.isEmpty)) {
      throw new RuntimeException("Please provide activity type and format")
    } else if (jobType == "cleanse" && batchDays.nonEmpty) {
      throw new UnsupportedOperationException("Days option is currently not supported for cleanse jobs.")
    }
    // Does not require activity type at all
    else if (jobType == "cleanse") {
      if (batchId.nonEmpty) {
        if (inputFilePath.isEmpty && batchFormat.isEmpty && batchDays.isEmpty &&
          batchMonth.isEmpty && sinceDate.isEmpty && inputActivityType.isEmpty) {
          if (!DataLakeUtilities.validateBatchId(batchId.get)) {
            throw new RuntimeException("Incorrect format for batch Id. " +
              "Required: <source>-<activity-type>-<format>-<batch>")
          }
        } else {
          throw new Exception(
            "Batch id can't be combined with Options(input-file path, " +
              "format, days, months, since date & activity type)")
        }
      } else if (inputFilePath.nonEmpty) {
        if (batchId.isEmpty && batchFormat.isEmpty && batchDays.isEmpty &&
          batchMonth.isEmpty && sinceDate.isEmpty && inputActivityType.isEmpty) {
          if (!DataLakeUtilities.validateRawS3ObjectKeys(inputFilePath.get)) {
            // TODO: Turn this back on
            //            throw new RuntimeException(s"Incorrect format for Input file path. Received ${inputFilePath.get}. " +
            //              s"Required: s3a://<bucket-name>/<source>/raw/<activity-type>/<format>/<batch>/")
          }
        } else {
          throw new Exception("Input file path can't be combined with " +
            "Options(format, days, months, since date & activity type)")
        }
      } else if (batchFormat.nonEmpty && sinceDate.nonEmpty) {
        if (batchId.isEmpty && inputFilePath.isEmpty && batchMonth.isEmpty &&
          batchDays.isEmpty && inputActivityType.isEmpty) {
        } else {
          throw new Exception("Since date with format can't be combined with Options(days, months & activity type)")
        }
      } else if (batchFormat.nonEmpty && batchMonth.nonEmpty) {
        if (batchId.isEmpty && inputFilePath.isEmpty && sinceDate.isEmpty &&
          batchDays.isEmpty && inputActivityType.isEmpty) {
        } else {
          throw new Exception("Months with format can't be combined with Options(days & activity type)")
        }
      } else if (batchFormat.nonEmpty && batchDays.nonEmpty) {
        throw new Exception("Days option is currently not supported for cleanse jobs.")
      } else if (batchFormat.nonEmpty) {
        if (batchId.isEmpty && inputFilePath.isEmpty && batchMonth.isEmpty
          && sinceDate.isEmpty && inputActivityType.isEmpty
          && batchDays.isEmpty) {
        } else {
          throw new Exception("Format can't be combined with Options(activity type)")
        }
      } else throw new Exception("Unsupported option combinations. Please provide <input-file> OR <batch-id> OR " +
        "<days & format> OR <months & format> OR <sinceDate & format> OR <format>")
    } else if (subJobType.contains("activities") ||
      subJobType.contains("activitypipeline") ||
      subJobType.contains("personpipeline") ||
      subJobType.contains("allpipelines")) {

      if (batchId.nonEmpty) {
        if (inputFilePath.nonEmpty && batchFormat.isEmpty && batchDays.isEmpty && batchMonth.isEmpty &&
          sinceDate.isEmpty && inputActivityType.isEmpty) {
          if (!DataLakeUtilities.validateBatchId(batchId.get)) {
            throw new RuntimeException("Incorrect format for batch Id. " +
              "Required: <source>-<activity-type>-<format>-<batch>")
          }
        } else {
          throw new Exception("Batch id can't be combined with " +
            "Options(input-file path, format, days, months, since date & activity type)")
        }
      } else if (inputFilePath.nonEmpty) {
        if (!subJobType.contains("personpipeline")) {
          if (batchId.isEmpty && batchFormat.isEmpty && batchDays.isEmpty &&
            batchMonth.isEmpty && sinceDate.isEmpty && inputActivityType.isEmpty) {
            if (!DataLakeUtilities.validateCleansedS3ObjectKeys(inputFilePath.get)) {
              throw new RuntimeException("Incorrect format for Input file path. " +
                "Required: s3a://<bucket-name>/<source>/cleansed/<activity-type>/<format>/<batch>.parquet/")
            }
          } else {
            throw new Exception("Input file path can't be combined with " +
              "Options(format, days, months, since date & activity type)")
          }
        } else {
          throw new Exception("Input file path is not an available option for Person Pipeline.")
        }
      } else if (batchFormat.nonEmpty && sinceDate.nonEmpty && inputActivityType.nonEmpty) {
        if (batchId.isEmpty && inputFilePath.nonEmpty && batchMonth.isEmpty && batchDays.isEmpty) {

        } else {
          throw new Exception("Since date with format and activity type can't be combined with Options(days & months)")
        }
      } else if (batchFormat.nonEmpty && batchMonth.nonEmpty && inputActivityType.nonEmpty) {
        if (batchId.isEmpty && inputFilePath.nonEmpty && sinceDate.isEmpty && batchDays.isEmpty) {
        } else throw new Exception("Months with format and activity type can't be combined with Options(days)")
      } else if (batchFormat.nonEmpty && batchDays.nonEmpty && inputActivityType.nonEmpty) {
      }
      else if (batchFormat.nonEmpty && inputActivityType.nonEmpty) {
      } else throw new Exception("Unsupported option combinations. Please provide <input-file> OR <batch-id> OR " +
        "<days & format & activity-type> OR <months & format & activity-type> OR " +
        "<sinceDate & format & activity-type> OR <format & activity-type>")
    } else {
      throw new RuntimeException("EDH command invalid.")
    }
  }

  def getActivityType(
                       jobType: String,
                       subJobType: String,
                       inputFilePath: Option[String],
                       batchId: Option[String],
                       batchMonth: Option[Int],
                       batchDays: Option[Int],
                       batchFormat: Option[String]
                     ): String = {
    if (inputFilePath.nonEmpty) {
      DataLakeUtilities.extractActivityTypeFromS3Url(inputFilePath.get)
    } else if (batchId.nonEmpty) {
      DataLakeUtilities.extractActivityTypeFromBatchId(batchId.get)
    } else if ((batchMonth.nonEmpty || batchFormat.nonEmpty) && jobType == "cleanse") {
      subJobType.trim
    } else {
      throw new RuntimeException("Unable to derive activity type")
    }
  }

  def getBatchFormat(batchId: Option[String], inputFilePath: Option[String]): String = {
    if (batchId.nonEmpty) {
      DataLakeUtilities.extractBatchDateFromBatchId(batchId.get)
    }
    else if (inputFilePath.nonEmpty) {
      DataLakeUtilities.extractFormatFromS3Url(inputFilePath.get)
    }
    else {
      throw new RuntimeException("Unable to extract format from given cleanse information.")
    }
  }

}

case class LoadJobConfig(
                          customer: String,
                          jobType: String,
                          subJobType: String,
                          activityType: String,
                          customerServiceAreas: Set[String],
                          s3Url: String,
                          batchId: String,
                          failOnError: Boolean,
                          user: String,
                          profile: String,
                          environment: String
                        ) extends JobConfig

object LoadJobConfig {

  def apply(appConfig: Config, s3Url: String, batchId: String): LoadJobConfig = {
    val customerName: String = appConfig.getString("app.customer")

    val jobType = appConfig.getString("app.main.command")

    val subJobType: String = appConfig.getString("app.sub.command")

    val activityType: String = DataLakeUtilities.extractActivityTypeFromS3Url(s3Url)

    val lookupsClient = AmqpLookupsClient(appConfig)

    val customer: Customer = lookupsClient.getCustomers.find(_.Key == customerName).get

    val customerServiceAreas: Set[String] = lookupsClient.getServiceAreas.
      filter(_.customerId == customer.Id).
      map(_.zip5)

    new LoadJobConfig(
      customer = customerName,
      jobType = jobType,
      subJobType = subJobType,
      activityType = activityType,
      customerServiceAreas = customerServiceAreas,
      s3Url = s3Url,
      batchId = batchId,
      failOnError = appConfig.getBoolean("app.validation.failOnError"),
      user = appConfig.getString("app.current.user"),
      profile = appConfig.getString("app.load.profile"),
      environment = appConfig.getString("app.load.environment")
    )

  }

  def apply(enrichJobConfig: EnrichJobConfig, s3Url: String): LoadJobConfig = {
    new LoadJobConfig(
      customer = enrichJobConfig.customer,
      jobType = enrichJobConfig.jobType,
      subJobType = enrichJobConfig.subJobType,
      activityType = DataLakeUtilities.extractActivityTypeFromS3Url(s3Url),
      customerServiceAreas = enrichJobConfig.customerServiceAreas.map(_.zip5),
      s3Url = s3Url,
      batchId = enrichJobConfig.batchId.get,
      failOnError = enrichJobConfig.failOnError,
      user = enrichJobConfig.user,
      profile = enrichJobConfig.profile,
      environment = enrichJobConfig.environment
    )
  }

}


case class EnrichJobConfig(
                            jobType: String,
                            subJobType: String,
                            customer: String,
                            customerId: Int,
                            customerPafName: Option[String],
                            customerLocations: Seq[Location],
                            customerServiceAreas: Set[ServiceArea],
                            activityType: Option[String],
                            batchId: Option[String],
                            allOrApplicable: String,
                            executorCores: Int,
                            inputFilePath: Option[String],
                            failOnError: Boolean,
                            databaseConfig: Option[DatabaseConfig] = None,
                            anchorConfig: Option[AnchorConfig] = None,
                            sg2Config: Option[SG2Config] = None,
                            bucketUrl: String,
                            batchFormat: String,
                            user: String,
                            profile: String,
                            environment: String,
                            fullRefresh: Boolean
                          ) extends JobConfig

object EnrichJobConfig {

  def apply(
             appConfig: Config,
             customerLocations: Seq[Location],
             customerServiceAreas: Set[ServiceArea],
             databaseConfig: Option[DatabaseConfig],
             anchorConfig: Option[AnchorConfig],
             sg2Config: Option[SG2Config]
           ): EnrichJobConfig = {

    val customer: String = appConfig.getString("app.customer")

    val customerId = Constants.EdhCustomers.find(_.customerKey == customer).get.customerId

    val jobType = appConfig.getString("app.main.command")

    val subJobType = appConfig.getString("app.sub.command")

    val bucketUrl: String = s"s3a://${appConfig.getString("s3.datalake.bucket")}"

    val inputFilePath: Option[String] = JobConfigHelper.optConfig(appConfig, "app.load.file-path")

    val activityType: Option[String] = JobConfigHelper.optConfig(appConfig, "app.load.input-activity-type")

    val batchMonth: Option[Int] = JobConfigHelper.optConfig(appConfig, "app.load.input-months")

    val batchFormat: Option[String] = JobConfigHelper.optConfig(appConfig, "app.load.input-format")

    val batchDays: Option[Int] = JobConfigHelper.optConfig(appConfig, "app.load.input-days")

    val sinceDate: Option[LocalDate] = JobConfigHelper.optConfig(appConfig, "app.load.since-date")

    val inputBatchId: Option[String] = JobConfigHelper.optConfig(appConfig, "app.batch-id")

    val fullRefresh = if(appConfig.hasPath("app.refresh.full-refresh")){
      appConfig.getBoolean("app.refresh.full-refresh")}
    else false

    val batchId: Option[String] =
      if(inputBatchId.nonEmpty){
        inputBatchId
      }
      else if(customer.nonEmpty && inputFilePath.nonEmpty){
        Some(DataLakeUtilities.extractBatchIdFromS3Url(inputFilePath.get, customer))
      } else if (fullRefresh) {
        None
      }
      else throw new RuntimeException(
        "input file path and batch id are empty, please provide input file path or batch id")

    val lookupsClient: LookupsClient = AmqpLookupsClient(appConfig)

    val databaseConfig: DatabaseConfig = PostgresConfig(appConfig)

    val anchorConfig = AnchorConfig(appConfig)

    val sg2Config = SG2Config(appConfig)

    val clients = lookupsClient.getCustomers
    val customerData = clients.find(y => y.Id.equals(customerId)).getOrElse {
      throw new Error(s"Could not find customer for id: $customerId")
    }
    new EnrichJobConfig(
      jobType,
      subJobType,
      customer = customer,
      customerId = customerId,
      customerPafName = customerData.PafName,
      customerLocations = customerLocations,
      customerServiceAreas = customerServiceAreas,
      batchId = batchId,
      batchFormat = batchFormat.getOrElse(
        if(batchId.nonEmpty) {DataLakeUtilities.extractFormatFromBatchId(batchId.get)} else if (inputFilePath.nonEmpty){
          DataLakeUtilities.extractFormatFromS3Bucket(inputFilePath.get)} else ""),
      activityType = activityType,
      inputFilePath = inputFilePath,
      allOrApplicable = appConfig.getString("app.location-scoring.all-or-applicable"),
      executorCores = appConfig.getInt("app.executor-cores"),
      databaseConfig = Some(databaseConfig),
      anchorConfig = Some(anchorConfig),
      failOnError = appConfig.getBoolean("app.validation.failOnError"),
      sg2Config = Some(sg2Config),
      user = appConfig.getString("app.current.user"),
      profile = appConfig.getString("app.load.profile"),
      environment = sys.env.getOrElse("EDH_ENV", None).toString,
      bucketUrl = bucketUrl,
      fullRefresh = fullRefresh
    )

  }
}

case class CheckHealthConfig(customer: String,
                             jobType: String,
                             subJobType: String,
                             slackHook: Option[String],
                             postgresConfig: PostgresConfig,
                             fullRefresh: Option[Boolean],
                             isJobStatEnable: Option[Boolean],
                             user: String,
                             profile: String,
                             environment: String) extends JobConfig

object CheckHealthConfig {
  def apply(appConfig: Config,
            channelName: Option[String] = None,
            apiToken: Option[String] = None,
            fullRefresh: Option[Boolean] = None,
            isJobStatEnable: Option[Boolean] = None
           ): CheckHealthConfig = new CheckHealthConfig(
    customer = appConfig.getString("app.customer"),
    jobType = appConfig.getString("app.main.command"),
    subJobType = appConfig.getString("app.sub.command"),
    slackHook = Some(Constants.SlackHooks),
    postgresConfig = PostgresConfig(appConfig),
    fullRefresh = Some(appConfig.getBoolean("app.check.health.full")),
    isJobStatEnable = Some(appConfig.getBoolean("app.job.stats.enabled")),
    user = appConfig.getString("app.current.user"),
    profile = appConfig.getString("app.load.profile"),
    environment = sys.env.getOrElse("EDH_ENV", None).toString
  )
}
case class DemoJobConfig(customer: String,
                         bucketUrl: String,
                         jobType: String,
                         subJobType: String,
                         postgresConfig: PostgresConfig,
                         user: String,
                         profile: String,
                         environment: String) extends JobConfig

object DemoJobConfig {
  def apply(appConfig: Config
           ): DemoJobConfig = new DemoJobConfig(
    customer = appConfig.getString("app.customer"),
    bucketUrl = s"s3a://${appConfig.getString("s3.datalake.bucket")}",
    jobType = appConfig.getString("app.main.command"),
    subJobType = appConfig.getString("app.sub.command"),
    postgresConfig = PostgresConfig(appConfig),
    user = appConfig.getString("app.current.user"),
    profile = appConfig.getString("app.load.profile"),
    environment = sys.env.getOrElse("EDH_ENV", None).toString
  )
}
case class CheckLoadConfig(customer: String,
                             jobType: String,
                             subJobType: String,
                             slackHook: Option[String],
                             postgresConfig: PostgresConfig,
                             isJobStatEnable: Option[Boolean],
                             user: String,
                             profile: String,
                             environment: String,
                             batchId: String,
                             bucketName: String,
                             activityType: String,
                             batchFormat: String
                          ) extends JobConfig
object CheckLoadConfig {
  def apply(appConfig: Config,
            channelName: Option[String] = None,
            apiToken: Option[String] = None,
            isJobStatEnable: Option[Boolean] = None): CheckLoadConfig = {
    val inputBatchId: String = appConfig.getString("app.batch-id")
    val inputJobType: String = appConfig.getString("app.main.command")
    val inputSubJobType = appConfig.getString("app.sub.command")

      new CheckLoadConfig(
      customer = appConfig.getString("app.customer"),
      jobType = inputJobType,
      subJobType = inputSubJobType,
      slackHook = Some(Constants.SlackHooks),
      postgresConfig = PostgresConfig(appConfig),
      isJobStatEnable = Some(appConfig.getBoolean("app.job.stats.enabled")),
      user = appConfig.getString("app.current.user"),
      profile = appConfig.getString("app.load.profile"),
      environment = sys.env.getOrElse("EDH_ENV", None).toString,
      batchId = inputBatchId,
      bucketName = appConfig.getString("s3.datalake.bucket"),
      activityType = getActivityType(inputJobType, inputSubJobType, None, Some(inputBatchId), None, None, None),
      batchFormat = getBatchFormat(Some(inputBatchId), None)
    )
  }
}

case class RefreshJobConfig(
                             customer: String,
                             jobType: String,
                             subJobType: String,
                             fullRefresh: Boolean,
                             batchId: Option[String],
                             sinceDate: Option[LocalDate],
                             postgresConfig: PostgresConfig,
                             elasticsearchConfig: ElasticsearchConfig,
                             redshiftConfig: RedshiftConfig,
                             user: String,
                             profile: String,
                             environment: String
                           ) extends JobConfig

object RefreshJobConfig {
  def apply(
             appConfig: Config
           ): RefreshJobConfig = new RefreshJobConfig(
    customer = appConfig.getString("app.customer"),
    jobType = appConfig.getString("app.main.command"),
    subJobType = appConfig.getString("app.sub.command"),
    fullRefresh = if(appConfig.hasPath("app.refresh.full-refresh")){
      appConfig.getBoolean("app.refresh.full-refresh")}
    else false,
    batchId = JobConfigHelper.optConfig(appConfig, "app.batch-id"),
    sinceDate = JobConfigHelper.optConfig[LocalDate](appConfig, "app.refresh.date"),
    postgresConfig = PostgresConfig(appConfig),
    elasticsearchConfig = ElasticsearchConfig(appConfig),
    redshiftConfig = RedshiftConfig(appConfig),
    user = appConfig.getString("app.current.user"),
    profile = appConfig.getString("app.load.profile"),
    environment = appConfig.getString("app.load.environment")
  )
}

case class AnchorConfig(
                         outputPath: String,
                         tempPath: String,
                         filenamePrefix: String,
                         outputFileCount: Int,
                         fileDelimiter: String,
                         downloadLocalPath: String,
                         anchorScriptPath: String
                       )

object AnchorConfig {
  def apply(appConfig: Config): AnchorConfig =
    new AnchorConfig(
      appConfig.getString(Constants.OutputPathKey),
      appConfig.getString(Constants.TempPathKey),
      appConfig.getString(Constants.FileNamePrefixKey),
      appConfig.getInt(Constants.OutputFileCountKey),
      appConfig.getString(Constants.FileDelimiterKey),
      appConfig.getString(Constants.DownloadLocalPathKey),
      appConfig.getString(Constants.AnchorScriptFolderKey)
    )
}


case class SG2Config(
                      outputPath: String,
                      tempPath: String,
                      filenamePrefix: String,
                      fileDelimiter: String,
                      inputFileName: String,
                      sg2ScriptPath: String
                    )

object SG2Config {
  def apply(appConfig: Config): SG2Config =
    new SG2Config(
      outputPath = appConfig.getString(Constants.SG2OutputPathKey),
      tempPath = appConfig.getString(Constants.SG2TempPathKey),
      filenamePrefix = appConfig.getString(Constants.SG2FileNamePrefixKey),
      fileDelimiter = appConfig.getString(Constants.SG2FileDelimiterKey),
      inputFileName = appConfig.getString(Constants.SG2InputFileNameKey),
      sg2ScriptPath = appConfig.getString(Constants.SG2ScriptFolderKey)
    )
}


trait DatabaseConfig {

  val host: String
  val port: Int
  val user: String
  val password: String
  val schema: String
  val driver: String
  val database: String
  val useSsl: Boolean
  val sslMode: Option[String]
  val sslRootCert: Option[String]
  val batchSize: Option[Int]

}

case class PostgresConfig(
                           host: String,
                           port: Int,
                           user: String,
                           password: String,
                           schema: String,
                           database: String,
                           driver: String,
                           useSsl: Boolean,
                           sslMode: Option[String],
                           sslRootCert: Option[String],
                           batchSize: Option[Int]
                         ) extends DatabaseConfig

object PostgresConfig {
  def apply(appConfig: Config): PostgresConfig =
    new PostgresConfig(
      host = appConfig.getString("postgres.host"),
      port = appConfig.getInt("postgres.port"),
      user = appConfig.getString("postgres.user"),
      password = appConfig.getString("postgres.password"),
      schema = appConfig.getString("postgres.schema"),
      database = appConfig.getString("postgres.db"),
      driver = appConfig.getString("postgres.driver"),
      useSsl = appConfig.getBoolean("postgres.useSsl"),
      sslMode = Some(appConfig.getString("postgres.sslMode")),
      sslRootCert = Some(appConfig.getString("postgres.sslRootCert")),
      batchSize = Some(appConfig.getInt("postgres.batchSize"))
    )
}

case class RedshiftConfig(
                           host: String,
                           port: Int,
                           user: String,
                           password: String,
                           schema: String,
                           database: String,
                           driver: String,
                           useSsl: Boolean,
                           sslMode: Option[String],
                           sslRootCert: Option[String],
                           batchSize: Option[Int] = None,
                           isFullRefresh: Option[Boolean] = Some(false),
                           batchId: Option[String] = None,
                           refreshDateTime: Option[LocalDate] = None,
                           customer: Option[String] = None,
                           tempBucketName: String,
                           connectionString: String
                         ) extends DatabaseConfig

object RedshiftConfig {
  def apply(appConfig: Config): RedshiftConfig =
    new RedshiftConfig(
      host = appConfig.getString("redshift.jdbc-url"),
      port = appConfig.getInt("redshift.port"),
      user = appConfig.getString("redshift.user"),
      password = appConfig.getString("redshift.password"),
      schema = appConfig.getString("redshift.schema"),
      database = appConfig.getString("redshift.db"),
      driver = appConfig.getString("redshift.driver"),
      useSsl = appConfig.getBoolean("redshift.use-ssl"),
      sslMode = Some(appConfig.getString("redshift.sslMode")),
      sslRootCert = Some(appConfig.getString("redshift.sslRootCert")),
      isFullRefresh = if(appConfig.hasPath("app.refresh.full-refresh")){
        Some(appConfig.getBoolean("app.refresh.full-refresh"))}
      else Some(false),
      batchId = JobConfigHelper.optConfig[String](appConfig, "app.batch-id"),
      refreshDateTime = JobConfigHelper.optConfig[LocalDate](appConfig, "app.refresh-redshift-date"),
      customer =  JobConfigHelper.optConfig[String](appConfig, "app.customer"),
      tempBucketName = appConfig.getString("redshift.temp-s3-bucket"),
      connectionString = appConfig.getString("redshift.connection-string")
    )
}

case class ElasticsearchConfig(
                                numberOfShards: Int,
                                numberOfReplicas: Int,
                                enableCacheRequest: Boolean,
                                node: String,
                                user: String,
                                password: String,
                                useSsl: Boolean,
                                keyStorePath: Option[String],
                                keystorePass: Option[String],
                                columnsToIgnore: Seq[String],
                                complexColumnsToPreserve: Seq[String],
                                timeout: Option[String],
                                force: Boolean,
                                thresholdValue: Double
                              )

object ElasticsearchConfig {
  def apply(appConfig: Config): ElasticsearchConfig = new ElasticsearchConfig(
    numberOfShards = appConfig.getInt("elasticsearch.numberOfShards"),
    numberOfReplicas = appConfig.getInt("elasticsearch.numberOfReplicas"),
    enableCacheRequest = appConfig.getBoolean("elasticsearch.enableCacheRequest"),
    node = appConfig.getString("elasticsearch.nodes"),
    user = appConfig.getString("elasticsearch.user"),
    password = appConfig.getString("elasticsearch.password"),
    useSsl = appConfig.getBoolean("elasticsearch.useSsl"),
    keyStorePath = Some(appConfig.getString("elasticsearch.keyStorePath")),
    keystorePass = Some(appConfig.getString("elasticsearch.keyStorePass")),
    columnsToIgnore = Option(appConfig.getStringList("elasticsearch.columnsToIgnore")).
      map(_.asScala).
      getOrElse(Seq.empty),
    complexColumnsToPreserve = Option(appConfig.getStringList("elasticsearch.complexColumnsToPreserve")).
      map(_.asScala).
      getOrElse(Seq.empty),
    timeout = JobConfigHelper.optConfig[String](appConfig, "elasticsearch.timeout"),
    force = JobConfigHelper.optConfig[Boolean](appConfig, "app.refresh.force").getOrElse(false),
    thresholdValue = appConfig.getDouble("elasticsearch.indexSwapThreshold")
  )
}

case class DataScienceConfig(
                              customer: String,
                              modelName: String,
                              outputS3Bucket: String,
                              inputS3Bucket: String,
                              delimiter: String,
                              inputFileName: String,
                              requiredColumns: Seq[String],
                              jobType: String,
                              subJobType: String,
                              user: String,
                              profile: String,
                              environment: String
                            ) extends JobConfig

object DataScienceConfig {
  def apply(appConfig: Config): DataScienceConfig = {
    DataScienceConfig(
      customer = appConfig.getString("app.customer"),
      modelName = appConfig.getString("datascience.model-name"),
      outputS3Bucket = appConfig.getString("datascience.output-bucket"),
      inputS3Bucket = appConfig.getString("datascience.output-bucket"),
      delimiter = appConfig.getString("datascience.delimiter"),
      inputFileName = appConfig.getString("datacience.input-file-name"),
      requiredColumns = appConfig.getStringList("datascience.output-bucket").asScala,
      jobType = appConfig.getString("app.main.command"),
      subJobType = appConfig.getString("app.sub.command"),
      user = appConfig.getString("app.current.user"),
      profile = appConfig.getString("app.load.profile"),
      environment = appConfig.getString("app.load.environment")
    )
  }
}

case class FileSystemConfig(
                             executorCores: Int
                           )



