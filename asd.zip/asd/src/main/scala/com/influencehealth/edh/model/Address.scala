package com.influencehealth.edh.model

import com.influencehealth.edh.model.Activity.{cleanseAddressCoordinates, cleanseRowField}
import org.apache.spark.sql.Row


case class Address(
                    customer: String,
                    addressId: String,
                    address1: String,
                    address2: Option[String] = None,
                    city: String,
                    state: String,
                    zip4: Option[String] = None,
                    zip5: String,
                    addressCoordinates: Coordinates
                  ) extends AddressIdentity

object Address {

  def buildFromRow(row: Row): Address = {
    Address(
      customer = row.getAs[String]("customer"),
      addressId = row.getAs[String]("addressId"),
      address1 = row.getAs[String]("address1"),
      address2 = cleanseRowField[String](row, "address2"),
      city = row.getAs[String]("city"),
      state = row.getAs[String]("state"),
      zip4 = cleanseRowField[String](row, "zip4"),
      zip5 = row.getAs[String]("zip5"),
      addressCoordinates = cleanseAddressCoordinates(row, "addressCoordinates").get
    )
  }
}