package com.influencehealth.edh.cleanse

import com.influencehealth.edh.Constants
import com.influencehealth.edh.model.activitytype.ActivityType
import com.influencehealth.edh.utils.{CleanseUtils, PersonUtils}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.lit

class NewMoversCleanser(val dateBatchReceived: String) extends DataCleanser {

  this: ActivityType =>


  override def cleanseData(
                            df: DataFrame,
                            customer: Option[String],
                            batchId: String
                          ): (DataFrame, DataFrame) = {

    // Apply default values for Required Columns if found NULL
    val defaultCodeForRequiredColumnsContainingNulls = assignDefaultValuesForRequiredColumnsContainingNulls(df).
      withColumn("source", lit(defaultSource)).
      transform(addSourceRecordId(_, batchId))

    // Cleanses String Column
    val dataFrameContainingCleansedStringColumns = cleanseStringColumns(
      defaultCodeForRequiredColumnsContainingNulls, cleanseStringColumnNames)

    // Aliases Data
    val aliasedData = aliasData(dataFrameContainingCleansedStringColumns, customer)

    import df.sparkSession.implicits._
    val emptySequence: Seq[String] = Seq()
    val errorDataFrame: DataFrame = emptySequence.toDF

    (aliasedData, errorDataFrame)
  }

  override def formatDateColumns(df: DataFrame): DataFrame = ???

  override def cleanseStringColumns(df: DataFrame, stringColumnsToBeCleansed: Seq[String]): DataFrame = {

    import df.sparkSession.implicits._

    val cleansedStringColumnsForRequiredFiles = stringColumnsToBeCleansed.foldLeft(df) {
      (accDF, column) => accDF.withColumn(s"$column", CleanseUtils.cleanseStringColumns(df(s"$column")))
    }
    cleansedStringColumnsForRequiredFiles.
      withColumn("sex", PersonUtils.sex($"sex")).
      withColumn("maritalStatus", PersonUtils.maritalStatus($"sourceMaritalStatus")).
      withColumn("movedToZip5", PersonUtils.getZip5($"zip5")).
      withColumn("zip4", CleanseUtils.get_zip4($"zip5")).
      withColumn("zip5", CleanseUtils.get_zip5($"zip5"))
  }

  override def aliasData(df: DataFrame, customer: Option[String]): DataFrame = {
    df.
      withColumn("trackingDate", lit(Constants.Today.toString)).
      withColumn("activityType", lit(defaultActivityType)).
      withColumn("servicedOn", lit(Constants.Today.toString)).
      withColumn("dateCreated", lit(Constants.Now.toString))
  }

  override def assignDefaultValuesForRequiredColumnsContainingNulls(
                                             df: DataFrame): DataFrame = {
    val moveMonthFromBatchReceived = CleanseUtils.getPreviousMonth(dateBatchReceived+"-01")
    df
      // .withColumn("source", lit(defaultSource))
      .withColumn("sourceType", lit(defaultSourceType))
      .withColumn("addressType", lit(defaultAddressType))
      .withColumn("activityDate", lit(CleanseUtils.parseStringToDate(dateBatchReceived)))
      .withColumn("activityType", lit(defaultActivityType))
      .withColumn("messageType", lit(defaultMessageType))
      .withColumn("experianMoveMonth", lit(moveMonthFromBatchReceived))
  }

}
