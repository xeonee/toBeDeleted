package com.influencehealth.edh.enrich.activity.crosswalks.helper

case class Race(
  customer: String,
  source: String,
  sourceType: String,
  sourceRace: String,
  race: String
) extends Serializable

object Race {
  val raceCw: Seq[Race] = Seq(
    Race("default", "default", "default", "a", "a"),
    Race("default", "default", "default", "b", "b"),
    Race("default", "default", "default", "h", "h"),
    Race("default", "default", "default", "o", "o"),
    Race("default", "default", "default", "w", "w"),
    Race("default", "default", "default", "u", "u")
  )
}

case class RaceCwCreationException(exc: Throwable)
  extends Exception("Unable to create race crosswalk", exc)

case class InvalidRaceValue(value: String)
  extends Exception(s"The following value does not match any standard race value: '$value'")