package com.influencehealth.edh.enrich.activity.address

import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf

import scala.io.Source

object EnrichAddressHelper {

  val countyToCbsa: Map[String, (String, String)] =
    Source.fromURL(getClass.getResource("/crosswalks/county_cbsa_cw.csv"))
      .getLines()
      .drop(1)
      .map(line => line.split(","))
      .map(line => (line(0), (line(1), line(2))))
      .toMap

  val ncoaActionToValidAddress: Map[String, Boolean] = Map(
    "B" -> false,
    "C" -> true,
    "P" -> false,
    "Y" -> false,
    "F" -> false,
    "Z" -> false,
    "G" -> false,
    "I" -> true,
    "M" -> true,
    "O" -> true
  )

  def getValidAddressFlag(ncoaActionCode: Option[String]): Option[Boolean] =
    ncoaActionCode.flatMap(EnrichAddressHelper.ncoaActionToValidAddress.get)

  def checkMovedAway(setOfZipCodes: Set[String], zip5: String, sourceType: String): Boolean = {
    !setOfZipCodes.contains(zip5) && sourceType.equalsIgnoreCase("PROSPECT")
  }

  def fetchValidAddress: UserDefinedFunction = udf((ncoaActionCode: String) => {
    EnrichAddressHelper.getValidAddressFlag(Some(ncoaActionCode)).getOrElse(false)
  })

  def checkMovedAway (setOfZipCodes: Set[String]): UserDefinedFunction = udf((zip5: String, sourceType: String) => {
    EnrichAddressHelper.checkMovedAway(setOfZipCodes,zip5,sourceType)
  })
}
