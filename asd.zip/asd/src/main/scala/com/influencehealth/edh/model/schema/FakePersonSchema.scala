package com.influencehealth.edh.model.schema

import org.apache.spark.sql.types.{StringType, StructField, StructType}

object FakePersonSchema {
  val schema: StructType = StructType(
    Array(
      StructField("seqNo", StringType, nullable = true),
      StructField("prefix", StringType, nullable = true),
      StructField("firstName", StringType, nullable = true),
      StructField("middleName", StringType, nullable = true),
      StructField("lastName", StringType, nullable = true),
      StructField("email", StringType, nullable = true),
      StructField("homePhone", StringType, nullable = true),
      StructField("sex", StringType, nullable = true),
      StructField("address1", StringType, nullable = true),
      StructField("address2", StringType, nullable = true),
      StructField("city", StringType, nullable = true),
      StructField("state", StringType, nullable = true),
      StructField("zip5", StringType, nullable = true),
      StructField("zip4", StringType, nullable = true),
      StructField("latitude", StringType, nullable = true),
      StructField("longitude", StringType, nullable = true),
      StructField("countyCode", StringType, nullable = true),
      StructField("deliveryPointCode", StringType, nullable = true)
    )
  )
}
