package com.influencehealth.edh.personmatching

import java.util.Calendar

import com.influencehealth.edh.model.PrimaryIdentity

object PersonMatcher {

  sealed trait BlockingKey extends Serializable

  object MridMatch extends BlockingKey {
    override def toString: String = "MRID MATCH"
  }

  case object PerfectMatch extends BlockingKey {
    override def toString: String = "PERFECT MATCH"
  }

  case object EMailMatch extends BlockingKey {
    override def toString: String = "EMAIL MATCH"
  }

  case object PhoneMatch extends BlockingKey {
    override def toString: String = "PHONE MATCH"
  }

  case object NickNameMatch extends BlockingKey {
    override def toString: String = "NICKNAME MATCH"
  }

  case object LastNameChangeMatch extends BlockingKey {
    override def toString: String = "MARRIED WOMEN MATCH"
  }

  def isSamePerson(inbound: PrimaryIdentity, potentialMatch: PrimaryIdentity, blockingKey: BlockingKey): Boolean = {

    def mridsMatch = inbound.mrids.toSet.intersect(potentialMatch.mrids.toSet).nonEmpty

    def dateOfBirthMatches = inbound.dateOfBirth == potentialMatch.dateOfBirth &&
      inbound.dateOfBirth.nonEmpty && potentialMatch.dateOfBirth.nonEmpty

    def sexMatches = inbound.sex == potentialMatch.sex

    def streetSecondNumberMatches = {
      if(inbound.streetSecondNumber.isEmpty || potentialMatch.streetSecondNumber.isEmpty){
        true
      } else inbound.streetSecondNumber == potentialMatch.streetSecondNumber
    }

    def middleNameMatches = {
      if(inbound.middleName.isEmpty || potentialMatch.middleName.isEmpty){
        true
      } else inbound.middleName == potentialMatch.middleName
    }

    def personalSuffixMatches = {
      if(inbound.personalSuffix.isEmpty || potentialMatch.personalSuffix.isEmpty){
        true
      } else inbound.personalSuffix == potentialMatch.personalSuffix
    }

    def rootFirstNameMatches = inbound.rootFirstName == potentialMatch.rootFirstName

    def substringFirstNameMatches = {
      inbound.firstName.map(substringOfSevenCharsOrLess) ==
        potentialMatch.firstName.map(substringOfSevenCharsOrLess) &&
        inbound.firstName.nonEmpty && potentialMatch.firstName.nonEmpty
    }

    def substringLastNameMatches = {
      inbound.lastName.map(substringOfSevenCharsOrLess) ==
        potentialMatch.lastName.map(substringOfSevenCharsOrLess) &&
        inbound.lastName.nonEmpty && potentialMatch.lastName.nonEmpty
    }

    def substringOfSevenCharsOrLess(string: String) = if (string.length <= 7) string else string.substring(0, 7)

    def soundexLastNameMatches = inbound.soundexLastName == potentialMatch.soundexLastName

    def lastNameContainsLastName =
      inbound.lastName.exists(
        inboundLastName =>
          potentialMatch.lastName.exists(
            potentialMatchLastName =>
              inboundLastName.contains(potentialMatchLastName))) ||
        potentialMatch.lastName.exists(
          potentialMatchLastName =>
            inbound.lastName.exists(inboundLastName =>
              potentialMatchLastName.contains(inboundLastName))
        )

    def birthMonthMatch = {

      inbound.dateOfBirth.map { date =>
        val cal = Calendar.getInstance()
        cal.setTime(date)
        cal.get(Calendar.MONTH)
      } == potentialMatch.dateOfBirth.map { date =>
        val cal = Calendar.getInstance()
        cal.setTime(date)
        cal.get(Calendar.MONTH)
      } &&
        inbound.dateOfBirth.nonEmpty && potentialMatch.dateOfBirth.nonEmpty
    }

    def birthYearMatch = {

      inbound.dateOfBirth.map { date =>
        val cal = Calendar.getInstance()
        cal.setTime(date)
        cal.get(Calendar.YEAR)
      } == potentialMatch.dateOfBirth.map { date =>
        val cal = Calendar.getInstance()
        cal.setTime(date)
        cal.get(Calendar.YEAR)
      } &&
        inbound.dateOfBirth.nonEmpty && potentialMatch.dateOfBirth.nonEmpty
    }

    def dateOfBirthIsPresentInExactlyOne =
      (inbound.dateOfBirth.isEmpty && potentialMatch.dateOfBirth.nonEmpty) ||
        (inbound.dateOfBirth.nonEmpty && potentialMatch.dateOfBirth.isEmpty)


    def ageDifferenceIsWithinTwo = {
      if (noDateOfBirthIsPresent){
        (inbound.sourceAge.isEmpty || potentialMatch.sourceAge.isEmpty) ||
          Math.abs(inbound.sourceAge.get - potentialMatch.sourceAge.get) <= 2
      } else {
        inbound.sourceAge.nonEmpty && potentialMatch.sourceAge.nonEmpty &&
          Math.abs(inbound.sourceAge.get - potentialMatch.sourceAge.get) <= 2
      }
    }

    def ageMatch: Boolean = {
      inbound.sourceAge.nonEmpty && potentialMatch.sourceAge.nonEmpty &&
        inbound.sourceAge.get == potentialMatch.sourceAge.get
    }

    def noDateOfBirthIsPresent =
      inbound.dateOfBirth.isEmpty && potentialMatch.dateOfBirth.isEmpty

    def primaryEmailMatch: Boolean = {
      inbound.primaryEmail.nonEmpty && potentialMatch.primaryEmail.nonEmpty &&
      inbound.primaryEmail == potentialMatch.primaryEmail
    }

    def primaryPhoneNumberMatch: Boolean = {
      inbound.primaryPhoneNumber.nonEmpty && potentialMatch.primaryPhoneNumber.nonEmpty &&
        inbound.primaryPhoneNumber == potentialMatch.primaryPhoneNumber
    }

    blockingKey match {

      case MridMatch => true

      // 1) Do the MRIDs match
      // 2) Do the dob and sex match
      // 3) If month match, year match, sex matches, middle name matches, personal suffix matches,
      //    and street second address matches
      // 4) If exactly one dob is present, sex matches, middle name matches, personal suffix matches,
      //    street second address matches, and age difference is less than or equal to 2 years
      // 5) if no dob present, sex matches, middle name matches, personal suffix matches, and
      //    street second address matches, and age difference is less than or equal to 2 years


      case PerfectMatch =>
        mridsMatch ||
          (dateOfBirthMatches && sexMatches) ||
          (birthMonthMatch &&
            birthYearMatch &&
            sexMatches ) ||
          (dateOfBirthIsPresentInExactlyOne &&
            sexMatches &&
            ageMatch) ||
          (dateOfBirthIsPresentInExactlyOne &&
            sexMatches &&
            middleNameMatches &&
            personalSuffixMatches &&
            streetSecondNumberMatches &&
            ageDifferenceIsWithinTwo) ||
          (noDateOfBirthIsPresent &&
            sexMatches &&
            middleNameMatches &&
            personalSuffixMatches &&
            streetSecondNumberMatches &&
            ageDifferenceIsWithinTwo)

      case EMailMatch | PhoneMatch =>
        mridsMatch ||
          (dateOfBirthMatches && sexMatches) ||
          (birthMonthMatch &&
            birthYearMatch &&
            sexMatches &&
            middleNameMatches &&
            personalSuffixMatches &&
            streetSecondNumberMatches) ||
          (dateOfBirthIsPresentInExactlyOne &&
            sexMatches &&
            middleNameMatches &&
            personalSuffixMatches &&
            streetSecondNumberMatches &&
            ageDifferenceIsWithinTwo) ||
          (noDateOfBirthIsPresent &&
            sexMatches &&
            middleNameMatches &&
            personalSuffixMatches &&
            streetSecondNumberMatches &&
            ageDifferenceIsWithinTwo)

      case NickNameMatch =>
        mridsMatch ||
          (dateOfBirthMatches &&
            sexMatches &&
            rootFirstNameMatches) ||
          (dateOfBirthMatches &&
            sexMatches &&
            substringFirstNameMatches) ||
          (dateOfBirthMatches &&
            rootFirstNameMatches &&
            sexMatches &&
            streetSecondNumberMatches &&
            middleNameMatches &&
            personalSuffixMatches)

      case LastNameChangeMatch =>
        mridsMatch ||
          (dateOfBirthMatches &&
            sexMatches &&
            soundexLastNameMatches) ||
          (dateOfBirthMatches &&
            sexMatches &&
            substringLastNameMatches) ||
          (dateOfBirthMatches &&
            sexMatches &&
            lastNameContainsLastName)
    }
  }


}
