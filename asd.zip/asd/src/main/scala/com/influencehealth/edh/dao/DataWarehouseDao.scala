package com.influencehealth.edh.dao

import org.apache.spark.sql.{DataFrame, SaveMode}

trait DataWarehouseDao {

  def loadTemporaryTable(data: DataFrame, tableName: String, transmissionName: String)

  def executeSQLFile(path: String, transmissionName: String, truncateMode: Boolean, customer: String)

  def cleanUpCustomerTempTables(transmissionName: String)

  def saveTable(tableName: String, dataFrame: DataFrame, mode: SaveMode = SaveMode.Overwrite): Unit

}