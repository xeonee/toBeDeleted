package com.influencehealth.edh.linker

import com.influencehealth.edh.dao.DatabaseDao
import com.influencehealth.edh.model.Activity
import org.apache.spark.sql._
import org.apache.spark.storage.StorageLevel

class ActivityLinker(
                      val databaseDao: DatabaseDao,
                      val customer: String
                    ) extends EntityLinker[Activity] with Serializable {

  this: EntityDB[Activity] =>

  implicit val rowEncoder: Encoder[Row] = Encoders.kryo[Row]

  override def linkRecords(inputDF: Dataset[Activity]): Dataset[Activity] = {

    // TRANSFORM THEN LINK
    val transformedDF = transformInput(inputDF).persist(StorageLevel.MEMORY_ONLY_SER)

    val linkedDF = linking(transformedDF)

    prepareOutputData(inputDF, linkedDF)

  }

  override def transformInput(inputDF: Dataset[Activity]): Dataset[IdentityEntity[Activity]] = {
    import inputDF.sparkSession.implicits._
    get(inputDF.map(activity => IdentityEntity[Activity]("in_memory_activity", activity)))
  }

  override def prepareOutputData(
                                  candidatesForLinkage: => Dataset[Activity],
                                  linkedDF: Dataset[IdentityEntity[Activity]]
                                ): Dataset[Activity] = {

    import linkedDF.sparkSession.implicits._
    linkedDF.filter(_.origin == "in_memory_activity").map(_.entity)
  }

  private def linking(inputDF: Dataset[IdentityEntity[Activity]]): Dataset[IdentityEntity[Activity]] = {
    mergeCandidatesOnBlockingKeys(inputDF)
  }

}
