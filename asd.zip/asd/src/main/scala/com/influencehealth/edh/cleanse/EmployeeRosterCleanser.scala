package com.influencehealth.edh.cleanse

import com.influencehealth.edh.model.activitytype.ActivityType
import com.influencehealth.edh.utils.{CleanseUtils, PersonUtils}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._

class EmployeeRosterCleanser(val dateBatchReceived: String) extends DataCleanser {

  this: ActivityType =>


  override def cleanseData(
                            df: DataFrame,
                            customer: Option[String],
                            batchId: String
                          ): (DataFrame, DataFrame) = {

    // Apply default values for Required Columns if found NULL
    val defaultCodeForRequiredColumnsContainingNulls = assignDefaultValuesForRequiredColumnsContainingNulls(df).
      withColumn("source", lit(defaultSource)).
      transform(addSourceRecordId(_, batchId))

    // filters required columns that are not null
    val (dataFrameContainingNonNullColumns, dataFrameContainingNullColumns) =
      filterRequiredColumnsContainingInvalidValues(
        defaultCodeForRequiredColumnsContainingNulls, nullColumnNames, mandatoryContactColumnsNames)

    // cleanses & filters Date column
    val dataFrameContainingValidDateColumns = formatDateColumns(dataFrameContainingNonNullColumns)

    // Cleanses String Column
    val dataFrameContainingCleansedStringColumns = cleanseStringColumns(dataFrameContainingValidDateColumns,
      cleanseStringColumnNames)

    // Cleanses Contact details: Phone numbers and emails
    val dataFrameContainingCleansedContactDetails = cleanseContactDetails(dataFrameContainingCleansedStringColumns)

    // Cleanse zip5 column
    val cleansedZips = cleanseZips(dataFrameContainingCleansedContactDetails)

    // Cleanse healthSystemEmployee  column
    val cleansedHealthSystemEmployee = setHealthSystemEmployee(cleansedZips)

    // Aliases Data
    val aliasedData = aliasData(cleansedHealthSystemEmployee, customer)

    (aliasedData, dataFrameContainingNullColumns)

  }

  override def formatDateColumns(df: DataFrame): DataFrame = {
    import df.sqlContext.implicits._

    val formattedDatesDataFrame = df
      .withColumn("dateOfBirth", CleanseUtils.timestamp_to_date(PersonUtils.validateInputDate(
        date_format(unix_timestamp($"dateOfBirth", "MM/dd/yy").cast("timestamp"), "yyyy-MM-dd"))))
      .withColumn("dateHired", date_format(unix_timestamp($"dateHired", "MM/dd/yyyy").
        cast("timestamp"), "MM/dd/yyyy"))
      .withColumn("terminationDate", date_format(unix_timestamp($"terminationDate", "MM/dd/yyyy").
        cast("timestamp"), "MM/dd/yyyy"))

    // Get difference in dates
    val dataFrameContainingDifferenceBetweenTwoDates = formattedDatesDataFrame.
      // Re-Assignment for length of stay from string to integer
      withColumn("lengthOfStay",
      datediff(date_format(unix_timestamp($"terminationDate", "MM/dd/yyyy").cast("timestamp"), "yyyy-MM-dd"),
        date_format(unix_timestamp($"dateHired", "MM/dd/yyyy").cast("timestamp"), "yyyy-MM-dd")))

    // filter day differences between two dates greater than -1
    val dataFrameContainingValidDateColumns = dataFrameContainingDifferenceBetweenTwoDates.withColumn("lengthOfStay",
      getValidDifferenceBetweenDates(dataFrameContainingDifferenceBetweenTwoDates("lengthOfStay")))

    dataFrameContainingValidDateColumns
  }

  override def cleanseStringColumns(df: DataFrame, stringColumnsToBeCleansed: Seq[String]): DataFrame = {
    stringColumnsToBeCleansed.foldLeft(df)((curr, n) => curr.withColumn(n, CleanseUtils.cleanseStringColumns(curr(n))))
  }

  override def assignDefaultValuesForRequiredColumnsContainingNulls(df: DataFrame): DataFrame = {
    df.
      withColumn("sourceType", lit(defaultSourceType)).
      withColumn("sourceActivityType", lit(defaultActivityType))
  }

  override def aliasData(df: DataFrame, customer: Option[String]): DataFrame = {
    super.aliasData(df, customer).
      withColumn("activityType", lit(defaultActivityType)).
      withColumn("activityDate", lit(CleanseUtils.parseStringToDate(dateBatchReceived))).
      withColumn("hospital", df("hospitalDesc")).
      withColumn("businessUnitId", df("businessUnit")).
      withColumn("businessUnit", df("businessUnitDesc")).
      withColumn("site", df("siteDesc")).
      withColumn("clinic", df("clinicDesc")).
      withColumn("practiceLocation", df("practiceLocationDesc"))
      .drop("lengthOfStay")
  }

  /** Validates the email and phone number columns
    *
    * @param df
    * @return dataFrame
    */
  private def cleanseContactDetails(df: DataFrame): DataFrame = {

    val updatedDf = df
      .withColumn("homePhone", CleanseUtils.cleanseAndParsePhone(df("homePhone")))
      .withColumn("workPhone", CleanseUtils.cleanseAndParsePhone(df("workPhone")))
      .withColumn("mobilePhone", CleanseUtils.cleanseAndParsePhone(df("mobilePhone")))

    val finalDf = updatedDf
      .withColumn("emails", CleanseUtils.cleanseAndValidateEmails(df("workEmail"), df("personalEmail")))
      .withColumn("phoneNumbers", CleanseUtils.cleanseAndConcatePhoneNumbers(
        col("homePhone"), col("workPhone"),col("mobilePhone")
      ))
    finalDf
  }

  /** If the length of stay is < 0 then return null */
  private def getValidDifferenceBetweenDates: UserDefinedFunction = udf((value: Int) => {
    if (value >= 0) {
      value
    } else 0
  })

  val stringify: UserDefinedFunction = udf((vs: Seq[String]) =>
    s"""[${vs.mkString(",").replace("null,", "").replace("null", "")}]""")

  /** Cleanse zip values
    *
    * @param df
    * @return
    */
  private def cleanseZips(df: DataFrame): DataFrame = {
    val x = df.withColumn("zip4", CleanseUtils.get_zip4(df("zip5"))).
      withColumn("zip5", CleanseUtils.get_zip5(df("zip5")))
    x
  }

  /** Set Health System
    *
    * @param df
    * @return
    */
  private def setHealthSystemEmployee(df: DataFrame): DataFrame = {
    val x = df.withColumn("healthSystemEmployee", getFlag(df("lengthOfStay")))
    x
  }

  /** extract zip4 values from zip column */
  private def getFlag: UserDefinedFunction = udf((lengthOfStay: String) => {
    if (lengthOfStay != null && lengthOfStay.toInt >= 0) {
      false
    }
    else true
  })


}
