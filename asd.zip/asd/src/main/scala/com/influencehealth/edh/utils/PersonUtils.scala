package com.influencehealth.edh.utils

import java.sql.{Date, Timestamp}
import java.time.format.DateTimeFormatter
import java.time.{LocalDate, LocalDateTime, Period}

import com.influencehealth.edh.Constants
import com.influencehealth.edh.model.crosswalk.{MaritalStatus, Sex}
import org.apache.spark.sql.Column
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType

object PersonUtils {

  import com.influencehealth.edh.implicits._

  case class DerivationException(
                                  message: String,
                                  throwable: Throwable = null
                                ) extends Exception(message, throwable)

  def sex: UserDefinedFunction = udf((sourceSex: String) => {
    val sex = Sex.sexCw.find(sex =>
      sex.sourceSex.equalsIgnoreCase(sourceSex)).map(_.sex)
    if (sex.isEmpty && (sourceSex != null && sourceSex.nonEmpty)) {
      throw DerivationException(
        s"No sex crosswalk value supplied for " +
          s"'$sourceSex'. Resulting value is null"
      )
    } else sex.getOrElse(Constants.UNKNOWN)
  })

  def maritalStatus: UserDefinedFunction = udf((sourceMaritalStatus: String) => {
    val maritalStatus = MaritalStatus.maritalStatusCw.find(maritalStatus =>
      maritalStatus.sourceMaritalStatus.equalsIgnoreCase(sourceMaritalStatus)).map(_.maritalStatus)

    if (maritalStatus.isEmpty && (sourceMaritalStatus != null && sourceMaritalStatus.nonEmpty)) {
      throw DerivationException(
        s"No marital status crosswalk value supplied for sourceMaritalStatus" +
          s" '$sourceMaritalStatus'. Resulting value is null")
    } else maritalStatus.orNull
  })

  def getZip5: UserDefinedFunction = udf((zip5: String) => {
    if (zip5 == "00000") null
    else zip5
  })

  /**
    * Returns valid date based on the input date value
    * if the input date is greater than todays date, it will update Century value to 19 and return the modified date,
    * as date of birth and activity date can not be in future dates.
    * else it will return the input date.
    *
    * @return a Timestamp
    */
  def validateInputDate: UserDefinedFunction = udf((inputDate: Timestamp) => {
    if (Option(inputDate).nonEmpty) {
      val inputDateLocal: LocalDateTime = inputDate.toLocalDateTime
      val today = Constants.Today.toTimestamp
      if (inputDateLocal.isAfter(today.toLocalDateTime)) {
        val yearFormatter = DateTimeFormatter.ofPattern("yy"); // Just the year, with 2 digits
        val formattedDate = inputDateLocal.format(yearFormatter)
        val modifiedDate: LocalDateTime = inputDateLocal.withYear(s"19$formattedDate".toInt)
        Some(Timestamp.valueOf(modifiedDate))
      }
      else Some(inputDate)
    }
    else None
  })

  /**
    * Returns age based on date of birth or (source age & date source age received)
    *
    * @return date value as string
    */
  def computeAge(dateOfBirth: Option[Date], sourceAge: Option[Int],
                 dateSourceAgeReceived: Option[Date]): Option[Int] = {
    val today: LocalDate = LocalDate.now()

    if (dateOfBirth.nonEmpty) {
      val today: LocalDate = LocalDate.now()
      val birthday: LocalDate = dateOfBirth.get.toLocalDate
      Some(Period.between(birthday, today).getYears)
    }
    else if (sourceAge.nonEmpty && dateSourceAgeReceived.nonEmpty) {
      val dateSourceAgeReceivedLocal: LocalDate = dateSourceAgeReceived.get.toLocalDate
      val differenceBetweenSourceAgeDateReceivedAndToday: Int =
        Period.between(dateSourceAgeReceivedLocal, today).getYears
      val currentAge: Int = sourceAge.get + differenceBetweenSourceAgeDateReceivedAndToday
      Some(currentAge)
    }
    else {
      None
    }
  }

  def compute_age(dateOfBirth: Column, sourceAge: Column, dateSourceAgeReceived: Column) = {
    when(dateOfBirth.isNotNull, (months_between(current_date(), dateOfBirth) / 12).cast(IntegerType)).
      otherwise(
        when(sourceAge.isNotNull && dateSourceAgeReceived.isNotNull,
          sourceAge + (months_between(current_date(), dateSourceAgeReceived) / 12).cast(IntegerType))
      )
  }

}
