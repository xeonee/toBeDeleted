package com.influencehealth.edh.enrich.activity.crosswalks.helper

case class DnsReason(
  customer: String,
  source: String,
  sourceType: String,
  sourceDnsReason: String,
  dnsReason: String,
  directMail: Boolean,
  call: Boolean,
  text: Boolean,
  email: Boolean
) extends Serializable

object DnsReason {

  val Default: String = "default"

  val dnsReasonCw: Seq[DnsReason] = Seq(
    DnsReason(Default, Default, Default, "opt-out: client supplied", "opt-out: client supplied", false, false, false, false),
    DnsReason(Default, Default, Default, "bad debt: client supplied", "bad debt: client supplied", false, false, false, false),
    DnsReason(Default, Default, Default, "fired patient: client supplied", "fired patient: client supplied", false, false, false, false),
    DnsReason(Default, Default, Default, "deceased: client supplied", "deceased: client supplied", false, false, false, false),
    DnsReason(Default, Default, Default, "opt-out", "opt-out: client supplied", false, false, false, false),
    DnsReason(Default, Default, Default, "opt out", "opt-out: client supplied", false, false, false, false),
    DnsReason(Default, Default, Default, "bad debt", "bad debt: client supplied", false, false, false, false),
    DnsReason(Default, Default, Default, "fired patient", "fired patient: client supplied", false, false, false, false),
    DnsReason(Default, Default, Default, "deceased", "deceased: client supplied", false, false, false, false),
    DnsReason("archildrens", Default, Default, "opt-out: client supplied", "opt-out: client supplied", false, false, false, false)
  )
}

case class DnsReasonCwCreationException(exc: Throwable)
  extends Exception("Unable to create dns reason crosswalk", exc)
