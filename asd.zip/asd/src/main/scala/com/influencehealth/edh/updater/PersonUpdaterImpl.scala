package com.influencehealth.edh.updater

import java.sql.Timestamp

import com.influencehealth.edh.Constants
import com.influencehealth.edh.model.{Person, PersonLocation, PersonPhoneNumber}
import org.apache.spark.sql.catalyst.expressions.GenericRowWithSchema

object PersonUpdaterImpl extends Serializable {

  val fieldsNotToBeUpdated = Seq(
    "personId",
    "customer",
    "dateCreated",
    "sourceFirstName",
    "sourceLastName",
    "sourceMiddleName",
    "sourcePersonType"
  )

  val atomicFields: Seq[Seq[String]] = Seq(
    Seq(
      "addressId",
      "addressQualityIndicator",
      "addressType",
      "isValidAddress",
      "address1",
      "address2",
      "city",
      "state",
      "zip5",
      "zip4",
      "county",
      "addressCoordinates",
      "streetPreDirection",
      "streetSuffix",
      "streetSecondNumber",
      "streetSecondUnit",
      "streetHouseNumber"
    ),
    Seq(
      "moveType",
      "moveMonth"
    )
  )

  val collectionFieldsToBeAppended = Seq(
    "activities",
    "mrids",
    "optOutCallReasons",
    "optOutDirectMailReasons",
    "optOutEmailReasons",
    "optOutTextReasons",
    "emails",
    "phoneNumbers"
  )

  val collectionFieldsToBeUpdated = Seq("locations")

  val genericUpdateFields: Seq[String] = Person.Schema.fieldNames.diff(
    collectionFieldsToBeAppended ++ atomicFields.flatten ++ fieldsNotToBeUpdated ++ collectionFieldsToBeUpdated)

  def updatePerson(oldestPerson: Person, newestPerson: Person): Person = {

    import com.influencehealth.edh.ToMapImplicits._

    val oldestPersonMap = personToMap(oldestPerson)
    val newestPersonMap = personToMap(newestPerson)

    def mergeOptSeq[T](seq1: Seq[T], seq2: Seq[T]): Seq[T] = {
      (Option(seq1).getOrElse(Seq.empty[T]) ++ Option(seq2).getOrElse(Seq.empty[T])).distinct
    }

    def middleNameUpdate(oldMiddleName: Option[String], newMiddleName: Option[String]): Option[String] = {
      newMiddleName match {
        case Some(m) if oldMiddleName.isEmpty => Option(m)
        case Some(m) if m.length == 1 && oldMiddleName.map(_.length).getOrElse(0) > 1 => oldMiddleName
        case Some(m) if m.length >= oldMiddleName.map(_.length).getOrElse(0) => Option(m)
        case _ => oldMiddleName
      }
    }

    // TODO: Add in unit test around this logic
    //    def primaryEmailUpdate(oldPrimaryEmail: Option[String], newPrimaryEmail: Option[String]): Option[String] = {
    //      if (newPrimaryEmail.exists(EmailValidator.getInstance().isValid)) {
    //        newPrimaryEmail match {
    //          case Some(m) if oldPrimaryEmail.isEmpty => Option(m)
    //          case _ => oldPrimaryEmail
    //        }
    //      } else {
    //        oldPrimaryEmail
    //      }
    //    }

    def deriveHasGenderConflict(oldSex: Option[String], newSex: Option[String]): Boolean = {
      if (newSex.isDefined && oldSex.isDefined && oldSex != newSex) true
      else false
    }

    def deriveIsDeceased(dateOfDeath: Option[String]): Boolean = {
      if (dateOfDeath.isDefined) true
      else false
    }

    // Check if the newestPerson's mostRelevantActivityType has higher importance
    // than the oldestPerson's mostRelevantActivityType
    if (
      newestPerson.mostRelevantActivityType.map(Constants.activityTypeRank).getOrElse(99)
        <= oldestPerson.mostRelevantActivityType.map(Constants.activityTypeRank).getOrElse(99)
    ) {
      // generete updatedPersonMap using different rules to merge persons informations
      val updatedPersonMap: Map[String, Any] = oldestPersonMap ++
        genericUpdateFields.foldLeft(Map.empty[String, Any]) { (map, field) =>
          if (Option(newestPersonMap(field)).nonEmpty) {
            map ++ Map(field -> newestPersonMap(field))
          } else map ++ Map(field -> oldestPersonMap(field))
        } ++
        collectionFieldsToBeUpdated.foldLeft(Map.empty[String, Any]) { (map, field) =>
          if (newestPersonMap(field).asInstanceOf[Seq[Any]].nonEmpty) {
            map ++ Map(field -> newestPersonMap(field))
          } else map ++ Map(field -> oldestPersonMap(field))
        } ++
        collectionFieldsToBeAppended.foldLeft(Map.empty[String, Any]) { (map, field) =>
          map ++
            Map(field -> mergeOptSeq(
              newestPersonMap(field).asInstanceOf[Seq[Any]],
              oldestPersonMap(field).asInstanceOf[Seq[Any]]
            ))
        } ++
        Map(
          "middleName" -> middleNameUpdate(
            Option(oldestPersonMap("middleName")).map(_.toString),
            Option(newestPersonMap("middleName")).map(_.toString)
          ).orNull,
          "hasGenderConflict" -> deriveHasGenderConflict(
            Option(oldestPersonMap("sex")).map(_.toString),
            Option(newestPersonMap("sex")).map(_.toString)
          ),
          "isDeceased" -> deriveIsDeceased(
            Option(oldestPersonMap("dateOfDeath"))
              .orElse(Option(newestPersonMap("dateOfDeath"))).map(_.toString)
          ),
          "mostRelevantActivityDate" -> newestPersonMap("mostRelevantActivityDate"),
          "mostRelevantActivityType" -> newestPersonMap("mostRelevantActivityType"),
          "personType" -> newestPersonMap("personType"),
          "dateModified" -> new Timestamp(System.currentTimeMillis())
          //          "primaryEmail" -> primaryEmailUpdate(
          //            Option(oldestPersonMap("primaryEmail")).map(_.toString),
          //            Option(newestPersonMap("primaryEmail")).map(_.toString)
          //          )
        ) ++
        atomicFields.map(fields => fields.foldLeft(Map.empty[String, Any]) { (map, field) =>
          map ++ Map(field -> newestPersonMap(field))
        }).foldLeft(Map.empty[String, Any]) { (concatenatedMap, map) =>
          concatenatedMap ++ map
        }

      // println(updatedPersonMap)
      // convert updatedPersonMap to a GenericRow and then to Person
      val personRow = new GenericRowWithSchema(
        Person.Schema.map { structField =>
          val fieldName = structField.name
          fieldName match {
            case "locations" => updatedPersonMap(fieldName).asInstanceOf[Seq[PersonLocation]].map(_.toString)
            case "phoneNumbers" => updatedPersonMap(fieldName).asInstanceOf[Seq[PersonPhoneNumber]]
              .map(_.toString)
            case "emails" => updatedPersonMap(fieldName).asInstanceOf[Seq[String]].map(_.toString.trim)
            case _ => updatedPersonMap(fieldName)
          }
        }.toArray, Person.Schema)

      val updatedPerson = Person.buildPersonFromRow(personRow)
      updatedPerson.copy(
        activities = updatedPerson.activities.map(a => a.copy(personId = Option(updatedPerson.personId))))
    } else {

      val updatedPersonMap = oldestPersonMap ++
        collectionFieldsToBeAppended.foldLeft(Map.empty[String, Any]) { (map, field) =>
          map ++
            Map(field -> mergeOptSeq(
              newestPersonMap(field).asInstanceOf[Seq[Any]],
              oldestPersonMap(field).asInstanceOf[Seq[Any]]
            ))
        } ++ Map("dateModified" -> new Timestamp(System.currentTimeMillis()))

      val personRow = new GenericRowWithSchema(
        Person.Schema.map { structField =>
          val fieldName = structField.name
          fieldName match {
            case "locations" => updatedPersonMap(fieldName).asInstanceOf[Seq[PersonLocation]].map(_.toString)
            case "phoneNumbers" => updatedPersonMap(fieldName).asInstanceOf[Seq[PersonPhoneNumber]]
              .map(_.toString)
            case "emails" => updatedPersonMap(fieldName).asInstanceOf[Seq[String]].map(_.toString)
            case _ => updatedPersonMap(fieldName)
          }
        }.toArray, Person.Schema)

      val updatedPerson = Person.buildPersonFromRow(personRow)
      updatedPerson.copy(
        activities = updatedPerson.activities.map(a => a.copy(personId = Option(updatedPerson.personId))))
    }

  }

}
