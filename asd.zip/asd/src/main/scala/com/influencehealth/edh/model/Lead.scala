package com.influencehealth.edh.model

import java.time.LocalDate


case class UnIdentifiedLead(
                             customer: String,
                             leadId: Int,
                             lastName: Option[String],
                             firstName: Option[String],
                             email: Option[String],
                             created: Option[String],
                             address1: Option[String],
                             city: Option[String],
                             state: Option[String],
                             zip5: Option[String],
                             callerId: Option[String],
                             phoneNumber: Option[String],
                             dateOfBirth: Option[LocalDate]
                           )

case class IdentifiedLead(
                           customer: String,
                           personId: String,
                           leadId: Int,
                           lastName: Option[String],
                           firstName: Option[String],
                           email: Option[String],
                           created: Option[String],
                           address1: Option[String],
                           city: Option[String],
                           state: Option[String],
                           zip5: Option[String],
                           callerId: Option[String],
                           phoneNumber: Option[String],
                           dateOfBirth: Option[LocalDate]
                         )