package com.influencehealth.edh.utilities.fixture

import java.util.regex.Pattern

import com.github.javafaker.Faker
import com.influencehealth.edh.dao._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.{broadcast, udf}
import org.apache.spark.storage.StorageLevel

/**
  * Created by pallavi.karan on 11/16/17.
  */
object DeIdentifier {

  val Delimiter = "|"
  val faker = new Faker

  /**
    * 1. Appends dummy data
    * 2. DeIdentifies data
    *
    * @param dataFrames input df
    * @return
    */
  def deIdentifyEncounterData(dataFrames: DataFrame):
  DataFrame = {

    val DfWithMRNs = generateRandomMRNs(dataFrames).persist(StorageLevel.MEMORY_AND_DISK)
    val deIdentifiedDf = deIdentifyPHIData(DfWithMRNs)
    deIdentifiedDf
  }

  /**
    * Generates Random MRNs
    *
    * @param df input dataframe
    * @return
    */
  def generateRandomMRNs(df: DataFrame): DataFrame = {

    val sourcePersonIdWithRandomMRNsDf = df.select("sourcePersonId").distinct().
      withColumn("person_id", DeIdentifier.generateRandomNumbers())

    val dfWithRandomMRNs = sourcePersonIdWithRandomMRNsDf.join(df, Seq("sourcePersonId"))

    dfWithRandomMRNs
  }

  /**
    * Appends dummy data for non physician dataframes
    *
    * @param df input df
    * @return
    */
  def deIdentifyPHIData(df: DataFrame): DataFrame = {

    // generate and append dummy data
    val generatedDummyDemogData: DataFrame = generateDummyDemographicData(df).persist(StorageLevel.MEMORY_AND_DISK)

    val appendedDummyDemographicData: DataFrame = appendDummyDemographicData(generatedDummyDemogData, df)

    val generatedDummyGuarantorData: DataFrame =
      generateDummyGuarantorData(appendedDummyDemographicData).persist(StorageLevel.MEMORY_AND_DISK)

    val appendedDummyGuarantorData = appendDummyGuarantorData(appendedDummyDemographicData,
      generatedDummyGuarantorData)

    // Derive data
    val derivedDemographicData: DataFrame = deriveDemographicData(appendedDummyGuarantorData)
      .persist(StorageLevel.MEMORY_AND_DISK)

    val appendedDerivedDemographicData: DataFrame = appendDerivedDemographicData(appendedDummyGuarantorData,
      derivedDemographicData)

    val derivedVisitData: DataFrame = deriveVisitData(appendedDerivedDemographicData)
      .persist(StorageLevel.MEMORY_AND_DISK)

    val appendedDerivedVisitData: DataFrame = appendDerivedVisitData(appendedDerivedDemographicData,
      derivedVisitData)


    appendedDerivedVisitData
  }


  /**
    * Extracts all the data into multiple dataframes
    *
    * @param df list of all the dataframes
    * @return
    */
  def generateListsOfDeidentifiedDataFrames(df: DataFrame): List[(EncounterFileType, DataFrame)] = {

    var splitDataFrame: List[(EncounterFileType, DataFrame)] = List()

    if (df.columns.contains("lastName")) {
      splitDataFrame = splitDataFrame :+ ((DemographicFile, extractDemogData(df)))
    }

    if (df.columns.contains("currentProceduralTerminologySeqNo")) {
      splitDataFrame = splitDataFrame :+ ((CurrentProceduralTerminologyFile, extractCPTData(df)))
    }

    if (df.columns.contains("diagnosisSeqNo")) {
      splitDataFrame = splitDataFrame :+ ((DiagnosisFile, extractDXData(df)))
    }

    if (df.columns.contains("prognosisSeqNo")) {
      splitDataFrame = splitDataFrame :+ ((PrognosisFile, extractPXData(df)))
    }

    if (df.columns.contains("hospitalId")) {
      splitDataFrame = splitDataFrame :+ ((FacilityFile, extractFacilityData(df)))
    }

    if (df.columns.contains("sourceRecordId")) {
      splitDataFrame = splitDataFrame :+ ((VisitFile, extractVisitData(df)))
    }

    if (df.columns.contains("guarantorLastName")) {
      splitDataFrame = splitDataFrame :+ ((GuarantorFile, extractGuarantorData(df)))
    }

    if (df.columns.contains("diastolic")) {
      splitDataFrame = splitDataFrame :+ ((BiometricFile, extractBiometricData(df)))
    }

    if (df.columns.contains("physicianLastName")) {
      splitDataFrame = splitDataFrame :+ ((PhysicianFile, extractPhysicianData(df)))
    }

    if (df.columns.contains("charges")) {
      splitDataFrame = splitDataFrame :+ ((FinancialFile, extractFinancialData(df)))
    }

    splitDataFrame
  }

  /**
    * Replaces/Substitutes demographic data with dummy data & returns the new dataframe
    * last name, first name, middle name, address1, address2, city, state, zip5, country,
    * home phone, work phone, mobile phone, email, employer replaced with dummy data.
    * It does not select sourcePersonId and instead selects person_id (Randomly generated MRN)
    *
    * @param demogDf input demog df
    * @return
    */
  def generateDummyDemographicData(demogDf: DataFrame): DataFrame = {
    val withDummyDataDf = demogDf.select("sourcePersonId").distinct().
      withColumn("fake_lastName", generateDummyLastName()).
      withColumn("fake_firstName", generateDummyFirstName()).
      withColumn("fake_middleName", generateDummyFirstName()).
      withColumn("fake_address1", generateDummyAddress1()).
      withColumn("fake_address2", generateDummyAddress2()).
      withColumn("fake_city", generateDummyCity()).
      withColumn("fake_state", generateDummyState()).
      withColumn("fake_zip5", generateDummyZip5()).
      withColumn("fake_country", generateDummyCountry()).
      withColumn("fake_homePhone", generateDummyPhoneNumber()).
      withColumn("fake_mobilePhone", generateDummyPhoneNumber()).
      withColumn("fake_workPhone", generateDummyPhoneNumber()).
      withColumn("fake_email", generateDummyEmail()).
      withColumn("fake_employer", generateDummyEmployer()).persist(StorageLevel.MEMORY_AND_DISK)
    withDummyDataDf
  }

  def appendDummyDemographicData(withDummyColumnsDf: DataFrame, consolidatedDf: DataFrame): DataFrame = {
    val withDummyColumns = consolidatedDf.join(broadcast(withDummyColumnsDf), Seq("sourcePersonId"))
    val replaceNullDf = withDummyColumns.na.fill("")
    replaceNullDf
  }


  /**
    * Extracts required column
    *
    * @param demogDf input demog df
    * @return
    */
  def extractDemogData(demogDf: DataFrame): DataFrame = {
    val basicDeIdentifiedDf = demogDf.select(
      demogDf("person_id"),
      demogDf("fake_lastName"),
      demogDf("fake_firstName"),
      demogDf("fake_middleName"),
      demogDf("prefix"),
      demogDf("personalSuffix"),
      demogDf("professionalSuffix"),
      demogDf("fake_address1"),
      demogDf("fake_address2"),
      demogDf("fake_city"),
      demogDf("fake_state"),
      demogDf("fake_zip5"),
      demogDf("fake_country"),
      demogDf("sourceSex"),
      demogDf("date_of_birth"),
      demogDf("date_of_death"),
      demogDf("sourceExclusionFlag"),
      demogDf("derived_home_phone"),
      demogDf("derived_mobile_phone"),
      demogDf("derived_work_phone"),
      demogDf("fake_email"),
      demogDf("sourceMaritalStatus"),
      demogDf("sourceRace"),
      demogDf("fake_employer"),
      demogDf("portalStatus")
    ).distinct()

    val renamedDf = basicDeIdentifiedDf.
      withColumnRenamed("fake_lastName", "lastName").
      withColumnRenamed("fake_firstName", "firstName").
      withColumnRenamed("fake_middleName", "middleName").
      withColumnRenamed("fake_address1", "address1").
      withColumnRenamed("fake_address2", "address2").
      withColumnRenamed("fake_city", "city").
      withColumnRenamed("fake_state", "state").
      withColumnRenamed("fake_zip5", "zip5").
      withColumnRenamed("fake_country", "country").
      withColumnRenamed("date_of_birth", "dateOfBirth").
      withColumnRenamed("date_of_death", "dateOfDeath").
      withColumnRenamed("derived_home_phone", "homePhone").
      withColumnRenamed("derived_mobile_phone", "mobilePhone").
      withColumnRenamed("derived_work_phone", "workPhone").
      withColumnRenamed("fake_email", "email").
      withColumnRenamed("fake_employer", "employer")

    val replaceNullDf = renamedDf.na.fill("")
    replaceNullDf

  }

  /**
    * Replaces/Substitutes demographic data's derivable columns with derived date & returns the new dataframe
    * Replaces month & date values with random numbers from date of birth & date of death
    * Formats phone numbers by removing special character from home, work & mobile phone
    *
    * @param df input demog df
    * @return
    */
  def deriveDemographicData(df: DataFrame): DataFrame = {
    val withDummyDataDf = df.select("sourcePersonId", "dateOfBirth", "dateOfDeath", "homePhone", "mobilePhone",
      "workPhone").distinct()
      .withColumn("date_of_birth", generateRandomDate(df("dateOfBirth"))).
      withColumn("date_of_death", generateRandomDate(df("dateOfDeath"))).
      withColumn("derived_home_phone", formatPhoneNumbers(df("homePhone"))).
      withColumn("derived_mobile_phone", formatPhoneNumbers(df("mobilePhone"))).
      withColumn("derived_work_phone", formatPhoneNumbers(df("workPhone")))

    withDummyDataDf
  }

  def appendDerivedDemographicData(df: DataFrame, withDummyDataDf: DataFrame): DataFrame = {
    val derivedData = df.join(withDummyDataDf, Seq("sourcePersonId", "dateOfBirth", "dateOfDeath",
      "homePhone", "mobilePhone", "workPhone"))

    val replaceNullDf = derivedData.na.fill("")
    replaceNullDf
  }

  /**
    * Selects columns based on CPT and replaces null with empty string
    *
    * @param df input df
    * @return
    */
  def extractCPTData(df: DataFrame): DataFrame = {
    val cptTransformedData = df.select("person_id", "sourceRecordId", "currentProceduralTerminologySeqNo",
      "currentProceduralTerminologyMxVersion", "currentProceduralTerminologyMxCode").distinct()
    val replaceNullDf = cptTransformedData.na.fill("")
    replaceNullDf
  }

  /**
    * Selects columns based on DX and replaces null with empty string
    *
    * @param df Dx df
    * @return
    */
  def extractDXData(df: DataFrame): DataFrame = {
    val dxTransformedData = df.
      select("person_id",
        "sourceRecordId",
        "diagnosisSeqNo",
        "diagnosisMxVersion",
        "diagnosisMxCode").distinct()
    val replaceNullDf = dxTransformedData.na.fill("")
    replaceNullDf
  }

  /**
    * Selects columns based on Facility and replaces null with empty string
    *
    * @param df input df
    * @return
    */
  def extractFacilityData(df: DataFrame): DataFrame = {
    val facilityTransformedData = df.select("person_id", "sourceRecordId", "hospitalId", "hospital", "businessUnitId",
      "businessUnit", "siteId", "site", "clinicId", "clinic", "practiceLocationId", "practiceLocation").distinct()
    val replaceNullDf = facilityTransformedData.na.fill("")
    replaceNullDf
  }

  /**
    * Selects columns based on PX and replaces null with empty string
    *
    * @param df input df
    * @return
    */
  def extractPXData(df: DataFrame): DataFrame = {
    val pxTransformedData = df.select("person_id", "sourceRecordId", "prognosisSeqNo", "prognosisMxVersion",
      "prognosisMxCode").distinct()
    val replaceNullDf = pxTransformedData.na.fill("")
    replaceNullDf
  }

  /**
    * Replaces/Substitutes Visit data with derived date & returns the new dataframe & saves to S3
    * Replaces month & date values with random numbers for admit date, discharge date & final bill date
    * Replaces Insurance Code with random numbers
    *
    * @param df input df
    * @return
    */
  def deriveVisitData(df: DataFrame): DataFrame = {
    val withDummyDataDf = df.select("sourcePersonId", "admitDate", "dischargeDate", "finalBillDate")
      .distinct().withColumn("admit_date", generateRandomDate(df("admitDate"))).
      withColumn("discharge_date", generateRandomDate(df("dischargeDate"))).
      withColumn("final_bill_date", generateRandomDate(df("finalBillDate"))).
      withColumn("insurance_code", generateRandomNumbers())
    withDummyDataDf
  }

  def appendDerivedVisitData(df: DataFrame, withDummyDataDf: DataFrame): DataFrame = {
    val derivedData = df.join(withDummyDataDf, Seq("sourcePersonId", "admitDate",
      "dischargeDate", "finalBillDate"))

    val replaceNullDf = derivedData.na.fill("")
    replaceNullDf
  }


  /**
    * Extracts required column
    *
    * @param visitDf visit df
    * @return
    */
  def extractVisitData(visitDf: DataFrame): DataFrame = {
    val deIdentifiedVisitData = visitDf.
      select(
        visitDf("sourceType"),
        visitDf("source"),
        visitDf("person_id"),
        visitDf("sourceRecordId"),
        visitDf("admit_date"),
        visitDf("discharge_date"),
        visitDf("final_bill_date"),
        visitDf("lengthOfStay"),
        visitDf("sourceDischargeStatus"),
        visitDf("sourcePatientType"),
        visitDf("sourceErPatient"),
        visitDf("medicalSeverityDiagnosisRelatedGroup"),
        visitDf("sourceFinancialClassId"),
        visitDf("sourceFinancialClass"),
        visitDf("insurance_code"),
        visitDf("insurance"),
        visitDf("visitTotalCharges"),
        visitDf("attendingId"),
        visitDf("referencingId"),
        visitDf("primaryCarePhysicianId")).distinct()

    val renamedDf = deIdentifiedVisitData.
      withColumnRenamed("admit_date", "admitDate").
      withColumnRenamed("discharge_date", "dischargeDate").
      withColumnRenamed("final_bill_date", "finalBillDate").
      withColumnRenamed("insurance_code", "insuranceId")

    val replaceNullDf = renamedDf.na.fill("")
    replaceNullDf

  }

  /**
    * Selects columns based on Physician data and replaces null with empty string
    *
    * @param physicianDf physician df
    * @return
    */
  def extractPhysicianData(physicianDf: DataFrame):
  DataFrame = {

    val consolidated = physicianDf.
      select(
        physicianDf("primaryCarePhysicianId"),
        physicianDf("physicianNationalProviderIdentifier"),
        physicianDf("physicianLastName"),
        physicianDf("physicianFirstName"),
        physicianDf("physicianMiddleName"),
        physicianDf("physicianFullName"),
        physicianDf("physicianPersonalSuffix"),
        physicianDf("physicianProfessionalSuffix"),
        physicianDf("physicianPrimarySpecialityCode"),
        physicianDf("physicianPrimarySpeciality")).distinct()

    val replaceNullDf = consolidated.na.fill("")
    replaceNullDf
  }

  /**
    * Replaces/Substitutes Guarantor data with dummy data & returns the new dataframe
    * last name, first name, middle name, full name, address1, address2, city, state, zip5, country replaced
    * with dummy data.
    * It does not select sourcePersonId and instead selects person_id (Randomly generated MRN)
    *
    * @param df input df
    * @return
    */
  def generateDummyGuarantorData(df: DataFrame): DataFrame = {
    val withDummyDataDf = df.select("sourcePersonId").distinct().
      withColumn("guar_last_name", generateDummyLastName()).
      withColumn("guar_first_name", generateDummyFirstName()).
      withColumn("guar_middle_name", generateDummyFirstName()).
      withColumn("guar_full_name", generateDummyFullName()).
      withColumn("guar_address1", generateDummyAddress1()).
      withColumn("guar_address2", generateDummyAddress2()).
      withColumn("guar_city", generateDummyCity()).
      withColumn("guar_state", generateDummyState()).
      withColumn("guar_zip5", generateDummyZip5()).
      withColumn("guar_country", generateDummyCountry()).persist(StorageLevel.MEMORY_AND_DISK)

    withDummyDataDf
  }

  def appendDummyGuarantorData(df: DataFrame, withDummyDataDf: DataFrame): DataFrame = {
    val withDummyColumns = df.join(broadcast(withDummyDataDf), Seq("sourcePersonId"))
    val replaceNullDf = withDummyColumns.na.fill("")
    replaceNullDf
  }

  /**
    * Extracts required column
    *
    * @param guarDf input df
    * @return
    */
  def extractGuarantorData(guarDf: DataFrame): DataFrame = {
    val basicDeIdentifiedDf = guarDf.
      select(guarDf("sourceRecordId"),
        guarDf("person_id"),
        guarDf("guar_last_name"),
        guarDf("guar_first_name"),
        guarDf("guar_middle_name"),
        guarDf("guar_full_name"),
        guarDf("guar_address1"),
        guarDf("guar_address2"),
        guarDf("guar_city"),
        guarDf("guar_state"),
        guarDf("guar_zip5"),
        guarDf("guar_country")
      ).distinct()

    val renamedDf = basicDeIdentifiedDf.
      withColumnRenamed("guar_last_name", "guarantorLastName").
      withColumnRenamed("guar_first_name", "guarantorFirstName").
      withColumnRenamed("guar_middle_name", "guarantorMiddleName").
      withColumnRenamed("guar_full_name", "guarantorFullName").
      withColumnRenamed("guar_address1", "guarantorAddress1").
      withColumnRenamed("guar_address2", "guarantorAddress2").
      withColumnRenamed("guar_city", "guarantorCity").
      withColumnRenamed("guar_state", "guarantorState").
      withColumnRenamed("guar_zip5", "guarantorZip5").
      withColumnRenamed("guar_country", "guarantorCountry")


    val replaceNullDf = renamedDf.na.fill("")
    replaceNullDf
  }

  /**
    * Selects columns based on Biometric and replaces null with empty string
    *
    * @param df input df
    * @return
    */
  def extractBiometricData(df: DataFrame): DataFrame = {
    val biometricTransformedData = df.select("sourceRecordId", "person_id", "systolic",
      "diastolic", "height", "weight", "bodyMassIndex").distinct()
    val replaceNullDf = biometricTransformedData.na.fill("")
    replaceNullDf
  }

  /**
    * Selects columns based on Financial and replaces null with empty string
    *
    * @param df input df
    * @return
    */
  def extractFinancialData(df: DataFrame): DataFrame = {
    val financialTransformedData = df.select("sourceRecordId", "person_id", "charges", "cost", "revenue",
      "contributionMargin", "profit").distinct()
    val replaceNullDf = financialTransformedData.na.fill("")
    replaceNullDf
  }


  /**
    * splits date into month, year, day
    *
    * @param date       input data to be formatted
    * @param param      part of the date eg: Day, Month, Year
    * @param dateFormat "MM/dd/yyyy" or "MM/dd/yy"
    * @return Int of param value
    */
  def splitDate(date: String, param: String, dateFormat: String): Int = {
    val dtf = java.time.format.DateTimeFormatter.ofPattern(dateFormat)
    val d = java.time.LocalDate.parse(date, dtf)
    param match {
      case "YEAR" => d.getYear
      case "MONTH" => d.getMonthValue
      case "DAY" => d.getDayOfMonth
    }
  }

  /**
    * Generate/Derive alternate data for date of birth from MM/dd/yyyy format
    *
    * @return
    */
  private def generateRandomDate: UserDefinedFunction = udf(
    (date: String) => {
      var dateFormat: String = null
      if (date.toString.isEmpty || date.toString == null || date.isEmpty || date == null || date.equals("//0") ||
        date.equals("//") || date.equals(" ") || date.equals("--") || date.equals("--0")) {
        ""
      }
      else {
        val regexPattern1 = Pattern.compile("^(1[0-2]|0[1-9])/(3[01]|[12][0-9]|0[1-9])/[0-9]{4}$") // MM/dd/yyyy
        val regexPattern2 = Pattern.compile("^(1[0-2]|0[1-9])/(3[01]|[12][0-9]|0[1-9])/[0-9]{2}$") // MM/dd/yy
        val regexPattern3 = Pattern.compile("^(1[0-2]|0?[1-9])/(3[01]|[12][0-9]|0?[1-9])/[0-9]{4}$") // M/d/yyyy
        val regexPattern4 = Pattern.compile("^(1[0-2]|0?[1-9])/(3[01]|[12][0-9]|0?[1-9])/[0-9]{2}$") // M/d/yy
        val regexPattern5 = Pattern.compile("^(1[0-2]|0?[1-9])-(3[01]|[12][0-9]|0?[1-9])-[0-9]{2}$") // M-d-yy
        val regexPattern6 = Pattern.compile("^(1[0-2]|0[1-9])-(3[01]|[12][0-9]|0[1-9])-[0-9]{4}$") // MM-dd-yyyy
        val regexPattern7 = Pattern.compile("^(1[0-2]|0[1-9])-(3[01]|[12][0-9]|0[1-9])-[0-9]{2}$") // MM-dd-yy
        val regexPattern8 = Pattern.compile("^(1[0-2]|0?[1-9])-(3[01]|[12][0-9]|0?[1-9])-[0-9]{4}$") // M-d-yyyy
        date match {
          case x if regexPattern1.matcher(x).matches => dateFormat = "MM/dd/yyyy"
          case x if regexPattern2.matcher(x).matches => dateFormat = "MM/dd/yy"
          case x if regexPattern3.matcher(x).matches => dateFormat = "M/d/yyyy"
          case x if regexPattern4.matcher(x).matches => dateFormat = "M/d/yy"
          case x if regexPattern5.matcher(x).matches => dateFormat = "M-d-yy"
          case x if regexPattern6.matcher(x).matches => dateFormat = "MM-dd-yyyy"
          case x if regexPattern7.matcher(x).matches => dateFormat = "MM-dd-yy"
          case x if regexPattern8.matcher(x).matches => dateFormat = "M-d-yyyy"
          case _ => throw new RuntimeException(" Date format not handled. ")
        }

        val year = splitDate(date, "YEAR", dateFormat)
        var day = splitDate(date, "DAY", dateFormat)
        var month = splitDate(date, "MONTH", dateFormat)

        val r = new scala.util.Random
        val random = 1 + r.nextInt((9 - 1) + 1)

        if (day >= 22) {
          day = day - random
        }
        else {
          day = day + random
        }

        val randomNo = 1 + r.nextInt((4 - 1) + 1)
        if (month >= 6) {
          month = month - randomNo
        }
        else {
          month = month + randomNo
        }
        month.toString.concat("/").concat(day.toString).concat("/").concat(year.toString)

      }
    })

  /**
    * Removes all special characters in phone numbers
    *
    * @return
    */
  private def formatPhoneNumbers: UserDefinedFunction = udf(
    (phoneNo: String) => {
      phoneNo.replaceAll("[^\\d]", "")
    })

  /**
    * Generates Random 6 digit number
    *
    * @return
    */
  def generateRandomNumbers: UserDefinedFunction = udf(
    () => {
      val r = scala.util.Random
      (1000000 + r.nextInt(900000)).toString
    })

  /**
    * Generates dummy last name
    *
    * @return
    */
  def generateDummyLastName: UserDefinedFunction = udf(
    () => {
      faker.name().lastName()

    })

  /**
    * Generates dummy first name
    *
    * @return
    */
  def generateDummyFirstName: UserDefinedFunction = udf(
    () => {
      faker.name().firstName()
    })

  /**
    * Generates dummy fullname
    *
    * @return
    */
  def generateDummyFullName: UserDefinedFunction = udf(
    () => {
      faker.name().fullName()
    })

  /**
    * Generates dummy address 1
    *
    * @return
    */
  def generateDummyAddress1: UserDefinedFunction = udf(
    () => {
      faker.address().streetAddress()
    })

  /**
    * Generates dummy address2
    *
    * @return
    */
  def generateDummyAddress2: UserDefinedFunction = udf(
    () => {
      faker.address().streetName()
    })

  /**
    * Generates dummy city
    *
    * @return
    */
  def generateDummyCity: UserDefinedFunction = udf(
    () => {
      faker.address().city()
    })

  /**
    * Generates dummy state
    *
    * @return
    */
  def generateDummyState: UserDefinedFunction = udf(
    () => {
      faker.address().state()
    })

  /**
    * Generates dummy zipcode
    *
    * @return
    */
  def generateDummyZip5: UserDefinedFunction = udf(
    () => {
      faker.address().zipCode()
    })

  /**
    * Generates dummy country
    *
    * @return
    */
  def generateDummyCountry: UserDefinedFunction = udf(
    () => {
      faker.address().country()
    })

  /**
    * Generates dummy phone number
    *
    * @return
    */
  def generateDummyPhoneNumber: UserDefinedFunction = udf(
    () => {
      faker.phoneNumber().cellPhone()
    })

  /**
    * Generates dummy email
    *
    * @return
    */
  def generateDummyEmail: UserDefinedFunction = udf(
    () => {
      faker.internet().emailAddress()
    })

  /**
    * Generates dummy employer name
    *
    * @return
    */
  def generateDummyEmployer: UserDefinedFunction = udf(
    () => {
      faker.company().name()
    })


}
