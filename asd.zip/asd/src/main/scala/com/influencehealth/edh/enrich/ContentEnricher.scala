package com.influencehealth.edh.enrich

import com.influencehealth.edh.{Constants, CustomLazyLogging}
import com.influencehealth.edh.model.{Activity, Person}
import org.apache.spark.sql.Dataset
import org.apache.spark.storage.StorageLevel

case class DataNotFoundException(message: String, exception: Throwable = null) extends Exception(message, exception)

trait ContentEnricher[A] extends CustomLazyLogging with Serializable {

  val name: String
  val next: Option[ContentEnricher[A]]

  // replace later with Dataset[Activity]
  def enrich(dataset: Dataset[A]): Dataset[A]

  def process(dataset: Dataset[A]): Dataset[A] = {

    logger.info(s"START $name")
    val outputDS: Dataset[A] = enrich(dataset)
    val outputCount = outputDS.count()
    logger.info(s"Finished step $name with $outputCount records")

    outputDS.persist(StorageLevel.MEMORY_ONLY_SER)

    // we can do an rdd checkpoint here
    if (outputCount == 0 && !name.equalsIgnoreCase(Constants.DnsEnrichStepName)) {
      throw DataNotFoundException(s"EnrichStep $name produced empty Dataset")
    }
    next match {
      case Some(ce) => ce.process(outputDS)
      case None => outputDS
    }
  }

}

trait ActivityEnricher extends ContentEnricher[Activity]

trait PersonEnricher extends ContentEnricher[Person]
