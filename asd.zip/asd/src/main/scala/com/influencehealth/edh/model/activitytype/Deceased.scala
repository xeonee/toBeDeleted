package com.influencehealth.edh.model.activitytype

import com.influencehealth.edh.Constants

trait Deceased extends ActivityType {

  override val formatType: String = Constants.DeceasedInfluenceHealthFormat
  override val defaultSource: String = Constants.DeceasedInfluenceHealthDefaultSource
  override val defaultMessageType: String = Constants.DeceasedDefaultMessageType
  override val defaultSourceType: String = Constants.DeceasedDefaultSourceType
  override val defaultAddressType: String = Constants.DeceasedDefaultAddressType
  override val defaultActivityType: String = Constants.DeceasedActivityType
  override val defaultPersonType: String = Constants.DeceasedPersonType

  override val cleanseStringColumnNames: Seq[String] = Seq(
    "lastName",
    "firstName",
    "middleName"
  )


  override val nullColumnNames: Seq[String] = Seq(
    "firstName",
    "lastName",
    "dateOfDeath",
    "source",
    "sourceRecordId"
  )

  override val zipColumnNames: Seq[String] = Seq.empty

  override val mandatoryContactColumnsNames: Seq[String] = Seq.empty


}
