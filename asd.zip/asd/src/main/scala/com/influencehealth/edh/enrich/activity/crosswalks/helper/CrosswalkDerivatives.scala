package com.influencehealth.edh.enrich.activity.crosswalks.helper

import java.sql.Timestamp
import java.text.DecimalFormat

import com.influencehealth.edh.implicits._
import com.influencehealth.edh.lookup_clients._
import com.influencehealth.edh.model.crosswalk.ActivityType
import com.typesafe.scalalogging.LazyLogging
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._


case class CrosswalkDerivatives(
                                 crosswalkDerivativesContext: CrosswalkData
                               ) extends LazyLogging with Serializable {
  val defaultCustomerId: Int = 0
  val defaultCustomer: String = "default"
  val defaultSource: String = "default"
  val defaultSourceType: String = "default"

  def sourceType: UserDefinedFunction = udf((inputSourceType: String) => {
    Option(inputSourceType).map(s => sourceTypeLookup.getOrElse(s.toLowerCase, s))
  })

  def patientType: UserDefinedFunction =
    udf((sourcePatientType: String, customer: String, source: String, sourceType: String) => {
      val patientType = crosswalkDerivativesContext.broadcastPatientTypeCW.value
        .find(patientType =>
          patientType.customer.equals(customer)
            && patientType.source.equalsIgnoreCase(source)
            && patientType.sourceType.equalsIgnoreCase(sourceType)
            && patientType.sourcePatientType.equalsIgnoreCase(sourcePatientType)).map(_.patientType)

      val defaultClientPatientType = crosswalkDerivativesContext.broadcastPatientTypeCW.value
        .find(patientType =>
          patientType.customer.equals(customer)
            && patientType.source.equalsIgnoreCase(defaultSource)
            && patientType.sourceType.equalsIgnoreCase(defaultSourceType)
            && patientType.sourcePatientType.equalsIgnoreCase(sourcePatientType)).map(_.patientType)

      val defaultPatientType = crosswalkDerivativesContext.broadcastPatientTypeCW.value
        .find(patientType =>
          patientType.customer.equals(defaultCustomer)
            && patientType.source.equalsIgnoreCase(defaultSource)
            && patientType.sourceType.equalsIgnoreCase(defaultSourceType)
            && patientType.sourcePatientType.equalsIgnoreCase(sourcePatientType)).map(_.patientType)

      if (patientType.isEmpty && defaultClientPatientType.isDefined) {
        defaultClientPatientType.get.toString
      } else if (patientType.isEmpty && defaultClientPatientType.isEmpty && defaultPatientType.isDefined) {
        defaultPatientType.get.toString
      } else {
        patientType.map(_.toString).orNull
      }
    })

  def activityType: UserDefinedFunction =
    udf((sourceActivityType: String, customer: String, source: String, sourceType: String) => {
      val activityType = crosswalkDerivativesContext.broadcastActivityTypeCW.value.find(activityType =>
        activityType.customer.equals(customer)
          && activityType.source.equalsIgnoreCase(source)
          && activityType.sourceType.equalsIgnoreCase(sourceType)
          && activityType.sourceActivityType.equalsIgnoreCase(sourceActivityType)).map(_.activityType)

      val defaultActivityType = crosswalkDerivativesContext.broadcastActivityTypeCW.value
        .find(activityType =>
          activityType.customer.equals(defaultCustomer)
            && activityType.source.equalsIgnoreCase("lvm")
            && activityType.sourceType.equalsIgnoreCase("call center")
            && activityType.sourceActivityType.equalsIgnoreCase(sourceActivityType)).map(_.activityType)

      if (activityType.isEmpty && defaultActivityType.isDefined) defaultActivityType.get.toString
      else activityType.map(_.toString).orNull
    })

  def erPatient: UserDefinedFunction =
    udf((sourceErPatient: String, customer: String, source: String, sourceType: String) => {
      val erPatient = crosswalkDerivativesContext.broadcastERPatientCW.value.find(erPatient =>
        erPatient.customer.equals(customer)
          && erPatient.source.equalsIgnoreCase(source)
          && erPatient.sourceType.equalsIgnoreCase(sourceType)
          && erPatient.sourceErPatient.equalsIgnoreCase(sourceErPatient)).map(_.erPatient)

      val defaultErPatient = crosswalkDerivativesContext.broadcastERPatientCW.value
        .find(erPatient =>
          erPatient.customer.equals(defaultCustomer)
            && erPatient.source.equalsIgnoreCase(defaultSource)
            && erPatient.sourceType.equalsIgnoreCase(defaultSourceType)
            && erPatient.sourceErPatient.equalsIgnoreCase(sourceErPatient)).map(_.erPatient)

      if (erPatient.isEmpty && defaultErPatient.isDefined) defaultErPatient.get.toString
      else erPatient.map(_.toString).orNull
    })

  def maritalStatus: UserDefinedFunction =
    udf((sourceMaritalStatus: String, customer: String, source: String, sourceType: String) => {
      val maritalStatus = crosswalkDerivativesContext.broadcastMaritalStatusCW.value.find(maritalStatus =>
        maritalStatus.customer.equals(customer)
          && maritalStatus.source.equalsIgnoreCase(source)
          && maritalStatus.sourceType.equalsIgnoreCase(sourceType)
          && maritalStatus.sourceMaritalStatus.equalsIgnoreCase(sourceMaritalStatus)).map(_.maritalStatus)

      val defaultMaritalStatus = crosswalkDerivativesContext.broadcastMaritalStatusCW.value
        .find(maritalStatus =>
          maritalStatus.customer.equals(defaultCustomer)
            && maritalStatus.source.equalsIgnoreCase(defaultSource)
            && maritalStatus.sourceType.equalsIgnoreCase(defaultSourceType)
            && maritalStatus.sourceMaritalStatus.equalsIgnoreCase(sourceMaritalStatus)).map(_.maritalStatus)

      if (maritalStatus.isEmpty && defaultMaritalStatus.isDefined) defaultMaritalStatus.get.toString
      else maritalStatus.map(_.toString).orNull
    })

  def race: UserDefinedFunction = udf((sourceRace: String, customer: String, source: String, sourceType: String) => {
    val race = crosswalkDerivativesContext.broadcastRaceCW.value.find(race =>
      race.customer.equals(customer)
        && race.source.equalsIgnoreCase(source)
        && race.sourceType.equalsIgnoreCase(sourceType)
        && race.sourceRace.equalsIgnoreCase(sourceRace)).map(_.race)

    val defaultRace = crosswalkDerivativesContext.broadcastRaceCW.value
      .find(race =>
        race.customer.equals(defaultCustomer)
          && race.source.equalsIgnoreCase(defaultSource)
          && race.sourceType.equalsIgnoreCase(defaultSourceType)
          && race.sourceRace.equalsIgnoreCase(sourceRace)).map(_.race)

    if (race.isEmpty && defaultRace.isDefined) defaultRace.get.toString
    else race.map(_.toString).orNull
  })

  def sex: UserDefinedFunction = udf((sourceSex: String, customer: String, source: String, sourceType: String) => {

    val sex = crosswalkDerivativesContext.broadcastSexCW.value.find(sex =>
      sex.customer.equals(customer)
        && sex.source.equalsIgnoreCase(source)
        && sex.sourceType.equalsIgnoreCase(sourceType)
        && sex.sourceSex.equalsIgnoreCase(sourceSex)).map(_.sex)

    val defaultSex = crosswalkDerivativesContext.broadcastSexCW.value
      .find(sex =>
        sex.customer.equals(defaultCustomer)
          && sex.source.equalsIgnoreCase(defaultSource)
          && sex.sourceType.equalsIgnoreCase(defaultSourceType)
          && sex.sourceSex.equalsIgnoreCase(sourceSex)).map(_.sex)

    if (sex.isEmpty && defaultSex.isDefined) defaultSex.get.toString
    else sex.map(_.toString).orNull

  })

  def dischargeStatus: UserDefinedFunction = udf((sourceDischargeStatus: String) => {


    val defaultDischargeStatus = crosswalkDerivativesContext.broadcastDischargeStatusCW.value
      .find(dischargeStatus =>
        dischargeStatus.customer.equals(defaultCustomer)
          && dischargeStatus.source.equalsIgnoreCase(defaultSource)
          && dischargeStatus.sourceType.equalsIgnoreCase(defaultSourceType)
          && dischargeStatus.sourceDischargeStatus.equalsIgnoreCase(sourceDischargeStatus)).map(_.dischargeStatus)

    defaultDischargeStatus.map(_.toString).orNull
  })

  def exclusionFlag: UserDefinedFunction =
    udf((sourceExclusionFlag: String, customer: String, source: String, sourceType: String) => {
      val exclusionFlag = crosswalkDerivativesContext.broadcastExclusionFlagCW.value.find(exclusionFlag =>
        exclusionFlag.customer.equals(customer)
          && exclusionFlag.source.equalsIgnoreCase(source)
          && exclusionFlag.sourceType.equalsIgnoreCase(sourceType)
          && exclusionFlag.sourceExclusionFlag.equalsIgnoreCase(sourceExclusionFlag)).map(_.exclusionFlag)

      val defaultExclusionFlag = crosswalkDerivativesContext.broadcastExclusionFlagCW.value
        .find(exclusionFlag =>
          exclusionFlag.customer.equals(defaultCustomer)
            && exclusionFlag.source.equalsIgnoreCase(defaultSource)
            && exclusionFlag.sourceType.equalsIgnoreCase(defaultSourceType)
            && exclusionFlag.sourceExclusionFlag.equalsIgnoreCase(sourceExclusionFlag)).map(_.exclusionFlag)

      if (exclusionFlag.isEmpty && defaultExclusionFlag.isDefined) defaultExclusionFlag.get.toString
      else exclusionFlag.map(_.toString).orNull
    })


  def clientLocation = udf((
                             hospitalId: String,
                             clinicId: String,
                             customer: String,
                             source: String,
                             sourceType: String
                           ) => {
    val sourceClientLocationId = if (hospitalId != null) {
      hospitalId
    }
    else {
      clinicId
    }
    val locationId = crosswalkDerivativesContext.broadcastClientToLocationCW.value.find(loc =>
      loc.customer.equals(customer)
        && loc.source.equalsIgnoreCase(source)
        && loc.sourceType.equalsIgnoreCase(sourceType)
        && loc.sourceClient.equalsIgnoreCase(sourceClientLocationId)).map(_.locationId)

    val defaultLocationId = crosswalkDerivativesContext.broadcastClientToLocationCW.value.find(loc =>
      loc.customer.equals(customer)
        && loc.source.equalsIgnoreCase(defaultSource)
        && loc.sourceType.equalsIgnoreCase(defaultSourceType)
        && loc.sourceClient.equalsIgnoreCase(sourceClientLocationId)).map(_.locationId)

    if (locationId.isEmpty && defaultLocationId.isDefined) {
      defaultLocationId.get.toString
    } else {
      locationId.map(_.toString).orNull
    }
  })

  def financialClass: UserDefinedFunction = udf((sourceFinancialClass: String, customer: String,
                                                 source: String, sourceType: String) => {

    val financialClass = crosswalkDerivativesContext.broadcastFinancialClassCW.value.find(financial =>
      financial.customer.equals(customer)
        && financial.source.equalsIgnoreCase(source)
        && financial.sourceType.equalsIgnoreCase(sourceType)
        && financial.financialClassOrig.contains(sourceFinancialClass)).map(_.financialClass)

    val defaultFinancialClass = crosswalkDerivativesContext.broadcastFinancialClassCW.value
      .find(financial =>
        financial.customer.equals(defaultCustomer)
          && financial.source.equalsIgnoreCase(defaultSource)
          && financial.sourceType.equalsIgnoreCase(defaultSourceType)
          && financial.financialClassOrig.contains(sourceFinancialClass)).map(_.financialClass)

    if (financialClass.isEmpty && defaultFinancialClass.isDefined) defaultFinancialClass.get.toString
    else financialClass.map(_.toString).orNull
  })

  def payerType: UserDefinedFunction = udf((sourceFinancialClass: String, customer: String,
                                            source: String, sourceType: String) => {

    val payerType = crosswalkDerivativesContext.broadcastFinancialClassCW.value.find(financial =>
      financial.customer.equals(customer)
        && financial.source.equalsIgnoreCase(source)
        && financial.sourceType.equalsIgnoreCase(sourceType)
        && financial.financialClassOrig.contains(sourceFinancialClass)).map(_.payerType)

    val defaultClientPayerType = crosswalkDerivativesContext.broadcastFinancialClassCW.value
      .find(financial =>
        financial.customer.equals(customer)
          && financial.source.equalsIgnoreCase(defaultSource)
          && financial.sourceType.equalsIgnoreCase(defaultSourceType)
          && financial.financialClassOrig.contains(sourceFinancialClass)).map(_.payerType)


    val defaultPayerType = crosswalkDerivativesContext.broadcastFinancialClassCW.value
      .find(financial =>
        financial.customer.equals(defaultCustomer)
          && financial.source.equalsIgnoreCase(defaultSource)
          && financial.sourceType.equalsIgnoreCase(defaultSourceType)
          && financial.financialClassOrig.contains(sourceFinancialClass)).map(_.payerType)

    if (payerType.isEmpty && defaultClientPayerType.isDefined) {
      defaultClientPayerType.get.toString
    } else if (payerType.isEmpty && defaultClientPayerType.isEmpty && defaultPayerType.isDefined) {
      defaultPayerType.get.toString
    } else {
      payerType.map(_.toString).orNull
    }
  })

  def profitProxy = udf((sourceFinancialClass: String, customer: String,
                          source: String, sourceType: String, charges: Double) => {

    val profitProxy = crosswalkDerivativesContext.broadcastFinancialClassCW.value.find(financial =>
      financial.customer.equals(customer)
        && financial.source.equalsIgnoreCase(source)
        && financial.sourceType.equalsIgnoreCase(sourceType)
        && financial.financialClassOrig.contains(sourceFinancialClass)).map(_.profitProxy.getOrElse(0.0))

    val defaultClientProfitProxy = crosswalkDerivativesContext.broadcastFinancialClassCW.value
      .find(financial =>
        financial.customer.equals(customer)
          && financial.source.equalsIgnoreCase(defaultSource)
          && financial.sourceType.equalsIgnoreCase(defaultSourceType)
          && financial.financialClassOrig.contains(sourceFinancialClass)).map(_.profitProxy.getOrElse(0.0))

    val defaultProfitProxy = crosswalkDerivativesContext.broadcastFinancialClassCW.value
      .find(financial =>
        financial.customer.equals(defaultCustomer)
          && financial.source.equalsIgnoreCase(defaultSource)
          && financial.sourceType.equalsIgnoreCase(defaultSourceType)
          && financial.financialClassOrig.contains(sourceFinancialClass)).map(_.profitProxy.getOrElse(0.0))

    val profitProxy2: Double = (profitProxy, defaultClientProfitProxy, defaultProfitProxy) match {
      case (x, y, z) if x.isEmpty && y.isDefined => y.get
      case (x, y, z) if x.isEmpty && y.isEmpty && z.isDefined => z.get
      case _ => profitProxy.getOrElse(0.0)

    }

    val amount = charges * profitProxy2
    val df: DecimalFormat = new DecimalFormat("00.00")
    df.setMaximumFractionDigits(2)
    new java.math.BigDecimal(df.format(amount.toDouble))
  })

  def dnsReasonFromSource: UserDefinedFunction =
    udf((customer: String, source: String, sourceType: String, sourceDnsReason: String) => {

      val dnsReason = crosswalkDerivativesContext.broadcastDnsReasons.value.find(dns =>
        dns.customer.equals(customer)
          && dns.source.equalsIgnoreCase(source)
          && dns.sourceType.equalsIgnoreCase(sourceType)
          && dns.sourceDnsReason.equalsIgnoreCase(sourceDnsReason)).map(_.dnsReason)

      val defaultDnsReason = crosswalkDerivativesContext.broadcastDnsReasons.value
        .find(dns =>
          dns.customer.equals(defaultCustomer)
            && dns.source.equalsIgnoreCase(defaultSource)
            && dns.sourceType.equalsIgnoreCase(defaultSourceType)
            && dns.sourceDnsReason.equalsIgnoreCase(sourceDnsReason)).map(_.dnsReason)

      if (dnsReason.isEmpty && defaultDnsReason.isDefined) Seq(defaultDnsReason.get.toString)
      else if (dnsReason.isDefined && defaultDnsReason.isEmpty) Seq(dnsReason.get.toString)
      else if (!sourceDnsReason.isNullOrEmpty) Seq(sourceDnsReason)
      else Seq(dnsReason.map(_.toString)).filter(_.isDefined).map(_.get).distinct

    })

  def deceasedFlag: UserDefinedFunction =
    udf((dischargeStatusStr: String, exclusionFlagStr: String, dateOfDeath: Timestamp) => {
      val deceasedDischargeStatuses =
        dischargeStatusDnsLookup.filter(x => x._2.equalsIgnoreCase("Deceased: Client Supplied")).keys.toSeq

      val deceasedExclusionFlags =
        exclusionDnsLookup.filter(x => x._2.equalsIgnoreCase("Deceased: Client Supplied")).keys.toSeq

      if (dischargeStatusStr != null &&
        dischargeStatusStr.nonEmpty &&
        deceasedDischargeStatuses.contains(dischargeStatusStr.toInt)) {
        true
      } else if (exclusionFlagStr != null &&
        exclusionFlagStr.nonEmpty &&
        deceasedExclusionFlags.contains(exclusionFlagStr.toInt)) {
        true
      } else if (dateOfDeath != null) {
        true
      } else {
        false
      }
    })

  def dnsBool: UserDefinedFunction = udf((dischargeStatusStr: String, exclusionFlagStr: String) => {
    val dischargeStatusDns = dischargeStatusStr match {
      case x if x != null && x.nonEmpty &&
        dischargeStatusDnsLookup.filter(x => !x._2.equalsIgnoreCase("Deceased: Client Supplied"))
          .get(x.toInt).nonEmpty =>
        Some(true)
      case _ => None
    }

    val exclusionFlagDns = exclusionFlagStr match {
      case x if x != null && x.nonEmpty &&
        exclusionDnsLookup.filter(x => !x._2.equalsIgnoreCase("Deceased: Client Supplied")).get(x.toInt).nonEmpty =>
        Some(true)
      case _ => None
    }

    val dnsBools = Seq(dischargeStatusDns, exclusionFlagDns).filter(_.isDefined).map(_.get)

    if (dnsBools.isEmpty) None
    else Some(dnsBools.reduce(_ && _))
  })

  def dnsReason: UserDefinedFunction =
    udf((dischargeStatusStr: String, exclusionFlagStr: String, trackingDate: Timestamp) => {
      val trackingDateStr = trackingDate.toString

      val dischargeStatusDns: Option[String] = dischargeStatusStr match {
        case x if x != null && x.nonEmpty =>
          dischargeStatusDnsLookup.filter(x => !x._2.equalsIgnoreCase("Deceased: Client Supplied")).get(x.toInt)
            .map(_ + s";$trackingDateStr")
        case _ => None
      }

      val exclusionFlagDns = exclusionFlagStr match {
        case x if x != null && x.nonEmpty =>
          exclusionDnsLookup.filter(x => !x._2.equalsIgnoreCase("Deceased: Client Supplied")).get(x.toInt)
            .map(_ + s";$trackingDateStr")
        case _ => None
      }

      Seq(dischargeStatusDns, exclusionFlagDns).filter(_.isDefined).map(_.get).distinct
    })
}

object CrosswalkDerivatives {

  val CrosswalkError: String = "~~Crosswalk Error"

  def isCrosswalkError = udf((value: String) => {
    if (value == null || value.isEmpty) {
      false
    } else value.startsWith(CrosswalkDerivatives.CrosswalkError)
  })

}

case class CrosswalkData(
                          broadcastLocationsCW: Broadcast[Seq[LocationCrosswalk]],
                          broadcastClientToLocationCW: Broadcast[Seq[ClientToLocation]],
                          broadcastActivityTypeCW: Broadcast[Seq[ActivityType]],
                          broadcastDnsReasons: Broadcast[Seq[DnsReason]],
                          broadcastSexCW: Broadcast[Seq[Sex]],
                          broadcastRaceCW: Broadcast[Seq[Race]],
                          broadcastMaritalStatusCW: Broadcast[Seq[MaritalStatus]],
                          broadcastDischargeStatusCW: Broadcast[Seq[DischargeStatus]],
                          broadcastExclusionFlagCW: Broadcast[Seq[ExclusionFlag]],
                          broadcastERPatientCW: Broadcast[Seq[ErPatient]],
                          broadcastPatientTypeCW: Broadcast[Seq[PatientType]],
                          broadcastFinancialClassCW: Broadcast[Seq[FinancialClass]]
                        )

object CrosswalkData {
  def apply(
             sparkSession: SparkSession
           ): CrosswalkData = {

    val broadcastLocationsCW: Broadcast[Seq[LocationCrosswalk]] =
      sparkSession.sparkContext.broadcast(LocationCrosswalk.locationCwData)

    val broadcastClientToLocationCW: Broadcast[Seq[ClientToLocation]] =
      sparkSession.sparkContext.broadcast(ClientToLocation.clientToLocationCwData)

    val broadcastActivityTypeCW: Broadcast[Seq[ActivityType]] =
      sparkSession.sparkContext.broadcast(ActivityType.activityTypeCw)

    val broadcastDnsReasonsCW: Broadcast[Seq[DnsReason]] =
      sparkSession.sparkContext.broadcast(DnsReason.dnsReasonCw)

    val broadcastSexCW: Broadcast[Seq[Sex]] =
      sparkSession.sparkContext.broadcast(Sex.sexCw)

    val broadcastRaceCW: Broadcast[Seq[Race]] =
      sparkSession.sparkContext.broadcast(Race.raceCw)

    val broadcastMaritalStatusCW: Broadcast[Seq[MaritalStatus]] =
      sparkSession.sparkContext.broadcast(MaritalStatus.maritalStatusCw)

    val broadcastDischargeStatusCW: Broadcast[Seq[DischargeStatus]] =
      sparkSession.sparkContext.broadcast(DischargeStatus.dischargeStatusCw)

    val broadcastExclusionFlagCW: Broadcast[Seq[ExclusionFlag]] =
      sparkSession.sparkContext.broadcast(ExclusionFlag.exclusionFlagCw)

    val broadcastERPatientCW: Broadcast[Seq[ErPatient]] =
      sparkSession.sparkContext.broadcast(ErPatient.erPatientCw)

    val broadcastPatientTypeCW: Broadcast[Seq[PatientType]] =
      sparkSession.sparkContext.broadcast(PatientType.patientTypeCw)

    val broadcastFinancialClassCW: Broadcast[Seq[FinancialClass]] =
      sparkSession.sparkContext.broadcast(FinancialClass.financialClassCw)

    new CrosswalkData(
      broadcastLocationsCW,
      broadcastClientToLocationCW,
      broadcastActivityTypeCW,
      broadcastDnsReasonsCW,
      broadcastSexCW,
      broadcastRaceCW,
      broadcastMaritalStatusCW,
      broadcastDischargeStatusCW,
      broadcastExclusionFlagCW,
      broadcastERPatientCW,
      broadcastPatientTypeCW,
      broadcastFinancialClassCW)
  }
}

