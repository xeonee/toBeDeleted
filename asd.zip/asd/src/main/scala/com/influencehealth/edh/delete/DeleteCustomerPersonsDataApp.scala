package com.influencehealth.edh.delete

import com.influencehealth.edh.CustomLazyLogging

object DeleteCustomerPersonsDataApp extends CustomLazyLogging {

  case class Stats(tableName: String, recordsDeleted: Long, distinctPersons: Long)

  def main(args: Array[String]): Unit = {

    // TODO: Wrap with BaldurApplicationConfig
    val customer = ???

    logger.info(
      s"""
         |  **************************************************************************************************
         |  * WARNING: This process will DELETE customer data for $customer. The data for $customer
         |  * will no longer be available!!!
         |  **************************************************************************************************
         |
         |  Press 'Y' to continue...""".stripMargin)
    val input = scala.io.StdIn.readChar()

    input match {
      case x: Char if x.equals('y') || x.equals('Y') =>
        logger.info("Starting cleanup process...")

        deleteActivities(customer)
        deleteAddresses(customer)

        logger.info("Done.")

      case _ => logger.info("Cancelling process.")
    }
  }

  def deleteActivities(customer: String): Unit = {}

  def deleteAddresses(customer: String): Unit = {}

}
