package com.influencehealth.edh.enrich.activity.caregrouper

import com.influencehealth.edh.CustomLazyLogging
import mojolly.inflector.Inflector
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

object CareGroupersFileHandler extends CustomLazyLogging {

  val InPatientColumns = Seq("customer", "batch_id", "activity_id", "Sg2_CARE_Group_Code",
    "Sg2_CARE_Group_Description", "Sg2_Service_Line_Group", "Sg2_CARE_Family", "Sg2_Procedure",
    "Sg2_Procedure_Group", "Mental_Health_Conditions", "Addiction_Adult", "Behavioral_Health_Conditions_Adult",
    "Diabetes_Adult", "Cardiac_Disease_Adult", "Pulmonary_Disease_Adult", "Adult_Chronic_Conditions_Count",
    "Asthma_Pediatric", "Behavioral_Health_Conditions_Pediatric", "Complex_Cardiac_Conditions_Pediatric",
    "Pediatric_Complex_Conditions_Count", "Trauma", "Sg2_Service_Line")

  val OutPatientColumns: Seq[String] = InPatientColumns ++ Seq("Sg2_Procedure_Group_Category",
    "Sports_Medicine", "Pain_Services", "Primary_Care_All_Adults", "Primary_Care_Geriatrics",
    "Primary_Care_Pediatrics")

  /**
    * Processes the caregrouper's script file and generates the enriched caregrouper dataframe
    *
    * @param sparkSession
    * @param patientType
    * @param fileNameForPatient
    * @param downloadFolder
    * @return
    */
  def processSg2Application(
                             sparkSession: SparkSession,
                             patientType: String,
                             fileNameForPatient: String,
                             downloadFolder: String,
                             careGrouperScriptPath: String
                           ): DataFrame = {
    val exitCode: Int = executeCareGrouperCommand(careGrouperScriptPath, patientType, fileNameForPatient)
    val sg2Output: DataFrame = readInputCareGrouperFile(
      sparkSession,
      exitCode,
      downloadFolder,
      fileNameForPatient)

    modifyColumnNames(sg2Output, patientType).
      transform(df => df.select(df.columns.map(c => col(c) as Inflector.camelize(c)): _*))
  }

  /**
    * Executes the shell script which processes the output care grouper files, runs sg2 commands based on patient types
    * & downloads the input file
    *
    * @param fileType
    * @param fileName
    * @return
    */
  def executeCareGrouperCommand(careGrouperScriptPath: String, fileType: String, fileName: String): Int = {
    import scala.sys.process._
    val submitCareGrouperCmd = s"$careGrouperScriptPath/submit_caregroupers_file.sh $fileName $fileType"
    submitCareGrouperCmd.!
  }

  /**
    * Reads the enriched caregrouper input file in spark
    *
    * @param sparkSession
    * @param exitCode
    * @param downloadFolder
    * @param fileName
    * @return enriched care grouper dataframe
    */
  def readInputCareGrouperFile(sparkSession: SparkSession, exitCode: Int, downloadFolder: String,
                               fileName: String): DataFrame = {
    if (exitCode == 0) {
      logger.info(s"Loading the output file from $downloadFolder/output_$fileName")
      sparkSession.read.option("header", "true").option("delimiter", "|").csv(s"$downloadFolder/output_$fileName")
    }
    else {
      throw new RuntimeException("Failed to generate Output file.")
    }
  }

  /**
    * Modifies the enriched caregrouper column names to match the cleansed_activities column names
    *
    * @param df
    * @param patientType
    * @return
    */
  def modifyColumnNames(df: DataFrame, patientType: String): DataFrame = {

    val selectedColumnsDf = patientType match {
      case "InPatient" => df.select(InPatientColumns.map(c => col(c)): _*)
      case "OutPatient" => df.select(OutPatientColumns.map(c => col(c)): _*).
        withColumnRenamed("Sg2_Procedure_Group_Category", "procedure_group_category")
      case _ => throw new RuntimeException("Patient type not found.")
    }
    val renamedColumnsDf: DataFrame = selectedColumnsDf

      // TODO:  - add service_lines to populate from primary_service_line col.
      //        - purpose of two columns having same value
      .withColumnRenamed("Sg2_Service_Line", "service_line")
      .withColumnRenamed("Sg2_CARE_Group_Code", "care_group_code")
      .withColumnRenamed("Sg2_CARE_Group_Description", "care_group_description")
      .withColumnRenamed("Sg2_Service_Line_Group", "service_line_group")
      .withColumnRenamed("Sg2_CARE_Family", "care_family")
      .withColumnRenamed("Sg2_Procedure", "procedure")
      .withColumnRenamed("Sg2_Procedure_Group", "procedure_group")
      .withColumn("date_modified", lit(current_timestamp()))

    renamedColumnsDf.toDF(renamedColumnsDf.columns.map(_.toLowerCase): _*)
  }

  /**
    * Get random CPT code from a list of multiple cpt codes
    *
    * @return
    */
  def getPrimaryService: UserDefinedFunction = udf((serviceLineGroup: String) => {
    if (serviceLineGroup != null && serviceLineGroup.nonEmpty) {
      Some(List(serviceLineGroup))
    }
    else {
      None
    }
  })
}
