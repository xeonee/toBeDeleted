package com.influencehealth.edh.model.schema

import org.apache.spark.sql.types.{StringType, StructField, StructType}

object DonorListSchema {

  val trueFlag: Boolean = true
  val falseFlag: Boolean = false

  val donorlistSchema: StructType = StructType(
    Array(
      StructField("sourceType", StringType, trueFlag),
      StructField("source", StringType, trueFlag),
      StructField("sourceRecordId", StringType, trueFlag),
      StructField("prefix", StringType, trueFlag),
      StructField("lastName", StringType, trueFlag),
      StructField("firstName", StringType, trueFlag),
      StructField("middleName", StringType, trueFlag),
      StructField("personalSuffix", StringType, trueFlag),
      StructField("professionalSuffix", StringType, trueFlag),
      StructField("addressType", StringType, trueFlag),
      StructField("addressStatus", StringType, trueFlag),
      StructField("address1", StringType, trueFlag),
      StructField("address2", StringType, trueFlag),
      StructField("city", StringType, trueFlag),
      StructField("state", StringType, trueFlag),
      StructField("zip5", StringType, trueFlag),
      StructField("sourceSex", StringType, trueFlag),
      StructField("dateOfBirth", StringType, trueFlag),
      StructField("phoneNumbers", StringType, trueFlag),
      StructField("emails", StringType, trueFlag)
    )
  )
}
