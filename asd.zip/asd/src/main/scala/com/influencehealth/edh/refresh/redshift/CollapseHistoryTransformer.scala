package com.influencehealth.edh.refresh.redshift

import com.influencehealth.edh.model.CollapseHistory
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.apache.spark.storage.StorageLevel

class CollapseHistoryTransformer (collapseHistoryData: Dataset[CollapseHistory],
                                  sparkSession: SparkSession) extends BaseTransformer with Serializable {


  val deNormalizedCollapseHistoryData: DataFrame = collapseHistoryData.toDF.
    persist(StorageLevel.MEMORY_ONLY)

  val collapseHistory: DataFrame = deNormalizedCollapseHistoryData.
      transform(dropComplexTypes).
      transform(aliasColumnsToSnakeCase)

  val close: Unit = deNormalizedCollapseHistoryData.unpersist()

}
