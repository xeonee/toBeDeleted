package com.influencehealth.edh.model.schema

import org.apache.spark.sql.types.{StringType, StructField, StructType}

object DeceasedPersonsSchema {

  // the structure of the deceased people file
  val schema: StructType = StructType(Array(
    StructField("recordType", StringType, nullable = true),
    StructField("socialSecurity", StringType, nullable = true),
    StructField("lastName", StringType, nullable = true),
    StructField("nameSuffix", StringType, nullable = true),
    StructField("firstName", StringType, nullable = true),
    StructField("middleName", StringType, nullable = true),
    StructField("verifiedOrProofCode", StringType, nullable = true),
    StructField("dateOfDeath", StringType, nullable = true),
    StructField("dateOfBirth", StringType, nullable = true)
  ))

}
