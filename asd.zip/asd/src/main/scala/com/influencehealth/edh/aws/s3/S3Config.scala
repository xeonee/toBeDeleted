package com.influencehealth.edh.aws.s3

import com.typesafe.config.Config
import org.apache.hadoop.conf.Configuration

case class S3Config(accessKey: String, secretKey: String) {

  def configureS3(hadoopConf: Configuration): Unit = {
    hadoopConf.set("fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
    hadoopConf.set("fs.s3a.access.key", accessKey)
    hadoopConf.set("fs.s3a.secret.key", secretKey)
    hadoopConf.set("fs.s3a.server-side-encryption-algorithm", "AES256")
    hadoopConf.set("fs.s3a.attempts.maximum", "30")
    hadoopConf.set("fs.s3a.multiobjectdelete.enable","false") // Fixes: AWS Error Code: null, AWS Error Message: One or more objects could not be deleted, S3 Extended Request ID: null
  }
}

object S3Config {

  def apply(appConfig: Config): S3Config = {
    val s3AccessKey = appConfig.getString("aws-accesskey")
    val s3SecretKey = appConfig.getString("aws-secretkey")
    S3Config(s3AccessKey, s3SecretKey)
  }


}