package com.influencehealth.edh.linker

import com.influencehealth.edh.model.Person
import com.influencehealth.edh.updater.PersonUpdaterImpl
import com.influencehealth.edh.personmatching.PersonMatcher
import com.influencehealth.edh.personmatching.PersonMatcher.BlockingKey
import org.apache.spark.util.LongAccumulator

import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks

trait PersonLinkerImpl extends Serializable {


  def mergeMatchedCollapsedCandidates(
                                       accumulator: LongAccumulator,
                                       potentialMatches: Iterator[IdentityEntity[Person]],
                                       blockingKey: BlockingKey
                                     ): Iterator[IdentityEntity[Person]] = {
    var mutableMatches: ListBuffer[IdentityEntity[Person]] = new collection.mutable.ListBuffer[IdentityEntity[Person]]()
    potentialMatches.foreach(candidate => mutableMatches += candidate)
    var matchFound: Boolean = true
    val MatchingLoopBreak: Breaks = new Breaks
    while (matchFound) {
      MatchingLoopBreak.breakable {
        for (candidate1 <- mutableMatches) {
          for (candidate2 <- mutableMatches.filter(_ != candidate1)) {
            if (originateFromTheSamePerson(blockingKey, candidate1.entity, candidate2.entity)) {
              val mergedCandidate: IdentityEntity[Person] = mergeCandidate(candidate1, candidate2, blockingKey)
              mutableMatches -= candidate1 -= candidate2 += mergedCandidate
              accumulator.add(1)
              MatchingLoopBreak.break()
            }
          }
        }
        matchFound = false
      }
    }
    mutableMatches.toIterator
  }


  def originateFromTheSamePerson(blockingKey: BlockingKey, candidate1: Person, candidate2: Person): Boolean = {
    PersonMatcher.isSamePerson(candidate1, candidate2, blockingKey)
  }

  /**
    * Merges candidates confirmed as duplicates with most recent information. Address related fields are updated
    * atomically. All other identifying fields are updated separately
    *
    * @param candidate1
    * @param candidate2
    * @param blockingKey
    * @return
    */
  def mergeCandidate(
                      candidate1: IdentityEntity[Person],
                      candidate2: IdentityEntity[Person],
                      blockingKey: BlockingKey
                    ): IdentityEntity[Person] = {

    val Seq(oldestCandidate, newestCandidate) =
      if (candidate1.origin == "person") {
        if (candidate2.origin == "person") {
          Seq(candidate1, candidate2).
            sortBy(_.entity.dateCreated.getTime)
        } else {
          Seq(candidate1, candidate2)
        }
      } else {
        if (candidate2.origin == "person") {
          Seq(candidate2, candidate1)
        } else {
          Seq(candidate1, candidate2).
            sortBy(_.entity.dateCreated.getTime)
        }
      }

    oldestCandidate.copy(entity = PersonUpdaterImpl.updatePerson(oldestCandidate.entity, newestCandidate.entity))
  }

}
