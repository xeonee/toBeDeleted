
package com.influencehealth.edh.utilities.fixture

import com.influencehealth.edh.aws.s3.S3Config
import com.influencehealth.edh.config._
import com.influencehealth.edh.dao.{DatabaseDao, EncounterFileType, FileSystemDao, S3FileSystemDao}
import com.influencehealth.edh.lookup_clients.support.ServiceArea
import com.influencehealth.edh.lookups.client.LookupsClient
import com.influencehealth.edh.lookups.messages.Location
import com.influencehealth.edh.utils.FileUtilities
import com.influencehealth.edh.{BaldurApplication, SuccessfulBaldurJob}
import com.typesafe.config.Config
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
  * Created by pallavi.karan on 10/30/17.
  */
object CreateFixtureApp extends BaldurApplication[EnrichJobConfig] {

  val Delimiter = "|"
  val sampleWithReplacementFlag: Boolean = false // Sample with replacement or not, in spark's sample function

  var inputRecordCount: Option[Long] = None
  var outputRecordCount: Option[Long] = None

  override def runJob(implicit sparkSession: SparkSession, config: EnrichJobConfig, databaseDao: DatabaseDao) = {

    val sampleSize: Int = ??? // TODO: appConfig.getInt("app.sample-rows")
    val s3URL: String = ??? // TODO: appConfig.getString("app.load.file-path")
    val saveOutputFolderPath = ??? // TODO: appConfig.getString("app.deidentified-fixtures-save-path")
    val outputFolder: String = ??? // TODO: artifactName.concat("_").concat(Constants.Now.toString)

    val sparkSession = SparkSession.builder().getOrCreate()
    // Applying S3 configurations
    if (s3URL.startsWith("s3a://") || s3URL.startsWith("s3n://")) {
      val accessKey: String = ??? // TODO: appConfig.getString("aws-accesskey")
      val secretKey: String = ??? // TODO: appConfig.getString("aws-secretkey")
      val s3Config = S3Config(accessKey, secretKey)
      s3Config.configureS3(sparkSession.sparkContext.hadoopConfiguration)
    }

    val fileSystemDao: FileSystemDao = new S3FileSystemDao(sparkSession, appConfig, s3client)

    // Load Utilization files
    val loadedListOfFiles: DataFrame = fileSystemDao.readCleansedFile(s3URL).toDF()

    // Samples dataFrame
    val sampledDataFrame = sampleDataFrame(loadedListOfFiles, sampleSize).persist(StorageLevel.MEMORY_AND_DISK)

    // De-Identify dataFrame
    val deIdentifiedDataFrame: DataFrame = DeIdentifier.deIdentifyEncounterData(sampledDataFrame).
      persist(StorageLevel.MEMORY_AND_DISK)

    // Extract required columns and split into multiple dataFrames
    val listOfFileTypesAndExtractedDataFrames: List[(EncounterFileType, DataFrame)] =
      DeIdentifier.generateListsOfDeidentifiedDataFrames(deIdentifiedDataFrame)

    // Save all the dataFrames
    saveAllDataFrames(sparkSession, listOfFileTypesAndExtractedDataFrames,
      saveOutputFolderPath, outputFolder)

    sampledDataFrame.unpersist()
    deIdentifiedDataFrame.unpersist()
  }

  /**
    * Saves all the dataFrames present in the list
    *
    * @param listOfDfs list of dataFrames to save
    */
  def saveAllDataFrames(sparkSession: SparkSession, listOfDfs: List[(EncounterFileType, DataFrame)], outputFolderPath: String,
                        outputFolder: String):
  Unit = {

    for (x <- listOfDfs) {
      FileUtilities.saveCsvToS3(sparkSession, x._2, Delimiter, x._1.toString, outputFolderPath.concat("/").
        concat(outputFolder), false)
    }
  }

  /**
    * Join the remaining dataframes with joinedDemogAndVisit based on sourcePersonId and sourceRecordId
    *
    * @param dataFrameToBeSampled df to be sampled
    * @param numberOfRows         sample size
    * @return a sampled dataframe
    */
  def sampleDataFrame(dataFrameToBeSampled: DataFrame, numberOfRows: Int): DataFrame = {
    val sampleCount = dataFrameToBeSampled.count()
    val fractionToBeSampled: Double = numberOfRows.toDouble / sampleCount
    if (fractionToBeSampled > 1) throw new RuntimeException(s"Sample size[${numberOfRows.toInt}] > " +
      s"available size[$sampleCount]")

    val sampledDataFrame = dataFrameToBeSampled.sample(sampleWithReplacementFlag, fractionToBeSampled)
    sampledDataFrame
  }


  override def buildConfig(appConfig: Config, lookupsClient: LookupsClient): EnrichJobConfig = {
    val customer: String = appConfig.getString("")
    val customerLocations: Seq[Location] = lookupsClient.
      getLocations.filter(_.ClientKey == customer)
    val customerServiceAreas: Set[ServiceArea] = customerLocations.flatMap(ServiceArea.create).toSet
    val databaseConfig: Option[DatabaseConfig] = Some(PostgresConfig(appConfig))
    val anchorConfig: Option[AnchorConfig] = Some(AnchorConfig(appConfig))
    val sg2Config: Option[SG2Config] = Some(SG2Config(appConfig))
    EnrichJobConfig(
      appConfig,
      customerLocations,
      customerServiceAreas,
      databaseConfig,
      anchorConfig,
      sg2Config
    )
  }

  override def countInputRecords = {
    inputRecordCount
  }

  override def countOutputRecords = {
    outputRecordCount
  }

}