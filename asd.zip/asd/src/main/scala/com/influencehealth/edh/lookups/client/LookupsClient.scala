package com.influencehealth.edh.lookups.client

import com.influencehealth.edh.lookup_clients.support.ServiceArea
import com.influencehealth.edh.lookups.messages.{Customer, FinancialClass, Location}


/**
  * Trait for defining interface for calls to the lookups microserivce
  */
trait LookupsClient {

  def getCustomers: Set[Customer]

  def getIndexName(customerId: Int): Option[String]

  def getLocations: Seq[Location]

  // filterTypes(config.noAuthRouteConfig.filterType, amqpConfig)
  def getFinancialClasses: Seq[FinancialClass]

  def getServiceAreas: Set[ServiceArea]

  def getApplicableCustomerAndZips(optEdhCustomerId: Option[Int]): Set[(String, Int)] = {
    val customers: Set[Customer] = getCustomers
    val edhCustomersAndZips = getLocations.
      flatMap(location => location.AvailableZipCodes.map(zip => (location.ClientKey, zip))).
      flatMap { case (clientKey, zip) =>
        customers.find(_.Key == clientKey).map(customer => (zip, customer.Id))
      }.toSet
    if (optEdhCustomerId.isDefined) {
      edhCustomersAndZips.filter(_._2 == optEdhCustomerId.get)
    } else {
      edhCustomersAndZips
    }
  }

}



