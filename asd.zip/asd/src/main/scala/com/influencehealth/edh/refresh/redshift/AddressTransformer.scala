package com.influencehealth.edh.refresh.redshift

import com.influencehealth.edh.model.Address
import org.apache.spark.sql.functions.to_json
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.apache.spark.storage.StorageLevel

private[redshift] class AddressTransformer (addressData: Dataset[Address],
                                            sparkSession: SparkSession
                                           ) extends BaseTransformer with Serializable {

  import sparkSession.implicits._

  val columnsWithSizeMoreThan256: Map[String, Int] = Map("address_coordinates" -> 1024)

  val deNormalizedAddressData: DataFrame = addressData.
    withColumn("addressCoordinates", to_json($"addressCoordinates").cast(StringType))


  val addresses: DataFrame = deNormalizedAddressData.transform(dropComplexTypes).transform(aliasColumnsToSnakeCase).
    transform(applyMetadataToTempTables(columnsWithSizeMoreThan256, _)).persist(StorageLevel.MEMORY_ONLY)

  val close: Unit = addresses.unpersist()


}
