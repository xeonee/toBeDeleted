package com.influencehealth.edh.utils
import org.apache.spark.sql.DataFrame

object SparkOptimizer {

  def repartitionDataFrames(df: DataFrame, maxParquetPartitions: Int, numberOfCores: Int): DataFrame ={

    val currentNumberOfPartitions = df.rdd.partitions.size
    val reScalePartitionsValue = {
      math.ceil(currentNumberOfPartitions / maxParquetPartitions.toDouble)
    }
      val refinedNumberOfPartitions = reScalePartitionsValue * numberOfCores
    df.coalesce(refinedNumberOfPartitions.toInt)
  }

}
