package com.influencehealth.edh.dao

import java.io.FileNotFoundException
import java.net.URI
import java.time.LocalDate
import java.time.temporal.ChronoUnit

import com.amazonaws.services.s3.AmazonS3
import com.amazonaws.services.s3.model._
import com.influencehealth.edh.Constants
import com.influencehealth.edh.config.CleanseJobConfig
import com.influencehealth.edh.model.Activity
import com.influencehealth.edh.model.schema._
import com.influencehealth.edh.utils.filesystem.PathInfo
import com.influencehealth.edh.utils.{DataLakeUtilities, FileUtilities, S3Utilities}
import com.typesafe.config.Config
import com.typesafe.scalalogging.LazyLogging
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._

import scala.collection.JavaConversions._
import scala.collection.mutable
import scala.util.{Failure, Success, Try}

class S3FileSystemDao(
                       sparkSession: SparkSession,
                       appConfig: Config,
                       s3Client: AmazonS3
                     ) extends FileSystemDao with LazyLogging {


  val maxParquetPartitions = appConfig.getInt("app.maxParquetPartitions")
  val executorCores = appConfig.getInt("app.executor-cores")
  val bucketUrl: String = appConfig.getString("s3.datalake.bucket")

  override def saveParquetFile(
                                dataFrame: DataFrame,
                                outputPath: String,
                                maxParquetPartitions: Int,
                                executorCores: Int,
                                saveMode: SaveMode// ,
                                // partitioningColumns: String*
                              ): Unit = {
    dataFrame.
      write.mode(saveMode).parquet(outputPath)
    //    if (partitioningColumns.nonEmpty) {
    //      dataFrame.
    //        write.partitionBy(partitioningColumns: _*).
    //        mode(SaveMode.Overwrite).parquet(outputPath)
    //    } else {
    //      dataFrame.
    //        write.mode(SaveMode.Overwrite).parquet(outputPath)
    //    }
  }

  override def loadCSVFile(force: Boolean, schema: StructType, delimiter: String, paths: String*): DataFrame = {

    sparkSession.read.
      option("header", false).
      option("delimiter", delimiter).
      schema(schema).csv(paths: _*)
  }

  def getFileExtension(
                        inputDirectoryPath: String
                      ): String = {

    val bucketName = DataLakeUtilities.extractBucketNameFromS3RawBatchUrl(inputDirectoryPath)
    val objectName = DataLakeUtilities.extractS3SourcePrefixForFileArchival(inputDirectoryPath)
    val availableListOfFiles: Seq[String] = getAvailableBatchDirectoryUrlsForInputBatchId(
      s"s3a://$bucketName", objectName).filterNot(_.endsWith("/"))


    availableListOfFiles.
      filterNot(_.endsWith(".done")).head.split("\\.").lastOption.getOrElse {
      throw new RuntimeException(s"Only found .done files at path, $inputDirectoryPath")
    }
  }

  override def loadFixedWidthFile(
                                   force: Boolean,
                                   schema: StructType,
                                   fieldSizes: Array[Int],
                                   paths: String*
                                 ): DataFrame = {
    import com.influencehealth.edh.spark.csv.FixedWidthContext
    sparkSession.sqlContext.fixedWidthFile(
      useHeader = false,
      filePath = paths.mkString(","),
      fixedWidths = fieldSizes,
      schema = schema,
      ignoreLeadingWhiteSpace = false,
      ignoreTrailingWhiteSpace = false,
      skipEmptyLines = true
    )
  }

  def validateFilesHaveNotBeenProcessed(force: Boolean, paths: String*) = {
    if (paths.exists(p => hasFileBeenProcessed(PathInfo(p, Constants.batchRawPhase))) && !force) {
      throw new RuntimeException(s"Files have already be processed. Try running using --force")
    }
  }

  override def readHRAFile(force: Boolean, format: String, paths: String*): Map[HRAFileType, DataFrame] = {
    validateFilesHaveNotBeenProcessed(force, paths: _*)
    val (delimiter, requiredFiles) = if (format == Constants.HraMedicomFormat) {
      (",", ListOfRequiredFilesForHra)
    } else if (format.toUpperCase == Constants.HraHealthWareFormat) {
      ("|", ListOfRequiredFilesForHealthwareHra)
    } else {
      throw new RuntimeException("Unknown HRA Version detected")
    }

    requiredFiles.map {
      case (fileType: HRAFileType, fileNamePrefix: String, hraSchema: StructType) =>
        (fileType, loadCSVFile(force, hraSchema, delimiter, paths: _*))

    }.toMap

  }

  override def readDeceasedFile(force: Boolean, paths: String*): DataFrame = {
    validateFilesHaveNotBeenProcessed(force, paths: _*)
    loadFixedWidthFile(force, DeceasedPersonsSchema.schema, FieldSizesForDeceased, paths: _*)
  }

  override def readDoNotSolicitFile(force: Boolean, paths: String*): DataFrame = {
    validateFilesHaveNotBeenProcessed(force, paths: _*)
    loadExcelFormatData(DnsSchema.DnsSchema, paths.head)
  }

  override def readDoNotSolicitUpdateFile(force: Boolean, paths: String*): DataFrame = {
    validateFilesHaveNotBeenProcessed(force, paths: _*)
    loadCSVFile(force, DnsUpdateSchema.dnsUpdateSchema, "|", paths: _*).
      transform(df => filterBasicHeaderRows(df, "optOutDirectMail"))
  }

  override def readDonorListFile(force: Boolean, paths: String*): DataFrame = {
    validateFilesHaveNotBeenProcessed(force, paths: _*)
    loadCSVFile(force, DonorListSchema.donorlistSchema, "|", paths: _*).
      transform(df => filterBasicHeaderRows(df, "zip5"))
  }

  override def readEmployeeRosterFile(force: Boolean, paths: String*): DataFrame = {
    validateFilesHaveNotBeenProcessed(force, paths: _*)
    loadCSVFile(force, EmployeeRosterSchema.employeeRosterSchema, "|", paths: _*).
      transform(df => filterBasicHeaderRows(df, "employeeId"))
  }

  override def readMarketingListFile(force: Boolean, paths: String*): DataFrame = {
    validateFilesHaveNotBeenProcessed(force, paths: _*)
    val potentialExtenions: Seq[String] = paths.map(getFileExtension).distinct
    if (potentialExtenions.length > 1) {
      throw new RuntimeException(s"Too many file extensions for marketing list: ${potentialExtenions.mkString(",")}")
    }
    val fileExtension: String = potentialExtenions.head
    if (fileExtension.equalsIgnoreCase("csv")) {
      loadCSVFile(force, MarketingListSchema.marketinglistSchema, ",", paths:_*)
    } else if (fileExtension.equalsIgnoreCase("xlsx")) {
      loadExcelFormatData(MarketingListSchema.marketinglistSchema, paths.head)
    } else {
      throw new RuntimeException(s"Unknown format for marketing list type: $fileExtension")
    }

  }

  override def readProspectFile(force: Boolean, paths: String*): DataFrame = {
    validateFilesHaveNotBeenProcessed(force, paths: _*)
    /**
      * We have issue with input prospect file, where we are getting additional blank record at end of the file
      * as it's fix width file it's reading and cleansed job is failing. Hence, we are removing
      * the last additional record from file while reading it so cleanse job run without any issue.
      */

    val globFilePaths: Seq[String] = paths.map(_.concat("Cnsv_[0-9]*.txt"))
    val loadedFile: DataFrame = loadFixedWidthFile(
      force, ProspectSchema.prospectSchema, FieldSizesForProspect, globFilePaths: _*)
    val total = loadedFile.count()
    val removeTail = loadedFile.rdd.zipWithIndex().filter(x => x._2 < total - 1).map(x => x._1)
    val finalDfWithloadedFile: DataFrame = sparkSession.sqlContext.createDataFrame(
      removeTail, StructType(loadedFile.schema.fields))
    finalDfWithloadedFile
  }

  override def readNewMoverFile(force: Boolean, paths: String*): DataFrame = {
    validateFilesHaveNotBeenProcessed(force, paths: _*)
    loadCSVFile(force, NewMoversSchema.schema, ",", paths: _*).
      transform(df => filterBasicHeaderRows(df, "firstName"))
  }

  override def readReferralFile(force: Boolean, paths: String*): DataFrame = {
    validateFilesHaveNotBeenProcessed(force, paths: _*)
    loadCSVFile(force, ReferralSchema.referralSchemaV1, "|", paths: _*).
      transform(df => filterBasicHeaderRows(df, "firstName"))
  }

  override def readEncounterFiles(force: Boolean, paths: String*): Map[EncounterFileType, DataFrame] = {
    validateFilesHaveNotBeenProcessed(force, paths: _*)

    val Delimiter = "|"

    val listOfMandatoryFileNames: List[String] = List(
      Demographic, Diagnosis, CurrentProceduralTerminology, Facility, Visit)
    val listOfNonMandatoryFileNames: List[String] = List(
      Prognosis, Guarantor, Biometric, Physician, Financial)

    val listOfFiles = listOfMandatoryFileNames ++ listOfNonMandatoryFileNames

    paths.flatMap { path => getListOfEncounterFiles(path)
    }.groupBy { path =>
      listOfFiles.find(fileType => path.toLowerCase().contains(fileType.toLowerCase()))
    }.filterKeys(_.nonEmpty).
      map { case (k, v) => (k.get, v) }.map {
      case (Demographic, filePaths) =>
        (DemographicFile, loadCSVFile(force, EncounterSchema.demographicSchema, Delimiter, filePaths: _*))
      case (Diagnosis, filePaths) =>
        (DiagnosisFile, loadCSVFile(force, EncounterSchema.diagnosisSchema, Delimiter, filePaths: _*))
      case (CurrentProceduralTerminology, filePaths) =>
        (
          CurrentProceduralTerminologyFile,
          loadCSVFile(force, EncounterSchema.currentProceduralTerminologySchema, Delimiter, filePaths: _*)
        )
      case (Facility, filePaths) =>
        (FacilityFile, loadCSVFile(force, EncounterSchema.facilitySchema, Delimiter, filePaths: _*))
      case (Visit, filePaths) =>
        (VisitFile, loadCSVFile(force, EncounterSchema.visitSchema, Delimiter, filePaths: _*))
      case (Prognosis, filePaths) =>
        (PrognosisFile, loadCSVFile(force, EncounterSchema.prognosisSchema, Delimiter, filePaths: _*))
      case (Guarantor, filePaths) =>
        (GuarantorFile, loadCSVFile(force, EncounterSchema.guarantorSchema, Delimiter, filePaths: _*))
      case (Biometric, filePaths) =>
        (BiometricFile, loadCSVFile(force, EncounterSchema.biometricSchema, Delimiter, filePaths: _*))
      case (Physician, filePaths) =>
        (
          PhysicianFile,
          loadCSVFile(force, EncounterSchema.physicianSchema, Delimiter, filePaths: _*)
        )
      case (Financial, filePaths) =>
        (FinancialFile, loadCSVFile(force, EncounterSchema.financialSchema, Delimiter, filePaths: _*))
    }.map {
      case (PhysicianFile, dataFrame) =>
        (
          PhysicianFile,
          dataFrame.
            transform(df => filterBasicHeaderRows(df, "primaryCarePhysicianId"))
        )
      case (fileType, dataFrame) =>
        (
          fileType,
          dataFrame.
            transform(df => df.filter(
              prepValueForComparision(df("sourcePersonId")) =!= "PATIENTID" &&
                prepValueForComparision(df("sourcePersonId")) =!= "MRN" &&
                prepValueForComparision(df("sourcePersonId")) =!= "MEDICALRECORD"
            ))
        )
    }
  }

  def prepValueForComparision = udf[String, String](str =>
    Option(str).
      map(_.
        replaceAll("_", "").
        replaceAll("\\s", "").
        toUpperCase()).
    orNull
  )

  /**
    * Get list of utilization files from a given file path or s3 url path
    *
    * @param inputDirectoryPath
    * @param s3Client
    * @return
    */
  def getListOfEncounterFiles(inputDirectoryPath: String): List[String] = {
    var availableListOfFiles: List[String] = List()
    if (inputDirectoryPath.startsWith("s3")) {
      val bucketName = DataLakeUtilities.extractBucketNameFromS3RawBatchUrl(inputDirectoryPath)
      val objectName = DataLakeUtilities.extractS3SourcePrefixForFileArchival(inputDirectoryPath)
      availableListOfFiles =
        getAvailableBatchDirectoryUrlsForInputBatchId(s"s3a://$bucketName", objectName)
    }
    else {
      availableListOfFiles = FileUtilities.getListOfFileNames(inputDirectoryPath, ".txt")
    }

    val listOfMandatoryFileNames: List[String] = List("demog", "dx", "cpt", "facility", "visit")
    val listOfNonMandatoryFileNames: List[String] = List("px", "guarantor", "biometric", "physician", "financial")

    val missingListOfMandatoryFileNames = listOfMandatoryFileNames.filterNot(
      fileName => availableListOfFiles.exists(x =>
        x.toLowerCase().split("/").last.contains(fileName)))

    val missingListOfNonMandatoryFileNames = listOfNonMandatoryFileNames.filterNot(
      fileName => availableListOfFiles.exists(x => x.toLowerCase().split("/").last.contains(fileName)))

    if (missingListOfMandatoryFileNames.nonEmpty) {
      throw new FileNotFoundException(s"${missingListOfMandatoryFileNames.mkString(",")} files not found")
    }

    if (missingListOfNonMandatoryFileNames.nonEmpty) {
      logger.warn(s"${missingListOfNonMandatoryFileNames.mkString(",")} files not found")
    }

    availableListOfFiles

  }

  override def readCallCenterFile(force: Boolean, format: String, paths: String*): DataFrame = {
    validateFilesHaveNotBeenProcessed(force, paths: _*)

    val dataFrame = format.toUpperCase match {
      case Constants.CallCenterSteriCycleFormat =>
        processStericycleFormat(paths.toList)

      case Constants.CallCenterConiferFormat => {
        loadExcelFormatData(CallCenterSchema.callCenterConiferSchema, paths.head)
      }
      case Constants.CallCenterBerylFormat =>
        loadCSVFile(force, CallCenterSchema.callCenterBerylSchema, "|", paths: _*)
    }

    dataFrame.
      transform(df => filterBasicHeaderRows(df, "firstName"))
  }

  override def saveCSVFile(dataFrame: DataFrame, path: String, delimiter: String): Unit = {
    dataFrame.write.mode("overwrite").
      option("header", "true").
      option("quote", null).
      option("delimiter", delimiter).
      csv(path)
  }

  override def saveErrorFile(dataFrame: DataFrame, path: String): Unit = {
    import dataFrame.sparkSession.implicits._
    saveCSVFile(dataFrame.withColumn("errors", concat_ws("&& ", $"errors")).transform { df =>
      df.
        drop(
          df.schema.fields.filter(f => f.dataType.isInstanceOf[ArrayType] ||
            f.dataType.isInstanceOf[StructType] ||
            f.dataType.isInstanceOf[MapType]
          ).map(_.name): _*)
    }, path, "|")
  }

  override def saveCleansedFile(dataFrame: DataFrame, path: String): Unit = {

    // TODO: Come up with a way that will ensure even distribution of files on write out without running into
    // of memory issue during coalesce

    //    val repartitionedDataFrame = dataFrame.
    //      withColumn("year", year($"activityDate")).
    //      withColumn("month", month($"activityDate")).
    //      withColumn("day", dayofmonth($"activityDate")).
    //      withColumn("core", lit(executorCores) % rand() * 100)

    saveParquetFile(dataFrame, path, maxParquetPartitions, executorCores, SaveMode.Append)
  }

  override def readCleansedFile(paths: String*): Dataset[Activity] = {
    import sparkSession.implicits._
    sparkSession.read.
      parquet(paths: _*).
      map(Activity.buildFromRow).
      as[Activity]
  }

  // call readExcelFiles to load excel files data based on schema provided.
  def loadExcelFormatData(schema: StructType, path: String): DataFrame = {
    val listOfIncomingFiles: List[String] = if (path.startsWith("s3")) {
      val objectName = DataLakeUtilities.getObjectNameForBatchUrls(path)
      S3Utilities.getAcceptableBatchDirectoryUrls(s3Client, s"${DataLakeUtilities.getBucketKeysFromS3URL(path)}",
        objectName).filterNot(_.endsWith("/"))
    } else {
      List(path)
    }

    val fileFormat = getFileExtension(path)

    if (fileFormat != "xlsx" && fileFormat != "xls") {
      throw new RuntimeException(s"Invalid extension for excel files, $fileFormat.")
    }

    val maxInMemoryRows = if (fileFormat == "xlsx") Some(100) else None

    listOfIncomingFiles.foldLeft(sparkSession.
      createDataFrame(sparkSession.sparkContext.emptyRDD[Row], schema)) { (x, y) =>
      x.union(readExcelFiles(schema, fileFormat, maxInMemoryRows, y))
    }
  }

  // read excel files based on file extensions.
  def readExcelFiles(
                      schemaStructure: StructType,
                      fileFormat: String,
                      maxInMemoryRows: Option[Int],
                      path: String
                    ): DataFrame = {

    val df = sparkSession.sqlContext.read
      .format("com.crealytics.spark.excel")
      .option("path", path)
      .option("useHeader", "true")
      .schema(schemaStructure)

    if (maxInMemoryRows.nonEmpty) {
      df.option("maxRowsInMemory", maxInMemoryRows.get).load()
    } else {
      df.load()
    }
  }


  /**
    * Returns the list of Available S3 URLS for a given ANY bucket URL & Object name
    *
    * @param s3Client   Amazon S3 client
    * @param bucketKeys S3 bucket URL
    * @param objectName The S3 path that begins after the bucket name
    *                   Eg: S3 Path: s3a://bucketName/folder1/folder2/folder3/xyz.txt
    *                   bucketKeys: s3a://bucketName/
    *                   objectName: folder1/ or folder1/folder2/ or folder1/folder2/folder3/
    * @return
    */
  def getAvailableS3Urls(bucketKeys: String, objectName: String): List[String] = {
    var listOfKeys: List[String] = List()
    val bucketName: String = DataLakeUtilities.getS3BucketName(bucketKeys)
    Try {
      val objectListing: ObjectListing = s3Client.listObjects(new ListObjectsRequest().withBucketName(bucketName).
        withPrefix(objectName))
      for (objectSummary <- objectListing.getObjectSummaries) {
        val s3Url = bucketKeys + "/" + objectSummary.getKey
        listOfKeys = listOfKeys :+ s3Url
      }
    }
    match {
      case Success(x) =>
      case Failure(e) => logger.warn("No object found under: " + bucketKeys + "/" + objectName)
    }
    listOfKeys
  }

  /**
    * Returns the list of Available S3 URLS for a given ANY bucket URL & Object name
    *
    * @param s3Client   Amazon S3 client
    * @param bucketKeys S3 bucket URL
    * @param objectName The S3 path that begins after the bucket name
    *                   Eg: S3 Path: s3a://bucketName/folder1/folder2/folder3/xyz.txt
    *                   bucketKeys: s3a://bucketName/
    *                   objectName: folder1/ or folder1/folder2/ or folder1/folder2/folder3/
    * @return
    */
  def getAvailableBatchDirectoryUrlsForInputBatchId(bucketKeys: String, objectName: String): List[String] = {
    var listOfKeys: List[String] = List()
    val bucketName: String = DataLakeUtilities.getS3BucketName(bucketKeys)

    Try {
      var objectListing: ObjectListing = s3Client.listObjects(bucketName, objectName)
      for (objectSummary <- objectListing.getObjectSummaries) {
        val s3Url = bucketKeys + "/" + objectSummary.getKey
        listOfKeys = listOfKeys :+ s3Url
      }
      // s3Client.listObjects returns at most 1000 objects at a time, so we need to check
      // ObjectListing's isTruncated() method to determine if there are more records and then use
      // s3Client.listNextBatchOfObjects to get the remaining object records.
      while (objectListing.isTruncated) {
        objectListing = s3Client.listNextBatchOfObjects(objectListing)
        for (objectSummary <- objectListing.getObjectSummaries) {
          val s3Url = bucketKeys + "/" + objectSummary.getKey
          listOfKeys = listOfKeys :+ s3Url
        }
      }
    }
    match {
      case Success(x) => listOfKeys
      case Failure(e) => throw new Exception(s"No object found under:$bucketKeys/$objectName", e)
    }
    listOfKeys
  }

  /**
    * Returns the list of Available S3 URLS for a given ANY bucket URL & Object name
    *
    * @param s3Client   Amazon S3 client
    * @param bucketKeys S3 bucket URL
    * @param objectName The S3 path that begins after the bucket name
    *                   Eg: S3 Path: s3a://bucketName/folder1/folder2/folder3/xyz.txt
    *                   bucketKeys: s3a://bucketName/
    *                   objectName: folder1/ or folder1/folder2/ or folder1/folder2/folder3/
    * @return
    */
  def getAcceptableBatchDirectoryUrls(bucketKeys: String, objectName: String): List[String] = {
    val bucketName: String = DataLakeUtilities.getS3BucketName(bucketKeys)

    val objectListing: Try[ObjectListing] = Try(s3Client.listObjects(new ListObjectsRequest().
      withBucketName(bucketName).withPrefix(objectName)))
    objectListing match {
      case Success(x) =>
        x.getObjectSummaries.filterNot(y => s"$bucketKeys/${y.getKey}".endsWith("done")).map { objectSummary =>
          s"$bucketKeys/${objectSummary.getKey}"
        }.toList
      case Failure(e) => logger.warn("No object found under: " + bucketKeys + "/" + objectName + e.getMessage)
        List()
    }
  }

  /**
    * return the file extension by reading the input files.
    *
    * @param inputDirectoryPath
    * @return extension of the file name
    */
  override def hasFileBeenProcessed(pathInfo: PathInfo): Boolean = {

    val listOfKeys: mutable.Buffer[String] = getAllFilesInSearchPath(pathInfo)

    listOfKeys.toList.exists(_.endsWith(".done"))
  }

  override def getAllFilesInSearchPath(pathInfo: PathInfo): mutable.Buffer[String] = {
    val bucket: String = pathInfo.bucketName

    val searchPath = pathInfo.batchPhase match {
      case Constants.batchRawPhase => if(pathInfo.batchYear.nonEmpty){
        s"${pathInfo.source}/raw/${pathInfo.activityType}/${pathInfo.activityFormat}/${pathInfo.batchYear.get}-${pathInfo.batchMonth.get}${pathInfo.batchDay.map(s => s"-$s").getOrElse("")}"
      }
      else{
        s"${pathInfo.source}/raw/${pathInfo.activityType}/${pathInfo.activityFormat}"
      }

      case Constants.batchCleansedPhase => if(pathInfo.batchYear.nonEmpty){
        s"${pathInfo.source}/cleansed/${pathInfo.activityType}/${pathInfo.activityFormat}/${pathInfo.batchYear.get}-${pathInfo.batchMonth.get}${pathInfo.batchDay.map(s => s"-$s").getOrElse("")}.parquet"
      }
      else{
        s"${pathInfo.source}/cleansed/${pathInfo.activityType}/${pathInfo.activityFormat}"
      }
    }
    val objectListing: ObjectListing = s3Client.listObjects(bucket, searchPath)
    val listOfKeys = for (objectSummary <- objectListing.getObjectSummaries) yield {
      s"s3a://$bucket/${objectSummary.getKey}"
    }
    listOfKeys
  }

  override def getAllFilesInSearchPath(dateRanges: IndexedSeq[LocalDate], pathInfo: PathInfo): List[String] = {
    val searchPaths = dateRanges.map(date => pathInfo.copy(
      batchYear = Some(date.getYear.toString),
      batchMonth = Some(f"${date.getMonthValue}%02d"),
      batchDay = if(pathInfo.batchDay.nonEmpty ||
        pathInfo.activityType.contains("redox")){Some(f"${date.getDayOfMonth}%02d")} else None
    ))

    searchPaths.flatMap(getAllFilesInSearchPath).toList
  }

  private def getInputFolderPath(filePath: String): String = {
    if (filePath.contains(".")) {
      val fileSplitter = filePath.split("/").last
      filePath.replace(fileSplitter, "")
    }
    else {
      filePath
    }
  }

  // TODO If/When cleanse jobs for sources to be processed on daily basis are added, modify since-date & default options to handle for both months & days option(2016-05 and 2016-05-02)
  override def getInputFolderPaths(cleanseJobConfig: CleanseJobConfig): List[String] = {

    if (cleanseJobConfig.inputFilePath.nonEmpty) {
      val pathInfo: PathInfo = PathInfo(cleanseJobConfig.inputFilePath.get, Constants.batchRawPhase)
      getAllFilesInSearchPath(pathInfo).toList.map(path => getInputFolderPath(path)).distinct
    }
    else if (cleanseJobConfig.batchId.nonEmpty) {
      val pathInfo: PathInfo = PathInfo(cleanseJobConfig.batchId.get, cleanseJobConfig.bucketUrl)
      getAllFilesInSearchPath(pathInfo).toList.map(path => getInputFolderPath(path)).distinct
    }

    else if (cleanseJobConfig.sinceDate.nonEmpty) {
      val pathInfo: PathInfo = PathInfo(
        cleanseJobConfig.source,
        cleanseJobConfig.activityType,
        cleanseJobConfig.batchFormat,
        cleanseJobConfig.sinceDate.get,
        cleanseJobConfig.bucketUrl,
        cleanseJobConfig.batchDays,
        Constants.batchRawPhase)

      if (cleanseJobConfig.batchMonth.nonEmpty) {
        val dateRanges = (1 until cleanseJobConfig.batchMonth.get).map(cleanseJobConfig.sinceDate.get.plusMonths(_))
        getAllFilesInSearchPath(dateRanges, pathInfo).map(path => getInputFolderPath(path)).distinct.sortWith(_ < _)

      }
      else if (cleanseJobConfig.batchDays.nonEmpty) {
        val dateRanges = (1 until cleanseJobConfig.batchDays.get).map(cleanseJobConfig.sinceDate.get.plusDays(_))
        getAllFilesInSearchPath(dateRanges, pathInfo).map(path => getInputFolderPath(path)).distinct.sortWith(_ < _)
      }
      else {
        // since-date cleanse will always compare to months
        val startDate = cleanseJobConfig.sinceDate
        val endDate = LocalDate.now
        val monthsCount = ChronoUnit.DAYS.between(startDate.get, endDate).toInt
        val dateRanges = (1 until monthsCount).map(cleanseJobConfig.sinceDate.get.plusDays(_))
        getAllFilesInSearchPath(dateRanges, pathInfo).map(path => getInputFolderPath(path)).distinct.sortWith(_ < _)
      }

    }
    else {
      val pathInfo: PathInfo = PathInfo(
        cleanseJobConfig.source,
        cleanseJobConfig.activityType,
        cleanseJobConfig.batchFormat,
        cleanseJobConfig.bucketUrl,
        Constants.batchCleansedPhase)
      val listOfFilesInSearchPath =
        getAllFilesInSearchPath(pathInfo).toList.map(path => getInputFolderPath(path)).distinct.sortWith(_ > _)
      if (listOfFilesInSearchPath.nonEmpty) {
        List(listOfFilesInSearchPath.head)
      }
      else {
        throw new Exception("No file found in the search path.")
      }
    }
  }

  override def deleteFiles(path: String): Unit = {
    FileSystem.get(new URI(path), sparkSession.sparkContext.hadoopConfiguration).delete(new Path(path), true)
  }

  /**
    * Get list of utilization files from a given file path or s3 url path
    *
    * @param inputDirectoryPath
    * @param s3Client
    * @return
    */
  override def isFilePresentInTheFolder(inputDirectoryPath: String): Boolean = {
    var availableListOfFiles: List[String] = List()

    val sizeOfFolderString: Int = inputDirectoryPath.split("/").length

    if (inputDirectoryPath.startsWith("s3")) {
      val bucketName = DataLakeUtilities.extractBucketNameFromS3RawBatchUrl(inputDirectoryPath)
      val objectName = DataLakeUtilities.extractS3SourcePrefixForFileArchival(inputDirectoryPath)
      availableListOfFiles =
        getAvailableBatchDirectoryUrlsForInputBatchId(s"s3a://$bucketName", objectName)
    }
    else {
      availableListOfFiles = FileUtilities.getListOfFileNames(inputDirectoryPath, ".txt")
    }

    val listOfFilesToLoad = availableListOfFiles.
      filter(x => (x.split("/").length == sizeOfFolderString + 1) && !x.contains(".done") && x.contains(".") && x.contains(inputDirectoryPath))

    if(listOfFilesToLoad.nonEmpty) {true} else false

  }

  /**
    * If the callcenter file format is Stericycle, it can have two version of schema.
    * This method looks at header of each file and reads it with respective schema,
    * create two seperate dataframes and returns union of these two dataframes.
    *
    * @param sparkSession
    * @param listOfIncomingFiles
    * @return dataframe
    */
  def processStericycleFormat(listOfIncomingFiles: List[String]): DataFrame = {

    val headerStringV1 = "cc_call_no|created_date_time|cc_person_no|lastname"
    val headerStringV2 = "cc_call_no|created_date_time|cc_person_no|city"

    var df1: DataFrame = sparkSession.createDataFrame(sparkSession.sparkContext.emptyRDD[Row],
      CallCenterSchema.callCenterBerylSchema)
    var df2: DataFrame = sparkSession.createDataFrame(sparkSession.sparkContext.emptyRDD[Row],
      CallCenterSchema.callCenterStericycleV2Schema)

    listOfIncomingFiles.foreach {
      filePath =>
        val header = sparkSession.read.text(filePath).head.getString(0)
        if (header.startsWith(headerStringV1)) {
          df1 = df1.union(sparkSession.read.option("header", true).option("delimiter", "|").
            schema(CallCenterSchema.callCenterBerylSchema).csv(filePath))
        }
        else if (header.startsWith(headerStringV2)) {
          df2 = df2.union(sparkSession.read.option("header", true).option("delimiter", "|").
            schema(CallCenterSchema.callCenterStericycleV2Schema).csv(filePath))
        }
    }

    val columns: Array[String] = df1.columns
    val result: DataFrame = df2.select(columns.head, columns.tail: _*)
    df1.union(result)
  }

}
