package com.influencehealth.edh.model.activitytype
import com.influencehealth.edh.Constants

trait Prospect extends ActivityType {

  override val formatType: String = Constants.ProspectExperianFormat
  override val defaultSource: String = Constants.ProspectExperianSource
  override val defaultMessageType: String = Constants.ProspectDefaultMessageType
  override val defaultSourceType: String = Constants.ProspectDefaultSourceType
  override val defaultAddressType: String = Constants.ProspectDefaultAddressType
  override val defaultActivityType: String = Constants.ProspectActivityType
  override val defaultPersonType: String = Constants.ProspectDefaultPersonType

  override val cleanseStringColumnNames: Seq[String] = Seq(
    // Experian List
    "addressId", "stateCode", "state", "zip5", "zip4", "deliveryPointCode", "carrierRoute", "workflowFieldShortCityNameToBeInvertedV2", "streetHouseNumber",
    "streetPreDirection", "streetPostDirection", "unitDesignator", "unitDesignatorNumber", "filler1", "filler2", "addressQualityIndicator", "countyCode",
    "filler3", "latitudeOriginal", "longitudeOriginal", "matchLevelForGeoData", "filler4", "filler5", "filler6", "filler7", "dwellingUnitSize", "dwellType", "filler8",
    "homeownerProbabilityModel", "combinedOwner", "filler9", "householdIncome", "filler10", "ncoaMoveUpdateCode", "ncoaMoveUpdateDateOrig", "filler11", "mailResponder",
    "filler12", "homeBusiness", "activityDateOrig", "person1PersonType", "filler13", "person1Ethnic", "person1EthnicReligion", "person1EthnicLanguage", "person1EthnicGroup",
    "person1OccupationGroup", "person1Sex", "person1DOBOrig", "person1CombinedAgeOrig", "person1EducationModelOrig", "person1MaritalStatusOrig",
    "filler14", "person1OccupationCode", "person1BusinessOwner", "filler15", "person2PersonType", "filler16", "person2Ethnic", "person2EthnicReligion", "person2EthnicLanguage",
    "person2EthnicGroup", "person2OccupationGroup", "person2Sex", "person2DOBOrig", "person2CombinedAgeOrig", "person2EducationModelOrig",
    "person2MaritalStatusOrig", "filler17", "person2OccupationCode", "person2BusinessOwner", "filler18", "person3PersonType", "filler19", "person3Ethnic", "person3EthnicReligion",
    "person3EthnicLanguage", "person3EthnicGroup",  "person3OccupationGroup", "person3Sex", "person3DOBOrig", "person3CombinedAgeOrig",
    "person3EducationModelOrig", "person3MaritalStatusOrig", "filler20", "person3OccupationCode", "person3BusinessOwner", "filler21", "person4PersonType", "filler22",
    "person4Ethnic", "person4EthnicReligion", "person4EthnicLanguage", "person4EthnicGroup",  "person4OccupationGroup", "person4Sex", "person4DOBOrig",
    "person4CombinedAgeOrig", "person4EducationModelOrig", "person4MaritalStatusOrig", "filler23", "person4OccupationCode", "person4BusinessOwner", "filler24", "person5PersonType",
    "filler25", "person5Ethnic", "person5EthnicReligion", "person5EthnicLanguage", "person5EthnicGroup",  "person5OccupationGroup", "person5Sex",
    "person5DOBOrig", "person5CombinedAgeOrig", "person5EducationModelOrig", "person5MaritalStatusOrig", "filler26", "person5OccupationCode", "person5BusinessOwner", "filler27",
    "person6PersonType", "filler28", "person6Ethnic", "person6EthnicReligion", "person6EthnicLanguage", "person6EthnicGroup",  "person6OccupationGroup",
    "person6Sex", "person6DOBOrig", "person6CombinedAgeOrig", "person6EducationModelOrig", "person6MaritalStatusOrig", "filler29", "person6OccupationCode", "person6BusinessOwner",
    "filler30", "filler31", "mortgageHomePurchaseHomePurchaseDateOrig", "filler32", "filler33", "filler34", "filler51", "behaviorBankDonatesToEnvironmentalCauses", "filler35",
    "donatesToCharity", "filler36", "behaviorBankPresenceOfCreditCard", "filler37", "behaviorBankPresenceOfPremiumCreditCard", "filler38", "behaviorBankInterestInReading",
    "filler39", "behaviorBankComputersPeripherals", "filler40", "filler41", "filler42", "mosaicZip4", "filler43", "mosaicGlobalZip4", "filler44", "householdComposition",
    "filler45", "filler46", "filler47", "filler48", "coreBasedStatisticalArea", "coreBasedStatisticalAreaType", "filler49", "presenceOfChildOrig", "filler50", "childZeroToThreeBktOrig",
    "childZeroToThreeScore", "childZeroToThreeGender", "childFourToSixBktOrig", "childFourToSixScore", "childFourToSixGender", "childSevenToNineBktOrig", "childSevenToNineScore",
    "childSevenToNineGender", "childTenToTwelveBktOrig", "childTenToTwelveScore", "childTenToTwelveGender", "childThirteenToFifteenBktOrig", "childThirteenToFifteenScore",
    "childThirteenToFifteenGender", "childSixteenToEighteenBktOrig", "childSixteenToEighteenScore", "childSixteenToEighteenGender", "census2010TractAndBlockGroup",
    "capeEducIspsaDecile","address1", "address2", "countyName", "person1FirstName", "person1MiddleName", "person1LastName", "person1NameSuffix",
    "person1NamePrefix", "person2FirstName", "person2MiddleName", "person2LastName", "person2NameSuffix", "person2NamePrefix",
    "person3FirstName", "person3MiddleName", "person3LastName", "person3NameSuffix", "person3NamePrefix", "person4FirstName",
    "person4MiddleName", "person4LastName", "person4NameSuffix", "person4NamePrefix", "person5FirstName", "person5MiddleName",
    "person5LastName", "person5NameSuffix", "person5NamePrefix", "person6FirstName", "person6MiddleName", "person6LastName",
    "person6NameSuffix", "person6NamePrefix"
  )
  override val nullColumnNames: Seq[String] = Seq.empty[String]

  override val zipColumnNames: Seq[String] = Seq.empty

  override val mandatoryContactColumnsNames: Seq[String] = Seq.empty

}
