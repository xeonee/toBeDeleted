package com.influencehealth.edh.enrich.activity.crosswalks.helper

case class PatientType(
  customer: String,
  source: String,
  sourceType: String,
  sourcePatientType: String,
  patientType: String
) extends Serializable

object PatientType {
  val patientTypeCw: Seq[PatientType] = Seq(
    PatientType("default", "default", "default", "INPATIENT", "INPATIENT"),
    PatientType("default", "default", "default", "OUTPATIENT", "OUTPATIENT"),
    PatientType("northwell", "default", "default", "a", "OUTPATIENT"),
    PatientType("northwell", "default", "default", "e", "OUTPATIENT"),
    PatientType("northwell", "SEM", "Hospital", "a", "OUTPATIENT"),
    PatientType("northwell", "SEM", "Hospital", "e", "OUTPATIENT"),
    PatientType("northwell", "Allscripts", "practice", "a", "OUTPATIENT"),
    PatientType("northwell", "Allscripts", "practice", "e", "OUTPATIENT")
  )
}

case class PatientTypeCwCreationException(exc: Throwable)
  extends Exception("Unable to create patient type crosswalk", exc)

case class InvalidPatientTypeValue(value: String)
  extends Exception(s"The following value does not match any standard patient type value: '$value'")