package com.influencehealth.edh.identity

import com.influencehealth.edh.dao.DatabaseDao
import com.influencehealth.edh.linker._
import com.influencehealth.edh.model.{Activity, Person, UnIdentifiableActivity}
import com.influencehealth.edh.updater.PersonUpdaterImpl
import com.influencehealth.edh.utils.EnrichUtils
import com.influencehealth.edh.{Constants, CustomLazyLogging}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, Row}
import org.apache.spark.util.LongAccumulator

object EnrichIdentity extends CustomLazyLogging {

  def identifyRecords(
                       records: Dataset[Activity],
                       databaseDao: DatabaseDao,
                       customer: String
                     ): Dataset[Person] = {

    import records.sparkSession.implicits._

    // val identifiableRecords = enrichWithPrimaryContactInfo(records)

    val accumulator: LongAccumulator =
      records.sparkSession.sparkContext.longAccumulator("Collapse Accumulator")

    val inMemoryPersonLinker = new PersonLinker(accumulator, databaseDao, customer, "activityId")
      with PersonLinkerImpl with PersonInMemoryEntityDB

    val dbPersonLinker = new PersonLinker(accumulator, databaseDao, customer, "activityId")
      with PersonLinkerImpl with PersonPostgresEntityDB

    val persons = records
      .map { activity =>
        val newActivity = if (activity.personId.isEmpty){
          activity.copy(personId = Some(activity.generatePersonId()))
        } else {
          activity
        }
        Person.
          deriveFromActivity(newActivity)
      }
      .transform { persons => linkPersons(persons, inMemoryPersonLinker) }
      .transform { persons => linkPersons(persons, dbPersonLinker) }

    persons.groupByKey(p => p.personId).reduceGroups { (person1, person2) =>
      val Seq(oldestPerson, newestPerson) = Seq(person1, person2).sortBy(_.dateCreated.getTime)
      PersonUpdaterImpl.updatePerson(oldestPerson, newestPerson)
    }.map(_._2)

  }

  def linkPersons(records: Dataset[Person], linker: PersonLinker): Dataset[Person] = {

    linker.linkRecords(records)

  }

  def validateActivities(records: Dataset[Activity], databaseDao: DatabaseDao, inputActivityType:String): 
  Dataset[Activity] = {
    import records.sparkSession.implicits._

    // Checking for records where validAddressFlag is null if null throw an error
    val invalidAddressRecords = records.distinct.
      where($"isValidAddress".isNull || ($"isValidAddress" === true && ($"zip5".isNull || $"address1".isNull))).
      withColumn("errorReasons", array(lit("invalid address provided.")))

    if (invalidAddressRecords.head(1).nonEmpty) {
      databaseDao.saveUnidentifiableActivities(invalidAddressRecords.as[UnIdentifiableActivity])
      throw new RuntimeException(
        "Unaddressable records discovered. Check for invalid records in unidentifiable_activities table")
    }

    val (identifiableRecords, unidentifiableRecords) = splitOnIdentifiableData(records.distinct, inputActivityType)

    val unidentifiableRecordsCount = unidentifiableRecords.count()

    if (unidentifiableRecordsCount > 0) {
      databaseDao.saveUnidentifiableActivities(unidentifiableRecords.as[UnIdentifiableActivity])
      logger.warn(s"$unidentifiableRecordsCount Unidentifiable records discovered. " +
        s"Check for invalid records in unidentifiable_activities table")
    }

    identifiableRecords
  }
  
  def splitOnIdentifiableData(activities: Dataset[Activity],
                              activityType: String): (Dataset[Activity], DataFrame) = {

    activityType.toUpperCase match {
      case Constants.DeceasedActivityType => {
        (activities,
          activities.sparkSession.
            createDataFrame(activities.sparkSession.sparkContext.emptyRDD[Row], activities.schema))
      }
      case _ => {
        val invalidActivities = activities.
          filter(a => EnrichUtils.isInvalidActivity(a)).
          withColumn("errorReasons", array(lit("Not enough data provided to create a person id")))

        val validActivities = activities.
          filter(a => !EnrichUtils.isInvalidActivity(a))

        (validActivities, invalidActivities)
      }
    }
  }
}
