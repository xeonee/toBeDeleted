package com.influencehealth.edh.cleanse

import com.influencehealth.edh.{Constants}
import com.influencehealth.edh.model.activitytype.ActivityType
import com.influencehealth.edh.utils.CleanseUtils
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{col, lit}

class DoNotSolicitUpdateCleanser(val dateBatchReceived: String) extends DataCleanser {

  this: ActivityType =>


  override def cleanseData(
                            df: DataFrame,
                            customer: Option[String],
                            batchId: String
                          ): (DataFrame, DataFrame) = {

    // filters required columns that are not null
    val (dataFrameContainingNonNullColumns, dataFrameContainingNullColumns) =
      filterRequiredColumnsContainingInvalidValues(df, nullColumnNames, mandatoryContactColumnsNames)


    val dataFrameContainingCleansedStringColumns = cleanseStringColumns(dataFrameContainingNonNullColumns,
      cleanseStringColumnNames)

    // Cleanses Contact details: Phone numbers and emails
    val dataFrameContainingCleansedContactDetails = cleanseDnsReasons(dataFrameContainingCleansedStringColumns)

    // Aliases Data
    val aliasedData = aliasData(dataFrameContainingCleansedContactDetails, customer)

    (aliasedData, dataFrameContainingNullColumns)

  }

  override def formatDateColumns(df: DataFrame): DataFrame = df

  override def cleanseStringColumns(df: DataFrame, stringColumnsToBeCleansed: Seq[String]): DataFrame = {
    stringColumnsToBeCleansed.foldLeft(df) { (df, column) =>
      df.withColumn(s"$column", CleanseUtils.cleanseStringColumns(df(s"$column")))
    }
  }

  override def assignDefaultValuesForRequiredColumnsContainingNulls(df: DataFrame): DataFrame = df


  private def cleanseDnsReasons(df: DataFrame): DataFrame = {

    val finalDf = df
      .withColumn("optOutDirectMailReasons", getStringToArray(col("optOutDirectMailReasons")))
      .withColumn("optOutCallReasons", getStringToArray(col("optOutCallReasons")))
      .withColumn("optOutEmailReasons", getStringToArray(col("optOutEmailReasons")))
      .withColumn("optOutTextReasons", getStringToArray(col("optOutTextReasons")))

    finalDf
  }

  override def aliasData(df: DataFrame, customer: Option[String]): DataFrame = {
    df.withColumn("activityDate", lit(Constants.Today.toString))
      .withColumn("activityType", lit(defaultActivityType))
  }

}
