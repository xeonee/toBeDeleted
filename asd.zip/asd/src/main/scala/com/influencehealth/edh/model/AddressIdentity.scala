package com.influencehealth.edh.model

import java.io.{ByteArrayInputStream, InputStream}

import org.apache.commons.codec.digest.DigestUtils

trait AddressIdentity {

  val customer: String

  val address1: String

  val address2: Option[String]

  val city: String

  val state: String

  val zip5: String

  val zip4: Option[String]

  val addressCoordinates: Coordinates

  def generateAddressId: String = {

    val byteArray: Array[Byte] =
      customer.toString.trim.getBytes() ++
        address1.toUpperCase.trim.getBytes ++
        address2.getOrElse("").toUpperCase.trim.getBytes() ++
        city.toUpperCase.trim.getBytes() ++
        state.toUpperCase.trim.getBytes() ++
        zip5.toUpperCase.trim.getBytes() ++
        zip4.getOrElse("").toUpperCase.trim.getBytes() ++
        s"${addressCoordinates.lat}".trim.getBytes() ++
        s"${addressCoordinates.lon}".trim.getBytes()

    val inputStream: InputStream = new ByteArrayInputStream(byteArray)

    DigestUtils.md5Hex(inputStream)

  }

}
