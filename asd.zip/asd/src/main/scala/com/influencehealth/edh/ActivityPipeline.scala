package com.influencehealth.edh

import com.amazonaws.services.s3.AmazonS3
import com.influencehealth.edh.config._
import com.influencehealth.edh.dao.DatabaseDao
import com.influencehealth.edh.enrich.activity.EnrichActivityPipelineBuilder
import com.influencehealth.edh.load.activities.LoadActivities
import com.influencehealth.edh.lookup_clients.support.ServiceArea
import com.influencehealth.edh.lookups.client.LookupsClient
import com.influencehealth.edh.lookups.messages.Location
import com.influencehealth.edh.model.{Activity, DoNotSolicitEmail}
import com.influencehealth.edh.utils.{DataLakeUtilities, S3Utilities}
import com.typesafe.config.Config
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.{col, udf}
import org.apache.spark.sql.{Dataset, SparkSession}
import org.apache.spark.storage.StorageLevel

object ActivityPipeline extends BaldurApplication[EnrichJobConfig] {

  var inputRecordCount: Option[Long] = None
  var outputRecordCount: Option[Long] = None

  override def runJob(
                       implicit sparkSession: SparkSession,
                       enrichJobConfig: EnrichJobConfig,
                       databaseDao: DatabaseDao
                     ) = {
    val listOfInputFolders: Seq[String] = getListOfInputFolders(s3client, enrichJobConfig)

    // Iterate over each input folder and call runActivityPipeline method to get the input and output records count.
    // runActivityPipeline method returns the tuple of number of input records (records read from S3) and
    // number of output records (activities processed).
    // Values of this tuple is used to populated jobHistory table.
    val (inputRecords, outputRecords) = listOfInputFolders.foldLeft((0L, 0L)){
      (acc, folderPath) => val res = runActivityPipeline(enrichJobConfig, folderPath, databaseDao)
        (acc._1 + res._1, acc._2 + res._2)
    }

    inputRecordCount = Some(inputRecords)
    outputRecordCount = Some(outputRecords)
  }

  // Iterate through each input folder and run enrichActivityPipeline on every folder
  def runActivityPipeline(implicit enrichJobConfig: EnrichJobConfig, inputFolderUrl: String,
                          databaseDao: DatabaseDao): (Long, Long) = {

    val loadJobConfig: LoadJobConfig = LoadJobConfig(enrichJobConfig, inputFolderUrl)
    val activityLoader = LoadActivities(loadJobConfig)
    // Load Activities
    val activities: Dataset[Activity] = activityLoader.loadActivities
    activities.persist(StorageLevel.MEMORY_ONLY_SER)

    val activitiesCount = activities.count
    logger.info(s"$activitiesCount Events Loaded from S3")

    val environment: String = enrichJobConfig.environment

    // Set move_type only for New Movers.
    val finalActivities = loadJobConfig.activityType.toUpperCase match {
      case Constants.NewMoverActivityType => {
        import sparkSession.implicits._
        val setOfCustomerServicingZipCodes: Set[String] = loadJobConfig.customerServiceAreas
        val activitiesWithMoveType = activities.withColumn("experianMoveType",
          checkNewMoverType(setOfCustomerServicingZipCodes)(col("zip5"), col("movedFromZip5")))
        activitiesWithMoveType.as[Activity]
      }
      case _ => activities
    }

    // set dnsSkipFlag to true only if activityType is DNS and firstName, lastName, address1 and zip5 are null for
    // all records in the finalActivities dataframe
    val dnsSkipFlag: Boolean = loadJobConfig.activityType.toUpperCase match {
      case Constants.DoNotSolicitActivityType => finalActivities.filter(col("firstName").isNotNull &&
        col("lastName").isNotNull && col("address1").isNotNull && col("zip5").isNotNull).head(1).isEmpty
      case _ => false
    }

    // Initialize enrichActivityPipeline
    // In local and e2e environments we are invoking mock address job as anchor process is not configured. So that,
    // it will update required address fields to the activities.
    val enrichActivityPipeline = if(dnsSkipFlag) EnrichActivityPipelineBuilder(Constants.DnsEnrichStepName)
      else environment match {
        case "local" | "test" => EnrichActivityPipelineBuilder(Constants.EnrichMockAddressStepName)
        case _ => EnrichActivityPipelineBuilder(Constants.EnrichAddressStepName)
      }

    // Start the pipeline
    val personActivities: Dataset[Activity] = enrichActivityPipeline.startEnrichPipeline(finalActivities)

    // Save activities
    databaseDao.saveActivities(personActivities)

    (activitiesCount, personActivities.count)
  }
  /**
    * Gets the list of input files required for cleansing or loading files from S3 based on app configs provided
    * @param s3Client
    * @param enrichJobConfig
    * @return
    */
  def getListOfInputFolders(s3Client: AmazonS3, enrichJobConfig: EnrichJobConfig): List[String] = {
    val activityType = DataLakeUtilities.extractActivityTypeFromBatchId(enrichJobConfig.batchId.get)
    val source = DataLakeUtilities.getSourceFromActivityType(activityType, enrichJobConfig.customer)
    val batchDate = DataLakeUtilities.extractBatchDateFromBatchId(enrichJobConfig.batchId.get)

    val listOfInputFolders = S3Utilities.getListOfS3UrlsForBatchAndFormatOptions(
      s3Client, source, batchDate, enrichJobConfig.bucketUrl, enrichJobConfig.jobType, activityType,
      enrichJobConfig.batchFormat
    )

    if (listOfInputFolders.isEmpty) {
      val errorMessageKey = s"${enrichJobConfig.bucketUrl}/$source/cleansed/$activityType/" +
        s"${enrichJobConfig.batchFormat}/$batchDate.parquet/"
      throw new RuntimeException(s"No cleansed files/folders are present at: $errorMessageKey")
    }else{
      listOfInputFolders
    }
  }

  override def buildConfig(appConfig: Config, lookupsClient: LookupsClient): EnrichJobConfig = {
    val customer: String = appConfig.getString("app.customer")
    val customerLocations: Seq[Location] = lookupsClient.
      getLocations.filter(_.ClientKey == customer)
    val customerServiceAreas: Set[ServiceArea] = customerLocations.flatMap(ServiceArea.create).toSet
    val databaseConfig: Option[DatabaseConfig] = Some(PostgresConfig(appConfig))
    val anchorConfig: Option[AnchorConfig] = Some(AnchorConfig(appConfig))
    val sg2Config: Option[SG2Config] = Some(SG2Config(appConfig))
    EnrichJobConfig(
      appConfig,
      customerLocations,
      customerServiceAreas,
      databaseConfig,
      anchorConfig,
      sg2Config
    )
  }

  override def countInputRecords = {
    inputRecordCount
  }

  override def countOutputRecords = {
    outputRecordCount
  }

  /**
    * IF A PRIOR ZIP IS NOT LISTED, IS NULL OR LISTED AS 00000, IT IS MARKED AS "U"
    * If priorzip fall under clientServiceArea and newzip fall within a clientServiceArea will set move_type “I”
    * If prior zip not fall under clientServiceArea and new zip fall within a clientServiceArea will set move_type “E”
    * @param setOfZipCodes clientServiceArea
    * @param currentZip5 zip5
    * @param priorZip5 moved from movedFromZip5
    * @return "I","U","E"
    */
  def assignNewMoverType(setOfZipCodes: Set[String], currentZip5: String, priorZip5: String): String = {
    (setOfZipCodes,currentZip5,priorZip5) match {
      case (x, y, z) if (!x.contains(z) || z.isEmpty || z.toInt == 0) => "U"
      case (x, y, z) if (x.contains(z) && x.contains(y)) => "I"
      case (x, y, z) if (!x.contains(z) && x.contains(y)) => "E"
      case _ => "U"
    }
  }

  /**
    * Assign movetype
    * @param setOfZipCodes ClientServiceArea
    * @return MoveType
    */
  def checkNewMoverType (setOfZipCodes: Set[String]): UserDefinedFunction =
    udf((currentZip5: String, priorZip5: String) => {
      assignNewMoverType(setOfZipCodes,currentZip5,priorZip5)
  })
}
