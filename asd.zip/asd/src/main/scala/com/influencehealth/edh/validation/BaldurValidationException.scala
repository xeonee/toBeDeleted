package com.influencehealth.edh.validation

case class BaldurValidationException(message: String, validationErrors: Seq[String]) extends Exception(message)