package com.influencehealth.edh.refresh.redshift

import com.influencehealth.edh.model._
import mojolly.inflector.Inflector
import org.apache.spark.sql.{Column, DataFrame}
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.types._

trait BaseTransformer {

  val convertSequenceStringToString: UserDefinedFunction = udf((a: Seq[String]) => a.mkString(", "))
  val convertSequencePersonLocationToString: UserDefinedFunction = udf((a: Seq[PersonLocation]) => a.mkString("; "))
  val convertSequenceActivityToString: UserDefinedFunction = udf((a: Seq[Activity]) => a.mkString("; "))
  val convertSequenceActivityMedicalCodeToString: UserDefinedFunction = udf((a: Seq[ActivityMedicalCode]) => a.mkString("; "))
  val convertSequenceAssessmentResultsToString: UserDefinedFunction = udf((a: Seq[AssessmentResults]) => a.mkString(", "))
  val convertSequencePhoneNumbersToString: UserDefinedFunction = udf((a: Seq[PersonPhoneNumber]) => a.mkString(", "))

  def aliasColumnsToSnakeCase(dataFrame: DataFrame): DataFrame = {
    import dataFrame.sparkSession.implicits._
    val aliasedColumns = dataFrame.columns.map(col => $"$col" as Inflector.underscore(col))
    dataFrame.select(aliasedColumns: _*)
  }

  def dropComplexTypes(dataFrame: DataFrame): DataFrame = {
    val columnsToDrop = dataFrame.schema.flatMap{
      case StructField(name, ArrayType(_, _), _, _) => Some(name)
      case StructField(name, MapType(_, _, _), _, _) => Some(name)
      case StructField(name, StructType(_), _, _) => Some(name)
      case _ => None
    }

    dataFrame.drop(columnsToDrop:_*)
  }

  /**
    * Configuring the maximum size of string columns
    * @param columnNames
    * @param df
    * @return
    */
  def applyMetadataToTempTables(columnNames: Map[String, Int], df: DataFrame): DataFrame = {


    var dfWithSchema: DataFrame = df

    columnNames.foreach{
      case (colName, length) =>
        val metadata = new MetadataBuilder().putLong("maxlength", length).build()
        dfWithSchema = dfWithSchema.withColumn(colName, dfWithSchema(colName).as(colName, metadata))
    }

    dfWithSchema
  }

}