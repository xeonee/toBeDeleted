package com.influencehealth.edh.updater

import java.sql.Timestamp

import com.influencehealth.edh.Constants
import com.influencehealth.edh.model.{Activity, SG2}
import org.apache.spark.sql.catalyst.expressions.GenericRowWithSchema


// This is a temporary solution. We need to merge this object with PersonUpdaterImpl to have a generic solution
object ActivityUpdaterImpl extends Serializable {

  val fieldsNotToBeUpdated = Seq(
    "personId",
    "activityId",
    "batchId",
    "customer",
    "dateCreated",
    "sourceFirstName",
    "sourceLastName",
    "sourceMiddleName",
    "sourcePersonType"
  )

  val atomicFields: Seq[Seq[String]] = Seq(
    Seq(
      "addressQualityIndicator",
      "addressType",
      "isValidAddress",
      "address1",
      "address2",
      "city",
      "state",
      "zip5",
      "zip4",
      "county",
      "addressCoordinates",
      "streetPreDirection",
      "streetSuffix",
      "streetSecondNumber",
      "streetSecondUnit",
      "streetHouseNumber"
    ),
    Seq(
      "experianMoveType",
      "experianMoveMonth"
    ),
    Seq(
      "ncoaMoveType",
      "ncoaMoveDate"
    )
  )

  val collectionFieldsToBeAppended = Seq(
    "optOutCallReasons",
    "optOutDirectMailReasons",
    "optOutEmailReasons",
    "optOutTextReasons",
    "currentProceduralTerminologyCodes",
    "diagnosisCodes",
    "procedureCodes"
  )

  val collectionFieldsToBeUpdated = Seq(
    "providers"
  )

  val genericUpdateFields: Seq[String] = Activity.Schema.fieldNames.diff(
    collectionFieldsToBeAppended ++ atomicFields.flatten ++ fieldsNotToBeUpdated ++ collectionFieldsToBeUpdated)

  def updateActivity(oldestActivity: Activity, newestActivity: Activity): Activity = {

    import com.influencehealth.edh.ToMapImplicits._

    val oldestActivityMap: Map[String, Any] = activityToMap(oldestActivity)
    val newestActivityMap: Map[String, Any] = activityToMap(newestActivity)


    def mergeOptSeq[T](seq1: Seq[T], seq2: Seq[T]): Seq[T] = {
      (Option(seq1).getOrElse(Seq.empty[T]) ++ Option(seq2).getOrElse(Seq.empty[T])).distinct
    }

    def mergeIds(existingMergedIds: Seq[String], oldId: Option[String], newId: Option[String]): Seq[String] = {
      (Option(existingMergedIds).getOrElse(Seq.empty[String]) ++ oldId.toSeq ++ newId.toSeq).distinct
    }

    def middleNameUpdate(oldMiddleName: Option[String], newMiddleName: Option[String]): Option[String] = {
      newMiddleName match {
        case Some(m) if oldMiddleName.isEmpty => Option(m)
        case Some(m) if m.length == 1 && oldMiddleName.map(_.length).getOrElse(0) > 1 => oldMiddleName
        case Some(m) if m.length >= oldMiddleName.map(_.length).getOrElse(0) => Option(m)
        case _ => oldMiddleName
      }
    }

    def deriveHasGenderConflict(oldSex: Option[String], newSex: Option[String]): Boolean = {
      if (newSex.isDefined && oldSex.isDefined && oldSex != newSex) true
      else false
    }

    def deriveIsDeceased(dateOfDeath: Option[String]): Boolean = {
      if (dateOfDeath.isDefined) true
      else false
    }

    if (
      newestActivity.activityType.map(Constants.activityTypeRank).getOrElse(99) <=
        oldestActivity.activityType.map(Constants.activityTypeRank).getOrElse(99)
    ) {
      // generete updatedPersonMap using different rules to merge persons informations
      val updatedActivityMap: Map[String, Any] = oldestActivityMap ++
        genericUpdateFields.foldLeft(Map.empty[String, Any]) { (map, field) =>
          if (Option(newestActivityMap(field)).nonEmpty) {
            map ++ Map(field -> newestActivityMap(field))
          } else map ++ Map(field -> oldestActivityMap(field))
        } ++
        collectionFieldsToBeUpdated.foldLeft(Map.empty[String, Any]) { (map, field) =>
          if (Option(newestActivityMap(field)).nonEmpty) {
            map ++ Map(field -> newestActivityMap(field))
          } else map ++ Map(field -> oldestActivityMap(field))
        } ++
        collectionFieldsToBeAppended.foldLeft(Map.empty[String, Any]) { (map, field) =>
          map ++
            Map(field -> mergeOptSeq(
              oldestActivityMap(field).asInstanceOf[Seq[Any]],
              newestActivityMap(field).asInstanceOf[Seq[Any]]
            ))
        } ++
        Map(
          "mergedBatchIds" -> mergeIds(
            oldestActivityMap("mergedBatchIds").asInstanceOf[Seq[String]],
            Option(oldestActivityMap("batchId")).map(_.toString),
            Option(newestActivityMap("batchId")).map(_.toString)
          )
        ) ++
        Map(
          "mergedActivityIds" -> mergeIds(
            oldestActivityMap("mergedActivityIds").asInstanceOf[Seq[String]],
            Option(oldestActivityMap("activityId")).map(_.toString),
            Option(newestActivityMap("activityId")).map(_.toString)
          )
        ) ++
        Map(
          "middleName" -> middleNameUpdate(
            Option(oldestActivityMap("middleName")).map(_.toString),
            Option(newestActivityMap("middleName")).map(_.toString)
          ).orNull,
          "dateModified" -> new Timestamp(System.currentTimeMillis())
        ) ++
        atomicFields.map(fields => fields.foldLeft(Map.empty[String, Any]) { (map, field) =>
          map ++ Map(field -> newestActivityMap(field))
        }).foldLeft(Map.empty[String, Any]) { (concatenatedMap, map) =>
          concatenatedMap ++ map
        }

      // println(updatedActivityMap)
      // convert updatedActivityMap to a GenericRow and then to Person
      val activityRow = new GenericRowWithSchema(
        Activity.Schema.map { structField =>
          val fieldName = structField.name
          fieldName match {
            case "sg2" =>
              updatedActivityMap("sg2").asInstanceOf[SG2]
            case "currentProceduralTerminologyCodes" | "diagnosisCodes" | "procedureCodes" =>
              updatedActivityMap(fieldName)
            case _ => updatedActivityMap(fieldName)
          }
        }.toArray,
        Activity.Schema
      )
      Activity.buildFromRow(activityRow)
    } else {
      val updatedActivityMap: Map[String, Any] = oldestActivityMap ++
        collectionFieldsToBeAppended.foldLeft(Map.empty[String, Any]) { (map, field) =>
          map ++
            Map(field -> mergeOptSeq(
              oldestActivityMap(field).asInstanceOf[Seq[Any]],
              newestActivityMap(field).asInstanceOf[Seq[Any]]
            ))
        } ++
        Map(
          "mergedBatchIds" -> mergeIds(
            oldestActivityMap("mergedBatchIds").asInstanceOf[Seq[String]],
            Option(oldestActivityMap("batchId")).map(_.toString),
            Option(newestActivityMap("batchId")).map(_.toString)
          )
        ) ++
        Map(
          "mergedActivityIds" -> mergeIds(
            oldestActivityMap("mergedActivityIds").asInstanceOf[Seq[String]],
            Option(oldestActivityMap("activityId")).map(_.toString),
            Option(newestActivityMap("activityId")).map(_.toString)
          )
        ) ++
        Map("dateModified" -> new Timestamp(System.currentTimeMillis()))

      val activityRow = new GenericRowWithSchema(
        Activity.Schema.map { structField =>
          val fieldName = structField.name
          fieldName match {
            case "sg2" => updatedActivityMap("sg2").asInstanceOf[SG2]
            case _ => updatedActivityMap(fieldName)
          }

        }.toArray,
        Activity.Schema
      )

      Activity.buildFromRow(activityRow)
    }

  }
}

