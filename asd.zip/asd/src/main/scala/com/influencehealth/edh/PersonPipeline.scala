package com.influencehealth.edh

import com.influencehealth.edh.config._
import com.influencehealth.edh.dao.{DatabaseDao, PostgresDatabaseDao}
import com.influencehealth.edh.enrich.person.EnrichPersonPipelineBuilder
import com.influencehealth.edh.lookup_clients.support.ServiceArea
import com.influencehealth.edh.lookups.client.LookupsClient
import com.influencehealth.edh.lookups.messages.Location
import com.influencehealth.edh.model.Person
import com.typesafe.config.Config
import org.apache.spark.sql.{Dataset, SparkSession}

object PersonPipeline extends BaldurApplication[EnrichJobConfig] {

  var inputRecordCount: Option[Long] = None
  var outputRecordCount: Option[Long] = None

  override def runJob(implicit sparkSession: SparkSession, config: EnrichJobConfig, databaseDao: DatabaseDao) = {

    val postgresConfig = config.databaseConfig.get

    val customer: String = config.customer

    val databaseDao: DatabaseDao = new PostgresDatabaseDao(postgresConfig)

    val enrichPersonPipeline = EnrichPersonPipelineBuilder(Constants.EnrichResidenceStepName)

    val persons: Dataset[Person] = config.fullRefresh match {
      case true => databaseDao.getPersonsByCustomer(customer, full = false)
      case _ => {
        databaseDao.getPersonsByBatchId(config.batchId.get)
      }
    }

    if (persons.head(1).nonEmpty) {
      // Start the pipeline
      val enrichedPersons: Dataset[Person] = enrichPersonPipeline.startEnrichPipeline(persons)

      // Save persons
      databaseDao.savePersons(enrichedPersons)

      inputRecordCount = Some(persons.count)
      outputRecordCount = Some(enrichedPersons.count)

    } else {
      throw new RuntimeException(s"No records present in the persons table for the customer")
    }
  }


  override def buildConfig(appConfig: Config, lookupsClient: LookupsClient): EnrichJobConfig = {
    val customer: String = appConfig.getString("app.customer")
    val customerLocations: Seq[Location] = lookupsClient.
      getLocations.filter(_.ClientKey == customer)
    val customerServiceAreas: Set[ServiceArea] = customerLocations.flatMap(ServiceArea.create).toSet
    val databaseConfig: Option[DatabaseConfig] = Some(PostgresConfig(appConfig))
    val anchorConfig: Option[AnchorConfig] = Some(AnchorConfig(appConfig))
    val sg2Config: Option[SG2Config] = Some(SG2Config(appConfig))
    EnrichJobConfig(
      appConfig,
      customerLocations,
      customerServiceAreas,
      databaseConfig,
      anchorConfig,
      sg2Config
    )
  }

  override def countInputRecords = {
    inputRecordCount
  }

  override def countOutputRecords = {
    outputRecordCount
  }

}
