package com.influencehealth.edh.model.crosswalk

import com.influencehealth.edh.Constants

case class MaritalStatus(
                          sourceMaritalStatus: String,
                          maritalStatus: String
                        ) extends Serializable

object MaritalStatus {

  val maritalStatusCw: Seq[MaritalStatus] = Seq(
    MaritalStatus("m", Constants.MaritalStatusMarried),
    MaritalStatus("s", Constants.MaritalStatusSingle),
    MaritalStatus("w", Constants.MaritalStatusWidowed),
    MaritalStatus("x", Constants.MaritalStatusSeparated),
    MaritalStatus("d", Constants.MaritalStatusDivorced),
    MaritalStatus("p", Constants.MaritalStatusLifePartner),
    MaritalStatus("1M", Constants.MaritalStatusMarried),
    MaritalStatus("5M", Constants.MaritalStatusMarried),
    MaritalStatus("5S", Constants.MaritalStatusSingle),
    MaritalStatus("5U", null)
  )
}

case class MaritalStatusCwCreationException(exc: Throwable)
  extends Exception("Unable to create marital status crosswalk", exc)

case class InvalidMaritalStatusValue(value: String)
  extends Exception(s"The following value does not match any standard marital status value: '$value'")