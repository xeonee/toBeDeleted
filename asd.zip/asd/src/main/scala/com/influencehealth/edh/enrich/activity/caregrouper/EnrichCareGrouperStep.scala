package com.influencehealth.edh.enrich.activity.caregrouper

import com.influencehealth.edh.config.EnrichJobConfig
import com.influencehealth.edh.dao.{DatabaseDao, PostgresDatabaseDao}
import com.influencehealth.edh.enrich.ActivityEnricher
import com.influencehealth.edh.implicits._
import com.influencehealth.edh.model.{Activity, UnIdentifiableActivity}
import com.influencehealth.edh.utils.FileUtilities
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.joda.time.DateTime

class EnrichCareGrouperStep(val name: String, val next: Option[ActivityEnricher])
                           (implicit enrichJobConfig: EnrichJobConfig, sparkSession: SparkSession)
  extends ActivityEnricher {

  override def enrich(activities: Dataset[Activity]): Dataset[Activity] = {

    val customer = enrichJobConfig.customer
    val uploadFolder = enrichJobConfig.sg2Config.get.outputPath
    val downloadFolder = enrichJobConfig.sg2Config.get.inputFileName
    val tempPath = enrichJobConfig.sg2Config.get.tempPath
    val fileNamePrefix = enrichJobConfig.sg2Config.get.filenamePrefix
    val now: String = DateTime.now().toTimestampStr.replace("-", "").replace(":", "")
    val fileNameForInPatient = s"${fileNamePrefix}_${customer}_InPatient_$now.csv"
    val fileNameForOutPatient = s"${fileNamePrefix}_${customer}_OutPatient_$now.csv"
    val batchId = enrichJobConfig.batchId
    val sg2ScriptPath: String = enrichJobConfig.sg2Config.get.sg2ScriptPath
    val databaseDao: DatabaseDao = new PostgresDatabaseDao(enrichJobConfig.databaseConfig.get)

    val (inPatientDataCountOriginal, outPatientDataCountOriginal, unGroupableActivities): (Long, Long, DataFrame) =
      generateCareGrouperOutputFiles(
      activities,
      customer,
      uploadFolder,
      tempPath,
      fileNamePrefix,
      batchId.get,
      fileNameForInPatient,
      fileNameForOutPatient)


    import unGroupableActivities.sparkSession.implicits._

    if (unGroupableActivities.head(1).nonEmpty) {
      logger.info(s"Filtering out UnGroupable Activities: ${unGroupableActivities.count()}")
      databaseDao.saveUngroupableActivities(unGroupableActivities.as[UnIdentifiableActivity])
    }

    // In local and e2e environments we are skipping sg2 application process, hence updating IN-PATIENT and OUT-PATIENT
    // count as zero.
    val environment: String = enrichJobConfig.environment
    val dummyCount = 0
    val inPatientDataCount = environment match {
      case "local" | "test" => logger.info(s"The number of IN-PATIENT records are : $inPatientDataCountOriginal")
        dummyCount
      case _ => inPatientDataCountOriginal
    }
    val outPatientDataCount = environment match {
      case "local" | "test" => logger.info(s"The number of OUT-PATIENT records are : $outPatientDataCountOriginal")
        dummyCount
      case _ => outPatientDataCountOriginal
    }

    activities.
      transform(a => retrieveEnrichedInPatientRecords(
        inPatientDataCount,
        fileNameForInPatient,
        downloadFolder,
        sg2ScriptPath,
        a
      )).transform(a => retrieveEnrichedOutPatientRecords(
      outPatientDataCount,
      fileNameForOutPatient,
      downloadFolder,
      sg2ScriptPath,
      activities
    ))

  }

  def retrieveEnrichedInPatientRecords(
                                        inPatientDataCount: Long,
                                        fileNameForInPatient: String,
                                        downloadFolder: String,
                                        sg2ScriptPath: String,
                                        activities: Dataset[Activity]
                                      ): Dataset[Activity] = {

    import sparkSession.implicits._

    if (inPatientDataCount > 0) {
      val inPatientDf: DataFrame = CareGroupersFileHandler.processSg2Application(
        sparkSession,
        "InPatient",
        fileNameForInPatient,
        downloadFolder,
        sg2ScriptPath
      )

      val joinedDF: DataFrame = activities.join(inPatientDf, Seq("activityId", "customer", "batchId"), "left_outer")


      // TODO: Remove bucketNumber as column from sg2 input and output schemas
      inPatientDf.columns.filterNot(Seq("activityId", "customer", "batchId").contains)
        .foldLeft(joinedDF) {
          (dataframe, fieldName) =>
            if (activities.columns.contains(fieldName)) {
              dataframe.drop(activities.col(fieldName))
            } else {
              dataframe
            }
        }.map(Activity.buildFromRow)

    } else {
      logger.info("No IN-PATIENT records found.")
      activities
    }
  }

  def retrieveEnrichedOutPatientRecords(
                                         outPatientDataCount: Long,
                                         fileNameForOutPatient: String,
                                         downloadFolder: String,
                                         sg2ScriptPath: String,
                                         activities: Dataset[Activity]
                                       ): Dataset[Activity] = {
    import sparkSession.implicits._

    if (outPatientDataCount > 0) {
      val outPatientDf = CareGroupersFileHandler.
        processSg2Application(sparkSession, "OutPatient", fileNameForOutPatient, downloadFolder, sg2ScriptPath)

      val joinedDF = activities.join(outPatientDf, Seq("activityId", "customer", "batchId"), "left_outer")

      outPatientDf.columns.filterNot(Seq("activityId", "customer", "batchId").contains)
        .foldLeft(joinedDF) {
          (dataframe, fieldName) =>
            if (activities.columns.contains(fieldName)) {
              dataframe.drop(activities.col(fieldName))
            } else {
              dataframe
            }
        }.map(Activity.buildFromRow)

    } else {
      logger.info("No OUT-PATIENT records found.")
      activities
    }

  }


  /**
    * Generates the care grouper output file based on Sg2 requirements to the specified folder
    *
    * @return
    */
  def generateCareGrouperOutputFiles(
                                      activities: Dataset[Activity],
                                      customer: String,
                                      uploadFolder: String,
                                      tempPath: String,
                                      fileNamePrefix: String,
                                      batchId: String,
                                      fileNameForInPatient: String,
                                      fileNameForOutPatient: String
                                    ): (Long, Long, DataFrame) = {

    // build output dataFrame with only required fields
    val personTypeDataFrames: Map[String, DataFrame] = CareGrouperGenerator.
      generateSg2InputFile(activities, customer, batchId)

    val outpatients: DataFrame = personTypeDataFrames("outpatients")
    val inpatients: DataFrame = personTypeDataFrames("inpatients")
    val ungroupableActivities: DataFrame = personTypeDataFrames("ungroupableActivities")

    val inpatientDataCount = inpatients.count
    if (inpatientDataCount <= 0) {
      logger.info(s"No records were found for caregroupers (inpatient) batch: $batchId")
    } else {
      // write file out
      FileUtilities.writeCareGrouperFile(
        uploadFolder,
        tempPath,
        fileNamePrefix,
        inpatients,
        customer,
        "InPatient",
        fileNameForInPatient
      )
    }

    val outPatientDataCount = outpatients.count
    if (outPatientDataCount <= 0) {
      logger.info(s"No records were found for caregroupers (outpatient) batch: $batchId")
    } else {
      FileUtilities.writeCareGrouperFile(uploadFolder, tempPath, fileNamePrefix,
        outpatients, customer, "OutPatient", fileNameForOutPatient)
    }
    (inpatientDataCount, outPatientDataCount, ungroupableActivities)
  }

}
