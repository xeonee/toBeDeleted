package com.influencehealth.edh.cleanse.normalizers

import com.influencehealth.edh.dao.FileReader._
import com.influencehealth.edh.dao._
import com.influencehealth.edh.{CustomLazyLogging, Constants}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType

object EncounterNormalizer extends CustomLazyLogging {

  val CurrentProceduralTerminology: String = "cpt"
  val Diagnosis: String = "dx"
  val Prognosis: String = "px"


  /**
    * Intakes the utilization files
    *
    * @param listOfFileNamesAndDataFrames
    * @return A list of distinct utilization type file names with their respective DataFrames
    */
  def normalizeEncounterFiles(inputList: Map[EncounterFileType, DataFrame]): DataFrame = {

    val demographicData = inputList.filterKeys(_ == DemographicFile).values.toList

    val diagnosisData = inputList.filterKeys(_ == DiagnosisFile).values.toList.
      map(getMedicalCodes(_, Diagnosis))

    val currentProceduralTerminologyData = inputList.filterKeys(_ == CurrentProceduralTerminologyFile).values.toList.
      map(getMedicalCodes(_, CurrentProceduralTerminology))

    val prognosisData = inputList.filterKeys(_ == PrognosisFile).values.toList.
      map(getMedicalCodes(_, Prognosis))

    val facilityData = inputList.filterKeys(_ == FacilityFile).values.toList

    val visitData = inputList.filterKeys(_ == VisitFile).values.toList

    val guarantorData = inputList.filterKeys(_ == GuarantorFile).values.toList

    val biometricData = inputList.filterKeys(_ == BiometricFile).values.toList

    val physicianData = inputList.filterKeys(_ == PhysicianFile).values.toList

    val financialData = inputList.filterKeys(_ == FinancialFile).values.toList

    val nonPhysicianData = diagnosisData ++ currentProceduralTerminologyData ++ facilityData ++
      prognosisData ++ guarantorData ++ financialData ++ biometricData

    // join visit & demographic dataFrames on sourcePersonId
    val joinedVisitAndDemographicDf = joinVisitAndDemographicDataFrames(visitData, demographicData)

    val bioMetricCountIsHigher = biometricData.reduceOption(_ union _).exists { df =>
      val distinctSourceRecordIdsInBiometricFile = df.
        groupBy("sourceRecordId", "sourcePersonId").count().count()
      distinctSourceRecordIdsInBiometricFile < df.count()
    }

    if (bioMetricCountIsHigher) {
      throw new RuntimeException(
        "There are more records in Biometric files than the number of visits and demographic combined")
    }

    logger.info("Join visit & demog count: " + joinedVisitAndDemographicDf.count)
    // join the remaining dataFrames based on sourcePersonId and sourceRecordId
    val joinedRemainingDfs = joinRemainingDataFrames(nonPhysicianData, joinedVisitAndDemographicDf).
      withColumn("dateCreated", lit(Constants.Now.toString)).
      withColumn("dateModified", col("dateCreated"))

    logger.info("Join visit & demog's resultant to a other dfs count: " + joinedRemainingDfs.count)
    if (physicianData.nonEmpty) {
      // joining physician dataFrame based on visit_pcp_id
      val completeJoinedDf = joinPhysicianAndVisitDataFrames(physicianData, joinedRemainingDfs)
      logger.info("Join consolidated with physician count: " + completeJoinedDf.count)
      completeJoinedDf
    }
    else {
      joinedRemainingDfs
    }
  }


  private def getMedicalCodes(df: DataFrame, medicalCodeType: String): DataFrame = {
    val codeDf: DataFrame = medicalCodeType match {
      case CurrentProceduralTerminology => df.where("sourcePersonId is not null and sourceRecordId is not null and" +
        " currentProceduralTerminologyMxVersion is not null and currentProceduralTerminologyMxCode is not null" +
        " and currentProceduralTerminologyPriorityNo is not null").
        groupBy(col("sourceRecordId"), col("sourcePersonId")).agg(collect_list(
        struct(
          col("currentProceduralTerminologyMxCode").substr(0, 5) as "medicalCode",
          col("currentProceduralTerminologyMxVersion") as "medicalCodeType",
          col("currentProceduralTerminologyPriorityNo").cast(IntegerType) as "sequenceNumber"
        )) as "currentProceduralTerminologyCodes").
        drop(
          "currentProceduralTerminologyMxVersion",
          "currentProceduralTerminologyMxVersion",
          "currentProceduralTerminologyPriorityNo")
      case Diagnosis => df.where("sourcePersonId is not null and sourceRecordId is not null and" +
        " diagnosisMxVersion is not null and diagnosisMxCode is not null and diagnosisPriorityNo is not null").
        groupBy(col("sourceRecordId"), col("sourcePersonId")).agg(collect_list(
        struct(
          stripDecimal(col("diagnosisMxCode")) as "medicalCode",
          stripNonAlphaNumericCharacters(col("diagnosisMxVersion")) as "medicalCodeType",
          col("diagnosisPriorityNo").cast(IntegerType) as "sequenceNumber"
        )) as "diagnosisCodes").
        drop("diagnosisMxCode", "diagnosisMxVersion", "diagnosisPriorityNo")
      case Prognosis => df.where("sourcePersonId is not null and sourceRecordId is not null and" +
        " prognosisMxCode is not null and prognosisMxVersion is not null and prognosisPriorityNo is not null").
        groupBy(col("sourceRecordId"), col("sourcePersonId")).agg(collect_list(
        struct(
          stripDecimal(col("prognosisMxCode")) as "medicalCode",
          stripNonAlphaNumericCharacters(col("prognosisMxVersion")) as "medicalCodeType",
          col("prognosisPriorityNo").cast(IntegerType) as "sequenceNumber"
        )) as "procedureCodes").
        drop("prognosisMxCode", "prognosisMxVersion", "prognosisPriorityNo")
    }
    codeDf
  }

  /**
    * Joins the demographic and visit dataFrame on sourcePersonId
    *
    * @param listContainingNonPhysicianData (FileType, DataFrame)
    * @return a dataFrames of resultant join condition
    */
  private def joinVisitAndDemographicDataFrames(
                                                 visitData: List[DataFrame],
                                                 demographicData: List[DataFrame]
                                               ): DataFrame = {

    visitData.
      reduce(_ union _).
      join(demographicData.reduce(_ union _), Seq("sourcePersonId"), "full_outer")

  }

  /**
    * Join the remaining dataFrames with joinedDemogAndVisit based on sourcePersonId and sourceRecordId
    *
    * @param listContainingNonPhysicianData list of all the dataFrames
    * @param joinedVisitAndDemographicDf    joined visit and demographic dfs
    * @return a dataFrame of resultant join condition
    */
  private def joinRemainingDataFrames(
                                       nonPhysicianData: List[DataFrame],
                                       joinedVisitAndDemographicDf: DataFrame
                                     ): DataFrame = {


    nonPhysicianData.foldLeft(joinedVisitAndDemographicDf) { (df, inputDf) =>
      df.join(inputDf, Seq("sourcePersonId", "sourceRecordId"), "left_outer")
    }

  }

  /**
    * joins physician dataFrame with visit dataFrame
    *
    * @param physiciansFiles physician df
    * @param consolidatedDf  consolidated df
    * @return
    */
  private def joinPhysicianAndVisitDataFrames(
                                               physiciansFiles: List[DataFrame],
                                               consolidatedDf: DataFrame
                                             ): DataFrame = {

    val attendingNpiValuesDf = physiciansFiles.reduce(_ union _).select("primaryCarePhysicianId", "physicianNationalProviderIdentifier").
      withColumnRenamed("primaryCarePhysicianId", "attendingId")

    // get attending NPI
    val attendingNpiDf = consolidatedDf.join(attendingNpiValuesDf, Seq("attendingId"), "left_outer")
      .withColumnRenamed("physicianNationalProviderIdentifier", "attendingPhysicianNationalProviderIdentifier")

    val referencingNpiValuesDf = attendingNpiValuesDf.withColumnRenamed("attendingId", "referencingId")

    // get Referencing NPI
    val referencingNpiDf = attendingNpiDf.join(referencingNpiValuesDf, Seq("referencingId"), "left_outer")
      .withColumnRenamed("physicianNationalProviderIdentifier", "referencingPhysicianNationalProviderIdentifier")

    // Physician DF Join
    val joinedDfs=physiciansFiles.foldLeft(referencingNpiDf)((a, b) => a.join(b, Seq("primaryCarePhysicianId"), "left_outer"))

    val providersDf = joinedDfs.withColumn("providers", providers(
      joinedDfs("attendingPhysicianNationalProviderIdentifier"),
      joinedDfs("referencingPhysicianNationalProviderIdentifier"),
      joinedDfs("physicianNationalProviderIdentifier"))).
      drop("attendingPhysicianNationalProviderIdentifier", "referencingPhysicianNationalProviderIdentifier")

    providersDf  }

  /**
    * Constructs a set of attendingNpi, referringNpi and pcpNpi with their internal EDH mappings.
    */
  def providers: UserDefinedFunction = udf((attendingNpi: String, referringNpi: String, physicianNpi: String) => {
    val attending =
      stringToOption(attendingNpi).
        map(x => s"$x;${Constants.physicianNPICodes("attendingNationalProviderIdentifier")}").toSeq
    val referring =
      stringToOption(referringNpi).
        map(x => s"$x;${Constants.physicianNPICodes("referringNationalProviderIdentifier")}").toSeq
    val physician =
      stringToOption(physicianNpi).
        map(x => s"$x;${Constants.physicianNPICodes("physicianNationalProviderIdentifier")}").toSeq

    (attending ++ referring ++ physician).filter(_.nonEmpty)
  })

  /**
    * converts a string into Option[String] if it is not null or empty
    *
    * @return
    */
  def stringToOption(str: String): Option[String] = str match {
    case x if x == null || x.isEmpty => None
    case x => Some(x)
  }

}

