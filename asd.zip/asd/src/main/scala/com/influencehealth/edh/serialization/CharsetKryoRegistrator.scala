package com.influencehealth.edh.serialization

import java.nio.charset.Charset

import com.esotericsoftware.kryo.io.{Input, Output}
import com.esotericsoftware.kryo.{Kryo, Serializer}
import com.typesafe.scalalogging.Logger
import org.apache.spark.serializer.KryoRegistrator


/**
  * Created to solve UTF-8 serialization issues with spark broadcast variables.
  * Also adds registers UTF-16, UTF-16BE, UTF-16LE, ISO_8859_1.
  * Borrowed from https://github.com/jagrutmehta/kryo-UTF and altered using
  * https://stackoverflow.com/questions/36144618/spark-kryo-register-a-custom-serializer
  */
class CharsetKryoRegistrator extends KryoRegistrator {

  /**
    * Registers java.nio.charset classes. By default it will register UTF-8,
    * UTF-16, UTF-16BE, UTF-16LE, ISO_8859_1 and US_ASCII. You can add more.
    *
    * @param kryo
    */
  override def registerClasses(kryo: Kryo): Unit = {
    val charsetCustomListSerializer: Serializer[Any] = new Serializer[Any] {
      def write(kryo: Kryo, output: Output, `object`: Any): Unit = {
        val charset = `object`.asInstanceOf[Charset]
        kryo.writeObject(output, charset.name)
      }

      def read(kryo: Kryo, input: Input, `type`: Class[Any]): Charset = {
        Charset.forName(kryo.readObject(input, classOf[String]))
      }

    }
    // Register those Charset classes which are not public.
    registerCharsets(kryo, "UTF-8", charsetCustomListSerializer)
    registerCharsets(kryo, "UTF-16", charsetCustomListSerializer)
    registerCharsets(kryo, "UTF-16BE", charsetCustomListSerializer)
    registerCharsets(kryo, "UTF-16LE", charsetCustomListSerializer)
    registerCharsets(kryo, "ISO_8859_1", charsetCustomListSerializer)
  }

  /**
    * Safe method to register CharSets. It ignores any exception and moves on.
    *
    * @param kryo
    * @param name
    * @param s
    * @return
    */
  private def registerCharsets(kryo: Kryo, name: String, s: Serializer[Any]): Boolean = {
    try {
      kryo.register(Charset.forName(name).getClass, s)
      true
    } catch {
      case e: Throwable =>
        val logger = Logger("KryoCharsetSeralizer")
        logger.warn("Unable to register charset " + name + " with Kryo. Exception is " + e.getMessage)
        false
    }
  }
}