package com.influencehealth.edh

import java.sql.Date

import com.influencehealth.edh.model.EdhCustomer
import org.joda.time.{DateTime, DateTimeZone, LocalDate}

object Constants {

  val Today: DateTime = LocalDate.now(DateTimeZone.UTC).
    toDateTimeAtStartOfDay(DateTimeZone.UTC)

  val Now: DateTime = DateTime.now(DateTimeZone.UTC)

  final val CASSANDRA_PARALLEL: Int = 48
  final val BLOCK_SIZE: Double = (64 * 1024 * 1024).toDouble

  val InputFileDelimiter = "|"
  val ErrorFileDelimiter = ","

  val batchRawPhase = "RAW"
  val batchCleansedPhase = "CLEANSED"

  val PersonTypePatient = "PATIENT"
  val PersonTypeNewMover = "NEW MOVER"
  val PersonTypeProspect = "PROSPECT"
  val PersonTypeQualifiedProspect = "QUALIFIED PROSPECT"
  val PersonTypeFamilyMember = "FAMILY MEMBER OF PATIENT"
  val PersonTypeDeceased = "DECEASED"
  val PersonTypeDNS = "DNS"
  val SourcePersonTypePatient = "C"

  ///////////////////////
  // Cleanse
  ///////////////////////
  val EncounterInfluenceHealthFormat: String = "INFLUENCEHEALTH"
  val EncounterInfluenceHealthDefaultSource: String = "MEDITECH"
  val EncounterDefaultAddressType: String = "HOME"
  val EncounterDefaultMessageType: String = "ENCOUNTER"
  val EncounterDefaultSourceType: String = "HOSPITAL"
  val EncounterActivityType: String = "ENCOUNTER"
  val EncounterPersonType: String = PersonTypePatient

  val ProspectExperianFormat: String = "STANDARD"
  val ProspectExperianSource: String = "EXPERIAN"
  val ProspectDefaultMessageType: String = "PROSPECT"
  val ProspectDefaultSourceType: String = "PROSPECT"
  val ProspectDefaultPersonType: String = PersonTypeProspect
  val ProspectActivityType: String = "PROSPECT"
  val ProspectDefaultAddressType: String = "HOME"

  val NewMoverExperianFormat: String = "STANDARD"
  val NewMoverExperianDefaultSource: String = "NEWMOVERS"
  val NewMoverDefaultAddressType: String = "HOME"
  val NewMoverDefaultMessageType: String = "NEW MOVERS"
  val NewMoverDefaultSourceType: String = "NEWMOVERS"
  val NewMoverActivityType: String = "NEWMOVERS"
  val NewMoverPersonType: String = PersonTypeNewMover

  val CallCenterSteriCycleFormat: String = "STERICYCLE"
  val CallCenterBerylFormat: String = "BERYL"
  val CallCenterBerylDefaultSource: String = "CALLCENTER"
  val CallCenterConiferFormat: String = "CONIFER"
  val CallCenterConiferDefaultSource: String = "CALLCENTER"
  val CallCenterDefaultMessageType: String = "CALL CENTER"
  val CallCenterDefaultSourceType: String = "CALL CENTER"
  val CallCenterActivityType: String = "CALLCENTER"
  val CallCenterPersonType: String = PersonTypeQualifiedProspect
  val CallCenterDefaultAddressType: String = "HOME"

  val DeceasedInfluenceHealthFormat: String = "INFLUENCEHEALTH"
  val DeceasedInfluenceHealthDefaultSource: String = "DECEASED"
  val DeceasedDefaultAddressType: String = "HOME"
  val DeceasedDefaultMessageType: String = "DECEASED"
  val DeceasedDefaultSourceType: String = "DECEASED"
  val DeceasedActivityType: String = "DECEASED"
  val DeceasedPersonType: String = PersonTypeDeceased

  val DonorListInfluenceHealthFormat: String = "INFLUENCEHEALTH"
  val DonorListInfluenceHealthDefaultSource: String = "MEDITECH"
  val DonorListDefaultAddressType: String = "HOME"
  val DonorListDefaultMessageType: String = "DONOR LIST"
  val DonorListDefaultSourceType: String = "HOSPITAL"
  val DonorListActivityType: String = "DONORLIST"
  val DonorListPersonType: String = PersonTypeQualifiedProspect

  val DoNotSolicitFoundationFormat: String = "FOUNDATION"
  val DoNotSolicitInfluenceHealthDefaultSource: String = "MEDITECH"
  val DoNotSolicitDefaultAddressType: String = "HOME"
  val DoNotSolicitDefaultMessageType: String = "DNS"
  val DoNotSolicitDefaultSourceType: String = "DNS"
  val DoNotSolicitActivityType: String = "DNS"
  val DoNotSolicitPersonType: String = PersonTypeDNS
  val DoNotSolicitDefaultDoNotSolicitFlag: Boolean = true

  val DoNotSolicitUpdateInfluenceHealthFormat: String = "INFLUENCEHEALTH"
  val DoNotSolicitUpdateInfluenceHealthDefaultSource: String = "MEDITECH"
  val DoNotSolicitUpdateDefaultAddressType: String = "HOME"
  val DoNotSolicitUpdateDefaultMessageType: String = "DONOTSOLICITUPDATE"
  val DoNotSolicitUpdateDefaultSourceType: String = "HOSPITAL"
  val DoNotSolicitUpdateActivityType: String = "DONOTSOLICITUPDATE"
  val DoNotSolicitUpdatePersonType: String = PersonTypeDNS

  val EmployeeRosterInfluenceHealthFormat: String = "INFLUENCEHEALTH"
  val EmployeeRosterDefaultSource: String = "EMPLOYEEROSTER" // TODO: Used to be Meditech test case required EMPLOYEEROSTER. Figure out which filed meditech goes into
  val EmployeeRosterDefaultAddressType: String = "HOME"
  val EmployeeRosterDefaultMessageType: String = "EMPLOYEE ROSTER"
  val EmployeeRosterDefaultSourceType: String = "EMPLOYEE ROSTER"
  val EmployeeRosterActivityType: String = "EMPLOYEEROSTER"
  val EmployeeRosterDefaultPersonType: String = PersonTypeQualifiedProspect

  val HraMedicomFormat: String = "MEDICOM"
  val HraMedicomDefaultSource: String = "MEDITECH"
  val HraHealthWareFormat: String = "HEALTHWARE"
  val HraDefaultAddressType: String = "HOME"
  val HraDefaultMessageType: String = "HRA"
  val HraDefaultSourceType: String = "HRA"
  val HraActivityType: String = "HRA"
  val HraPersonType: String = PersonTypeQualifiedProspect

  val MarketingListInfluenceHealthFormat: String = "INFLUENCEHEALTH"
  val MarketingListInfluenceHealthDefaultSource: String = "MARKETINGLIST"
  val MarketingListDefaultAddressType: String = "HOME"
  val MarketingListDefaultMessageType: String = "MARKETING_LIST"
  val MarketingListDefaultSourceType: String = "HOSPITAL"
  val MarketingListActivityType: String = "MARKETINGLIST"
  val MarketingListPersonType: String = PersonTypeQualifiedProspect

  val ReferralInfluenceHealthFormat: String = "STERICYCLE"
  val ReferralInfluenceHealthDefaultSource: String = "REFERRAL"
  val ReferralDefaultAddressType: String = "HOME"
  val ReferralDefaultMessageType: String = "REFERRAL"
  val ReferralDefaultSourceType: String = "HOSPITAL"
  val ReferralDefaultSource: String = "REFERRAL"
  val ReferralActivityType: String = "REFERRAL"
  val ReferralPersonType: String = PersonTypePatient

  val PersonMasterPrimaryKeyColumns = Seq("person_id", "customer", "customer_id")
  val SocialSecurityAdministrationDefaultSource: String = "SOCIAL_SECURITY_ADMINISTRATION"

  // Anchor Configuration Constants
  val OutputPathKey = "app.enrich.address.output.path"
  val TempPathKey = "app.enrich.address.temp.path"
  val FileNamePrefixKey = "app.enrich.address.output.filename.prefix"
  val OutputFileCountKey = "app.enrich.address.output.count"
  val FileDelimiterKey = "app.enrich.address.file.delimiter"
  val InputFileNameKey = "app.enrich.address.file-path"
  val DownloadLocalPathKey = "app.enrich.address.download.local.path"
  val AnchorScriptFolderKey = "app.utils.script.path"


  // SG2 Configuration Constants
  val SG2OutputPathKey = "app.enrich.caregroupers.output.path"
  val SG2TempPathKey = "app.enrich.caregroupers.temp.path"
  val SG2FileNamePrefixKey = "app.enrich.caregroupers.output.filename.prefix"
  val SG2FileDelimiterKey = "app.enrich.caregroupers.file.delimiter"
  val SG2InputFileNameKey = "app.enrich.caregroupers.input.path"
  val SG2DownloadLocalPathKey = "app.enrich.caregroupers.download.local.path"
  val SG2ScriptFolderKey = "app.utils.script.path"

  val EnrichFirstStepName = "START"
  val EnrichAddressStepName = "ADDRESS"
  val EnrichMockAddressStepName = "MOCKADDRESS"
  val EnrichCrosswalksStepName = "CROSSWALKS"
  val EnrichIdentityStepName = "IDENTITY"
  val EnrichCareGroupsStepName = "CAREGROUPS"
  val DnsEnrichStepName = "DNSSKIP"

  val EnrichResidenceStepName = "RESIDENCE"
  val EnrichChildrenStepName = "CHILDREN"
  val EnrichLocationsStepName = "LOCATIONS"

  // Spark requires precision and scale to be set to these values no matter what
  // https://issues.apache.org/jira/browse/SPARK-18484
  val DecimalTypePrecision = 38
  val DecimalTypeScale = 18

  val SexMale = "MALE"
  val SexFemale = "FEMALE"

  val MaritalStatusSingle = "SINGLE"
  val MaritalStatusMarried = "MARRIED"
  val MaritalStatusWidowed = "WIDOWED"
  val MaritalStatusSeparated = "SEPARATED"
  val MaritalStatusDivorced = "DIVORCED"
  val MaritalStatusLifePartner = "LIFE PARTNER"

  val PhoneTypeMobile = "MOBILE"
  val PhoneTypeHome = "HOME"
  val PhoneTypeWork = "WORK"

  val EmailTypeHome = "HOME"
  val EmailTypeWork = "WORK"

  val activityTypeToPersonType = Map(
    EncounterActivityType -> EncounterPersonType,
    ProspectActivityType -> ProspectDefaultPersonType,
    NewMoverActivityType -> NewMoverPersonType,
    CallCenterActivityType -> CallCenterPersonType,
    DeceasedActivityType -> DeceasedPersonType,
    DonorListActivityType -> DonorListPersonType,
    DoNotSolicitActivityType -> DoNotSolicitPersonType,
    EmployeeRosterActivityType -> EmployeeRosterDefaultPersonType,
    HraActivityType -> HraPersonType,
    MarketingListActivityType -> MarketingListPersonType,
    ReferralActivityType -> ReferralPersonType
  )

  val personTypeRank: Map[String, Int] = Map(
    DeceasedPersonType -> 1,
    EncounterPersonType -> 1,
    ReferralPersonType -> 1,
    EmployeeRosterDefaultPersonType -> 2,
    PersonTypeFamilyMember -> 2,
    ProspectDefaultPersonType -> 3,
    MarketingListPersonType -> 4,
    HraPersonType -> 5,
    DonorListPersonType -> 6,
    NewMoverPersonType -> 7,
    CallCenterPersonType -> 8,
    DoNotSolicitPersonType -> 9
  )

  val activityTypeRank: Map[String, Int] = Map(
    DeceasedActivityType -> 1,
    EncounterActivityType -> 1,
    EmployeeRosterActivityType -> 2,
    ProspectActivityType -> 3,
    MarketingListActivityType -> 4,
    HraActivityType -> 5,
    DonorListActivityType -> 6,
    NewMoverActivityType -> 7,
    CallCenterActivityType -> 8,
    ReferralActivityType -> 8,
    DoNotSolicitActivityType -> 9
  )

  val MaritalStatusMapping = Map(
    "M" -> MaritalStatusMarried,
    "m" -> MaritalStatusMarried,
    "S" -> MaritalStatusSingle,
    "s" -> MaritalStatusSingle,
    "W" -> MaritalStatusWidowed,
    "w" -> MaritalStatusWidowed,
    "X" -> MaritalStatusSeparated,
    "x" -> MaritalStatusSeparated,
    "D" -> MaritalStatusDivorced,
    "d" -> MaritalStatusDivorced,
    "P" -> MaritalStatusLifePartner,
    "p" -> MaritalStatusLifePartner
  )

  val DwellTypeSingleFamily = "SINGLE FAMILY"
  val DwellTypeMultiFamily = "MULTI-FAMILY"
  val DwellTypeMarginalMultiFamily = "MARGINAL MULTI-FAMILY"
  val DwellTypePoBoxes = "P.O. BOXES"

  val DwellTypeMapping = Map[String, String](
    "S" -> DwellTypeSingleFamily,
    "A" -> DwellTypeMultiFamily,
    "M" -> DwellTypeMarginalMultiFamily,
    "P" -> DwellTypePoBoxes
  )

  val RaceWhite = "WHITE"
  val RaceBlackOrAfricanAmerican = "BLACK OR AFRICAN AMERICAN"
  val RaceAsian = "ASIAN"
  val RaceHispanic = "HISPANIC"
  val RaceOther = "OTHER"

  val RaceMapping: Map[String, String] = Map(
    "W" -> RaceWhite,
    "B" -> RaceBlackOrAfricanAmerican,
    "A" -> RaceAsian,
    "H" -> RaceHispanic
  )

  val EstimatedHomeValueMap = Map(
    "A" -> "0 TO 49,999",
    "B" -> "50,000 TO 99,999",
    "C" -> "100,000 TO 149,999",
    "D" -> "150,000 TO 199,999",
    "E" -> "200,000 TO 249,999",
    "F" -> "250,000 TO 299,999",
    "G" -> "300,000 TO 349,999",
    "H" -> "350,000 TO 399,999",
    "I" -> "400,000 TO 449,999",
    "J" -> "450,000 TO 499,999",
    "K" -> "500,000+"
  )

  val physicianNPICodes: Map[String, Int] = Map(
    "attendingNationalProviderIdentifier" -> 1815,
    "referringNationalProviderIdentifier" -> 1820,
    "physicianNationalProviderIdentifier" -> 1805
  )

  val FinancialClassBlueCrossBlueShield = "BLUE CROSS / BLUE SHIELD"
  val FinancialClassCommercial = "COMMERCIAL"
  val FinancialClassManagedCare = "MANAGED CARE"
  val FinancialClassMedicaid = "MEDICAID"
  val FinancialClassMedicaidManaged = "MEDICAID MANAGED"
  val FinancialClassMedicare = "MEDICARE"
  val FinancialClassMedicareManaged = "MEDICARE MANAGED"
  val FinancialClassOther = "OTHER"
  val FinancialClassOtherGovernment = "OTHER GOVERNMENT"
  val FinancialClassSelfPay = "SELF PAY"
  val FinancialClassTricare = "TRICARE"
  val FinancialClassUninsured = "UNINSURED"
  val FinancialClassWorkersCompensation = "WORKERS COMPENSATION"
  val FinancialClassTargetPayerProfitable = "TARGET PAYER  - PROFITABLE"
  val FinancialClassTargetPayerUnprofitable = "TARGET PAYER  - UNPROFITABLE"
  val FinancialClassTargetPayerMedicare = "TARGET PAYER  - MEDICARE"


  val PayerTypeMedicareInferred = "MEDICARE-INFERRED"
  val PayerTypeMedicareKnown = "MEDICARE-KNOWN"
  val PayerTypeNotProfitableInferred = "NOT-PROFITABLE-INFERRED"
  val PayerTypeNotProfitableKnown = "NOT-PROFITABLE-KNOWN"
  val PayerTypeProfitableInferred = "PROFITABLE-INFERRED"
  val PayerTypeProfitableKnown = "PROFITABLE-KNOWN"
  val PayerTypeUnKnown = "UNKNOWN"

  val PayerTypeMedicareInferredDesc = "MI"
  val PayerTypeProfitableInferredDesc = "PI"
  val PayerTypeNotProfitableInferredDesc ="NI"

  val PayerTypeDescriptionMapping = Map(
    "MI" -> PayerTypeMedicareInferred,
    "MK" -> PayerTypeMedicareKnown,
    "NI" -> PayerTypeNotProfitableInferred,
    "NK" -> PayerTypeNotProfitableKnown,
    "PI" -> PayerTypeProfitableInferred,
    "PK" -> PayerTypeProfitableKnown,
    "UU" -> PayerTypeUnKnown
  )

  lazy val MosaicTypesLookup: Map[String, String] = Map(
    "A01" -> "American Royalty",
    "A02" -> "Platinum Prosperity",
    "A03" -> "Kids and Cabernet",
    "A04" -> "Picture Perfect Families",
    "A05" -> "Couples with Clout",
    "A06" -> "Jet Set Urbanites",
    "B07" -> "Generational Soup",
    "B08" -> "Babies and Bliss",
    "B09" -> "Family Fun-tastic",
    "B10" -> "Cosmopolitan Achievers",
    "C11" -> "Aging of Aquarius",
    "C12" -> "Golf Carts and Gourmets",
    "C13" -> "Silver Sophisticates",
    "C14" -> "Boomers and Boomerangs",
    "D15" -> "Sports Utility Families",
    "D16" -> "Settled in Suburbia",
    "D17" -> "Cul de Sac Diversity",
    "D18" -> "Suburban Attainment",
    "E19" -> "Full Pockets, Empty Nests",
    "E20" -> "No Place Like Home",
    "E21" -> "Unspoiled Splendor",
    "F22" -> "Fast Track Couples",
    "F23" -> "Families Matter Most",
    "G24" -> "Status Seeking Singles",
    "G25" -> "Urban Edge",
    "H26" -> "Progressive Potpourri",
    "H27" -> "Birkenstocks and Beemers",
    "H28" -> "Everyday Moderates",
    "H29" -> "Destination Recreation",
    "I30" -> "Stockcars and State Parks",
    "I31" -> "Blue Collar Comfort",
    "I32" -> "Steadfast Conventionalists",
    "I33" -> "Balance and Harmony",
    "J34" -> "Aging in Place",
    "J35" -> "Rural Escape",
    "J36" -> "Settled and Sensible",
    "K37" -> "Wired for Success",
    "K38" -> "Gotham Blend",
    "K39" -> "Metro Fusion",
    "K40" -> "Bohemian Groove",
    "L41" -> "Booming and Consuming",
    "L42" -> "Rooted Flower Power",
    "L43" -> "Homemade Happiness",
    "M44" -> "Red, White and Bluegrass",
    "M45" -> "Diapers and Debit Cards",
    "N46" -> "True Grit Americans",
    "N47" -> "Countrified Pragmatics",
    "N48" -> "Rural Southern Bliss",
    "N49" -> "Touch of Tradition",
    "O50" -> "Full Steam Ahead",
    "O51" -> "Digital Dependents",
    "O52" -> "Urban Ambition",
    "O53" -> "Colleges and Cafes",
    "O54" -> "Striving Single Scene",
    "O55" -> "Family Troopers",
    "P56" -> "Mid-scale Medley",
    "P57" -> "Modest Metro Means",
    "P58" -> "Heritage Heights",
    "P59" -> "Expanding Horizons",
    "P60" -> "Striving Forward",
    "P61" -> "Humble Beginnings",
    "Q62" -> "Reaping Rewards",
    "Q63" -> "Footloose and Family Free",
    "Q64" -> "Town Elders",
    "Q65" -> "Senior Discounts",
    "R66" -> "Dare to Dream",
    "R67" -> "Hope for Tomorrow",
    "S68" -> "Small Town Shallow Pockets",
    "S69" -> "Urban Survivors",
    "S70" -> "Tight Money",
    "S71" -> "Tough Times"
  )

  val ReligionMapping: Map[String, String] = Map(
    "B" -> "BUDDHIST",
    "C" -> "CATHOLIC",
    "E" -> "ETHIOPIAN ORTHODOX",
    "G" -> "GREEK ORTHODOX",
    "H" -> "HINDU",
    "I" -> "ISLAMIC",
    "J" -> "JEWISH",
    "K" -> "SIKH",
    "L" -> "LUTHERAN",
    "M" -> "MORMON",
    "O" -> "EASTERN ORTHODOX",
    "P" -> "PROTESTANT",
    "S" -> "SHINTO"
  )

  val OccupationGroupMapping: Map[String, String] = Map(
    "I1" -> "MANAGEMENT/BUSINESS AND FINANCIAL OPERATIONS",
    "I2" -> "TECHNICAL: COMPUTERS/MATH AND ARCHITECT/ENGINEERING",
    "I3" -> "PROFESSIONAL: LEGAL/EDUCATION AND HEALTH PRACTITIONER",
    "I4" -> "SALES",
    "I5" -> "OFFICE AND ADMINISTRATIVE SUPPORT",
    "I6" -> "BLUE COLLAR",
    "I7" -> "FARMING/FISH/FORESTRY",
    "I8" -> "OTHER",
    "I9" -> "RETIRED",
    "K1" -> "MANAGEMENT/BUSINESS AND FINANCIAL OPERATIONS",
    "K2" -> "TECHNICAL: COMPUTERS/MATH AND ARCHITECT/ENGINEERING",
    "K3" -> "PROFESSIONAL: LEGAL/EDUCATION AND HEALTH PRACTITIONER",
    "K4" -> "SALES",
    "K5" -> "OFFICE AND ADMINISTRATIVE SUPPORT",
    "K6" -> "BLUE COLLAR",
    "K7" -> "FARMING/FISH/FORESTRY",
    "K8" -> "OTHER",
    "K9" -> "RETIRED"
  )

  val EducationBachelorDegree = "BACHELOR DEGREE"
  val EducationSomeCollege = "SOME COLLEGE"
  val EducationLessThanHighSchoolDiploma = "LESS THAN HIGH SCHOOL DIPLOMA"
  val EducationHighSchool = "HIGH SCHOOL DIPLOMA"
  val EducationGraduateDegree = "GRADUATE DEGREE"

  val EducationMapping: Map[Int, String] = Map(
    0 -> EducationLessThanHighSchoolDiploma,
    1 -> EducationHighSchool,
    2 -> EducationSomeCollege,
    3 -> EducationBachelorDegree,
    4 -> EducationGraduateDegree
  )
  val DefinedReligionLookupValues = Seq("B", "C", "E", "H", "I", "J", "K", "L", "M", "O", "P", "S", "X")
  val DefinedReligion = Seq(
    "BUDDHIST",
    "CATHOLIC",
    "ETHIOPIAN ORTHODOX",
    "GREEK ORTHODOX",
    "HINDU",
    "ISLAMIC",
    "JEWISH",
    "SIKH",
    "LUTHERAN",
    "MORMON",
    "EASTERN ORTHODOX",
    "PROTESTANT",
    "SHINTO",
    null
  )
  val DefinedRaceLookupValues = Seq("W", "A", "B", "U", "H", "O")
  val DefinedRace = Seq(
    Constants.RaceWhite,
    Constants.RaceBlackOrAfricanAmerican,
    Constants.RaceAsian,
    Constants.RaceHispanic,
    Constants.RaceOther
  )


  val BeehiveToFinancialClass: Map[Int, (Option[Int], Option[String], Option[String])] =
    Map(
      1 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferred)),
      2 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferred)),
      3 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferred)),
      4 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferred)),
      5 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferred)),
      6 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferred)),
      7 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferred)),
      8 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferred)),
      9 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferred)),
      10 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferred)),
      11 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferred)),
      12 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferred)),
      13 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferred)),
      14 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferred)),
      15 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferred)),
      16 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferred)),
      17 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferred)),
      18 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferred)),
      19 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferred)),
      20 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferred)),
      21 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferred)),
      22 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferred)),
      23 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferred)),
      24 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferred)),
      25 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferred)),
      26 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferred)),
      27 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferred)),
      28 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferred)),
      29 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferred)),
      30 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferred))
    )

  val PayerTypeBeehiveToFinancialClass: Map[Int, (Option[Int], Option[String], Option[String])] =
    Map(
      1 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferredDesc)),
      2 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferredDesc)),
      3 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferredDesc)),
      4 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferredDesc)),
      5 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferredDesc)),
      6 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferredDesc)),
      7 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferredDesc)),
      8 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferredDesc)),
      9 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferredDesc)),
      10 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferredDesc)),
      11 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferredDesc)),
      12 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferredDesc)),
      13 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferredDesc)),
      14 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferredDesc)),
      15 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferredDesc)),
      16 -> (Some(9910), Some(FinancialClassTargetPayerProfitable), Some(PayerTypeProfitableInferredDesc)),
      17 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferredDesc)),
      18 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferredDesc)),
      19 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferredDesc)),
      20 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferredDesc)),
      21 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferredDesc)),
      22 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferredDesc)),
      23 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferredDesc)),
      24 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferredDesc)),
      25 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferredDesc)),
      26 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferredDesc)),
      27 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferredDesc)),
      28 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferredDesc)),
      29 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferredDesc)),
      30 -> (Some(9920), Some(FinancialClassTargetPayerUnprofitable), Some(PayerTypeNotProfitableInferredDesc))
    )

  val DefinedPayerTypes = Seq("MI", "MK", "NI", "NK", "PI", "PK", "UU", null,PayerTypeMedicareInferred,PayerTypeMedicareKnown,PayerTypeNotProfitableInferred,PayerTypeNotProfitableKnown,PayerTypeProfitableInferred,
    PayerTypeProfitableKnown)

  val DefinedPayerTypeCodes: Seq[String] = Seq("MI", "MK", "NI", "NK", "PI", "PK", "UU", null)

  val DefinedState = Seq("AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA", "HI", "ID", "IL", "IN", "IA", "KS", "KY",
    "LA", "ME", "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND",
    "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY", "GU",
    "PR", "VI", "AA", "AE", "AP", "DC")

  val DefinedFullTextStateMapping: Map[String, String] = Map(
    "Alabama" -> "AL",
    "Alaska" -> "AK",
    "Alberta" -> "AB",
    "American Samoa" -> "AS",
    "Arizona" -> "AZ",
    "Arkansas" -> "AR",
    "Armed Forces (AE," -> "AE",
    "Armed Forces Americas" -> "AA",
    "Armed Forces Pacific" -> "AP",
    "British Columbia" -> "BC",
    "California" -> "CA",
    "Colorado" -> "CO",
    "Connecticut" -> "CT",
    "Delaware" -> "DE",
    "District Of Columbia" -> "DC",
    "Florida" -> "FL",
    "Georgia" -> "GA",
    "Guam" -> "GU",
    "Hawaii" -> "HI",
    "Idaho" -> "ID",
    "Illinois" -> "IL",
    "Indiana" -> "IN",
    "Iowa" -> "IA",
    "Kansas" -> "KS",
    "Kentucky" -> "KY",
    "Louisiana" -> "LA",
    "Maine" -> "ME",
    "Manitoba" -> "MB",
    "Maryland" -> "MD",
    "Massachusetts" -> "MA",
    "Michigan" -> "MI",
    "Minnesota" -> "MN",
    "Mississippi" -> "MS",
    "Missouri" -> "MO",
    "Montana" -> "MT",
    "Nebraska" -> "NE",
    "Nevada" -> "NV",
    "New Brunswick" -> "NB",
    "New Hampshire" -> "NH",
    "New Jersey" -> "NJ",
    "New Mexico" -> "NM",
    "New York" -> "NY",
    "Newfoundland" -> "NF",
    "North Carolina" -> "NC",
    "North Dakota" -> "ND",
    "Northwest Territories" -> "NT",
    "Nova Scotia" -> "NS",
    "Nunavut" -> "NU",
    "Ohio" -> "OH",
    "Oklahoma" -> "OK",
    "Ontario" -> "ON",
    "Oregon" -> "OR",
    "Pennsylvania" -> "PA",
    "Prince Edward Island" -> "PE",
    "Puerto Rico" -> "PR",
    "Quebec" -> "QC",
    "Rhode Island" -> "RI",
    "Saskatchewan" -> "SK",
    "South Carolina" -> "SC",
    "South Dakota" -> "SD",
    "Tennessee" -> "TN",
    "Texas" -> "TX",
    "Utah" -> "UT",
    "Vermont" -> "VT",
    "Virgin Islands" -> "VI",
    "Virginia" -> "VA",
    "Washington" -> "WA",
    "West Virginia" -> "WV",
    "Wisconsin" -> "WI",
    "Wyoming" -> "WY",
    "Yukon Territory" -> "YT")


  val DefinedMosaicZip4 = Seq("A01", "A02", "A03", "A04", "A05", "A06", "B07", "B08", "B09",
    "B10", "C11", "C12", "C13",
    "C14", "D15", "D16", "D17", "D18", "E19", "E20", "E21", "F22", "F23",
    "G24", "G25", "H26", "H27", "H28",
    "H29", "I30", "I31", "I32", "I33", "J34", "J35", "J36",
    "K37", "K38", "K39", "K40", "L41", "L42", "L43", "M44",
    "M45", "N46", "N47", "N48", "N49", "O50", "O51", "O52", "O53", "O54",
    "O55", "P56", "P57", "P58", "P59", "P60", "P61", "Q62", "Q63", "Q64",
    "Q65", "R66", "R67", "S68", "S69", "S70", "S71")

  val DefinedPersonTypes = Seq(Constants.PersonTypePatient,Constants.PersonTypeProspect,Constants.PersonTypeNewMover,
    Constants.PersonTypeFamilyMember,
    Constants.PersonTypeQualifiedProspect,Constants.PersonTypeDeceased,
    Constants.PersonTypeDNS)
  val DefinedCombinedOwner = Seq("7", "8", "9", "H", "R", "T", "U")
  val StandardLanguageTypes = Seq("eng","dan","swe","nor","fin","ice","dut","wln","ger","hun","cze","slo","fre","ita",
    "spa","por","pol","est","lav","lit","geo","arm","rus","tur","kur","gre","per","rum","bul","rum","alb","slv","hrv",
    "aze","kaz","pus","urd","ben","ind","bur","mon","chi","kor","jpn","tha","may","lao","khm","vie","sin","uzb","heb",
    "ara","tuk","tgk","kir","ton","orm","bnt","dzo","amh","tsn","hin","nep","smo","tib","ssw","zul","xho","afr","twi",
    "swa","hau","som","mac","ibo","yor","tgl","sot","mlg","baq")

  val DefinedDwellTypes = Seq( DwellTypeSingleFamily,DwellTypeMultiFamily,
    DwellTypeMarginalMultiFamily,DwellTypePoBoxes)
  val DefinedMaritalStatus = Seq(MaritalStatusSingle,MaritalStatusMarried,MaritalStatusWidowed,
    MaritalStatusSeparated, MaritalStatusDivorced,MaritalStatusLifePartner)
  val DefinedDonateToCharity = Seq("Y", "N", "U")
  val DefinedPortalStatus = Seq("0", "1", "2", "3", "4", "5", "6", "9")
  val DefinedMosaicGlobalZip4Types = Seq("A", "B", "C", "D", "E", "F", "G", "H", "I", "J")

  val DefinedSex = Seq("M", "MALE", "F", "FEMALE", "UNKNOWN", "U")
  val DefinedFinancialClass = Seq(FinancialClassBlueCrossBlueShield,FinancialClassCommercial,FinancialClassManagedCare,  FinancialClassMedicaid,
    FinancialClassMedicaidManaged, FinancialClassMedicare, FinancialClassMedicareManaged, FinancialClassOther,
    FinancialClassOtherGovernment, FinancialClassSelfPay, FinancialClassTricare, FinancialClassUninsured,
    FinancialClassWorkersCompensation, FinancialClassTargetPayerProfitable, FinancialClassTargetPayerUnprofitable, FinancialClassTargetPayerMedicare)

  val DefinedMailResponder = Seq("M", "U", "Y")
  val DefinedHouseholdCompositionTypes = Seq("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "U")
  val DefinedEstimatedHomeValueTypes = Seq("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "U")
  val DefinedHouseHoldIncomeTypes = Seq("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "U")

  val MaritalStatusCodes: Map[String, String] = Map(
    MaritalStatusSingle -> "07",
    MaritalStatusMarried -> "06").
    withDefaultValue("07")

  val NoServiceArea: String = "NO_SERVICE_AREA"

  // Oldest date. To be set to for default old dates for activity related records
  val DefaultDate: Date = Date.valueOf("1000-01-01")
  val SlackHooks = "https://hooks.slack.com/services/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"

  val greaterThanOperator = ">"
  val equalToOperator = "="
  val lessThanOperator = "<"
  val greaterThanAndEqualToOperator = ">="

  val thresholdValues: Map[String, Double] = Map(
    // For totalPersons, configurable value is not a percentage value.
    "tannerTotalPersonsWarn" -> 500000.0,
    "tannerTotalPersonsFail" -> 1.0,
    "christusTotalPersonsWarn" -> 500000.0,
    "christusTotalPersonsFail" -> 1.0,

    // total number of adults
    "totalAdultsWarn" -> 70.0,
    "totalAdultsFail" -> 1.0,

    // firstName
    "firstName_warn" -> 10.0,
    "firstName_fail" -> 99.0,

    // lastName
    "lastName_warn" -> 10.0,
    "lastName_fail" -> 99.0,

    // dateOfBirth
    "dateOfBirth_warn" -> 10.0,
    "dateOfBirth_fail" -> 99.0,

    // dateOfBirth_future_date
    "dateOfBirth_future_date_warn" -> 1.0,
    "dateOfBirth_future_date_fail" -> 10.0,

    // dateOfDeath_future_date
    "dateOfDeath_future_date_warn" -> 1.0,
    "dateOfDeath_future_date_fail" -> 10.0,

    // address1
    "address1_warn" -> 10.0,
    "address1_fail" -> 99.0,

    // zip5
    "zip5_warn" -> 10.0,
    "zip5_fail" -> 99.0,

    // isDeceased
    "isDeceased_warn" -> 10.0,
    "isDeceased_fail" -> 99.0,

    // householdComposition
    "householdComposition_warn" -> 1.0,
    "householdComposition_Fail" -> 5.0,

    // addressQualityIndicator
    "addressQualityIndicator_warn" -> 10.0,
    "addressQualityIndicator_fail" -> 99.0,

    // sourceAge
    "sourceAge_warn" -> 5.0,
    "sourceAge_fail" -> 10.0,

    // payerType
    "payerType_warn" -> 10.0,
    "payerType_fail" -> 99.0,

    // sex
    "sex_warn" -> 10.0,
    "sex_fail" -> 99.0,

    // financialClass.0
    "financialClass_warn" -> 10.0,
    "financialClass_fail" -> 99.0,

    // age_bucket
    "age_bucket_warn" -> 1.0,
    "age_bucket_fail" -> 5.0,

    // dateOfBirth_age
    "dateOfBirth_age_warn" -> 0.0,
    "dateOfBirth_age_fail" -> 4.0,

    // children_living_unit
    "children_living_unit_warn" -> 1.0,
    "children_living_unit_fail" -> 5.0,

    // standardAgeValue
    "standardAgeValueWarn" -> 98.0,
    "standardAgeValueFail" -> 90.0,

    // wealthRating
    "wealthRatingWarn" -> 50.0,
    "wealthRatingFail" -> 40.0,

    // zip4
    "zip4Warn" -> 98.0,
    "zip4Fail" -> 90.0,

    // zip5
    "zip5Warn" -> 98.0,
    "zip5Fail" -> 90.0,

    // locations
    "locationsWarn" -> 98.0,
    "locationsFail" -> 90.0,

    // experianData
    "experianDataWarn" -> 40.0,
    "experianDataFail" -> 15.0,

    // patientsWithNoEncounters
    "patientsWithNoEncountersWarn" -> 90.0,
    "patientsWithNoEncountersFail" -> 1.0

  )

  val JobCompletedMessage = "COMPLETED"
  val JobFailureMessage = "FAILED"

  val listOccupationValidValues = Seq (
    "MANAGEMENT/BUSINESS AND FINANCIAL OPERATIONS",
    "TECHNICAL: COMPUTERS/MATH AND ARCHITECT/ENGINEERING",
    "PROFESSIONAL: LEGAL/EDUCATION AND HEALTH PRACTITIONER",
    "SALES",
    "OFFICE AND ADMINISTRATIVE SUPPORT",
    "BLUE COLLAR",
    "FARMING/FISH/FORESTRY",
    "OTHER",
    "RETIRED"
  )

  // map that contains valid values Sequence and column name tuple
  val validValuesForColumns: Map[String, Seq[String]] =
    Map(
      "religion" -> DefinedReligion,
      "race" -> DefinedRace,
      "state" -> DefinedState,
      "mailResponder" -> DefinedMailResponder,
      "mosaicZip4" -> DefinedMosaicZip4,
      "personType" -> DefinedPersonTypes,
      "payerType" -> DefinedPayerTypes,
      "combinedOwner" -> DefinedCombinedOwner,
      "maritalStatus" -> DefinedMaritalStatus,
      "dwellType" -> DefinedDwellTypes,
      "occupationGroup" -> listOccupationValidValues,
      "mosaicGlobalZip4" -> DefinedMosaicGlobalZip4Types,
      "householdIncome" -> DefinedHouseHoldIncomeTypes,
      "estimatedHomeValue" -> DefinedEstimatedHomeValueTypes,
      "householdComposition" -> DefinedHouseholdCompositionTypes,
      "isoLanguageCode" -> StandardLanguageTypes
    )

  val nullCheckColumns: Seq[String] = Seq(
    "firstName",
    "lastName",
    "dateOfBirth",
    "address1",
    "zip5",
    "isDeceased",
    "householdComposition",
    "addressQualityIndicator",
    "sourceAge"
  )

  val collectionColumns: Seq[String] =
    Seq(
      "phoneNumbers",
      "emails"
    )

  val nullOrUnknownCheckColumns: Seq[String] = Seq(
    "payerType"
  )

  val encounterDataMappingColumns: Seq[String] = Seq(
    "sex",
    "employer",
    "emails",
    "portalStatus",
    "dateOfDeath",
    "maritalStatus",
    "race",
    "householdIncome"
  )

  val nullAndGreaterThanZeroColumns: Seq[String] = Seq(
    "homeLandValue",
    "homeYearBuilt",
    "lengthOfResidence"
  )

  val listMaritalStatusValidValues = Seq (MaritalStatusSingle,MaritalStatusMarried,MaritalStatusWidowed,
    MaritalStatusSeparated, MaritalStatusDivorced,MaritalStatusLifePartner)

  val listDwellValidValues = Seq(DwellTypeSingleFamily,DwellTypeMultiFamily,
    DwellTypeMarginalMultiFamily,DwellTypePoBoxes)

  val listEducationValidValues = Seq (EducationBachelorDegree,EducationSomeCollege,EducationLessThanHighSchoolDiploma,
    EducationHighSchool,EducationGraduateDegree)

  val EdhCustomers: Set[EdhCustomer] = Set(
    EdhCustomer(1,"piedmont"),
    EdhCustomer(40,"medseek"),
    EdhCustomer(71,"php"),
    EdhCustomer(74,"chihealth"),
    EdhCustomer(75,"trinity"),
    EdhCustomer(76,"presence"),
    EdhCustomer(78,"monroe"),
    EdhCustomer(80,"legacyhealth"),
    EdhCustomer(82,"hahv"),
    EdhCustomer(84,"christushealth"),
    EdhCustomer(85,"samc"),
    EdhCustomer(90,"chs"),
    EdhCustomer(101,"beaufort"),
    EdhCustomer(104,"evergreen"),
    EdhCustomer(105,"allegiancehealth"),
    EdhCustomer(106,"mosaiclifecare"),
    EdhCustomer(108,"promedica"),
    EdhCustomer(110,"prohealth"),
    EdhCustomer(111,"universitycolorado"),
    EdhCustomer(113,"reid"),
    EdhCustomer(115,"texashealth"),
    EdhCustomer(116,"stlukes"),
    EdhCustomer(117,"meridianhealth"),
    EdhCustomer(118,"chistlukes"),
    EdhCustomer(119,"athens"),
    EdhCustomer(120,"tucson"),
    EdhCustomer(122,"memorialhealth"),
    EdhCustomer(124,"nortonhealth"),
    EdhCustomer(125,"hca"),
    EdhCustomer(126,"baptistkentucky"),
    EdhCustomer(127,"chomp"),
    EdhCustomer(128,"fremont"),
    EdhCustomer(129,"quorum"),
    EdhCustomer(132, "peacehealth"),
    EdhCustomer(134, "centralmaine"),
    EdhCustomer(20001,"northwell"),
    EdhCustomer(20002,"archildrens"),
    EdhCustomer(20003, "bonsecours"),
    EdhCustomer(99999, "peachtree"),
    EdhCustomer(20004, "tanner"),
    EdhCustomer(20005, "christus")
  )

  val StandardLanguageMap: Map[String, (String, String)] = Map(
    "01" -> ("english","eng"),
    "03" -> ("danish","dan"),
    "04" -> ("swedish","swe"),
    "05" -> ("norwegian","nor"),
    "06" -> ("finnish","fin"),
    "07" -> ("icelandic","ice"),
    "08" -> ("dutch; flemish","dut"),
    "09" -> ("walloon","wln"),
    "10" -> ("german","ger"),
    "12" -> ("hungarian","hun"),
    "13" -> ("czech","cze"),
    "14" -> ("slovak","slo"),
    "17" -> ("french","fre"),
    "19" -> ("italian","ita"),
    "20" -> ("spanish; castilian","spa"),
    "21" -> ("portuguese","por"),
    "22" -> ("polish","pol"),
    "23" -> ("estonian","est"),
    "24" -> ("latvian","lav"),
    "25" -> ("lithuanian","lit"),
    "27" -> ("georgian","geo"),
    "29" -> ("armenian","arm"),
    "30" -> ("russian","rus"),
    "31" -> ("turkish","tur"),
    "32" -> ("kurdish","kur"),
    "33" -> ("greek, modern (1453-)","gre"),
    "34" -> ("persian","per"),
    "35" -> ("romanian; moldavian; moldovan","rum"),
    "36" -> ("bulgarian","bul"),
    "37" -> ("romanian; moldavian; moldovan","rum"),
    "38" -> ("albanian","alb"),
    "40" -> ("slovenian","slv"),
    "41" -> ("croatian","hrv"),
    "44" -> ("azerbaijani","aze"),
    "45" -> ("kazakh","kaz"),
    "46" -> ("pushto; pashto","pus"),
    "47" -> ("urdu","urd"),
    "48" -> ("bengali","ben"),
    "49" -> ("indonesian","ind"),
    "51" -> ("burmese","bur"),
    "52" -> ("mongolian","mon"),
    "53" -> ("chinese","chi"),
    "56" -> ("korean","kor"),
    "57" -> ("japanese","jpn"),
    "58" -> ("thai","tha"),
    "59" -> ("malay","may"),
    "60" -> ("lao","lao"),
    "61" -> ("central khmer","khm"),
    "62" -> ("vietnamese","vie"),
    "63" -> ("sinhala; sinhalese","sin"),
    "64" -> ("uzbek","uzb"),
    "68" -> ("hebrew","heb"),
    "70" -> ("arabic","ara"),
    "72" -> ("turkmen","tuk"),
    "73" -> ("tajik","tgk"),
    "74" -> ("kirghiz; kyrgyz","kir"),
    "80" -> ("tonga (tonga islands)","ton"),
    "86" -> ("oromo","orm"),
    "92" -> ("bantu languages","bnt"),
    "94" -> ("dzongkha","dzo"),
    "95" -> ("amharic","amh"),
    "97" -> ("tswana","tsn"),
    "7A" -> ("hindi","hin"),
    "7E" -> ("nepali","nep"),
    "7F" -> ("samoan","smo"),
    "8G" -> ("tibetan","tib"),
    "8I" -> ("swati","ssw"),
    "8J" -> ("zulu","zul"),
    "8K" -> ("xhosa","xho"),
    "8M" -> ("afrikaans","afr"),
    "8S" -> ("twi","twi"),
    "8T" -> ("swahili","swa"),
    "8X" -> ("hausa","hau"),
    "9E" -> ("somali","som"),
    "9F" -> ("macedonian","mac"),
    "9K" -> ("igbo","ibo"),
    "9L" -> ("yoruba","yor"),
    "9N" -> ("tagalog","tgl"),
    "9O" -> ("sotho, southern","sot"),
    "9R" -> ("malagasy","mlg"),
    "9S" -> ("basque","baq")
  )

  val DefinedSourcePatientType = Seq("INPATIENT", "OUTPATIENT", "EMERGENCY", "PREADMIT")

  val physicianNPICodesForES: Map[Int, String] = Map(
    1805 -> "Primary Care",
    1810 -> "Admitting",
    1815 -> "Attending",
    1820 -> "Referring",
    1825 -> "Supervising",
    1830 -> "Operating",
    1835 -> "Ordering",
    1840 -> "Unknown"
  )

  val UNKNOWN = "UNKNOWN"
}
