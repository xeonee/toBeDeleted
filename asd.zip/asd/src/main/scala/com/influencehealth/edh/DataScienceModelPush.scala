package com.influencehealth.edh

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

import com.influencehealth.edh.config._
import com.influencehealth.edh.dao.DatabaseDao
import com.influencehealth.edh.lookups.client.LookupsClient
import com.influencehealth.edh.utils.{FileUtilities, PersonUtils}
import com.typesafe.config.Config
import org.apache.spark.sql.{Column, SparkSession}

object DataScienceModelPush extends BaldurApplication[DataScienceConfig] {

  var personsCount: Option[Long] = None

  override def runJob(
                       implicit sparkSession: SparkSession,
                       config: DataScienceConfig,
                       databaseDao: DatabaseDao
                     ) = {

    val customer: String = config.customer

    import sparkSession.implicits._

    val columns: Seq[Column] = config.requiredColumns.map {
      case "age" =>
        PersonUtils.compute_age($"dateOfBirth", $"sourceAge", $"dateSourceAgeReceived")
      case columnName =>
        $"$columnName"
    }

    val persons = databaseDao.getPersonsByCustomer(customer, full = false).select(columns: _*)

    personsCount = Some(persons.count)

    val outputPath = s"s3a://${config.outputS3Bucket}/$customer/raw/".toLowerCase()

    val dateFormatter = DateTimeFormatter.ofPattern("YMMdd")
    val postfix = LocalDateTime.now().format(dateFormatter)
    val fileName: String = s"${customer}_$postfix.parquet".toLowerCase()
    val delimiter: String = ","

    FileUtilities.saveCsvToS3(sparkSession, persons, delimiter, fileName, outputPath, true)
  }

  override def buildConfig(appConfig: Config, lookupsClient: LookupsClient) = {
    DataScienceConfig(appConfig)
  }

  override def countInputRecords = {
    personsCount
  }

  override def countOutputRecords = {
    personsCount
  }
}
