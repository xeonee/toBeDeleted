package com.influencehealth.edh.enrich.activity.crosswalks.helper

case class DischargeStatus(
  customer: String,
  source: String,
  sourceType: String,
  sourceDischargeStatus: String,
  dischargeStatus: Int,
  dnsReason: Option[String]
) extends Serializable

object DischargeStatus {

  val dischargeStatusCw: Seq[DischargeStatus] = Seq(
    DischargeStatus("default", "default", "default", "1", 1, None),
    DischargeStatus("default", "default", "default", "01", 1, None),
    DischargeStatus("default", "default", "default", "2", 2, None),
    DischargeStatus("default", "default", "default", "02", 1, None),
    DischargeStatus("default", "default", "default", "3", 3, Some("discharge status")),
    DischargeStatus("default", "default", "default", "03", 3, Some("discharge status")),
    DischargeStatus("default", "default", "default", "4", 4, Some("discharge status")),
    DischargeStatus("default", "default", "default", "04", 4, Some("discharge status")),
    DischargeStatus("default", "default", "default", "5", 5, None),
    DischargeStatus("default", "default", "default", "05", 5, None),
    DischargeStatus("default", "default", "default", "6", 6, None),
    DischargeStatus("default", "default", "default", "06", 6, None),
    DischargeStatus("default", "default", "default", "7", 7, Some("discharge status")),
    DischargeStatus("default", "default", "default", "07", 7, Some("discharge status")),
    DischargeStatus("default", "default", "default", "8", 8, None),
    DischargeStatus("default", "default", "default", "8", 8, None),
    DischargeStatus("default", "default", "default", "9", 9, None),
    DischargeStatus("default", "default", "default", "09", 9, None),
    DischargeStatus("default", "default", "default", "20", 20, Some("deceased: client supplied")),
    DischargeStatus("default", "default", "default", "21", 21, Some("discharge status")),
    DischargeStatus("default", "default", "default", "30", 30, None),
    DischargeStatus("default", "default", "default", "31", 31, None),
    DischargeStatus("default", "default", "default", "40", 40, Some("deceased: client supplied")),
    DischargeStatus("default", "default", "default", "41", 41, Some("deceased: client supplied")),
    DischargeStatus("default", "default", "default", "42", 42, Some("deceased: client supplied")),
    DischargeStatus("default", "default", "default", "43", 43, None),
    DischargeStatus("default", "default", "default", "50", 50, Some("discharge status")),
    DischargeStatus("default", "default", "default", "51", 51, Some("discharge status")),
    DischargeStatus("default", "default", "default", "61", 61, None),
    DischargeStatus("default", "default", "default", "62", 62, None),
    DischargeStatus("default", "default", "default", "63", 63, Some("discharge status")),
    DischargeStatus("default", "default", "default", "64", 64, Some("discharge status")),
    DischargeStatus("default", "default", "default", "65", 65, Some("discharge status")),
    DischargeStatus("default", "default", "default", "66", 66, None),
    DischargeStatus("default", "default", "default", "69", 69, None),
    DischargeStatus("default", "default", "default", "70", 70, None),
    DischargeStatus("default", "default", "default", "71", 71, None),
    DischargeStatus("default", "default", "default", "72", 72, None),
    DischargeStatus("default", "default", "default", "81", 81, None),
    DischargeStatus("default", "default", "default", "82", 82, None),
    DischargeStatus("default", "default", "default", "83", 83, Some("discharge status")),
    DischargeStatus("default", "default", "default", "84", 84, None),
    DischargeStatus("default", "default", "default", "85", 85, None),
    DischargeStatus("default", "default", "default", "86", 86, None),
    DischargeStatus("default", "default", "default", "87", 87, Some("discharge status")),
    DischargeStatus("default", "default", "default", "88", 88, None),
    DischargeStatus("default", "default", "default", "89", 89, None),
    DischargeStatus("default", "default", "default", "90", 90, None),
    DischargeStatus("default", "default", "default", "91", 91, Some("discharge status")),
    DischargeStatus("default", "default", "default", "92", 92, Some("discharge status")),
    DischargeStatus("default", "default", "default", "93", 93, Some("discharge status")),
    DischargeStatus("default", "default", "default", "94", 94, None),
    DischargeStatus("default", "default", "default", "95", 95, None)
  )
}

case class DischargeStatusCwCreationException(exc: Throwable)
  extends Exception("Unable to create discharge status crosswalk", exc)