package com.influencehealth.edh.cleanse

import com.influencehealth.edh.Constants
import com.influencehealth.edh.model.activitytype.ActivityType
import com.influencehealth.edh.utils.{CleanseUtils, PersonUtils}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._

class DoNotSolicitCleanser(val dateBatchReceived: String) extends DataCleanser {

  this: ActivityType =>

  val DefaultDnsFlag: Boolean = true

  override def cleanseData(
                            df: DataFrame,
                            customer: Option[String],
                            batchId: String
                          ): (DataFrame, DataFrame) = {

    // Apply default values for Required Columns if found NULL
    val defaultCodeForRequiredColumnsContainingNulls = assignDefaultValuesForRequiredColumnsContainingNulls(df).
      withColumn("source", lit(defaultSource)).
      transform(addSourceRecordId(_, batchId))

    // filters required columns that are not null
    val (dataFrameContainingNonNullColumns, dataFrameContainingNullColumns) =
      filterRequiredColumnsContainingInvalidValues(
        defaultCodeForRequiredColumnsContainingNulls, nullColumnNames, mandatoryContactColumnsNames)

    // cleanses & filters Date column
    val dataFrameContainingValidDateColumns = formatDateColumns(dataFrameContainingNonNullColumns)

    // Cleanses String Column
    val dataFrameContainingCleansedStringColumns = cleanseStringColumns(dataFrameContainingValidDateColumns, cleanseStringColumnNames)

    // Cleanses Contact details: Phone numbers and emails
    val dataFrameContainingCleansedContactDetails = cleanseContactDetails(dataFrameContainingCleansedStringColumns)

    // Cleanse zip5 column
    val cleansedZips = cleanseZips(dataFrameContainingCleansedContactDetails)

    // Aliases Data
    val aliasedData = aliasData(cleansedZips, customer)

    (aliasedData, dataFrameContainingNullColumns)

  }

  override def formatDateColumns(df: DataFrame): DataFrame = {

    import df.sqlContext.implicits._
    // Convert string date into Date type columns after validating the dates, known behavior

    val formattedDf = df
      .withColumn("dateOfBirth", CleanseUtils.timestamp_to_date(PersonUtils.validateInputDate(
        date_format(unix_timestamp($"dateOfBirth", "MM/dd/yy").cast("timestamp"), "yyyy-MM-dd"))))

    val formattedDataFrame = formattedDf
      .withColumn("deceasedFlag", deceasedFlag(formattedDf("sourceDnsReason")))
      .withColumn("doNotSolicit", lit(DefaultDnsFlag))
      .withColumn("optOutDirectMail", lit(DefaultDnsFlag))
      .withColumn("optOutCall", lit(DefaultDnsFlag))
      .withColumn("optOutEmail", lit(DefaultDnsFlag))
      .withColumn("optOutText", lit(DefaultDnsFlag))
      .withColumn("sex", PersonUtils.sex(formattedDf("sourceSex")))

    formattedDataFrame
  }


  override def cleanseStringColumns(df: DataFrame, stringColumnsToBeCleansed: Seq[String]): DataFrame = {
    stringColumnsToBeCleansed.foldLeft(df) { (df, column) =>
      df.withColumn(s"$column", CleanseUtils.cleanseStringColumns(df(s"$column")))
    }
  }

  override def assignDefaultValuesForRequiredColumnsContainingNulls(df: DataFrame): DataFrame = {

    val addingColumnNames: DataFrame = df.
      withColumn("sourceType", lit(defaultSourceType)).
      withColumn("addressType", lit(defaultAddressType)).
      withColumn("personType", lit(defaultPersonType))

    addingColumnNames
  }

  def deceasedFlag = udf((sourceDnsReason: String) => {
    if (sourceDnsReason != null && sourceDnsReason.toLowerCase.contains("deceased")) true
    else false
  })


  val stringify: UserDefinedFunction = udf((vs: Seq[String]) =>
    s"""[${vs.mkString(",").replace("null,", "").replace("null", "")}]""")

  override def aliasData(df: DataFrame, customer: Option[String]): DataFrame = {
    super.aliasData(df, customer)
      .withColumn("activityDate", lit(CleanseUtils.parseStringToDate(dateBatchReceived)))
      .withColumn("activityType", lit(defaultActivityType))
      .withColumn("customer", lit(customer.get))
      .withColumn("dateCreated", lit(Constants.Now.toString))
  }

  private def cleanseContactDetails(df: DataFrame): DataFrame = {

    df
      .withColumn("email", CleanseUtils.cleanseAndValidateEmail(df("emails")))
      .withColumn("homePhone", CleanseUtils.cleanseAndParsePhone(col("phoneNumbers")))
  }

  /** Cleanse zip values
    *
    * @param df
    * @return
    */
  private def cleanseZips(df: DataFrame): DataFrame = {
    val x = df.withColumn("zip4", CleanseUtils.get_zip4(df("zip5"))).
      withColumn("zip5", CleanseUtils.get_zip5(df("zip5")))
    x
  }

}
