package com.influencehealth.edh.enrich.activity.address

import java.io.{File, FileFilter}
import java.nio.file.{Files, StandardCopyOption}

import com.influencehealth.edh.Constants
import com.influencehealth.edh.config.EnrichJobConfig
import com.influencehealth.edh.enrich.ActivityEnricher
import com.influencehealth.edh.implicits._
import com.influencehealth.edh.model.Activity
import com.influencehealth.edh.model.address.{AnchorInputData, AnchorOutputData}
import com.influencehealth.edh.utils.FileUtilities
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.{udf, _}
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.util.SizeEstimator
import org.joda.time.DateTime

import scala.sys.process._

class EnrichAddressStep(val name: String, val next: Option[ActivityEnricher])
                       (implicit enrichJobConfig: EnrichJobConfig, sparkSession: SparkSession)
  extends ActivityEnricher {

  override def enrich(ds: Dataset[Activity]): Dataset[Activity] = {

    import sparkSession.implicits._

    val anchorDataset: Dataset[AnchorInputData] = ds.map { activity =>
      AnchorInputData(
        Some(activity.activityId),
        activity.customer,
        activity.batchId,
        -1,
        activity.source,
        activity.sourceType,
        activity.sourceRecordId,
        activity.sourcePersonId,
        activity.firstName,
        activity.middleName,
        activity.lastName,
        activity.address1,
        activity.address2,
        activity.city,
        activity.state,
        activity.zip5
      )

    }

    val inputAnchorDataCount = anchorDataset.count
    if (inputAnchorDataCount <= 0) {
      throw new RuntimeException(
        s"No Records was fetched from Postgres by Enrich Anchor for batch: ${enrichJobConfig.batchId}")
    }
    generateAnchorFile(anchorDataset)

    // execute shell script : submit_anchor_file.sh
    val outputPath = enrichJobConfig.anchorConfig.get.outputPath
    val anchorScriptPath = enrichJobConfig.anchorConfig.get.anchorScriptPath
    val submitAnchorCmd = s"$anchorScriptPath/submit_anchor_file.sh $outputPath/baldur_*.txt"
    println(s"running: $submitAnchorCmd")
    val exitCode = submitAnchorCmd.!

    if (exitCode != 0) {
      throw new RuntimeException("Error when submitting data to Anchor")
    }

    val outputFolder = s"${enrichJobConfig.anchorConfig.get.downloadLocalPath}/output"
    logger.info(s"outputFolder: $outputFolder")
    val anchorOutputFiles: Array[File] = new File(outputFolder).listFiles(new FileFilter {
      override def accept(pathname: File): Boolean =
        pathname.getName.startsWith("baldur_") && pathname.getName.endsWith(".txt")
    })

    logger.info("anchor output files: ")
    anchorOutputFiles.foreach(f => logger.info(f.getName))

    val dataframes: Array[DataFrame] = anchorOutputFiles.map { anchorOutputFile =>
      val anchorOutputDF = processAnchorOutput(enrichJobConfig.customerId, anchorOutputFile.getAbsolutePath)
      anchorOutputDF.persist
      anchorOutputDF.count()
      // cleanup files after processed so they aren't left to be picked up again next time
      val processedOutputDir = new File(s"${enrichJobConfig.anchorConfig.get.downloadLocalPath}/output/processed/")
      if (!processedOutputDir.exists()) {
        processedOutputDir.mkdirs()
      }

      Files.move(
        anchorOutputFile.toPath,
        new File(processedOutputDir.getAbsolutePath.concat(s"/${anchorOutputFile.getName}")).toPath,
        StandardCopyOption.ATOMIC_MOVE
      )
      anchorOutputDF
    }

    val unionDataframe = dataframes.foldLeft(
      sparkSession.createDataFrame(sparkSession.sparkContext.emptyRDD[Row], dataframes.head.schema)
    ) {
      case (finalDF, anchorDF) => finalDF.union(anchorDF)
    }.
      withColumn("addressCoordinates", struct($"latitude" as "lat", $"longitude" as "lon")).
      drop("latitude", "longitude")

    val outputAnchorDataCount = unionDataframe.count()
    if (outputAnchorDataCount != inputAnchorDataCount) {
      throw new RuntimeException(
        s"ERROR: Data sent to Anchor: $inputAnchorDataCount  / Data Received from Anchor: $outputAnchorDataCount"
      )
    }

    logger.info(s"number of null zip5: ${unionDataframe.where($"zip5".isNull).count()}")

    val joinedDF = ds.join(unionDataframe, Seq("activityId", "customer"))

    unionDataframe.columns.filterNot(Seq("activityId", "customer").contains(_))
      .foldLeft(joinedDF) {
        (dataframe, fieldName) => dataframe.drop(ds.col(fieldName))
      }.map(Activity.buildFromRow)
  }


  def generateAnchorFile(anchorData: Dataset[AnchorInputData]): Unit = {

    import sparkSession.implicits._

    if (enrichJobConfig.anchorConfig.isEmpty) {
      throw new RuntimeException("Anchor configuration required")
    }

    val outputPath = enrichJobConfig.anchorConfig.get.outputPath
    val tempPath = enrichJobConfig.anchorConfig.get.tempPath
    val fileNamePrefix = enrichJobConfig.anchorConfig.get.filenamePrefix
    val outputFileCount = enrichJobConfig.anchorConfig.get.outputFileCount

    // logger.info(s"number of activities: ${anchorData.count()}")

    // pad to 100 records
    val paddingRecords = sparkSession.createDataFrame(Seq.fill(100)(AnchorInputData.paddingRecord))
    val paddedData = anchorData.union(paddingRecords.as[AnchorInputData]).
      coalesce(Math.max(Math.ceil(SizeEstimator.estimate(anchorData) / Constants.BLOCK_SIZE).toInt, 1))
      .toDF

    // write file out

    val now: String = DateTime.now().toTimestampStr.replace("-", "").replace(":", "")
    val fileName = s"${fileNamePrefix}_${enrichJobConfig.customerId}_${enrichJobConfig.customerPafName.getOrElse("INFLUENCE HEALTH~001228")}_$now.txt"

    FileUtilities.writeMinimalAnchorFile(sparkSession, outputPath, tempPath, fileNamePrefix,
      paddedData, outputFileCount, fileName)
  }

  /**
    * processes a file containing the data returned from anchor and updates cleansed activities
    *
    * @param customerId customerId
    */
  def processAnchorOutput(customerId: Int, file: String): DataFrame = {

    import sparkSession.implicits._

    val fileDelimiter = enrichJobConfig.anchorConfig.get.fileDelimiter
    val setOfCustomerServicingZipCodes: Set[String] = enrichJobConfig.customerServiceAreas.map(_.serviceAreaName)
    import org.apache.spark.sql.functions._

    // build output dataFrame with only required fields and filter out junk records
    FileUtilities.readDelimitedFile(sparkSession, file, fileDelimiter, AnchorOutputData.schema).
      filter($"batchId" =!= "removeMe").
      withColumn("longitude", AnchorOutputData.stripStringLocation(col("longitude"))).
      withColumn("latitude", AnchorOutputData.stripStringLocation(col("latitude"))).
      withColumn("dateModified", lit(current_timestamp())).
      withColumn("isValidAddress", EnrichAddressHelper.fetchValidAddress($"ncoaActionCode")).
      withColumn("ncoaMoveDate", cleanseMoveDate($"ncoaMoveDate")).
      withColumn("hasMovedAway",
        EnrichAddressHelper.checkMovedAway(setOfCustomerServicingZipCodes)(col("zip5"), col("sourceType"))).
      drop(
        "originalAddress1",
        "originalAddress2",
        "originalCity",
        "originalState",
        "originalZip5",
        "zip",
        "bucketNumber",
        "deliveryPointBarcode",
        "originalAddress1",
        "originalAddress2",
        "originalCity",
        "originalState",
        "originalZip5",
        "deliveryPointBarcode",
        "countyFederalInformationProcessingStandards",
        "enhancedLineOfTravel",
        "ncoaActionCode",
        "ncoaAnklinkCode",
        "llkFootnote",
        "barcode",
        "llkFootnote",
        "lacs",
        "cassStand",
        "deliveryPointValidationFootnote"
      )
  }

  def cleanseMoveDate: UserDefinedFunction = udf((moveDate: String) => {

    if (Option(moveDate).isDefined && moveDate.nonEmpty) {
      Some(moveDate)
    } else None
  })

}
