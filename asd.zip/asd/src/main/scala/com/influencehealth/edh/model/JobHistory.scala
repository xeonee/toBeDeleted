package com.influencehealth.edh.model

import java.sql.{Date, Timestamp}

case class JobHistory(
                       customer: String,
                       activityType: Option[String],
                       batchId: Option[String],
                       sinceDate: Option[Date],
                       jobType: String,
                       jobCommand: String,
                       inputFile: Option[String],
                       timeStarted: Timestamp,
                       timeFinished: Timestamp,
                       user: String,
                       numberOfInputRecords: Option[Long],
                       numberOfUpdatedRecords: Option[Long],
                       jobStatus: String
                     )