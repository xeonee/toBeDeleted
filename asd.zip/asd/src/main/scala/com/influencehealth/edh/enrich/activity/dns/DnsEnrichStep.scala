package com.influencehealth.edh.enrich.activity.dns

import com.influencehealth.edh.config.{DatabaseConfig, EnrichJobConfig, PostgresConfig}
import com.influencehealth.edh.dao.{DatabaseDao, PostgresDatabaseDao}
import com.influencehealth.edh.enrich.ActivityEnricher
import com.influencehealth.edh.model.{Activity, DoNotSolicitEmail}
import org.apache.spark.sql.{Dataset, Row, SparkSession}

class DnsEnrichStep (val name: String, val next: Option[ActivityEnricher])
                    (implicit enrichJobConfig: EnrichJobConfig, sparkSession: SparkSession) extends ActivityEnricher {

  override def enrich(activities: Dataset[Activity]): Dataset[Activity] = {
    import activities.sparkSession.implicits._
    val databaseDao: DatabaseDao = new PostgresDatabaseDao(enrichJobConfig.databaseConfig.get)

    val dnsEmails: Dataset[DoNotSolicitEmail] = activities
      .select($"customer", $"source", $"dateCreated", $"dateModified", $"email", $"optOutEmailReasons".alias("reason"),
        $"batchId")
      .where(s"email is not null")
      .as[DoNotSolicitEmail]
      .dropDuplicates(Seq("customer", "email"))

    databaseDao.saveDoNotSolicitEmails(dnsEmails)
    logger.info(s"${dnsEmails.count} Events Loaded into do_not_solicit_emails table")

    // returning empty Dataset
    activities.sparkSession.createDataFrame(activities.sparkSession.sparkContext.emptyRDD[Row],
      activities.schema).as[Activity]
  }
}
