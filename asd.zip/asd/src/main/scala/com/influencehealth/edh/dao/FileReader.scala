package com.influencehealth.edh.dao

import java.io.FileNotFoundException

import com.amazonaws.services.s3.AmazonS3
import com.influencehealth.edh.cleanse.normalizers.{EncounterNormalizer, HraNormalizer}
import com.influencehealth.edh.model.schema._
import com.influencehealth.edh.utils.{DataLakeUtilities, FileUtilities, S3Utilities}
import com.influencehealth.edh.{Constants, CustomLazyLogging}
import org.apache.spark.sql.expressions.{UserDefinedFunction, Window}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, StringType, StructType}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

import scala.util.{Failure, Success, Try}

object FileReader extends CustomLazyLogging {

  val Demographic: String = "demog"
  val CurrentProceduralTerminology: String = "cpt"
  val Diagnosis: String = "dx"
  val Prognosis: String = "px"
  val Facility: String = "facility"
  val Visit: String = "visit"
  val Guarantor: String = "guarantor"
  val Biometric: String = "biometric"
  val Physician: String = "physician"
  val Financial: String = "financial"
  val detailFile: String = "DETAIL"
  val detailFileV2: String = "Detail"
  val CallCenter: String = "callcenter"
  val HraHeader: String = "HEADER*"
  val HraDetail: String = "DETAIL*"
  val HraHeaderV2: String = "Header**"
  val HraDetailV2: String = "Detail*"

  val fieldSizesForDeceased: Array[Int] = Array(1, 9, 20, 4, 15, 15, 1, 8, 8)

  val fieldSizesForProspect: Array[Int] = Array(10, 2, 2, 5, 4, 3, 4, 13, 28, 10, 2, 28, 4, 2, 6, 8, 4, 30, 30, 2, 1, 3,
    25, 7, 9, 10, 1, 6, 6, 1, 10, 1, 10, 10, 13, 1, 1, 2, 3, 1, 1, 1, 2, 1, 8, 1, 2, 1, 1, 1, 2, 1, 1, 1, 8, 10, 1, 15,
    1, 20, 6, 6, 5, 2, 2, 1, 2, 1, 2, 2, 1, 8, 2, 2, 3, 2, 2, 3, 2, 1, 1, 10, 1, 15, 1, 20, 6, 6, 5, 2, 2, 1, 2, 1, 2,
    2, 1, 8, 2, 2, 3, 2, 2, 3, 2, 1, 1, 10, 1, 15, 1, 20, 6, 6, 5, 2, 2, 1, 2, 1, 2, 2, 1, 8, 2, 2, 3, 2, 2, 3, 2, 1, 1,
    10, 1, 15, 1, 20, 6, 6, 5, 2, 2, 1, 2, 1, 2, 2, 1, 8, 2, 2, 3, 2, 2, 3, 2, 1, 1, 10, 1, 15, 1, 20, 6, 6, 5, 2, 2, 1,
    2, 1, 2, 2, 1, 8, 2, 2, 3, 2, 2, 3, 2, 1, 1, 10, 1, 15, 1, 20, 6, 6, 5, 2, 2, 1, 2, 1, 2, 2, 1, 8, 2, 2, 3, 2, 2, 3,
    2, 1, 14, 1, 17, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 4, 8, 4, 4, 2,
    12, 7, 4, 3, 1, 4, 1, 1, 1, 1, 1, 6, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 7, 3, 3, 1, 1, 2, 1, 3, 4, 27, 58, 5, 1, 3,
    2, 2, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 7, 4, 4, 4, 4, 4, 4, 4, 4, 4, 3, 4, 4, 4, 4, 4, 4, 7, 4,
    2, 4, 4, 4, 1, 1, 6)

  val listOfRequiredFilesForHra: List[(String, String, StructType)] = List(
    (HraHeader, "*HEADER", HraSchema.hraHeaderSchema),
    (HraDetail, "*DETAIL", HraSchema.hraDetailSchema))

  val listOfRequiredFilesForHealthwareHra: List[(String, String, StructType)] = List(
    (HraHeaderV2, "*Header", HraSchema.hraHeaderV2Schema),
    (HraDetailV2, "*Detail", HraSchema.hraDetailV2Schema))

  lazy val schemaType: Map[String, StructType] = Map(
    Constants.DeceasedActivityType -> DeceasedPersonsSchema.schema,
    Constants.DoNotSolicitActivityType -> DnsSchema.DnsSchema,
    Constants.DoNotSolicitUpdateActivityType -> DnsUpdateSchema.dnsUpdateSchema,
    Constants.DonorListActivityType -> DonorListSchema.donorlistSchema,
    Constants.EmployeeRosterActivityType -> EmployeeRosterSchema.employeeRosterSchema,
    Constants.MarketingListActivityType -> MarketingListSchema.marketinglistSchema,
    Constants.ProspectActivityType -> ProspectSchema.prospectSchema,
    Constants.NewMoverActivityType -> NewMoversSchema.schema,
    Constants.ReferralActivityType -> ReferralSchema.referralSchemaV1
  )

  /**
    * Load all files based on activity types and input s3 url
    *
    * @param sparkSession
    * @param inputDirectoryPath
    * @param activityType
    * @param s3Client
    * @param force
    * @return
    */
  def readFilesFromS3(
                       sparkSession: SparkSession,
                       inputDirectoryPath: String,
                       s3Bucket: String,
                       activityType: String,
                       s3Client: AmazonS3,
                       force: Boolean
                     ): DataFrame = {

    // check file extension
    val fileExtension = checkFileExtension(inputDirectoryPath, s3Client, activityType, force)

    // Read Files
    val readFilesDataFrames: Map[String, DataFrame] = readInputFilesIntoDataFrames(
      sparkSession, inputDirectoryPath, activityType, s3Client, s3Bucket, fileExtension)

    readFilesDataFrames.foreach(_._2.foreach{ row =>
      s"Row(${row.toSeq.map {
        case x: String => s""" "$x" """
        case f: Float => s"${f}f"
      }.mkString(",")})"
    })

    //    // Filter HeaderreadInputFilesIntoDataFrames
    //    val listOfFileNamesAndDataFrames: Map[String, DataFrame] = FileReader.filterHeader(activityType, readFilesDataFrames)
    //
    //    // Join files if required
    //    val joinedAllDataFrames: DataFrame = joinAllDataFrames(activityType, listOfFileNamesAndDataFrames, inputDirectoryPath)
    //
    //    if (inputDirectoryPath.startsWith("s3a") || inputDirectoryPath.startsWith("s3n")) {
    //      // add source and sourceRecordId
    //      val dfWithSourceAndSourceRecordId = addSourceAndSourceRecordId(activityType, joinedAllDataFrames, inputDirectoryPath)
    //      dfWithSourceAndSourceRecordId
    //    } else {
    //      // add source and sourceRecordId to the input DataFrame for the unit testing
    //      val dfWithSourceAndSourceRecordId = addDummySourceData(activityType, joinedAllDataFrames)
    //      dfWithSourceAndSourceRecordId
    //    }

    readFilesDataFrames.head._2
  }

  /**
    * Read all types of files into a df (fixed with, comma separated etc)
    *
    * @param sparkSession
    * @param inputDirectoryPath
    * @param activityType
    * @return
    */
  def readInputFilesIntoDataFrames(
                                    sparkSession: SparkSession,
                                    inputDirectoryPath: String,
                                    activityType: String,
                                    s3Client: AmazonS3,
                                    s3Bucket: String,
                                    fileExtension: Option[String]
                                  ): Map[String, DataFrame] = {
    val delimiter: Option[String] = fileExtension match {
      case Some("txt") => Some("|")
      case Some("csv") => Some(",")
      case Some("xls" | "xlsx") => Some("xlstype")
      case Some("NoExtension") => throw new RuntimeException(s"Empty Input Folder at $inputDirectoryPath")
      case Some("InputFilesNotInS3Folder") =>
        activityType.toUpperCase match {
          case Constants.DoNotSolicitActivityType |
               Constants.DonorListActivityType |
               Constants.EmployeeRosterActivityType |
               Constants.MarketingListActivityType |
               Constants.DonorListActivityType |
               Constants.EncounterActivityType |
               Constants.ReferralActivityType => Some("|")
          case Constants.HraActivityType | Constants.NewMoverActivityType =>
            val format = "healthware"
            format match {
              case "healthware" => Some("|")
              case _ => Some(",")
            }
          case Constants.ProspectActivityType | Constants.DeceasedActivityType => Some("")
          case Constants.CallCenterActivityType =>
            val format = DataLakeUtilities.extractFormatFromProjectUrl(inputDirectoryPath)
            format.toUpperCase match {
              case Constants.CallCenterBerylFormat | Constants.CallCenterSteriCycleFormat => Some("|")
              case Constants.CallCenterConiferFormat => Some("xlstype")
              case _ =>
                throw new RuntimeException(s"$format is an invalid format for input files at $inputDirectoryPath")
            }
          case _ =>
            throw new RuntimeException(
              s"$activityType is an invalid activity type in input files at $inputDirectoryPath")
        }
      case _ =>
        throw new RuntimeException(
          s"$fileExtension is an invalid file extension for input files at $inputDirectoryPath")
    }

    val readFiles: Map[String, DataFrame] = activityType match {
      case Constants.DeceasedActivityType => readFixedWidthFiles(
        sparkSession, inputDirectoryPath, activityType, fieldSizesForDeceased)

      case Constants.ProspectActivityType => readFixedWidthFiles(
        sparkSession, inputDirectoryPath, activityType, fieldSizesForProspect)

      case Constants.EncounterActivityType | Constants.HraActivityType =>
        readCSVFilesBasedOnActivityType(sparkSession, inputDirectoryPath, delimiter, activityType, s3Client, null)

      case _ => readCSVFilesBasedOnActivityType(sparkSession, inputDirectoryPath, delimiter, activityType, s3Client,
        s3Bucket)
    }
    readFiles
  }

  /**
    *
    * @param sparkSession
    * @param inputDirectoryPath
    * @param delimiter
    * @param activityType
    * @return
    */
  def readCSVFilesBasedOnActivityType(
                                       sparkSession: SparkSession,
                                       inputDirectoryPath: String,
                                       delimiter: Option[String],
                                       activityType: String,
                                       s3Client: AmazonS3,
                                       s3Bucket: String
                                     ): Map[String, DataFrame] = {

    var mapOfFileNamesAndDataFrames: Map[String, DataFrame] = Map()

    activityType.toUpperCase match {
      case Constants.EncounterActivityType =>

        val listOfMandatoryFileNames: List[String] = List(
          Demographic, Diagnosis, CurrentProceduralTerminology, Facility, Visit)
        val listOfNonMandatoryFileNames: List[String] = List(
          Prognosis, Guarantor, Biometric, Physician, Financial)

        val listOfFiles = listOfMandatoryFileNames ++ listOfNonMandatoryFileNames

        val outgoingMap: Map[String, DataFrame] = getListOfEncounterFiles(inputDirectoryPath, s3Client).groupBy(filePath => {
          listOfFiles.find(fileType => filePath.toLowerCase.contains(fileType.toLowerCase))
        }).filterKeys(_.nonEmpty).map {
          case (k, v) => (k.get, v)
        }.map { case (fileType, filePaths) =>
          println(fileType)
          fileType match {
            case y if y.toLowerCase.contains("demog") =>
              (fileType, readEncounterCSVinSpark(sparkSession, delimiter, EncounterSchema.demographicSchema, filePaths, fileType))
            case y if y.toLowerCase.contains("cpt") =>
              (fileType, readEncounterCSVinSpark(sparkSession, delimiter, EncounterSchema.currentProceduralTerminologySchema, filePaths, fileType))
            case y if y.toLowerCase.contains("dx") =>
              (fileType, readEncounterCSVinSpark(sparkSession, delimiter, EncounterSchema.diagnosisSchema, filePaths, fileType))
            case y if y.toLowerCase.contains("px") =>
              (fileType, readEncounterCSVinSpark(sparkSession, delimiter, EncounterSchema.prognosisSchema, filePaths, fileType))
            case y if y.toLowerCase.contains("facility") =>
              (fileType, readEncounterCSVinSpark(sparkSession, delimiter, EncounterSchema.facilitySchema, filePaths, fileType))
            case y if y.toLowerCase.contains("visit") =>
              (fileType, readEncounterCSVinSpark(sparkSession, delimiter, EncounterSchema.visitSchema, filePaths, fileType))
            case y if y.toLowerCase.contains("guarantor") =>
              (fileType, readEncounterCSVinSpark(sparkSession, delimiter, EncounterSchema.guarantorSchema, filePaths, fileType))
            case y if y.toLowerCase.contains("biometric") =>
              (fileType, readEncounterCSVinSpark(sparkSession, delimiter, EncounterSchema.biometricSchema, filePaths, fileType))
            case y if y.toLowerCase.contains("physician") =>
              (fileType, readEncounterCSVinSpark(sparkSession, delimiter, EncounterSchema.physicianSchema, filePaths, fileType))
            case y if y.toLowerCase.contains("financial") =>
              (fileType, readEncounterCSVinSpark(sparkSession, delimiter, EncounterSchema.financialSchema, filePaths, fileType))
          }
        }
        mapOfFileNamesAndDataFrames = outgoingMap
      case Constants.HraActivityType =>
        if (inputDirectoryPath.startsWith("s3a") || inputDirectoryPath.startsWith("s3n")) {
          val format = "healthware"
          format match {
            case "healthware" => listOfRequiredFilesForHealthwareHra.foreach(x => {
              val df = readCSVinSpark(sparkSession, delimiter, x._3, inputDirectoryPath, x._2)
              mapOfFileNamesAndDataFrames = mapOfFileNamesAndDataFrames + (x._1 -> df)
            })
            case _ => listOfRequiredFilesForHra.foreach(x => {
              val df = readCSVinSpark(sparkSession, delimiter, x._3, inputDirectoryPath, x._2)
              mapOfFileNamesAndDataFrames = mapOfFileNamesAndDataFrames + (x._1 -> df)
            })
          }
        }
        // Just for test case
        else {
          val format = "healthware"
          format match {
            case "healthware" => listOfRequiredFilesForHealthwareHra.foreach(x => {
              val df = readCSVinSpark(sparkSession, delimiter, x._3, inputDirectoryPath, x._2)
              mapOfFileNamesAndDataFrames = mapOfFileNamesAndDataFrames + (x._1 -> df)
            })
            case _ => listOfRequiredFilesForHra.foreach(x => {
              val df = readCSVinSpark(sparkSession, delimiter, x._3, inputDirectoryPath, x._2)
              mapOfFileNamesAndDataFrames = mapOfFileNamesAndDataFrames + (x._1 -> df)
            })
          }
        }
      case _ =>
        val schema = activityType.toUpperCase match {
          case Constants.CallCenterActivityType =>
            if (inputDirectoryPath.startsWith("s3a") || inputDirectoryPath.startsWith("s3n")) {
              getSchemaByFormat(DataLakeUtilities.extractFormatFromS3Url(inputDirectoryPath))
            }
            else {
              getSchemaByFormat(DataLakeUtilities.extractFormatFromProjectUrl(inputDirectoryPath))
            }
          case _ => schemaType(activityType.toUpperCase)
        }
        val listOfIncomingFiles: List[String] = if (inputDirectoryPath.startsWith("s3")) {
          val objectName = DataLakeUtilities.getObjectNameForBatchUrls(inputDirectoryPath)
          S3Utilities.getAcceptableBatchDirectoryUrls(s3Client, s3Bucket, objectName).filterNot(_.endsWith("/"))
        } else {
          List(inputDirectoryPath)
        }
        if (delimiter.get.equals("xlstype")) {
          val df = listOfIncomingFiles.foldLeft(sparkSession.createDataFrame(sparkSession.sparkContext.emptyRDD[Row],
            schema)) { (x, y) => x.union(readExcelFiles(sparkSession, y, schema))
          }
          mapOfFileNamesAndDataFrames = mapOfFileNamesAndDataFrames + (activityType -> df)
        }
        else {
          activityType match {
            case Constants.CallCenterActivityType => {
              val df = processCallcenterFiles(sparkSession, inputDirectoryPath, listOfIncomingFiles, delimiter, schema)
              mapOfFileNamesAndDataFrames = mapOfFileNamesAndDataFrames + (activityType -> df)
            }
            case _ =>
              val df = listOfIncomingFiles.foldLeft(sparkSession.createDataFrame(sparkSession.sparkContext.emptyRDD[Row],
                schema)) { (x, y) => x.union(readCSVinSpark(sparkSession, delimiter, schema, y, "*")) }
              mapOfFileNamesAndDataFrames = mapOfFileNamesAndDataFrames + (activityType -> df)
          }
        }
    }
    mapOfFileNamesAndDataFrames
  }

  /**
    * Spark read file and return a df
    *
    * @param sparkSession
    * @param delimiter
    * @param schemaStructure
    * @param inputDirectoryPath
    * @param inputFileNamePrefix
    * @return
    */
  def readCSVinSpark(
                      sparkSession: SparkSession,
                      delimiter: Option[String],
                      schemaStructure: StructType,
                      inputDirectoryPath: String,
                      inputFileNamePrefix: String
                    ): DataFrame = {
    val df = sparkSession.read.option("header", false).option("delimiter", delimiter.get).
      schema(schemaStructure).csv(inputDirectoryPath.concat(s"*$inputFileNamePrefix*"))

/*    df.foreach(r => println(s"Row(${
      r.toSeq.map { case any =>
        if (any == null) {
          "null"
        } else {
          s""" "$any" """
        }
      }.mkString(",")
    })"))*/

    df
  }

  /**
    * Spark read file and return a df
    *
    * @param sparkSession
    * @param delimiter
    * @param schemaStructure
    * @param inputDirectoryPath
    * @param inputFileNamePrefix
    * @return
    */
  def readEncounterCSVinSpark(
                               sparkSession: SparkSession,
                               delimiter: Option[String],
                               schemaStructure: StructType,
                               filePaths: Seq[String],
                               fileType: String
                             ): DataFrame = {
    val loadedDf = sparkSession.read.option("header", false).option("delimiter", delimiter.get).
      schema(schemaStructure).csv(filePaths: _*)

    println(fileType)
    loadedDf.foreach(r => println(s"Row(${
      r.toSeq.map { case any =>
        if (any == null) {
          "null"
        } else {
          s""" "$any" """
        }
      }.mkString(",")
    }),"))

    val replaceNULLvalues = loadedDf.columns.foldLeft(loadedDf) {
      (x, colName) => x.withColumn(colName, when(col(colName).equalTo("NULL"), null).otherwise(col(colName)))
    }

    val df = fileType match {
      case CurrentProceduralTerminology | Diagnosis | Prognosis => getMedicalCodes(replaceNULLvalues, fileType)
      case _ => replaceNULLvalues
    }
    df
  }

  def getMedicalCodes(df: DataFrame, medicalCodeType: String): DataFrame = {
    val codeDf: DataFrame = medicalCodeType match {
      case CurrentProceduralTerminology => df.where("sourcePersonId is not null and sourceRecordId is not null and" +
        " currentProceduralTerminologyMxVersion is not null and currentProceduralTerminologyMxCode is not null" +
        " and currentProceduralTerminologyPriorityNo is not null").
        groupBy(col("sourceRecordId"), col("sourcePersonId")).agg(collect_list(
        struct(
          col("currentProceduralTerminologyMxCode").substr(0, 5) as "medicalCode",
          col("currentProceduralTerminologyMxVersion") as "medicalCodeType",
          col("currentProceduralTerminologyPriorityNo").cast(IntegerType) as "sequenceNumber"
        )) as "currentProceduralTerminologyCodes").
        drop(
          "currentProceduralTerminologyMxVersion",
          "currentProceduralTerminologyMxVersion",
          "currentProceduralTerminologyPriorityNo")
      case Diagnosis => df.where("sourcePersonId is not null and sourceRecordId is not null and" +
        " diagnosisMxVersion is not null and diagnosisMxCode is not null and diagnosisPriorityNo is not null").
        groupBy(col("sourceRecordId"), col("sourcePersonId")).agg(collect_list(
        struct(
          stripDecimal(col("diagnosisMxCode")) as "medicalCode",
          stripNonAlphaNumericCharacters(col("diagnosisMxVersion")) as "medicalCodeType",
          col("diagnosisPriorityNo").cast(IntegerType) as "sequenceNumber"
        )) as "diagnosisCodes").
        drop("diagnosisMxCode", "diagnosisMxVersion", "diagnosisPriorityNo")
      case Prognosis => df.where("sourcePersonId is not null and sourceRecordId is not null and" +
        " prognosisMxCode is not null and prognosisMxVersion is not null and prognosisPriorityNo is not null").
        groupBy(col("sourceRecordId"), col("sourcePersonId")).agg(collect_list(
        struct(
          stripDecimal(col("prognosisMxCode")) as "medicalCode",
          stripNonAlphaNumericCharacters(col("prognosisMxVersion")) as "medicalCodeType",
          col("prognosisPriorityNo").cast(IntegerType) as "sequenceNumber"
        )) as "procedureCodes").
        drop("prognosisMxCode", "prognosisMxVersion", "prognosisPriorityNo")
    }
    codeDf
  }

  val stripNonAlphaNumericCharacters: UserDefinedFunction = udf((value: String) => {
    if (value != null && value.nonEmpty) {
      value.replaceAll("[^\\d.]", "")
    }
    else null
  })
  // This will strip the decimal from the input medical code values, for example, E11.9 will be replaced as E119
  val stripDecimal: UserDefinedFunction = udf((value: String) => {
    if (value != null && value.nonEmpty && value.contains(".")) {
      value.replace(".", "")
    } else value
  })

  /**
    * Get list of utilization files from a given file path or s3 url path
    *
    * @param inputDirectoryPath
    * @param s3Client
    * @return
    */
  def getListOfEncounterFiles(inputDirectoryPath: String, s3Client: AmazonS3): List[String] = {
    var availableListOfFiles: List[String] = List()
    if (inputDirectoryPath.startsWith("s3")) {
      val bucketName = DataLakeUtilities.extractBucketNameFromS3RawBatchUrl(inputDirectoryPath)
      val objectName = DataLakeUtilities.extractS3SourcePrefixForFileArchival(inputDirectoryPath)
      availableListOfFiles = S3Utilities.
        getAvailableBatchDirectoryUrlsForInputBatchId(s3Client, s"s3a://$bucketName", objectName)
    }
    else {
      availableListOfFiles = FileUtilities.getListOfFileNames(inputDirectoryPath, ".txt")
    }

    val listOfMandatoryFileNames: List[String] = List("demog", "dx", "cpt", "facility", "visit")
    val listOfNonMandatoryFileNames: List[String] = List("px", "guarantor", "biometric", "physician", "financial")

    val missingListOfMandatoryFileNames = listOfMandatoryFileNames.filterNot(
      fileName => availableListOfFiles.exists(x =>
        x.toLowerCase().split("/").last.contains(fileName)))

    val missingListOfNonMandatoryFileNames = listOfNonMandatoryFileNames.filterNot(
      fileName => availableListOfFiles.exists(x => x.toLowerCase().split("/").last.contains(fileName)))

    if (missingListOfMandatoryFileNames.nonEmpty) {
      throw new FileNotFoundException(s"${missingListOfMandatoryFileNames.mkString(",")} files not found")
    }

    if (missingListOfNonMandatoryFileNames.nonEmpty) {
      logger.warn(s"${missingListOfNonMandatoryFileNames.mkString(",")} files not found")
    }

    availableListOfFiles

  }

  /**
    * Read fixed width files
    *
    * @param sparkSession
    * @param inputDirectoryPath
    * @param activityType
    * @return
    */
  def readFixedWidthFiles(sparkSession: SparkSession, inputDirectoryPath: String,
                          activityType: String, fieldSizes: Array[Int]): Map[String, DataFrame] = {
    import com.influencehealth.edh.spark.csv.FixedWidthContext
    var listOfFileNamesAndDataFrames: Map[String, DataFrame] = Map()
    val fileName = activityType.toUpperCase() match {
      case Constants.ProspectActivityType => "Cnsv"
      case _ => activityType.toLowerCase
    }
    val schema = schemaType(activityType.toUpperCase)

    Try {
      val loadedFile: DataFrame = sparkSession.sqlContext.fixedWidthFile(useHeader = false,
        filePath = inputDirectoryPath.concat(s"$fileName*"), fixedWidths = fieldSizes, schema = schema,
        ignoreLeadingWhiteSpace = false, ignoreTrailingWhiteSpace = false)

      /**
        * We have issue with input prospect file, where we are getting additional blank record at end of the file
        * as it's fix width file it's reading and cleansed job is failing. Hence, we are removing
        * the last additional record from file while reading it so cleanse job run without any issue.
        */
      if (activityType.equalsIgnoreCase(Constants.ProspectActivityType)) {
        val total = loadedFile.count()
        val removeTail = loadedFile.rdd.zipWithIndex().filter(x => x._2 < total - 1).map(x => x._1)
        val finalDfWithloadedFile: DataFrame = sparkSession.sqlContext.createDataFrame(
          removeTail, StructType(loadedFile.schema.fields))

        listOfFileNamesAndDataFrames = listOfFileNamesAndDataFrames + (activityType -> finalDfWithloadedFile)
      }
      else {
        listOfFileNamesAndDataFrames = listOfFileNamesAndDataFrames + (activityType -> loadedFile)
      }
    } match {
      case Success(x) =>
      case Failure(e) =>
        throw new RuntimeException(s"No $activityType files were found for at input location " +
          s"$inputDirectoryPath")
    }
    listOfFileNamesAndDataFrames
  }


  /**
    * Filter header if required
    *
    * @param activityType
    * @param listOfDataFrames
    * @return
    */
  def filterHeader(activityType: String, listOfDataFrames: Map[String, DataFrame]): Map[String, DataFrame] = {
    val dfWithoutHeader: Map[String, DataFrame] = activityType match {
      case Constants.CallCenterActivityType |
           Constants.CallCenterBerylFormat |
           Constants.CallCenterSteriCycleFormat |
           Constants.CallCenterConiferFormat |
           Constants.DoNotSolicitActivityType |
           Constants.DoNotSolicitUpdateActivityType |
           Constants.DonorListActivityType |
           Constants.EmployeeRosterActivityType |
           Constants.EncounterActivityType |
           Constants.HraActivityType |
           Constants.MarketingListActivityType |
           Constants.NewMoverActivityType |
           Constants.ReferralActivityType => filterHeaders(listOfDataFrames, activityType)
      case _ => listOfDataFrames
    }
    dfWithoutHeader
  }

  /**
    * Join calls for activityTypes that have multiple types of files
    *
    * @param activityType
    * @param listOfDataFrames
    * @return
    */
  def joinAllDataFrames(
                         activityType: String,
                         listOfDataFrames: Map[String, DataFrame],
                         inputDirectoryPath: String
                       ): DataFrame = {
    val format = if (inputDirectoryPath.startsWith("s3a") || inputDirectoryPath.startsWith("s3n")) {
      DataLakeUtilities.extractFormatFromS3Url(inputDirectoryPath).toString
    } else { // Just for test case
      DataLakeUtilities.extractFormatFromProjectUrl(inputDirectoryPath).toString
    }

    val df = activityType match {
      case Constants.EncounterActivityType => EncounterNormalizer.
        normalizeEncounterFiles(listOfDataFrames.map { x =>
          x._1 match {
            case Demographic =>
              (DemographicFile, x._2)
            case CurrentProceduralTerminology =>
              (CurrentProceduralTerminologyFile, x._2)
            case Diagnosis =>
              (DiagnosisFile, x._2)
            case Prognosis =>
              (PrognosisFile, x._2)
            case Facility =>
              (FacilityFile, x._2)
            case Visit =>
              (VisitFile, x._2)
            case Guarantor =>
              (GuarantorFile, x._2)
            case Biometric =>
              (BiometricFile, x._2)
            case Physician =>
              (PhysicianFile, x._2)
            case Financial =>
              (FinancialFile, x._2)
          }
        })
      case Constants.HraActivityType =>
        val list = listOfDataFrames.map {
          case (HraDetail, df) =>
            (HRADetailV1, df)
          case (HraDetailV2, df) =>
            (HRADetailV2, df)
          case (HraHeader, df) =>
            (HRAHeaderV1, df)
          case (HraHeaderV2, df) =>
            (HRAHeaderV2, df)
        }
        HraNormalizer.joinAllHraDataFrames(list, format)
      case _ => listOfDataFrames.filter(x => x._1.contains(activityType)).head._2
    }
    df.withColumn("dateCreated", lit(Constants.Now.toString))
  }

  /**
    * add source and sourceRecordId to the input dataframe
    *
    * @param activityType
    * @param joinedAllDataFrames
    * @param inputDirectoryPath
    * @return
    */
  def addSourceAndSourceRecordId(activityType: String, joinedAllDataFrames: DataFrame,
                                 inputDirectoryPath: String, customer: String): DataFrame = {
    // Generating source name from the input S3Url
    val source: String = DataLakeUtilities.getBatchIdFromS3Url(inputDirectoryPath, activityType, customer)
    val df = activityType match {
      case Constants.MarketingListActivityType |
           Constants.CallCenterActivityType |
           Constants.DoNotSolicitActivityType |
           Constants.EmployeeRosterActivityType |
           Constants.NewMoverActivityType |
           Constants.ProspectActivityType => {
        val addUniqueId = joinedAllDataFrames.withColumn("uniqueId", monotonically_increasing_id())
        // As monotonically_increasing_id() method generates guaranteed monotonically increasing and unique,
        // but not consecutive, hence added below logic to generate consecutive row_numbers based on unique ids.
        val addRowId = addUniqueId.withColumn("rowId", row_number().over(Window.orderBy("uniqueId"))).
          drop("uniqueId")
        val addSourceAndSRId: DataFrame = addRowId
          .withColumn("sourceRecordId", col("rowId").cast(StringType))
          .withColumn("source", lit(source))
          .drop("rowId")
        addSourceAndSRId
      }
      case Constants.DeceasedActivityType => {
        val updateSourceData = joinedAllDataFrames.withColumn("sourceRecordId", col("socialSecurity"))
          .withColumn("source", lit(source))
        updateSourceData
      }
      case Constants.HraActivityType => {
        val updateSourceData = joinedAllDataFrames.withColumn("sourceRecordId", col("transactionId"))
          .withColumn("source", lit(source))
        updateSourceData
      }
      case Constants.ReferralActivityType => {
        val updateSourceData = joinedAllDataFrames
          .withColumn("sourceRecordId", concat(col("ccCallNo"), col("seqNo")))
          .withColumn("source", lit(source))
        updateSourceData
      }
      case _ => joinedAllDataFrames
    }
    df
  }

  /**
    * add source and sourceRecordId to the input dataframe for the unit testing
    *
    * @param activityType
    * @param joinedAllDataFrames
    * @return
    */
  def addDummySourceData(activityType: String, joinedAllDataFrames: DataFrame): DataFrame = {
    val df = activityType.toUpperCase match {
      case Constants.MarketingListActivityType |
           Constants.CallCenterActivityType |
           Constants.DoNotSolicitActivityType |
           Constants.EmployeeRosterActivityType |
           Constants.NewMoverActivityType |
           Constants.ProspectActivityType => {
        val addUniqueId = joinedAllDataFrames.withColumn("uniqueId", monotonically_increasing_id())
        // As monotonically_increasing_id() method generates guaranteed monotonically increasing and unique,
        // but not consecutive, hence added below logic to generate consecutive row_numbers based on unique ids.
        val addRowId = addUniqueId.withColumn("rowId", row_number().over(Window.orderBy("uniqueId"))).
          drop("uniqueId")
        val addSourceAndSRId: DataFrame = addRowId
          .withColumn("sourceRecordId", col("rowId").cast(StringType))
          .withColumn("source", lit(activityType))
          .drop("rowId")
        addSourceAndSRId
      }
      case Constants.DeceasedActivityType => {
        val updateSourceData = joinedAllDataFrames.withColumn("sourceRecordId", col("socialSecurity"))
          .withColumn("source", lit(activityType))
        updateSourceData
      }
      case Constants.HraActivityType => {
        val updateSourceData = joinedAllDataFrames.withColumn("sourceRecordId", col("transactionId"))
          .withColumn("source", lit(activityType))
        updateSourceData
      }
      case Constants.ReferralActivityType => {
        val updateSourceData = joinedAllDataFrames
          .withColumn("sourceRecordId", concat(col("ccCallNo"), col("seqNo")))
          .withColumn("source", lit(activityType))
        updateSourceData
      }
      case _ => joinedAllDataFrames
    }
    df
  }

  /**
    * Filters header row for all sources
    *
    * @param listOfDataFrames
    * @param activityType
    * @return
    */
  def filterHeaders(listOfDataFrames: Map[String, DataFrame], activityType: String): Map[String, DataFrame] = {
    var filteredDataFrame: DataFrame = null
    var listOfDataFramesWithoutHeader: Map[String, DataFrame] = Map()

    for (element <- listOfDataFrames) {
      activityType.toUpperCase match {
        case Constants.CallCenterActivityType |
             Constants.CallCenterBerylFormat |
             Constants.CallCenterSteriCycleFormat |
             Constants.CallCenterConiferFormat |
             Constants.DoNotSolicitActivityType |
             Constants.ReferralActivityType |
             Constants.NewMoverActivityType => filteredDataFrame =
          element._2.filter(
            prepValueForComparision(element._2("firstName")) =!= "FIRSTNAME" ||
              element._2("firstName").isNull)
        case Constants.DoNotSolicitUpdateActivityType => filteredDataFrame =
          element._2.filter(prepValueForComparision(element._2("optOutDirectMail")) =!= "OPTOUTDIRECTMAIL")
        case Constants.DonorListActivityType => filteredDataFrame = element._2.filter(
          prepValueForComparision(element._2("zip5")) =!= "ZIP" || element._2("zip5").isNull
        )
        case Constants.EmployeeRosterActivityType => filteredDataFrame =
          element._2.filter(prepValueForComparision(element._2("employeeId")) =!= "EMPLOYEEID")
        case Constants.EncounterActivityType => element._1 match {
          case x if x.equals(Physician) => filteredDataFrame =
            element._2.filter(prepValueForComparision(element._2("primaryCarePhysicianId")) =!= "PHYSICIANID")
          case _ => filteredDataFrame =
            element._2.filter(
              prepValueForComparision(element._2("sourcePersonId")) =!= "PATIENTID" &&
                prepValueForComparision(element._2("sourcePersonId")) =!= "MRN" &&
                prepValueForComparision(element._2("sourcePersonId")) =!= "MEDICALRECORD")
        }
        case Constants.HraActivityType => element._1 match {
          case x if x.contains(detailFile) || x.contains(detailFileV2) => filteredDataFrame = {
            element._2.filter(
              upper(element._2("transactionId")) =!= "TRANSACTION_ID" || element._2("transactionId").isNull
            )
          }
          case _ => filteredDataFrame = {
            element._2.filter(
              upper(element._2("zip5")) =!= "ZIP" || element._2("zip5").isNull
            )
          }
        }
        case Constants.MarketingListActivityType => filteredDataFrame =
          element._2.filter(prepValueForComparision(element._2("lastName")) =!= "LASTNAME")
      }
      listOfDataFramesWithoutHeader = listOfDataFramesWithoutHeader + (element._1 -> filteredDataFrame)
    }
    listOfDataFramesWithoutHeader
  }

  def prepValueForComparision = udf[String, String](str =>
    Option(str).
      map(_.
        replaceAll("_", "").
        replaceAll("\\s", "").
        toUpperCase()).
    orNull
  )

  /**
    * return the file extension by reading the input files.
    *
    * @param inputDirectoryPath
    * @param s3Client
    * @param activityType
    * @return extension of the file name
    */
  def checkFileExtension(inputDirectoryPath: String, s3Client: AmazonS3,
                         activityType: String, force: Boolean): Option[String] = {

    if (inputDirectoryPath.startsWith("s3a") || inputDirectoryPath.startsWith("s3n")) {
      // Check if .txt/.csv file exists
      val bucketName = DataLakeUtilities.extractBucketNameFromS3RawBatchUrl(inputDirectoryPath)
      val objectName = DataLakeUtilities.extractS3SourcePrefixForFileArchival(inputDirectoryPath)
      val availableListOfFiles: Seq[String] = S3Utilities.
        getAvailableBatchDirectoryUrlsForInputBatchId(s3Client,
          s"s3a://$bucketName", objectName).filterNot(_.endsWith("/"))

      if (availableListOfFiles.exists(x => x.endsWith("done"))) {
        if (!force) {
          throw new RuntimeException(s"Files at $inputDirectoryPath has been already processed. To process them again" +
            s", run the job with --force command")
        }
        else {
          logger.info(s"Running job on already cleansed files.")
        }
      }

      val fileExtension = availableListOfFiles match {
        case x if x.isEmpty => "NoExtension"
        case _ => availableListOfFiles.filterNot(_.endsWith(".done")).head.split("\\.").last
      }
      Some(fileExtension)
    }
    else Some("InputFilesNotInS3Folder")
  }

  /**
    * Spark read excel input file and return a df
    *
    * @param sparkSession
    * @param schemaStructure
    * @param file
    * @return
    */
  def readExcelFiles(sparkSession: SparkSession, file: String, schemaStructure: StructType): DataFrame = {
    sparkSession.sqlContext.read
      .format("com.crealytics.spark.excel")
      .option("path", file)
      .option("useHeader", "true")
      .option("maxRowsInMemory", 100)
      .schema(schemaStructure)
      .load()
  }

  /**
    * method to return the schema for the given format
    *
    * @return a StructType schema
    */
  def getSchemaByFormat(format: String): StructType = {
    format.toUpperCase match {
      case Constants.CallCenterBerylFormat | Constants.CallCenterSteriCycleFormat =>
        CallCenterSchema.callCenterBerylSchema
      case Constants.CallCenterConiferFormat => CallCenterSchema.callCenterConiferSchema
    }
  }


  /**
    * method to process callcenter files
    *
    * @param sparkSession
    * @param inputDirectoryPath
    * @param listOfIncomingFiles
    * @param delimiter
    * @param schema
    * @return dataframe
    */
  def processCallcenterFiles(sparkSession: SparkSession,
                             inputDirectoryPath: String,
                             listOfIncomingFiles: List[String],
                             delimiter: Option[String],
                             schema: StructType): DataFrame = {

    val format = inputDirectoryPath match {
      case x if x.startsWith("s3a") || x.startsWith("s3n") =>
        DataLakeUtilities.extractFormatFromS3Url(inputDirectoryPath)
      case _ => DataLakeUtilities.extractFormatFromProjectUrl(inputDirectoryPath)
    }

    if (format.equalsIgnoreCase(Constants.CallCenterSteriCycleFormat)) {
      processStericycleFormat(sparkSession, listOfIncomingFiles)
    }
    else {
      listOfIncomingFiles.foldLeft(sparkSession.createDataFrame(sparkSession.sparkContext.emptyRDD[Row],
        schema)) { (x, y) => x.union(readCSVinSpark(sparkSession, delimiter, schema, y, "*")) }
    }
  }

  /**
    * If the callcenter file format is Stericycle, it can have two version of schema.
    * This method looks at header of each file and reads it with respective schema,
    * create two seperate dataframes and returns union of these two dataframes.
    *
    * @param sparkSession
    * @param listOfIncomingFiles
    * @return dataframe
    */
  def processStericycleFormat(sparkSession: SparkSession,
                              listOfIncomingFiles: List[String]): DataFrame = {

    val headerStringV1 = "cc_call_no|created_date_time|cc_person_no|lastname"
    val headerStringV2 = "cc_call_no|created_date_time|cc_person_no|city"

    var df1: DataFrame = sparkSession.createDataFrame(sparkSession.sparkContext.emptyRDD[Row],
      CallCenterSchema.callCenterBerylSchema)
    var df2: DataFrame = sparkSession.createDataFrame(sparkSession.sparkContext.emptyRDD[Row],
      CallCenterSchema.callCenterStericycleV2Schema)

    listOfIncomingFiles.foreach {
      filePath =>
        val header = sparkSession.read.text(filePath).head.getString(0)
        if (header.startsWith(headerStringV1)) {
          df1 = df1.union(sparkSession.read.option("header", true).option("delimiter", "|").
            schema(CallCenterSchema.callCenterBerylSchema).csv(filePath))
        }
        else if (header.startsWith(headerStringV2)) {
          df2 = df2.union(sparkSession.read.option("header", true).option("delimiter", "|").
            schema(CallCenterSchema.callCenterStericycleV2Schema).csv(filePath))
        }
    }

    val columns: Array[String] = df1.columns
    val result: DataFrame = df2.select(columns.head, columns.tail: _*)
    df1.union(result)
  }

  /**
    * Reads CSV File
    *
    * @return
    */
  def readCSVFilesWithHeader(sparkSession: SparkSession, inputDirectoryPath: String): DataFrame = {
    val inputDataFrame = sparkSession.read.option("header", true).option("delimiter", ",").
      csv(s"$inputDirectoryPath*")

    inputDataFrame.columns.
      foldLeft(inputDataFrame)((whiteSpace, noWhiteSpace) => whiteSpace.
        withColumnRenamed(noWhiteSpace, noWhiteSpace.replaceAll(" ", "")))
  }


}
