package com.influencehealth.edh.model.schema

import org.apache.spark.sql.types.{StringType, StructField, StructType}

object DnsSchema {

  val trueFlag: Boolean = true
  val falseFlag: Boolean = false

  val DnsSchema: StructType = StructType(
    Array(
      StructField("lastName", StringType, trueFlag),
      StructField("firstName", StringType, trueFlag),
      StructField("middleName", StringType, trueFlag),
      StructField("address1", StringType, trueFlag),
      StructField("address2", StringType, trueFlag),
      StructField("city", StringType, trueFlag),
      StructField("state", StringType, trueFlag),
      StructField("zip5", StringType, trueFlag),
      StructField("sourceSex", StringType, trueFlag),
      StructField("dateOfBirth", StringType, trueFlag),
      StructField("phoneNumbers", StringType, trueFlag),
      StructField("emails", StringType, trueFlag),
      StructField("sourceDnsReason", StringType, trueFlag)
    )
  )
}
