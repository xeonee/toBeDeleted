package com.influencehealth.edh.check

import java.sql.Date

import allbegray.slack.SlackClientFactory
import allbegray.slack.`type`.Payload
import com.influencehealth.edh.BaldurApplication
import com.influencehealth.edh.Constants._
import com.influencehealth.edh.config._
import com.influencehealth.edh.dao.DatabaseDao
import com.influencehealth.edh.lookups.client.LookupsClient
import com.influencehealth.edh.model._
import com.typesafe.config.Config
import mojolly.inflector.Inflector
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.apache.spark.storage.StorageLevel

/** Runs a few queries and gathers statistics on the state of the EDH database  */
object CheckHealthApp extends BaldurApplication[CheckHealthConfig] {
  var personsCount: Option[Long] = None

  override def runJob(
                       implicit sparkSession: SparkSession,
                       config: CheckHealthConfig,
                       databaseDao: DatabaseDao
                     ) = {

    val healthCheckStat = StringBuilder.newBuilder

    var passCount: Int = 0
    var failCount: Int = 0
    var warnCount: Int = 0

    def pass: String = {
      passCount += 1
      "PASS"
    }

    def fail: String = {
      failCount += 1
      "FAIL"
    }

    def warn: String = {
      warnCount += 1
      "WARN"
    }

    val customerName: String = config.customer

    logger.info("Healthcheck Start")

    val personsDf: Dataset[Person] = databaseDao.getPersonsByCustomer(customerName, full = true)
      .persist(StorageLevel.MEMORY_AND_DISK)

    personsCount = Some(personsDf.count)
    if (personsDf.head(1).nonEmpty) {

      val totalPersons = personsDf.count()
      val totalAdults = personsDf.select("personId").where("sourceAge > 18").count()
      val totalAdultsPercent: Double = calculatePercentage(totalAdults, totalPersons)

      formatStats(s"Total persons for customer ${config.customer}", s"${totalPersons.toString}" +
        s" ${validateStatus(totalPersons.toDouble, config.customer + "TotalPersons")}")

      formatStats(s"Total number of Adults (sourceAge > 18)", s"$totalAdults " +
        s"(${"%3.2f".format(totalAdultsPercent)}%) ${validateStatus(totalAdultsPercent, "totalAdults")}")

      def fullCheck: Boolean = if (config.fullRefresh.get) {
        config.fullRefresh.get
      }
      else {
        false
      }

      countNulls(personsDf, nullCheckColumns, totalPersons)

      checkColumnsForNullOrUnknownValues(personsDf, nullOrUnknownCheckColumns, totalPersons)

      checkGendersForAcceptedThresholds(personsDf, totalPersons)

      val personTypeCounts = checkPersonTypesForAcceptedThresholds(personsDf, totalPersons)

      checkForAcceptedThresholdNullFinancialClass(personsDf, personTypeCounts) // for patients only

      countsOfPopulatedCollections(personsDf, collectionColumns, totalPersons)

      countPayerTypesForAcceptedThresholds(personsDf, totalPersons, personTypeCounts)

      checkValidAddressForValidAddressFlag(personsDf, totalPersons)

      countPotentialDuplicates(personsDf, totalPersons)

      checkAdultsInUnitForAcceptedValues(personsDf, totalPersons)

      checkStandardValuesForAge(personsDf, totalPersons)

      checkWealthRatingForAcceptedValues(personsDf)

      checkZip4ContainsValidValues(personsDf)

      checkZip5ContainsValidValues(personsDf)

      checkStandardValuesForFinancialClass(personsDf)

      checkPersonInLivingUnitContainsValidValues(personsDf)

      checkAgeOrDateOfBirthPresentForAcceptedThresholds(personsDf, totalPersons)

      // more detailed checks that we may not always want to run
      if (fullCheck) {

        checkColumnsContainsValidValues(personsDf, validValuesForColumns)

        checkEducationContainsValidValues(personsDf, totalPersons)

        duplicationByPersonType(personsDf, personTypeCounts, totalPersons)

        duplicationWithHouseholdComposition(personsDf, totalPersons)

        duplicationByPayerType(personsDf, totalPersons)

        checkEmailForValidoptOutEmailFlag(personsDf, totalPersons)

        checkoptOutTextPreferencesForValidPhoneNumbers(personsDf, totalPersons)

        checkAcceptedThresholdForLocationScoring(personsDf, totalPersons)

        checkAddressIdsForDistinctAddresses(personsDf, totalPersons)

        checkPatientPersonType(personsDf, totalPersons)

        checkQualifiedPersonTypeForMarketingList(personsDf, totalPersons)

        checkExperianDataOnPatients(personsDf, personTypeCounts)

        checkAcceptedThresholdForDeceasedPersons(personsDf, totalPersons)

        checkPatientForHavingAtLeastOneEncounter(personsDf, totalPersons)

        checkForValidDateOfBirth(personsDf, totalPersons)

        checkForValidDateOfDeath(personsDf, totalPersons)

        checkPrimaryCarePhysicianContainsValidValues(personsDf, totalPersons)

        checkAllChildrenAgeBucketsContainsValidValues(personsDf, totalPersons)

        checkChildrenInLivingUnitForPresentChildrenContainsValidValues(personsDf, totalPersons)

        checkMappingsBetweenEncounterDataAndPersonMaster(personsDf,
          encounterDataMappingColumns, totalPersons)

        checkColumnsForNonNullAndGreaterThanZero(personsDf, totalPersons, nullAndGreaterThanZeroColumns)

        checkOccupationContainsValidValues(personsDf, totalPersons)
      }
      formatStats(s"Health Check Summary", s"Total Tests: ${passCount + failCount + warnCount}" +
        s" -- Passing: $passCount -- Warning: $warnCount -- Failing: $failCount")
      formatStats(s"Overall Health", s"${
        if (failCount > 0) {
          "FAIL"
        } else {
          "PASS"
        }
      }")

      personsDf.unpersist()

    } else {
      throw new RuntimeException(s"No records present in the persons table for the input customer: $customerName")
    }

    try {
      // TODO extract this to an external configuration as necessary if health check config ever needs to change
      val webhookUrl = config.slackHook.get
      val webApiClient = SlackClientFactory.createWebhookClient(webhookUrl)
      val payload = new Payload()
      payload.setText(healthCheckStat.toString())
      webApiClient.post(payload)
    } catch {
      case e: Exception => logger.error("There was an error while attempting to post the results to Slack", e)
    }
    println(healthCheckStat)

    logger.info("Healthcheck End")

    def evaluateGreaterThan(percent: Double, value: Double): Boolean = {
      percent > value
    }

    def evaluateGreaterThanAndEqualTo(percent: Double, value: Double): Boolean = {
      percent >= value
    }

    def evaluateEqualTo(percent: Double, value: Double): Boolean = {
      percent == value
    }

    def evaluateLessThan(percent: Double, value: Double): Boolean = {
      percent < value
    }

    def formatStats(statKey: String, statValue: String) = {
      healthCheckStat.append(s"$statKey: $statValue\n")
    }

    /**
      * Education is populated between 0 - 5
      *
      * @param personMasterDf the DF of the person master data
      * @param statsWriter    instance of utility class for writing stats out
      * @param totalPersons   the total number of persons in the presons table for a customer
      */
    def checkEducationContainsValidValues(personMasterDf: Dataset[Person],
                                          totalPersons: Long): Unit = {

      val count = personMasterDf.select("education").where("education is not null").
        filter(row => !listEducationValidValues.contains(row.getAs[String]("education").toUpperCase)).count()

      val passOrFail = if (count <= 0) pass else fail
      formatStats(s"Persons having invalid education are", s"$count $passOrFail ")
    }

    /**
      * check pass or fail and print message.
      *
      * @param percent          the valid or invalid percentage
      * @param value            count value of valid or invalid check
      * @param threshold        the threshold
      * @param conditionToCheck the condition
      * @param message          the print message
      * @param statsWriter      the statsWriter
      */
    def printMessage(percent: Double, value: Long, threshold: Int, conditionToCheck: String, message: String
                    ): Unit = {
      val checkPassOrFails = conditionToCheck match {
        case ">" => evaluateGreaterThan(percent, threshold)
        case "<" => evaluateLessThan(percent, threshold)
        case "=" => evaluateEqualTo(percent, threshold)
        case ">=" => evaluateGreaterThanAndEqualTo(percent, threshold)
      }

      val passOrFail = if (checkPassOrFails) {
        pass
      } else {
        fail
      }
      formatStats(s"$message", s"$value (${"%3.2f".format(percent)}%) $passOrFail")
    }

    /**
      * all persons should have either age or date of birth populated
      *
      * @param personMaster the DF of the person master data
      * @param statsWriter  instance of utility class for writing stats out
      * @param totalPersons the total persons in the db for the customer
      */
    def checkAgeOrDateOfBirthPresentForAcceptedThresholds(personMaster: Dataset[Person],
                                                          totalPersons: Long) {
      val getAgeAndDateOfBirthCount = personMaster
        .select("sourceAge", "dateOfBirth")
        .where("sourceAge is null AND dateOfBirth is null")
        .count()

      val percentOfPersons = calculatePercentage(getAgeAndDateOfBirthCount, totalPersons)

      formatStats(s"< 5% of persons where both dateOfBirth and sourceAge is null",
        s"$getAgeAndDateOfBirthCount (${"%3.2f".format(percentOfPersons)}%) " +
          s"${validateCountNulls(percentOfPersons, "dateOfBirth_age")}")

    }

    /**
      * get non null column persons
      *
      * @param personMaster  the DF of the person master data
      * @param columnToCheck instance of utility class for writing stats out
      */
    def nonNullColumnPersonsDf(personMaster: Dataset[Person], columnToCheck: String): DataFrame = {
      personMaster.select(columnToCheck).where(columnToCheck + " is not null")
    }

    /**
      * check if given string is number
      *
      * @param str input String
      */
    def isAllDigits(str: String) = str forall Character.isDigit

    /**
      * financial class id is populated with standard values
      *
      * @param personMaster the DF of the person master data
      * @param statsWriter  instance of utility class for writing stats out
      */
    def checkStandardValuesForFinancialClass(personMaster: Dataset[Person]) {

      val persons = nonNullColumnPersonsDf(personMaster, "financialClass")

      val nonNullPersonsCount = persons.count()

      val getFinancialClassIdCount =
        persons.filter(a => DefinedFinancialClass.contains(a.getAs[String]("financialClass").toUpperCase)).count()


      val percentOfPersons = calculatePercentage(getFinancialClassIdCount, nonNullPersonsCount)

      printMessage(percentOfPersons, getFinancialClassIdCount, 100, equalToOperator,
        "financial class is populated with standard values")
    }

    /**
      * Runs a health check to see whether a text column is be populated with valid values
      *
      * @param personMaster              the DF of the person master data
      * @param statsWriter               instance of utility class for writing stats out
      * @param validValuesForColumnsList the coulumn to check
      */
    def checkColumnsContainsValidValues(personMaster: Dataset[Person], validValuesForColumnsList:
    Map[String, Seq[String]]) {

      for (x <- validValuesForColumnsList) {

        val nonNullColumnPersons = personMaster.select(x._1).where(x._1 + " is not null")
        val nonNullColumnPersonsCount = nonNullColumnPersons.count()
        val invalidColumnPersonCount = nonNullColumnPersons
          .filter(a => !x._2.contains(a.getAs[String](x._1).toUpperCase)).count()

        val percentOfValidColumns = calculatePercentage(invalidColumnPersonCount, nonNullColumnPersonsCount)

        val passOrFail = if (percentOfValidColumns == 0) {
          pass
        } else if (percentOfValidColumns > 5) {
          fail
        } else if (percentOfValidColumns > 1) {
          warn
        }

        formatStats(s"Persons populated with invalid values for ".concat(x._1),
          s"$invalidColumnPersonCount (${"%3.2f".format(percentOfValidColumns)}%) $passOrFail")
      }

    }

    /**
      * persons in living unit is populated with accepted values
      *
      * @param personMaster the DF of the person master data
      * @param statsWriter  instance of utility class for writing stats out
      */
    def checkPersonInLivingUnitContainsValidValues(personMaster: Dataset[Person]) {
      import personMaster.sqlContext.implicits._
      val persons = nonNullColumnPersonsDf(personMaster, "personsInLivingUnit")
      val nonNullPersonsCount = persons.count()
      val personInLivingUnitCount = persons
        .filter($"personsInLivingUnit" <= 0).count()

      val percentOfValidColumns = calculatePercentage(personInLivingUnitCount, nonNullPersonsCount)

      val passOrWarn = if (percentOfValidColumns <= 0) {
        pass
      } else {
        warn
      }
      formatStats(s"persons in living unit is populated with accepted values",
        s"$personInLivingUnitCount (${"%3.2f".format(percentOfValidColumns)}%) $passOrWarn")
    }

    /**
      * validates zip5 represents an number between 0 and 9999
      *
      * @param personMaster the DF of the person master data
      * @param statsWriter  instance of utility class for writing stats out
      */
    def checkZip5ContainsValidValues(personMaster: Dataset[Person]) {
      val zip5Range = (0 to 99999).toArray
      val persons = nonNullColumnPersonsDf(personMaster, "zip5")
      val nonNullPersonsCount = persons.count()

      val zip5Count = persons
        .filter(x => isAllDigits(x.getAs[String]("zip5")) && x.getAs[String]("zip5").length <= 5)
        .filter(a => zip5Range.contains(a.getAs[String]("zip5").toInt))
        .count()
      val percentOfPersons = calculatePercentage(zip5Count, nonNullPersonsCount)

      formatStats(s"zip5 represents an number between 0 and 99999",
        s"$zip5Count (${"%3.3f".format(percentOfPersons)}%) ${validateStatus(percentOfPersons, "zip5")}")
    }

    /**
      * validates zip4 represents an number between 0 and 9999
      *
      * @param personMaster the DF of the person master data
      * @param statsWriter  instance of utility class for writing stats out
      */
    def checkZip4ContainsValidValues(personMaster: Dataset[Person]) {
      val zip4Range = (0 to 9999).toArray
      val persons = nonNullColumnPersonsDf(personMaster, "zip4")
      val nonNullPersonsCount = persons.count()
      val zip4Count = persons
        .filter(x => isAllDigits(x.getAs[String]("zip4")) && x.getAs[String]("zip4").length <= 4)
        .filter(a => zip4Range.contains(a.getAs[String]("zip4").toInt))
        .count()

      val percentOfPersons = calculatePercentage(zip4Count, nonNullPersonsCount)

      formatStats(s"zip4 represents an number between 0 and 9999",
        s"$zip4Count (${"%3.3f".format(percentOfPersons)}%) ${validateStatus(percentOfPersons, "zip4")}")
    }

    /**
      * validates wealth Rating is populated with accepted values
      *
      * @param personMaster the DF of the person master data
      * @param statsWriter  instance of utility class for writing stats out
      */
    def checkWealthRatingForAcceptedValues(personMaster: Dataset[Person]) {
      import personMaster.sqlContext.implicits._
      val persons = nonNullColumnPersonsDf(personMaster, "wealthRating")
      val nonNullPersonsCount = persons.count()

      val wealthCount = persons
        .filter($"wealthRating" >= 0 && $"wealthRating" <= 9)
        .count()

      val percentOfPersons = calculatePercentage(wealthCount, nonNullPersonsCount)

      formatStats(s"wealth Rating is populated with accepted values",
        s"$wealthCount (${"%3.2f".format(percentOfPersons)}%) ${validateStatus(percentOfPersons, "wealthRating")}")
    }

    /**
      * check number of adults in living unit should be populated and less than 50:
      *
      * @param personMaster the DF of the person master data
      * @param statsWriter  instance of utility class for writing stats out
      * @param totalPersons the total persons in the db for the customer
      */
    def checkAdultsInUnitForAcceptedValues(personMaster: Dataset[Person], totalPersons: Long) {
      import personMaster.sqlContext.implicits._
      val persons = nonNullColumnPersonsDf(personMaster, "adultsInLivingUnit")
      val nonNullPersonsCount = persons.count()

      val adultsCount = persons
        .filter($"adultsInLivingUnit" >= 0 && $"adultsInLivingUnit" <= 50)
        .count()

      val percentOfPersons = calculatePercentage(adultsCount, nonNullPersonsCount)

      val passOrWarn = if (percentOfPersons > 99) {
        pass
      } else {
        warn
      }
      formatStats(s"adults in unit populated and less than 50",
        s"$adultsCount (${"%3.2f".format(percentOfPersons)}%) $passOrWarn")
    }

    /**
      * check sourceAge is populated between 0 and 125:
      *
      * @param personMaster the DF of the person master data
      * @param statsWriter  instance of utility class for writing stats out
      * @param totalPersons the total persons in the db for the customer
      */
    def checkStandardValuesForAge(personMaster: Dataset[Person], totalPersons: Long) {
      import personMaster.sqlContext.implicits._
      val persons = nonNullColumnPersonsDf(personMaster, "sourceAge")
      val nonNullPersonsCount = persons.count()

      val ageCount = persons
        .filter($"sourceAge" > 0 && $"sourceAge" <= 125)
        .count()

      val percentOfPersons = calculatePercentage(ageCount, nonNullPersonsCount)

      formatStats(s"sourceAge is populated between 0 and 125",
        s"$ageCount (${"%3.2f".format(percentOfPersons)}%) ${validateStatus(percentOfPersons, "standardAgeValue")}")
    }

    /**
      * gathers counts of each person type
      *
      * @param personMaster the DF of the person master data
      * @param statsWriter  instance of utility class for writing stats out
      * @return a list of tuples List[(String, Long) = (personType, count(personType))
      */
    def checkPersonTypesForAcceptedThresholds(personMaster: Dataset[Person], totalPersons: Long):
    List[(String, Long)] = {
      val personTypes = personMaster
        .select("personType")
        .groupBy("personType")
        .count()
        .collect()
        .toList

      personTypes.foreach(row => {
        val personType = row.getString(0)
        val count = row.getLong(1)
        val percent = calculatePercentage(count, totalPersons)
        val passFail = personType match {
          case null => if (percent > 1) {
            fail
          } else {
            pass
          }
          case _ => pass
        }
        formatStats(s"personType '$personType'", s"$count (${"%3.2f".format(percent)}%) $passFail")
      })

      personTypes.map(r => (r.getString(0), r.getLong(1)))
    }

    /**
      * gathers counts of each sex
      *
      * @param personMaster the DF of the person master data
      * @param statsWriter  instance of utility class for writing stats out
      * @param totalPersons the total persons in the db for the customer
      */
    def checkGendersForAcceptedThresholds(personMaster: Dataset[Person],
                                          totalPersons: Long) {
      import personMaster.sqlContext.implicits._
      val nullSexesCount = personMaster.select($"sex").where("sex is null").toDF().count()
      val percent = calculatePercentage(nullSexesCount, totalPersons)
      formatStats(s"count of sex null :$nullSexesCount", s"(${"%3.2f".format(percent)}%) " +
        s"${validateCountNulls(percent, "sex")}")

      val persons = nonNullColumnPersonsDf(personMaster, "sex")

      val sexes = persons
        .select(upper($"sex").as("sex"))
        .groupBy("sex")
        .count()
        .collect()
        .toList

      sexes.foreach(row => {
        val count = row.getLong(1)
        val sex = row.getString(0)
        val percent = calculatePercentage(count, totalPersons)
        val passOrFailThreshold = sex.toUpperCase match {
          case SexMale => 100
          case SexFemale => 100
          case null => 100
          case _ => 0 // if any other values than the 3 above are present this check should fail
        }
        val passOrFail = if (percent == passOrFailThreshold) {
          fail
        } else {
          pass
        }

        formatStats(s"count of sex '$sex'", s"$count (${"%3.2f".format(percent)}%) $passOrFail")
      })
    }

    /**
      * gathers counts of each payer type and calculates their distribution
      *
      * @param personMaster     the DF of the person master data
      * @param statsWriter      instance of utility class for writing stats out
      * @param totalPersons     number of records in the presons table
      * @param personTypeCounts the counts for each personType
      */
    def countPayerTypesForAcceptedThresholds(personMaster: Dataset[Person], totalPersons: Long,
                                             personTypeCounts: List[(String, Long)]) {
      import personMaster.sqlContext.implicits._

      val payerTypes = personMaster
        .select(upper($"payerType").as("payerType"))
        .groupBy("payerType")
        .count()
        .collect()
        .toList

      val payerTypesForPatients = personMaster
        .select(upper($"payerType").as("payerType"))
        .where(col("personType").contains(PersonTypePatient))
        .groupBy("payerType")
        .count()
        .collect()
        .toList

      val totalPatients = personTypeCounts.find(p => p._1 != null && p._1.toUpperCase == PersonTypePatient) match {
        case Some((x: String, y: Long)) => y
        case _ => 0
      }

      DefinedPayerTypeCodes.foreach(pt => {
        val row = payerTypes.find(row => row.getString(0) == pt)
        val totalForPayerTypeAllPersons = if (row.isDefined) {
          row.get.getLong(1)
        } else {
          0
        }
        val rowForPatients = payerTypesForPatients.find(row => row.getString(0) == pt)
        val totalForPayerTypeForPatientsOnly = if (rowForPatients.isDefined) {
          rowForPatients.get.getLong(1)
        } else {
          0
        }
        val percentOfTotal = calculatePercentage(totalForPayerTypeAllPersons, totalPersons)

        val percentOfPatients = calculatePercentage(totalForPayerTypeForPatientsOnly, totalPatients)

        // check the percentage of persons with the given payer type against the total number of persons
        val passOrFailTotal = if (pt match {
          case "MI" => percentOfTotal > 25
          case "MK" => percentOfTotal > 25
          case "NI" => percentOfTotal > 25
          case "NK" => percentOfTotal > 25
          case "PI" => percentOfTotal > 40
          case "PK" => percentOfTotal > 40
          case null => percentOfTotal < 18
          case _ => false // unknown payer type value
        }) {
          pass
        }
        else {
          fail
        }

        // check the percentage of patients with the given inferred payer type to ensure its within appropriate ranges
        val passOrFailPatients = if (pt match {
          case "MI" => percentOfPatients <= 2
          case "NI" => percentOfPatients <= 2
          case "PI" => percentOfPatients <= 2
          case "PK" => percentOfPatients >= 40
          case "MK" => percentOfPatients >= 20
          case "NK" => percentOfPatients >= 25
          case null => percentOfPatients == 2
          case _ => false // unknown payer type value
        }) {
          pass
        }
        else {
          fail
        }

        formatStats(s"payerType '$pt'",
          s"$totalForPayerTypeAllPersons (${"%3.2f".format(percentOfTotal)}%) $passOrFailTotal ")
        formatStats(s"payerType '$pt' for patients only",
          s"$totalForPayerTypeForPatientsOnly (${"%3.2f".format(percentOfPatients)}%) $passOrFailPatients ")
      })
    }

    /**
      * gathers counts potential duplicates (rough count based on matching:
      * first name, last name, date of birth, sex, address1 and zip5)
      *
      * @param personMaster the DF of the person master data
      * @param statsWriter  instance of utility class for writing stats out
      * @param totalPersons the total persons in the db for the customer
      */
    def countPotentialDuplicates(personMaster: Dataset[Person], totalPersons: Long) {
      import personMaster.sqlContext.implicits._

      val potentialDupsWithAddressDf = personMaster
        .select("firstName", "lastName", "dateOfBirth", "sex", "address1", "zip5")
        .groupBy("firstName", "lastName", "dateOfBirth", "sex", "address1", "zip5")
        .count()
        .filter($"count" > 1)

      val distinctCountIncludingAddress = potentialDupsWithAddressDf.count()

      val percentDuplicatesByAddress = calculatePercentage(distinctCountIncludingAddress, totalPersons)

      val passOrFail = if (percentDuplicatesByAddress < 6) {
        pass
      } else {
        fail
      }
      formatStats(s"potential duplicates (including address)",
        s"$distinctCountIncludingAddress (${"%3.2f".format(percentDuplicatesByAddress)}%) $passOrFail")

      val potentialDupsDf = personMaster
        .select("firstName", "lastName", "dateOfBirth", "sex")
        .groupBy("firstName", "lastName", "dateOfBirth", "sex")
        .count()
        .filter($"count" > 1)

      val distinctCount = potentialDupsDf.count()
      val percentDuplicatesExcludingAddress = calculatePercentage(distinctCount, totalPersons)
      val passFailExcludingAddress = if (percentDuplicatesExcludingAddress < 6) {
        pass
      } else {
        fail
      }

      formatStats(s"potential duplicates (excluding Address)",
        s"$distinctCount (${"%3.2f".format(percentDuplicatesExcludingAddress)}%) $passFailExcludingAddress")
    }

    /**
      * gathers counts potential duplicates (rough count based on matching:
      * first name, last name, date of birth, sex, address1, zip5, and payerType)
      *
      * @param personMaster the DF of the person master data
      * @param statsWriter  instance of utility class for writing stats out
      * @param totalPersons the total number of persons in the database for the customer
      */
    def duplicationByPayerType(personMaster: Dataset[Person],
                               totalPersons: Long) {
      import personMaster.sqlContext.implicits._

      val potentialDups = personMaster
        .select("firstName", "lastName", "dateOfBirth", "sex", "address1", "zip5", "payerType")
        .groupBy("firstName", "lastName", "dateOfBirth", "sex", "address1", "zip5", "payerType")
        .count()
        .filter($"count" > 1)

      DefinedPayerTypeCodes.foreach(pt => {
        val dupsByPayerType = potentialDups.where(s"payerType = '$pt'")
        val distinctCountOfDups = dupsByPayerType.count()

        val percentOfTotal = calculatePercentage(distinctCountOfDups, totalPersons)

        // check the percentage of persons with the given payer type against the total number of persons
        val passOrFail = if (percentOfTotal < 4) {
          pass
        } else {
          fail
        }

        formatStats(s"duplicates by payerType '$pt'",
          s"$distinctCountOfDups (${"%3.2f".format(percentOfTotal)}%) $passOrFail ")
      })
    }

    /**
      * determines the rate of potential duplication by personType by grouping on
      * first name, last name, date of birth, sex.
      *
      * If the total for a given personType / the potential distinct persons for personType is > 1.5, fail
      *
      * @param personMaster     the DF of the person master data
      * @param statsWriter      instance of utility class for writing stats out
      * @param personTypeCounts the counts for each personType
      * @param totalPersons     the total persons in the db for the customer
      */
    def duplicationByPersonType(personMaster: Dataset[Person],
                                personTypeCounts: List[(String, Long)],
                                totalPersons: Long) {

      val personTypes = personTypeCounts.map(_._1)

      personTypes.foreach(personType => {
        val totalPersonsForPersonType = personTypeCounts.find(p => (personType == null && p._1 == null) ||
          (personType != null && p._1 != null && p._1.toUpperCase == personType)) match {
          case Some((x: String, y: Long)) => y
          case Some((null, y: Long)) => y
          case _ => 0
        }

        val potentialDistinctPersonsForPersonType = personType match {
          case null =>
            personMaster
              .where(s"personType is null")
              .select("firstName", "lastName", "dateOfBirth", "sex", "address1")
              .groupBy("firstName", "lastName", "dateOfBirth", "sex", "address1")
              .count()
          case _ =>
            personMaster
              .where(s"personType = '$personType'")
              .select("firstName", "lastName", "dateOfBirth", "sex", "address1")
              .groupBy("firstName", "lastName", "dateOfBirth", "sex", "address1")
              .count()
        }

        val distinctCount = potentialDistinctPersonsForPersonType.count()
        val duplicateCount = totalPersonsForPersonType - distinctCount

        val percentOfTotalPersons = calculatePercentage(duplicateCount, totalPersons)

        val passFail = if (percentOfTotalPersons < 4.0) pass else fail

        formatStats(s"duplicate persons by personType '$personType'",
          s"$duplicateCount (${"%3.2f".format(percentOfTotalPersons)}%) $passFail")
      })
    }

    /**
      * gathers counts for null values by column
      *
      * @param personMasterDf the DF of the person master data
      * @param columns        the columns to check for null values
      * @param statsWriter    instance of utility class for writing stats out
      * @param totalPersons   the total persons in the db for the customer
      */
    def countNulls(personMasterDf: Dataset[Person], columns: Seq[String],
                   totalPersons: Long) {
      columns.foreach(c => {
        val nulls = personMasterDf.where(s"$c is null")
        val nullCount = nulls.count()
        val percentInvalid = calculatePercentage(nullCount, totalPersons)

        formatStats(s"$c is null", s"$nullCount (${"%3.2f".format(percentInvalid)}%) " +
          s"${validateCountNulls(percentInvalid, c)}")
      })
    }

    /**
      * gathers counts for collection columns to see how many are populated with data.
      * Note: because these are collection columns we cannot check them for null vs empty
      * as they are treated the same way
      *
      * @param personMasterDf    the DataFrame of the person master table
      * @param collectionColumns the collection column names to check for data
      * @param statsWriter       instance of utility class for writing stats out
      */
    def countsOfPopulatedCollections(personMasterDf: Dataset[Person], collectionColumns: Seq[String],
                                     totalPersons: Long) {
      collectionColumns.foreach(c => {
        val count = personMasterDf.where(size(col(c)) > 0).count()
        val percent = calculatePercentage(count, totalPersons)

        val passFail = c match {
          case "phoneNumbers" => if (percent > 50) pass else fail
          case "emails" => if (percent > 0) pass else fail
          case _ => pass
        }

        formatStats(s"$c is populated", s"$count (${"%3.2f".format(percent)}%) $passFail")
      })
    }

    /**
      * validates duplicate counts including household composition
      *
      * @param personMaster the DF of the person master data
      * @param statsWriter  instance of utility class for writing stats out
      * @param totalPersons the total persons in the db for the customer
      */
    def duplicationWithHouseholdComposition(personMaster: Dataset[Person],
                                            totalPersons: Long) {
      import personMaster.sqlContext.implicits._
      val duplicates = personMaster
        .select("firstName", "lastName", "dateOfBirth", "sex", "address1", "householdComposition")
        .where("householdComposition is not null")
        .groupBy("firstName", "lastName", "dateOfBirth", "sex", "address1", "householdComposition")
        .count()
        .filter($"count" > 1)
        .count()

      val percentOfPersons = calculatePercentage(duplicates, totalPersons)

      val passOrFail = if (percentOfPersons < 1) pass else fail
      formatStats(s"duplicates by householdComposition",
        s"$duplicates (${"%3.2f".format(percentOfPersons)}%) $passOrFail")
    }

    /**
      * check for persons with isValidAddress = true but missing address1 or zip5 (invalid address)
      *
      * @param personMaster the DF of the person master data
      * @param statsWriter  instance of utility class for writing stats out
      */
    def checkValidAddressForValidAddressFlag(personMaster: Dataset[Person], totalPersons: Long) {
      val validAddressFlagNullCount = personMaster
        .where("isValidAddress is null")
        .count()

      val invalidFlagPersons = personMaster
        .where("isValidAddress = true and (address1 is null or zip5 is null)")
        .count()

      // everyone should have a isValidAddress set to true or false
      var passOrFail = if (validAddressFlagNullCount > 0) {
        fail
      } else {
        pass
      }
      var percent = calculatePercentage(validAddressFlagNullCount, totalPersons)

      formatStats(s"isValidAddress = null",
        s"$validAddressFlagNullCount (${"%3.2f".format(percent)}%) $passOrFail")

      passOrFail = if (invalidFlagPersons > 0) fail else pass
      percent = invalidFlagPersons.toFloat / totalPersons.toFloat * 100
      formatStats(s"isValidAddress = true and invalid or missing address",
        s"$invalidFlagPersons (${"%3.2f".format(percent)}%) $passOrFail")
    }

    /**
      * check for persons with isOptedOutEmail = false but missing email address
      *
      * @param personMaster the DF of the person master data
      * @param statsWriter  instance of utility class for writing stats out
      */
    def checkEmailForValidoptOutEmailFlag(personMaster: Dataset[Person], totalPersons: Long) {
      val invalidEmailPreferenceCount = personMaster
        .where("isOptedOutEmail = false and (emails is null or size(emails) = 0)")
        .count()

      val passOrFail = if (invalidEmailPreferenceCount > 0) fail else pass
      val percent = calculatePercentage(invalidEmailPreferenceCount, totalPersons)

      formatStats(s"isOptedOutEmail = false and invalid or missing email address",
        s"$invalidEmailPreferenceCount (${"%3.2f".format(percent)}%) $passOrFail")
    }

    /**
      * check for persons with isOptedOutText = false but missing phone number
      *
      * @param personMaster the DF of the person master data
      * @param statsWriter  instance of utility class for writing stats out
      */
    def checkoptOutTextPreferencesForValidPhoneNumbers(personMaster: Dataset[Person],
                                                       totalPersons: Long) {
      val invalidoptOutTextPreferenceCount = personMaster
        .where("isOptedOutText = false and (phoneNumbers is null or size(phoneNumbers) = 0)")
        .count()

      val passOrFail = if (invalidoptOutTextPreferenceCount > 0) fail else pass
      val percent = calculatePercentage(invalidoptOutTextPreferenceCount, totalPersons)

      formatStats(s"isOptedOutText = false and invalid or missing phoneNumbers",
        s"$invalidoptOutTextPreferenceCount (${"%3.2f".format(percent)}%) $passOrFail")
    }

    /**
      * Checks the threshold of people that have been location scored.
      *
      * @param personMaster the DF of the person master data
      * @param statsWriter  instance of utility class for writing stats out
      * @param totalPersons total persons in the presons table for a customer
      */
    def checkAcceptedThresholdForLocationScoring(personMaster: Dataset[Person], totalPersons: Long) {
      val locationScoredPersonsCount = personMaster
        .where("size(locations) > 0")
        .count()

      val percentLocationScored = calculatePercentage(locationScoredPersonsCount, totalPersons)

      formatStats(s"locations is scored/populated", s"$locationScoredPersonsCount " +
        s"(${"%3.2f".format(percentLocationScored)}%) ${validateStatus(percentLocationScored, "locations")}")
    }

    /**
      * Checks that every distinct address has its own address id
      *
      * @param personMaster the DF of the person master data
      * @param statsWriter  instance of utility class for writing stats out
      */
    def checkAddressIdsForDistinctAddresses(personMaster: Dataset[Person], totalPersons: Long) {
      import personMaster.sqlContext.implicits._
      val duplicatesByAddressId = personMaster
        .select("address1", "address2", "city", "state", "zip5", "zip4", "addressId")
        .groupBy("address1", "address2", "city", "state", "zip5", "zip4")
        .agg(countDistinct("addressId"))
        .filter($"count(DISTINCT addressId)" > 1)
        .count()

      val passOrFail = if (duplicatesByAddressId > 0) fail else pass
      val percent = calculatePercentage(duplicatesByAddressId, totalPersons)
      formatStats(s"addressId duplicates by address", s"$duplicatesByAddressId " +
        s"(${"%3.2f".format(percent)}%) $passOrFail")
    }

    /**
      * checks to see if all persons with a source_type of "hospital", "practice", "physician office"
      * all have person type = 'PATIENT'
      *
      * @param personMaster      the DF of the person master data
      * @param personsActivities the activity records for a customer
      * @param statsWriter       instance of utility class for writing stats out
      */
    def checkPatientPersonType(personMaster: Dataset[Person], totalPersons: Long) {
      val patientSourceTypes = Seq("hospital", "practice", "physician office")

      val personsWhoShouldBePatients = personMaster
        .filter(activity => activity.activities.contains(patientSourceTypes))
        .select("personId", "customer")

      // join to presons by personId, customer
      val shouldBePatientCount = personsWhoShouldBePatients
        .select("personId")
        .where(!col("personType").contains(PersonTypePatient))
        .select(countDistinct("personId")).first().getLong(0)

      val passFail = if (shouldBePatientCount > 0) fail else pass
      val percent = calculatePercentage(shouldBePatientCount, totalPersons)
      formatStats("incorrect person type count (should be " + PersonTypePatient + ")",
        s"$shouldBePatientCount (${"%3.2f".format(percent)}%) $passFail")
    }

    /**
      * checks to see if all persons with a source_type of 'marketing list',
      * 'listmarket','listMarket','call center','ulm' or activity_type = 'marketing list',
      * 'listMarket', 'listmarket' do not have a person type of 'NEW MOVER' or 'PROSPECT'
      *
      * @param personMaster      the DF of the person master data
      * @param personsActivities the activity records for a customer
      * @param statsWriter       instance of utility class for writing stats out
      */
    def checkQualifiedPersonTypeForMarketingList(personMaster: Dataset[Person],
                                                 totalPersons: Long) {
      val sourceTypes = Seq("marketing list", "listmarket", "call center", "ulm")
      val activityTypes = Seq("marketing list", "listmarket")

      // filter down to the activities we care about
      val filteredActivities = personMaster
        .filter(activity => activity.activities.contains(sourceTypes) ||
          activity.activities.contains(activityTypes))
        .select("personId", "customer")

      // join to presons by personId, customer
      val count = filteredActivities
        .select("personId")
        .where(col("personType").contains(PersonTypePatient) && col("personType").contains(PersonTypeProspect))
        .select(countDistinct("personId")).first().getLong(0)

      // the count should be zero, there should not be any persons with P or N person type with those activities
      val passFail = if (count > 0) fail else pass
      val percent = calculatePercentage(count, totalPersons)
      formatStats("incorrect person type count (incorrectly flagged as 'NEW MOVER' or 'PROSPECT')",
        s"$count (${"%3.2f".format(percent)}%) $passFail")
    }

    /**
      * checks experian data on patients
      *
      * @param personMaster
      * @param statsWriter
      * @param personTypeCounts
      */
    def checkExperianDataOnPatients(personMaster: Dataset[Person],
                                    personTypeCounts: List[(String, Long)]) {
      val experianColumns: Seq[String] = Seq(
        "combinedOwner",
        "dwellType",
        "beehiveCluster"
      )

      val patientData = personMaster
        .select(experianColumns.map(c => col(c)): _*)
        .where(col("personType").contains(PersonTypePatient))

      val totalPatients = personTypeCounts.find(p => p._1 != null && p._1.toUpperCase == PersonTypePatient) match {
        case Some((x: String, y: Long)) => y
        case _ => 0
      }

      experianColumns.foreach(colName => {
        val countOfPatientsWithData = patientData.where(s"$colName is not null").count()

        val percentOfPatientsWithData = calculatePercentage(countOfPatientsWithData, totalPatients)

        formatStats(s"experian data '$colName' fill rate for patients", s"$countOfPatientsWithData " +
          s"(${"%3.2f".format(percentOfPatientsWithData)}%) ${
            validateStatus(percentOfPatientsWithData,
              "experianData")
          }")


      })
    }

    /**
      * Less than 15% of persons should have deceased flag true
      *
      * @param personMaster the DF of the person master data
      * @param statsWriter  instance of utility class for writing stats out
      * @param totalPersons the total number of persons in the presons table for a customer
      */
    def checkAcceptedThresholdForDeceasedPersons(personMaster: Dataset[Person],
                                                 totalPersons: Long): Unit = {
      val deceasedFlagTrueCount = personMaster.select("isDeceased").
        where("isDeceased = TRUE").count()

      val percent = calculatePercentage(deceasedFlagTrueCount, totalPersons)

      val passOrFail = if (percent == 0) warn else pass
      formatStats(s"Persons that deceased are",
        s"$deceasedFlagTrueCount (${"%3.2f".format(percent)}%) $passOrFail")
    }

    /**
      * All patients should have at least one encounter
      *
      * @param personMaster      the DF of the person master data
      * @param personsActivities the activity records for a customer
      * @param statsWriter       instance of utility class for writing stats out
      */
    def checkPatientForHavingAtLeastOneEncounter(personMaster: Dataset[Person],
                                                 totalPersons: Long) {

      val patientSourceTypes = Seq("HOSPITAL", "PRACTICE", "PHYSICIAN OFFICE", "PATIENTADMIN")

      val allPatientsFromPersonMaster = personMaster.where(col("personType").contains(PersonTypePatient))

      // filter down to the activities we care about
      val patientsWithNoEncountersCount = allPatientsFromPersonMaster
        .filter(activity => activity.activities.map(_.activityType).contains(EncounterActivityType)
          && !activity.activities.map(_.sourceType).contains(patientSourceTypes)).count()

      val percent = calculatePercentage(patientsWithNoEncountersCount, totalPersons)

      formatStats(s"All patients who do not have at least one encounter", s"$patientsWithNoEncountersCount " +
        s"(${"%3.2f".format(percent)}%) ${validateStatus(percent, "patientsWithNoEncounters")}")

    }

    /**
      * Date of birth should not be a future date
      *
      * @param personMaster the DF of the person master data
      * @param statsWriter  instance of utility class for writing stats out
      */
    def checkForValidDateOfBirth(personMaster: Dataset[Person], totalPersons: Long): Unit = {
      val futureCount = personMaster.select("dateOfBirth")
        .where("dateOfBirth is not null")
        .filter(r => r.getAs[Date]("dateOfBirth").after(Today.toDate))
        .count()

      val percent = calculatePercentage(futureCount, totalPersons)

      formatStats(s"Date of birth should not be a future date.", s"$futureCount " +
        s"(${"%3.2f".format(percent)}%) ${validateCountNulls(percent, "dateOfBirth_future_date")}")


    }

    /**
      * Date of death should not be a future date
      *
      * @param personMaster the DF of the person master data
      * @param statsWriter  instance of utility class for writing stats out
      */
    def checkForValidDateOfDeath(personMaster: Dataset[Person], totalPersons: Long): Unit = {
      val futureCount = personMaster.select("dateOfDeath")
        .where("dateOfDeath is not null")
        .filter(r => r.getAs[Date]("dateOfDeath").after(Today.toDate))
        .count()

      val percent = calculatePercentage(futureCount, totalPersons)

      formatStats(s"Date of death should not be a future date.", s"$futureCount " +
        s"(${"%3.2f".format(percent)}%) ${validateCountNulls(percent, "dateOfDeath_future_date")}")
    }

    /**
      * Gathers counts for null OR Unknowns values by column
      *
      * @param personMasterDf the DF of the person master data
      * @param statsWriter    instance of utility class for writing stats out
      * @param totalPersons   the total number of persons in the presons table for a customer
      */
    def checkColumnsForNullOrUnknownValues(personMasterDf: Dataset[Person], columns: Seq[String],
                                           totalPersons: Long): Unit = {
      columns.foreach(c => {
        val nullsOrUnknowns = personMasterDf.where(s"$c is null")
        val nullCount = nullsOrUnknowns.count()
        val percentInvalid = calculatePercentage(nullCount, totalPersons)
        formatStats(s"$c is null OR Unknown", s"$nullCount (${"%3.2f".format(percentInvalid)}%)" +
          s" ${validateCountNulls(percentInvalid, c)}")
      })
    }

    /**
      * Primary Care Physician should be 10 Digits Or Blank/Null
      *
      * @param personMasterDf the DF of the person master data
      * @param statsWriter    instance of utility class for writing stats out
      * @param totalPersons   the total number of persons in the presons table for a customer
      */
    def checkPrimaryCarePhysicianContainsValidValues(personMasterDf: Dataset[Person],
                                                     totalPersons: Long): Unit = {

      val primaryCarePhysicianCount = personMasterDf.select("primaryCarePhysicianId").
        where(col("primaryCarePhysicianId").isNotNull && col("personType").contains(PersonTypePatient) &&
          length(col("primaryCarePhysicianId")) != 10).
        count()

      val percent = calculatePercentage(primaryCarePhysicianCount, totalPersons)
      val warnOrPass = if (primaryCarePhysicianCount == 100) warn else pass
      formatStats(s"Persons having invalid primary care physician",
        s"$primaryCarePhysicianCount $warnOrPass")
    }

    /**
      * When isChildPresent is true, one of the child bucket should have true value as the child should belongs
      * to any one of the children bucket.
      *
      * @param personMasterDf the DF of the person master data
      * @param statsWriter    instance of utility class for writing stats out
      * @param totalPersons   the total number of persons in the persons table for a customer
      */
    def checkAllChildrenAgeBucketsContainsValidValues(personMasterDf: Dataset[Person],
                                                      totalPersons: Long): Unit = {
      import personMasterDf.sqlContext.implicits._
      val invalidAgeBucketCount = personMasterDf.filter(
        $"isChildPresent" === true && $"hasChildZeroToThree" === false && $"hasChildFourToSix" === false &&
          $"hasChildSevenToNine" === false && $"hasChildTenToTwelve" === false && $"hasChildThirteenToFifteen" === false
          && $"hasChildSixteenToEighteen" === false
      ).count()

      val percent = calculatePercentage(invalidAgeBucketCount, totalPersons)
      formatStats(s"Persons having invalid age bucket ", s"$invalidAgeBucketCount " +
        s"(${"%3.2f".format(percent)}%) ${validateCountNulls(percent, "age_bucket")}")
    }

    /**
      * Children in Living Unit is > 0 where a child is present flag is true
      *
      * @param personMasterDf the DF of the person master data
      * @param statsWriter    instance of utility class for writing stats out
      * @param totalPersons   the total number of persons in the presons table for a customer
      */
    def checkChildrenInLivingUnitForPresentChildrenContainsValidValues(personMasterDf: Dataset[Person],

                                                                       totalPersons: Long): Unit = {
      import personMasterDf.sqlContext.implicits._
      val personWithPoC = personMasterDf.select("childrenInLivingUnit").where("isChildPresent = 'Y'")
      val childrenCount = personWithPoC
        .filter($"childrenInLivingUnit".<(0) || $"childrenInLivingUnit".===(0) || $"childrenInLivingUnit".isNull)
        .count()

      val percent = calculatePercentage(childrenCount, personWithPoC.count())

      formatStats(s"Persons having isChildPresent = 'Y' but No childrenInLivingUnit",
        s"$childrenCount (${"%3.2f".format(percent)}%) ${validateCountNulls(percent, "children_living_unit")}")
    }

    /**
      * gathers counts of null financialClass for patients
      *
      * @param personMaster     the DF of the person master data
      * @param statsWriter      instance of utility class for writing stats out
      * @param personTypeCounts the counts for each personType
      */
    def checkForAcceptedThresholdNullFinancialClass(personMaster: Dataset[Person],
                                                    personTypeCounts: List[(String, Long)]) {
      val nulls = personMaster.where(col("financialClass").isNull && col("personType").contains(PersonTypePatient))
      val nullCount = nulls.count()

      val totalPatients = personTypeCounts.find(p => p._1 != null && p._1.toUpperCase == PersonTypePatient) match {
        case Some((x: String, y: Long)) => y
        case _ => 0
      }

      val percentOfPatients = calculatePercentage(nullCount, totalPatients)

      // check the percentage of patients with the given inferred payer type to ensure its within appropriate ranges
      formatStats(s"financialClass is null for patients",
        s"$nullCount (${"%3.2f".format(percentOfPatients)}%) " +
          s"${validateCountNulls(percentOfPatients, "financialClass")}")
    }

    /**
      * Columns mapped from the latest encounter data where multiple different entries exist
      *
      * @param personMasterDf the DF of the person master data
      * @param statsWriter    instance of utility class for writing stats out
      */
    def checkMappingsBetweenEncounterDataAndPersonMaster(personMasterDf: Dataset[Person],
                                                         columns: Seq[String], totalPersons: Long): Unit = {

      import personMasterDf.sqlContext.implicits._
      val personMasterDs = personMasterDf
        .select(personMasterDf.columns.map(colName => col(colName).as(Inflector.camelize(colName))): _*)
        .as[Person]

      val personActivityGrouped = personMasterDf
        .rdd.groupBy(a => a.activities.map(_.personId))

      val listOfActivities = personActivityGrouped.map(_._2.toSeq)

      val sortedActivities: RDD[Seq[Person]] = listOfActivities.map(row =>
        row.sortWith((a: Person, b: Person) => {
          val dischargeDateListA = a.activities.filter(x => x.dischargeDate.isDefined).map(_.dischargeDate.get)
          val dischargeDateListB = b.activities.filter(x => x.dischargeDate.isDefined).map(_.dischargeDate.get)
          if (dischargeDateListA.nonEmpty && dischargeDateListB.nonEmpty) {
            dischargeDateListA.head after dischargeDateListB.head
          }
          else false
        }))

      val sortedActivitiesTrimmed = sortedActivities.filter(x => x.nonEmpty).map(x => x.head).toDS()

      val joinedDs = personMasterDs.joinWith(sortedActivitiesTrimmed,
        personMasterDs("personId") === sortedActivitiesTrimmed("personId"))

      columns.foreach(c => {
        var count: Long = 0L
        c match {
          case "sex" => count = joinedDs.filter(row => row._1.sex != row._2.sex).count()
          case "employer" => joinedDs.filter(row => row._1.employer != row._2.employer).count()
          case "portalStatus" => joinedDs.filter(row => row._1.portalStatus != row._2.portalStatus).count()
          case "dateOfDeath" => joinedDs.filter(row => row._1.dateOfDeath != row._2.dateOfDeath).count()
          case "maritalStatus" => joinedDs.filter(row => row._1.maritalStatus != row._2.maritalStatus).count()
          case "race" => joinedDs.filter(row => row._1.race != row._2.race).count()
          case "householdIncome" => joinedDs.filter(row => row._1.householdIncome != row._2.householdIncome).count()
          case "emails" => joinedDs.filter(row => row._1.emails.toSet != row._2.emails.toSet).count()
          case _ => 1
        }
        val percent = calculatePercentage(count, totalPersons)
        val passOrFail = if (percent <= 1) pass else fail

        formatStats(s"Persons not having $c from the latest encounter data where multiple " +
          s"different entries exist", s"$count (${"%3.2f".format(percent)}%) $passOrFail")
      })
    }

    /**
      * columns should be greater than 0
      *
      * @param personMasterDf the DF of the person master data
      * @param statsWriter    instance of utility class for writing stats out
      * @param totalPersons   the total number of persons in the presons table for a customer
      */
    def checkColumnsForNonNullAndGreaterThanZero(personMasterDf: Dataset[Person],
                                                 totalPersons: Long, columns: Seq[String]): Unit = {
      columns.foreach(row => {
        val personMasterColumn = personMasterDf.select(s"$row").where(s"$row is not null")

        val count = row match {
          case "homeLandValue" => personMasterColumn.filter(row => row.getAs[Float]("homeLandValue").<(0f) ||
            row.getAs[Float]("homeLandValue").==(0f)).count()
          case "homeYearBuilt" => personMasterColumn.filter(
            row => row.getAs[Int]("homeYearBuilt").<(0) || row.getAs[Int]("homeYearBuilt").==(0)).count()
          case "lengthOfResidence" => personMasterColumn.filter(
            row => row.getAs[Int]("lengthOfResidence").<(0)).count()
        }
        val percent = calculatePercentage(count, totalPersons)
        val passOrFail = if (percent <= 1) pass else fail

        formatStats(s"Persons having $row < 0 are ", s"$count (${"%3.2f".format(percent)}%) $passOrFail ")
      }
      )
    }

    /**
      * occupation is populated with accepted values
      *
      * @param personMasterDf the DF of the person master data
      * @param statsWriter    instance of utility class for writing stats out
      * @param totalPersons   the total number of persons in the presons table for a customer
      */
    def checkOccupationContainsValidValues(personMasterDf: Dataset[Person],
                                           totalPersons: Long): Unit = {
      val count = personMasterDf.select("occupation").where("occupation is not null").
        filter(row => Integer.parseInt(row.getAs[String]("occupation")).>(54) ||
          Integer.parseInt(row.getAs[String]("occupation")).<(0)).count()

      val passOrFail = if (count <= 1) pass else fail
      formatStats(s"Persons having invalid occupation are", s"$count $passOrFail ")
    }

    /**
      * calculates percentage
      *
      * @param valueCount numerator of the fraction
      * @param totalCount denominator of the franction
      */
    def calculatePercentage(valueCount: Long, totalCount: Long): Double = {
      val percent: Double = if (totalCount > 0) {
        (valueCount.toFloat / totalCount.toFloat) * 100.0
      }
      else {
        0.0
      }
      percent
    }

    /**
      * validate status for the input columns based on the given thresholdValues
      *
      * @param percent input percenatage value
      * @param column  name of the column
      */
    def validateStatus(percent: Double, column: String) = {

      val warnCount = thresholdValues.getOrElse(s"${column + "Warn"}", 0.0)
      val failCount = thresholdValues.getOrElse(s"${column + "Fail"}", 0.0)

      if (percent < failCount) {
        fail
      } else if (percent < warnCount) {
        warn
      } else {
        pass
      }
    }

    /**
      * validate status for the input columns based on the given thresholdValues for the null value counts
      *
      * @param percent input percenatage value
      * @param column  name of the column
      */
    def validateCountNulls(percent: Double, column: String) = {

      val warnCount = thresholdValues.getOrElse(s"${column + "_warn"}", 0.0)
      val failCount = thresholdValues.getOrElse(s"${column + "_fail"}", 0.0)

      if (percent > failCount) {
        fail
      } else if (percent > warnCount) {
        warn
      } else {
        pass
      }
    }

  }

  override def countInputRecords = {
    personsCount
  }

  override def countOutputRecords = {
    personsCount
  }

  override def buildConfig(appConfig: Config, lookupsClient: LookupsClient): CheckHealthConfig = {
    CheckHealthConfig(appConfig)
  }

}

