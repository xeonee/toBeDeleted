package com.influencehealth.edh.utils

import java.lang.reflect.Type

import com.google.gson._

object SerializationUtils {

  val gson = new GsonBuilder()
    .serializeNulls()
    .registerTypeHierarchyAdapter(classOf[Option[String]], new StringOptionDeSerializer)
    .registerTypeHierarchyAdapter(classOf[Option[String]], new StringOptionSerializer)
    .create()
}

class StringOptionSerializer extends JsonSerializer[Option[String]] {
  override def serialize(src: Option[String], typeOfSrc: Type, context: JsonSerializationContext): JsonElement = {
    src match {
      case None => JsonNull.INSTANCE
      case Some(v) => context.serialize(v)
    }
  }
}

class StringOptionDeSerializer extends JsonDeserializer[Option[String]] {
  override def deserialize(
                            jsonElement: JsonElement,
                            typeOfOutput: Type,
                            context: JsonDeserializationContext
                          ): Option[String] = {
    if(jsonElement.isJsonNull){
      None
    } else {
      Option(jsonElement.getAsString)
    }
  }
}
