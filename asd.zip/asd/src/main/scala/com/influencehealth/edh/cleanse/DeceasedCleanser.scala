package com.influencehealth.edh.cleanse

import com.influencehealth.edh.{Constants}
import com.influencehealth.edh.model.activitytype.ActivityType
import com.influencehealth.edh.utils.{CleanseUtils, PersonUtils}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._

class DeceasedCleanser(val dateBatchReceived: String) extends DataCleanser {

  this: ActivityType =>

  val DateFormat = "MMddyyyy"

  override def cleanseData(
                            df: DataFrame,
                            customer: Option[String],
                            batchId: String
                          ): (DataFrame, DataFrame) = {

    // Apply default values for Required Columns if found NULL
    val defaultCodeForRequiredColumnsContainingNulls = assignDefaultValuesForRequiredColumnsContainingNulls(df)

    // filters required columns that are not null
    val (dataFrameContainingNonNullColumns, dataFrameContainingNullColumns) =
      filterRequiredColumnsContainingInvalidValues(
        defaultCodeForRequiredColumnsContainingNulls, nullColumnNames, mandatoryContactColumnsNames)

    // cleanses & filters Date column
    val dataFrameContainingValidDateColumns = formatDateColumns(dataFrameContainingNonNullColumns)

    // Cleanses String Column
    val dataFrameContainingCleansedStringColumns = cleanseStringColumns(dataFrameContainingValidDateColumns, cleanseStringColumnNames)

    // Aliases Data
    val aliasedData = aliasData(dataFrameContainingCleansedStringColumns, customer)

    (aliasedData, dataFrameContainingNullColumns)
  }

  override def formatDateColumns(df: DataFrame): DataFrame = {

    // Convert string date into Date type columns after validating the dates, known behavior
    val formattedDatesDataFrame = df
      .withColumn("dateOfBirth", CleanseUtils.timestamp_to_date(PersonUtils.validateInputDate(
        date_format(unix_timestamp(df("dateOfBirth"), DateFormat).cast("timestamp"), "yyyy-MM-dd"))))
      .withColumn("dateOfDeath", CleanseUtils.timestamp_to_date(PersonUtils.validateInputDate(
        date_format(unix_timestamp(df("dateOfDeath"), DateFormat).cast("timestamp"), "yyyy-MM-dd"))))

    formattedDatesDataFrame
  }


  override def cleanseStringColumns(df: DataFrame, stringColumnsToBeCleansed: Seq[String]): DataFrame = {
    stringColumnsToBeCleansed.foldLeft(df)((curr, n) => curr.withColumn(n, CleanseUtils.cleanseStringColumns(curr(n))))
  }

  override def assignDefaultValuesForRequiredColumnsContainingNulls(df: DataFrame): DataFrame = {
    df.withColumn("sourceRecordId", col("socialSecurity")).
      withColumn("source", lit(defaultSource)).
      withColumn("sourceType", lit(defaultSourceType)).
      withColumn("addressType", lit(defaultAddressType))
  }

  /** Alias Data
    *
    * @param df
    * @param customer
    * @return dataFrame with alias
    * */
  override def aliasData(df: DataFrame, customer: Option[String]): DataFrame = {

    df.
      withColumn("activityDate", lit(Constants.Today.toString)).
      withColumn("dateCreated", lit(Constants.Now.toString)).
      withColumn("dateModified", col("dateCreated")).
      withColumn("activityType", df("sourceType")).
      withColumn("customer", lit(customer.get))
  }

  val stringify: UserDefinedFunction = udf((vs: Seq[String]) =>
    s"""[${vs.mkString(",").replace("null,", "").replace("null", "")}]""")


}
