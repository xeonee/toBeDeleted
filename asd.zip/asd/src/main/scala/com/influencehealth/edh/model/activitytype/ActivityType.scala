package com.influencehealth.edh.model.activitytype

trait ActivityType {

  val formatType: String

  val defaultSource: String
  val defaultMessageType: String
  val defaultSourceType: String
  val defaultAddressType: String
  val defaultActivityType: String
  val defaultPersonType: String

  val cleanseStringColumnNames: Seq[String]

  val nullColumnNames: Seq[String]

  val zipColumnNames: Seq[String]

  val mandatoryContactColumnsNames: Seq[String]

  // val contactDetailsColumns: Seq[String]

  val ValidBooleanType = Seq("Y", "N")
  val ValidPatientType = Seq("I", "O")
  val ValidERPatientType = Seq("E", "N")
  val ValidDxPxVersionType = Seq("9", "10")
  val ValidCptVersionType = Seq("C", "H")

  val RemoveMeFilter = "REMOVE_ME"
  val SourceExclusionFlagDefault = "N"
  val SourcePatientTypeDefault = "OUTPATIENT"
  val SourceErPatientDefault = "N"
  val SourceExclusionFlagIdentifier = "EXCLUSION"
  val SourcePatientTypeIdentifier = "SOURCE_PATIENT_TYPE"
  val SourceErPatientIdentifier = "SOURCE_ER_PATIENT"

}
