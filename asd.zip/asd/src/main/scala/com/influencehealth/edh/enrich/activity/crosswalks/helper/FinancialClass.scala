package com.influencehealth.edh.enrich.activity.crosswalks.helper

import com.influencehealth.edh.lookup_clients._

case class FinancialClass(
                           customer: String,
                           source: String,
                           sourceType: String,
                           locationId: Option[Int],
                           financialClassIdOrig: String,
                           financialClassOrig: Option[String],
                           financialClassId: Int,
                           financialClass: String,
                           payerType: String,
                           profitProxy: Option[Double],
                           costProxy: Option[Double],
                           revenueProxy: Option[Double],
                           contributionMarginProxy: Option[Double]
                         ) extends Serializable

object FinancialClass {

  val Default = "default"
  val Optimum = "OPTIMUM"
  val Meditech = "Meditech"
  val Hospital = "hospital"
  val Allscripts = "ALLSCRIPTS"
  val SEM = "SEM"
  val practice = "practice"
  val McKessonSeries = "McKesson Series"
  val PK = "pk"

  // TODO: Make everything matchup with original file
  val financialClassCwOrig: Seq[FinancialClass] = Seq(
    FinancialClass(Default, Default, Default, None, "9010", None, 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass(Default, Default, Default, None, "9020", None, 9020, financialClassLookup(9020), "PK", Some(0.05), None, None, None),
    FinancialClass(Default, Default, Default, None, "9030", None, 9030, financialClassLookup(9030), "PK", Some(0.05), None, None, None),
    FinancialClass(Default, Default, Default, None, "9100", None, 9100, financialClassLookup(9100), "nk", Some(0.05), None, None, None),
    FinancialClass(Default, Default, Default, None, "9150", None, 9150, financialClassLookup(9150), "nk", Some(0.05), None, None, None),
    FinancialClass(Default, Default, Default, None, "9200", None, 9200, financialClassLookup(9200), "mk", Some(0.05), None, None, None),
    FinancialClass(Default, Default, Default, None, "9250", None, 9250, financialClassLookup(9250), "mk", Some(0.05), None, None, None),
    FinancialClass(Default, Default, Default, None, "9300", None, 9300, financialClassLookup(9300), "nk", Some(0.05), None, None, None),
    FinancialClass(Default, Default, Default, None, "9310", None, 9310, financialClassLookup(9310), "nk", Some(0.05), None, None, None),
    FinancialClass(Default, Default, Default, None, "9320", None, 9320, financialClassLookup(9320), "nk", Some(0.05), None, None, None),
    FinancialClass(Default, Default, Default, None, "9330", None, 9330, financialClassLookup(9330), "nk", Some(0.05), None, None, None),
    FinancialClass(Default, Default, Default, None, "9340", None, 9340, financialClassLookup(9340), "nk", Some(0.05), None, None, None),
    FinancialClass(Default, Default, Default, None, "9350", None, 9350, financialClassLookup(9350), "PK", Some(0.05), None, None, None),
    FinancialClass("athens", Optimum, Hospital, None, "W", Some("WORKERS COMP"), 9350, financialClassLookup(9350), "PK", Some(0.05), None, None, None),
    FinancialClass("athens", Optimum, Hospital, None, "N", Some("MEDICARE ADVANTAGE"), 9250, financialClassLookup(9250), "mk", Some(0.05), None, None, None),
    FinancialClass("athens", Optimum, Hospital, None, "H", Some("HEALTH PLAN SELECT"), 9030, financialClassLookup(9030), "PK", Some(0.05), None, None, None),
    FinancialClass("athens", Optimum, Hospital, None, "B", Some("BLUE CROSS"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("athens", Optimum, Hospital, None, "U", Some("INSTITUTIONAL"), 9300, financialClassLookup(9300), "nk", Some(0.05), None, None, None),
    FinancialClass("athens", Optimum, Hospital, None, "G", Some("UNITED HEALTHCARE"), 9030, financialClassLookup(9030), "PK", Some(0.05), None, None, None),
    FinancialClass("athens", Optimum, Hospital, None, "M", Some("MEDICARE"), 9200, financialClassLookup(9200), "mk", Some(0.05), None, None, None),
    FinancialClass("athens", Optimum, Hospital, None, "E", Some("MEDICAID CMO"), 9100, financialClassLookup(9100), "nk", Some(0.05), None, None, None),
    FinancialClass("athens", Optimum, Hospital, None, "C", Some("COMMERCIAL"), 9020, financialClassLookup(9020), "PK", Some(0.05), None, None, None),
    FinancialClass("athens", Optimum, Hospital, None, "X", Some("HOSPICE"), 9300, financialClassLookup(9300), "nk", Some(0.05), None, None, None),
    FinancialClass("athens", Optimum, Hospital, None, "F", Some("MANAGED CARE"), 9030, financialClassLookup(9030), "PK", Some(0.05), None, None, None),
    FinancialClass("athens", Optimum, Hospital, None, "S", Some("SELF PAY"), 9320, financialClassLookup(9320), "nk", Some(0.05), None, None, None),
    FinancialClass("athens", Optimum, Hospital, None, "T", Some("MILITARY"), 9330, financialClassLookup(9330), "nk", Some(0.05), None, None, None),
    FinancialClass("athens", Optimum, Hospital, None, "D", Some("MEDICAID"), 9100, financialClassLookup(9100), "nk", Some(0.05), None, None, None),
    FinancialClass("athens", Optimum, Hospital, None, "A", Some("AUTO"), 9300, financialClassLookup(9300), "nk", Some(0.05), None, None, None),
    FinancialClass("athens", Optimum, Hospital, None, "V", Some("VETERANS ADMIN"), 9330, financialClassLookup(9330), "nk", Some(0.05), None, None, None),
    FinancialClass("athens", Optimum, Hospital, None, "5", Some("ALTERNATIVE SERVICES"), 9300, financialClassLookup(9300), "nk", Some(0.05), None, None, None),
    FinancialClass("athens", Optimum, Hospital, None, "P", Some("MEDICARE PFFS"), 9200, financialClassLookup(9010), "mk", Some(0.05), None, None, None),
    FinancialClass("athens", Optimum, Hospital, None, "Y", Some("CLIENT BILLING"), 9300, financialClassLookup(9010), "nk", Some(0.05), None, None, None),
    FinancialClass("athens", Optimum, Hospital, None, "J", Some("COMMERCIAL"), 9020, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("hca", Meditech, Hospital, None, "1", Some("MEDICARE PPS"), 9200, financialClassLookup(9010), "MK", Some(0.05), None, None, None),
    FinancialClass("hca", Meditech, Hospital, None, "3", Some("MEDICAID"), 9100, financialClassLookup(9010), "NK", Some(0.05), None, None, None),
    FinancialClass("hca", Meditech, Hospital, None, "4", Some("WORKERS COMPENSATION"), 9350, financialClassLookup(9010), "NK", Some(0.05), None, None, None),
    FinancialClass("hca", Meditech, Hospital, None, "5", Some("COMMERCIAL"), 9020, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("hca", Meditech, Hospital, None, "6", Some("CHAMPUS"), 9330, financialClassLookup(9010), "NK", Some(0.05), None, None, None),
    FinancialClass("hca", Meditech, Hospital, None, "7", Some("HMO"), 9030, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("hca", Meditech, Hospital, None, "8", Some("PPO"), 9030, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("hca", Meditech, Hospital, None, "9", Some("MANAGED CARE MEDICAID"), 9150, financialClassLookup(9010), "NK", Some(0.05), None, None, None),
    FinancialClass("hca", Meditech, Hospital, None, "11", Some("STATE NON MCAID LOCL GOV"), 9100, financialClassLookup(9010), "NK", Some(0.05), None, None, None),
    FinancialClass("hca", Meditech, Hospital, None, "12", Some("MANAGED CARE MEDICARE"), 9250, financialClassLookup(9010), "MK", Some(0.05), None, None, None),
    FinancialClass("hca", Meditech, Hospital, None, "14", Some("HIX"), 9300, financialClassLookup(9010), "NK", Some(0.05), None, None, None),
    FinancialClass("hca", Meditech, Hospital, None, "15", Some("CHARITY"), 9340, financialClassLookup(9010), "NK", Some(0.05), None, None, None),
    FinancialClass("hca", Meditech, Hospital, None, "99", Some("SELF PAY"), 9320, financialClassLookup(9010), "NK", Some(0.05), None, None, None),
    FinancialClass("hca", Meditech, Hospital, None, "2", Some("MEDICARE DPU"), 9200, financialClassLookup(9010), "MK", Some(0.05), None, None, None),
    FinancialClass("hca", Meditech, Hospital, None, "10", Some("FEDERAL"), 9310, financialClassLookup(9010), "NK", Some(0.05), None, None, None),
    FinancialClass("hca", Meditech, Hospital, None, "13", Some("BLUE CROSS COST BASED"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("hca", Meditech, Hospital, None, "01", Some("MEDICARE PPS"), 9200, financialClassLookup(9010), "MK", Some(0.05), None, None, None),
    FinancialClass("hca", Meditech, Hospital, None, "02", Some("MEDICARE DPU"), 9200, financialClassLookup(9010), "MK", Some(0.05), None, None, None),
    FinancialClass("hca", Meditech, Hospital, None, "03", Some("MEDICAID"), 9100, financialClassLookup(9010), "NK", Some(0.05), None, None, None),
    FinancialClass("hca", Meditech, Hospital, None, "04", Some("WORKERS COMPENSATION"), 9350, financialClassLookup(9010), "NK", Some(0.05), None, None, None),
    FinancialClass("hca", Meditech, Hospital, None, "05", Some("COMMERCIAL"), 9020, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("hca", Meditech, Hospital, None, "06", Some("CHAMPUS"), 9330, financialClassLookup(9010), "NK", Some(0.05), None, None, None),
    FinancialClass("hca", Meditech, Hospital, None, "07", Some("HMO"), 9030, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("hca", Meditech, Hospital, None, "08", Some("PPO"), 9030, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("hca", Meditech, Hospital, None, "09", Some("MANAGED CARE MEDICAID"), 9150, financialClassLookup(9010), "NK", Some(0.05), None, None, None),
    FinancialClass("chomp", Allscripts, Hospital, None, "4", Some("CHOMP CARE"), 9320, financialClassLookup(9010), "NK", Some(-0.07), Some(0), Some(0), Some(0)),
    FinancialClass("chomp", Allscripts, Hospital, None, "91", Some("COMM DISCOUNT"), 9300, financialClassLookup(9010), "PK", Some(0.74), Some(0), Some(0), Some(0)),
    FinancialClass("chomp", Allscripts, Hospital, None, "8", Some("COMMERCIAL"), 9020, financialClassLookup(9010), "PK", Some(0.82), Some(0), Some(0), Some(0)),
    FinancialClass("chomp", Allscripts, Hospital, None, "14", Some("HMO"), 9030, financialClassLookup(9010), "PK", Some(0.88), Some(0), Some(0), Some(0)),
    FinancialClass("chomp", Allscripts, Hospital, None, "6", Some("MEDI - CAL"), 9100, financialClassLookup(9010), "PK", Some(0.07), Some(0), Some(0), Some(0)),
    FinancialClass("chomp", Allscripts, Hospital, None, "5", Some("MEDICARE"), 9200, financialClassLookup(9010), "MK", Some(0.06), Some(0), Some(0), Some(0)),
    FinancialClass("chomp", Allscripts, Hospital, None, "15", Some("MEDICARE MNGD CARE"), 9200, financialClassLookup(9010), "MK", Some(0.07), Some(0), Some(0), Some(0)),
    FinancialClass("chomp", Allscripts, Hospital, None, "7", Some("MILITARY"), 9330, financialClassLookup(9010), "NK", Some(0.05), Some(0), Some(0), Some(0)),
    FinancialClass("chomp", Allscripts, Hospital, None, "1", Some("SELFPAY"), 9320, financialClassLookup(9010), "NK", Some(0.03), Some(0), Some(0), Some(0)),
    FinancialClass("chomp", Allscripts, Hospital, None, "10", Some("VETERANS ADMIN"), 9330, financialClassLookup(9010), "NK", Some(0.08), Some(0), Some(0), Some(0)),
    FinancialClass("chomp", Allscripts, Hospital, None, "9", Some("WORK COMP"), 9350, financialClassLookup(9010), "PK", Some(0.12), Some(0), Some(0), Some(0)),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "Y", Some("EMPLOYEE"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "1", Some("WORKERS' COMP"), 9350, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "3", Some("PENDING MEDICAID"), 9100, financialClassLookup(9010), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "6", Some("MM MEDICARE SKILLED"), 9200, financialClassLookup(9010), "MK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "9", Some("MEDICAID OUT STATE"), 9100, financialClassLookup(9010), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "A", Some("MM OP PART B"), 9250, financialClassLookup(9250), "MK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "B", Some("BLUE CROSS"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "C", Some("COVENTRY - MEDICAID"), 9100, financialClassLookup(9100), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "D", Some("UHC MEDICAID"), 9100, financialClassLookup(9100), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "E", Some("MA - ADVANTRA"), 9150, financialClassLookup(9150), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "F", Some("MA - HUMANA"), 9150, financialClassLookup(9150), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "G", Some("PT ATTORNEY IN LITIG"), 9300, financialClassLookup(9300), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "H", Some("MA - OTHER"), 9100, financialClassLookup(9100), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "I", Some("MM MEDICARE REPLACE"), 9200, financialClassLookup(9200), "MK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "M", Some("MEDICARE"), 9200, financialClassLookup(9200), "MK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "N", Some("NURSING HOME"), 9300, financialClassLookup(9300), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "O", Some("MISC.COMMERCIAL"), 9020, financialClassLookup(9020), "PK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "P", Some("ARBOR HLTH MEDICAID"), 9100, financialClassLookup(9100), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "Q", Some("UHC"), 9030, financialClassLookup(9030), "PK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "S", Some("SELF PAY HOSPITAL"), 9320, financialClassLookup(9320), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "T", Some("MIDLANDS CHOICE"), 9030, financialClassLookup(9030), "PK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "U", Some("TRICARE"), 9330, financialClassLookup(9330), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "V", Some("PT BAL AFTER INS"), 9300, financialClassLookup(9300), "UU", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "W", Some("MEDICAID"), 9100, financialClassLookup(9100), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "X", Some("COVENTRY / PRINCIPAL"), 9200, financialClassLookup(9200), "MK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "8", Some("MEDICARE - NO PART A"), 9200, financialClassLookup(9200), "MK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "4", Some("SELF - PAY MED OP"), 9320, financialClassLookup(9320), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "J", Some("MA - SECURE HORIZON"), 9250, financialClassLookup(9250), "MK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "L", Some("MA - MEDICARE BLUE"), 9200, financialClassLookup(9200), "MK", Some(0.05), None, None, None),
    FinancialClass("fremont", McKessonSeries, Hospital, None, "K", Some("MEDICARE - NO PART B"), 9200, financialClassLookup(9200), "MK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "6", Some("United Health Care"), 9030, financialClassLookup(9030), "PK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "3", Some("Medicaid"), 9100, financialClassLookup(9100), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "5", Some("Coventry Health Care"), 9200, financialClassLookup(9200), "MK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "2", Some("BCBS"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "12", Some("Auto Insurance"), 9300, financialClassLookup(9300), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "8", Some("other insurances"), 9300, financialClassLookup(9300), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "4", Some("Midlands Choice"), 9030, financialClassLookup(9030), "PK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "9", Some("Tricare"), 9330, financialClassLookup(9330), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "10", Some("SELF PAY"), 9320, financialClassLookup(9320), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "11", Some("Work Comp"), 9350, financialClassLookup(9350), "PK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "1", Some("Medicare"), 9200, financialClassLookup(9200), "MK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "13", Some("Nursing Homes"), 9300, financialClassLookup(9300), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "14", Some("The Benefit Group"), 9300, financialClassLookup(9300), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "6", Some("United Health Care"), 9030, financialClassLookup(9030), "PK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "3", Some("Medicaid"), 9100, financialClassLookup(9100), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "5", Some("Coventry Health Care"), 9200, financialClassLookup(9200), "MK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "2", Some("BCBS"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "12", Some("Auto Insurance"), 9300, financialClassLookup(9300), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "8", Some("other insurances"), 9300, financialClassLookup(9300), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "4", Some("Midlands Choice"), 9030, financialClassLookup(9030), "PK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "9", Some("Tricare"), 9330, financialClassLookup(9330), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "10", Some("SELF PAY"), 9320, financialClassLookup(9320), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "11", Some("Work Comp"), 9350, financialClassLookup(9350), "PK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "1", Some("Medicare"), 9200, financialClassLookup(9200), "MK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "13", Some("Nursing Homes"), 9300, financialClassLookup(9300), "NK", Some(0.05), None, None, None),
    FinancialClass("fremont", "ECW", Hospital, None, "14", Some("The Benefit Group"), 9300, financialClassLookup(9300), "NK", Some(0.05), None, None, None),
    FinancialClass("archildrens", Default, Default, None, "", Some("COMMERCIAL"), 9020, financialClassLookup(9020), "PK", Some(0.05), None, None, None),
    FinancialClass("archildrens", Default, Default, None, "C", Some("COMMERCIAL"), 9020, financialClassLookup(9020), "PK", Some(0.05), None, None, None),
    FinancialClass("archildrens", Default, Default, None, "J", Some("COMMERCIAL"), 9020, financialClassLookup(9020), "PK", Some(0.05), None, None, None),
    FinancialClass("archildrens", Default, Default, None, "5", Some("COMMERCIAL"), 9020, financialClassLookup(9020), "PK", Some(0.05), None, None, None),
    FinancialClass("archildrens", Default, Default, None, "05", Some("COMMERCIAL"), 9020, financialClassLookup(9020), "PK", Some(0.05), None, None, None),
    FinancialClass("archildrens", Default, Default, None, "", Some("MEDICAID"), 9100, financialClassLookup(9100), "nk", Some(0.05), None, None, None),
    FinancialClass("archildrens", Default, Default, None, "D", Some("MEDICAID"), 9100, financialClassLookup(9100), "nk", Some(0.05), None, None, None),
    FinancialClass("archildrens", Default, Default, None, "3", Some("MEDICAID"), 9100, financialClassLookup(9100), "nk", Some(0.05), None, None, None),
    FinancialClass("archildrens", Default, Default, None, "03", Some("MEDICAID"), 9100, financialClassLookup(9100), "nk", Some(0.05), None, None, None),
    FinancialClass("archildrens", Default, Default, None, "W", Some("MEDICAID"), 9100, financialClassLookup(9100), "nk", Some(0.05), None, None, None),
    FinancialClass("archildrens", Default, Default, None, "", Some("Other Government"), 9310, financialClassLookup(9310), "nk", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "FORES-A", Some("MEDICAID TOTAL"), 9100, financialClassLookup(9100), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "FORES-B", Some("BLUE CROSS"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "FORES-C", Some("WORKERS COMPENSATION"), 9350, financialClassLookup(9350), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "FORES-E", Some("EMPLOYEE, SELF, AND OTHER"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "FORES-G", Some("MANAGED CARE"), 9030, financialClassLookup(9030), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "FORES-I", Some("COMMERCIAL"), 9020, financialClassLookup(9020), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "FORES-J", Some("MEDICARE MANAGED TOTAL"), 9200, financialClassLookup(9200), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "FORES-M", Some("MEDICARE TOTAL"), 9200, financialClassLookup(9200), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "FORES-Q", Some("MEDICAID MANAGED TOTAL"), 9150, financialClassLookup(9150), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "FORES-S", Some("SELF PAY AND SLIDING SCALE"), 9320, financialClassLookup(9320), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "FORES-U", Some("CHAMPUS"), 9330, financialClassLookup(9330), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "GLENC-A", Some("MEDICAID TOTAL"), 9100, financialClassLookup(9100), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "GLENC-B", Some("BLUE CROSS"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "GLENC-C", Some("WORKERS COMPENSATION"), 9350, financialClassLookup(9350), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "GLENC-E", Some("EMPLOYEE, SELF, AND OTHER"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "GLENC-G", Some("MANAGED CARE"), 9030, financialClassLookup(9030), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "GLENC-I", Some("COMMERCIAL"), 9020, financialClassLookup(9020), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "GLENC-J", Some("MEDICARE MANAGED TOTAL"), 9200, financialClassLookup(9200), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "GLENC-M", Some("MEDICARE TOTAL"), 9200, financialClassLookup(9200), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "GLENC-Q", Some("MEDICAID MANAGED TOTAL"), 9150, financialClassLookup(9150), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "GLENC-S", Some("SELF PAY AND SLIDING SCALE"), 9320, financialClassLookup(9320), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "GLENC-U", Some("CHAMPUS"), 9330, financialClassLookup(9330), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "MANSY-A", Some("MEDICAID TOTAL"), 9100, financialClassLookup(9100), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "MANSY-B", Some("BLUE CROSS"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "MANSY-C", Some("WORKERS COMPENSATION"), 9350, financialClassLookup(9350), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "MANSY-E", Some("EMPLOYEE, SELF, AND OTHER"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "MANSY-G", Some("MANAGED CARE"), 9030, financialClassLookup(9030), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "MANSY-I", Some("COMMERCIAL"), 9020, financialClassLookup(9020), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "MANSY-J", Some("MEDICARE MANAGED TOTAL"), 9200, financialClassLookup(9200), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "MANSY-M", Some("MEDICARE TOTAL"), 9200, financialClassLookup(9200), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "MANSY-Q", Some("MEDICAID MANAGED TOTAL"), 9150, financialClassLookup(9150), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "MANSY-S", Some("SELF PAY AND SLIDING SCALE"), 9320, financialClassLookup(9320), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "MANSY-U", Some("CHAMPUS"), 9330, financialClassLookup(9330), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "PLAIN-A", Some("MEDICAID TOTAL"), 9100, financialClassLookup(9100), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "PLAIN-B", Some("BLUE CROSS"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "PLAIN-C", Some("WORKERS COMPENSATION"), 9350, financialClassLookup(9350), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "PLAIN-E", Some("EMPLOYEE, SELF, AND OTHER"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "PLAIN-G", Some("MANAGED CARE"), 9030, financialClassLookup(9030), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "PLAIN-I", Some("COMMERCIAL"), 9020, financialClassLookup(9020), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "PLAIN-J", Some("MEDICARE MANAGED TOTAL"), 9200, financialClassLookup(9200), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "PLAIN-M", Some("MEDICARE TOTAL"), 9200, financialClassLookup(9200), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "PLAIN-Q", Some("MEDICAID MANAGED TOTAL"), 9150, financialClassLookup(9150), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "PLAIN-S", Some("SELF PAY AND SLIDING SCALE"), 9320, financialClassLookup(9320), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "PLAIN-U", Some("CHAMPUS"), 9330, financialClassLookup(9330), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "SSID2-A", Some("MEDICAID TOTAL"), 9100, financialClassLookup(9100), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "SSID2-B", Some("BLUE CROSS"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "SSID2-C", Some("WORKERS COMPENSATION"), 9350, financialClassLookup(9350), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "SSID2-E", Some("EMPLOYEE, SELF, AND OTHER"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "SSID2-G", Some("MANAGED CARE"), 9030, financialClassLookup(9030), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "SSID2-I", Some("COMMERCIAL"), 9020, financialClassLookup(9020), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "SSID2-J", Some("MEDICARE MANAGED TOTAL"), 9200, financialClassLookup(9200), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "SSID2-M", Some("MEDICARE TOTAL"), 9200, financialClassLookup(9200), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "SSID2-Q", Some("MEDICAID MANAGED TOTAL"), 9150, financialClassLookup(9150), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "SSID2-S", Some("SELF PAY AND SLIDING SCALE"), 9320, financialClassLookup(9320), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "SSID2-U", Some("CHAMPUS"), 9330, financialClassLookup(9330), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "SSIUH-A", Some("MEDICAID TOTAL"), 9100, financialClassLookup(9100), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "SSIUH-B", Some("BLUE CROSS"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "SSIUH-C", Some("WORKERS COMPENSATION"), 9350, financialClassLookup(9350), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "SSIUH-E", Some("EMPLOYEE, SELF, AND OTHER"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "SSIUH-G", Some("MANAGED CARE"), 9030, financialClassLookup(9030), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "SSIUH-I", Some("COMMERCIAL"), 9020, financialClassLookup(9020), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "SSIUH-J", Some("MEDICARE MANAGED TOTAL"), 9200, financialClassLookup(9200), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "SSIUH-M", Some("MEDICARE TOTAL"), 9200, financialClassLookup(9200), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "SSIUH-Q", Some("MEDICAID MANAGED TOTAL"), 9150, financialClassLookup(9150), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "SSIUH-S", Some("SELF PAY AND SLIDING SCALE"), 9320, financialClassLookup(9320), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", Allscripts, practice, None, "SSIUH-U", Some("CHAMPUS"), 9330, financialClassLookup(9330), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital , None, "FORES-A", Some("MEDICAID TOTAL"), 9100, financialClassLookup(9100), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "FORES-B", Some("BLUE CROSS"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "FORES-C", Some("WORKERS COMPENSATION"), 9350, financialClassLookup(9350), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "FORES-E", Some("EMPLOYEE, SELF, AND OTHER"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "FORES-G", Some("MANAGED CARE"), 9030, financialClassLookup(9030), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "FORES-I", Some("COMMERCIAL"), 9020, financialClassLookup(9020), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "FORES-J", Some("MEDICARE MANAGED TOTAL"), 9200, financialClassLookup(9200), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "FORES-M", Some("MEDICARE TOTAL"), 9200, financialClassLookup(9200), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "FORES-Q", Some("MEDICAID MANAGED TOTAL"), 9150, financialClassLookup(9150), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "FORES-S", Some("SELF PAY AND SLIDING SCALE"), 9320, financialClassLookup(9320), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "FORES-U", Some("CHAMPUS"), 9330, financialClassLookup(9330), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "GLENC-A", Some("MEDICAID TOTAL"), 9100, financialClassLookup(9100), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "GLENC-B", Some("BLUE CROSS"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "GLENC-C", Some("WORKERS COMPENSATION"), 9350, financialClassLookup(9350), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "GLENC-E", Some("EMPLOYEE, SELF, AND OTHER"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "GLENC-G", Some("MANAGED CARE"), 9030, financialClassLookup(9030), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "GLENC-I", Some("COMMERCIAL"), 9020, financialClassLookup(9020), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "GLENC-J", Some("MEDICARE MANAGED TOTAL"), 9200, financialClassLookup(9200), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "GLENC-M", Some("MEDICARE TOTAL"), 9200, financialClassLookup(9200), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "GLENC-Q", Some("MEDICAID MANAGED TOTAL"), 9150, financialClassLookup(9150), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "GLENC-S", Some("SELF PAY AND SLIDING SCALE"), 9320, financialClassLookup(9320), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "GLENC-U", Some("CHAMPUS"), 9330, financialClassLookup(9330), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "MANSY-A", Some("MEDICAID TOTAL"), 9100, financialClassLookup(9100), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "MANSY-B", Some("BLUE CROSS"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "MANSY-C", Some("WORKERS COMPENSATION"), 9350, financialClassLookup(9350), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "MANSY-E", Some("EMPLOYEE, SELF, AND OTHER"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "MANSY-G", Some("MANAGED CARE"), 9030, financialClassLookup(9030), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "MANSY-I", Some("COMMERCIAL"), 9020, financialClassLookup(9020), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "MANSY-J", Some("MEDICARE MANAGED TOTAL"), 9200, financialClassLookup(9200), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "MANSY-M", Some("MEDICARE TOTAL"), 9200, financialClassLookup(9200), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "MANSY-Q", Some("MEDICAID MANAGED TOTAL"), 9150, financialClassLookup(9150), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "MANSY-S", Some("SELF PAY AND SLIDING SCALE"), 9320, financialClassLookup(9320), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "MANSY-U", Some("CHAMPUS"), 9330, financialClassLookup(9330), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "PLAIN-A", Some("MEDICAID TOTAL"), 9100, financialClassLookup(9100), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "PLAIN-B", Some("BLUE CROSS"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "PLAIN-C", Some("WORKERS COMPENSATION"), 9350, financialClassLookup(9350), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "PLAIN-E", Some("EMPLOYEE, SELF, AND OTHER"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "PLAIN-G", Some("MANAGED CARE"), 9030, financialClassLookup(9030), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "PLAIN-I", Some("COMMERCIAL"), 9020, financialClassLookup(9020), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "PLAIN-J", Some("MEDICARE MANAGED TOTAL"), 9200, financialClassLookup(9200), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "PLAIN-M", Some("MEDICARE TOTAL"), 9200, financialClassLookup(9200), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "PLAIN-Q", Some("MEDICAID MANAGED TOTAL"), 9150, financialClassLookup(9150), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "PLAIN-S", Some("SELF PAY AND SLIDING SCALE"), 9320, financialClassLookup(9320), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "PLAIN-U", Some("CHAMPUS"), 9330, financialClassLookup(9330), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "SSID2-A", Some("MEDICAID TOTAL"), 9100, financialClassLookup(9100), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "SSID2-B", Some("BLUE CROSS"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "SSID2-C", Some("WORKERS COMPENSATION"), 9350, financialClassLookup(9350), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "SSID2-E", Some("EMPLOYEE, SELF, AND OTHER"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "SSID2-G", Some("MANAGED CARE"), 9030, financialClassLookup(9030), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "SSID2-I", Some("COMMERCIAL"), 9020, financialClassLookup(9020), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "SSID2-J", Some("MEDICARE MANAGED TOTAL"), 9200, financialClassLookup(9200), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "SSID2-M", Some("MEDICARE TOTAL"), 9200, financialClassLookup(9200), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "SSID2-Q", Some("MEDICAID MANAGED TOTAL"), 9150, financialClassLookup(9150), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "SSID2-S", Some("SELF PAY AND SLIDING SCALE"), 9320, financialClassLookup(9320), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "SSID2-U", Some("CHAMPUS"), 9330, financialClassLookup(9330), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "SSIUH-A", Some("MEDICAID TOTAL"), 9100, financialClassLookup(9100), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "SSIUH-B", Some("BLUE CROSS"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "SSIUH-C", Some("WORKERS COMPENSATION"), 9350, financialClassLookup(9350), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "SSIUH-E", Some("EMPLOYEE, SELF, AND OTHER"), 9010, financialClassLookup(9010), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "SSIUH-G", Some("MANAGED CARE"), 9030, financialClassLookup(9030), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "SSIUH-I", Some("COMMERCIAL"), 9020, financialClassLookup(9020), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "SSIUH-J", Some("MEDICARE MANAGED TOTAL"), 9200, financialClassLookup(9200), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "SSIUH-M", Some("MEDICARE TOTAL"), 9200, financialClassLookup(9200), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "SSIUH-Q", Some("MEDICAID MANAGED TOTAL"), 9150, financialClassLookup(9150), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "SSIUH-S", Some("SELF PAY AND SLIDING SCALE"), 9320, financialClassLookup(9320), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell", SEM, Hospital, None, "SSIUH-U", Some("CHAMPUS"), 9330, financialClassLookup(9330), "PK", Some(0.05), None, None, None),
    FinancialClass("northwell",Allscripts,practice,None,"FORES-N",Some("NO FAULT"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),
    FinancialClass("northwell",Allscripts,practice,None,"GLENC-N",Some("NO FAULT"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),
    FinancialClass("northwell",Allscripts,practice,None,"MANSY-N",Some("NO FAULT"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),
    FinancialClass("northwell",Allscripts,practice,None,"PLAIN-N",Some("NO FAULT"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),
    FinancialClass("northwell",Allscripts,practice,None,"SSID2-N",Some("NO FAULT"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),
    FinancialClass("northwell",Allscripts,practice,None,"SSIUH-N",Some("NO FAULT"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),
    FinancialClass("northwell",SEM,Hospital,None,"FORES-N",Some("NO FAULT"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),
    FinancialClass("northwell",SEM,Hospital,None,"GLENC-N",Some("NO FAULT"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),
    FinancialClass("northwell",SEM,Hospital,None,"MANSY-N",Some("NO FAULT"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),
    FinancialClass("northwell",SEM,Hospital,None,"PLAIN-N",Some("NO FAULT"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),
    FinancialClass("northwell",SEM,Hospital,None,"SSID2-N",Some("NO FAULT"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),
    FinancialClass("northwell",SEM,Hospital,None,"SSIUH-N",Some("NO FAULT"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),
    FinancialClass("northwell",Allscripts,practice,None,"PLAIN-Z",Some("PAYOR NOT MAPPED"),9910,financialClassLookup(9910),"PK",Some(0.05),None,None,None),
    FinancialClass("northwell",Allscripts,practice,None,"SSIUH-Z",Some("PAYOR NOT MAPPED"),9910,financialClassLookup(9910),"PK",Some(0.05),None,None,None),
    FinancialClass("northwell",SEM,Hospital,None,"PLAIN-Z",Some("PAYOR NOT MAPPED"),9910,financialClassLookup(9910),"PK",Some(0.05),None,None,None),
    FinancialClass("northwell",SEM,Hospital,None,"SSIUH-Z",Some("PAYOR NOT MAPPED"),9910,financialClassLookup(9910),"PK",Some(0.05),None,None,None),
    FinancialClass("northwell",Allscripts,practice,None,"FORES-W",Some("SPECIAL INTEREST"),9910,financialClassLookup(9910),"PK",Some(0.05),None,None,None),
    FinancialClass("northwell",Allscripts,practice,None,"GLENC-W",Some("SPECIAL INTEREST"),9910,financialClassLookup(9910),"PK",Some(0.05),None,None,None),
    FinancialClass("northwell",Allscripts,practice,None,"MANSY-W",Some("SPECIAL INTEREST"),9910,financialClassLookup(9910),"PK",Some(0.05),None,None,None),
    FinancialClass("northwell",Allscripts,practice,None,"PLAIN-W",Some("SPECIAL INTEREST"),9910,financialClassLookup(9910),"PK",Some(0.05),None,None,None),
    FinancialClass("northwell",Allscripts,practice,None,"SSID2-W",Some("SPECIAL INTEREST"),9910,financialClassLookup(9910),"PK",Some(0.05),None,None,None),
    FinancialClass("northwell",Allscripts,practice,None,"SSIUH-W",Some("SPECIAL INTEREST"),9910,financialClassLookup(9910),"PK",Some(0.05),None,None,None),
    FinancialClass("northwell",SEM,Hospital,None,"FORES-W",Some("SPECIAL INTEREST"),9910,financialClassLookup(9910),"PK",Some(0.05),None,None,None),
    FinancialClass("northwell",SEM,Hospital,None,"GLENC-W",Some("SPECIAL INTEREST"),9910,financialClassLookup(9910),"PK",Some(0.05),None,None,None),
    FinancialClass("northwell",Allscripts,practice,None,"MANSY-U",Some("CHAMPUS"),9330,financialClassLookup(9330),"PK",Some(0.05),None,None,None),
    FinancialClass("northwell",SEM,Hospital,None,"PLAIN-W",Some("SPECIAL INTEREST"),9910,financialClassLookup(9910),"PK",Some(0.05),None,None,None),
    FinancialClass("northwell",Allscripts,practice,None,"MANSY-U",Some("CHAMPUS"),9330,financialClassLookup(9330),"PK",Some(0.05),None,None,None),
    FinancialClass("northwell",SEM,Hospital,None,"SSIUH-W",Some("SPECIAL INTEREST"),9910,financialClassLookup(9910),"PK",Some(0.05),None,None,None),
    FinancialClass("northwell",Allscripts,practice,None,"FORES-F",Some("NO CHARGE"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),
    FinancialClass("northwell",Allscripts,practice,None,"GLENC-F",Some("NO CHARGE"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),
    FinancialClass("northwell",Allscripts,practice,None,"MANSY-F",Some("NO CHARGE"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),
    FinancialClass("northwell",Allscripts,practice,None,"PLAIN-F",Some("NO CHARGE"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),
    FinancialClass("northwell",Allscripts,practice,None,"SSID2-F",Some("NO CHARGE"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),
    FinancialClass("northwell",SEM,Hospital,None,"FORES-F",Some("NO CHARGE"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),
    FinancialClass("northwell",SEM,Hospital,None,"GLENC-F",Some("NO CHARGE"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),
    FinancialClass("northwell",SEM,Hospital,None,"MANSY-F",Some("NO CHARGE"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),
    FinancialClass("northwell",SEM,Hospital,None,"PLAIN-F",Some("NO CHARGE"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),
    FinancialClass("northwell",SEM,Hospital,None,"SSID2-F",Some("NO CHARGE"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),
    FinancialClass("northwell",Allscripts,practice,None,"FORES-M",Some("MEDICARE TOTAL"),9200,financialClassLookup(9200),"PK",Some(0.05),None,None,None),
    FinancialClass("northwell",Allscripts,practice,None,"PLAIN-0",Some("NO CHARGE"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),
    FinancialClass("northwell",Allscripts,practice,None,"SSIUH-0",Some("NO CHARGE"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),
    FinancialClass("northwell",SEM,Hospital,None,"MANSY-0",Some("NO CHARGE"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),
    FinancialClass("northwell",Allscripts,practice,None,"MANSY-U",Some("CHAMPUS"),9330,financialClassLookup(9330),"PK",Some(0.05),None,None,None),
    FinancialClass("northwell",SEM,Hospital,None,"SSIUH-0",Some("NO CHARGE"),9920,financialClassLookup(9920),"NK",Some(0.05),None,None,None),

    // Financial croswalks for Tanner
    FinancialClass("tanner",Meditech,Hospital,None,"BC",Some("BLUE CROSS"),9010,financialClassLookup(9010),"PK",Some(0.67),None,None,None),
    FinancialClass("tanner",Meditech,Hospital,None,"CH",Some("CHAMPUS"),9330,financialClassLookup(9330),"NK",Some(0.38),None,None,None),
    FinancialClass("tanner",Meditech,Hospital,None,"CO",Some("COMMERCIAL"),9020,financialClassLookup(9020),"PK",Some(0.62),None,None,None),
    FinancialClass("tanner",Meditech,Hospital,None,"MCD",Some("MEDICAID"),9100,financialClassLookup(9100),"NK",Some(0.3),None,None,None),
    FinancialClass("tanner",Meditech,Hospital,None,"MCRA",Some("MEDICARE PART A"),9200,financialClassLookup(9200),"MK",Some(0.21),None,None,None),
    FinancialClass("tanner",Meditech,Hospital,None,"MCRB",Some("MEDICARE PART B"),9200,financialClassLookup(9200),"MK",Some(0.13),None,None,None),
    FinancialClass("tanner",Meditech,Hospital,None,"OT",Some("OTHER"),9300,financialClassLookup(9300),"NK",Some(0.39),None,None,None),
    FinancialClass("tanner",Meditech,Hospital,None,"SP",Some("SELF-PAY"),9320,financialClassLookup(9320),"NK",Some(0.15),None,None,None),
    FinancialClass("tanner",Meditech,Hospital,None,"U",Some("UNKNOWN"),9999,financialClassLookup(9999),"UU",Some(0.34),None,None,None),
    FinancialClass("tanner",Meditech,Hospital,None,"WC",Some("WORKERS' COMPENSATION"),9350,financialClassLookup(9350),"PK",Some(0.43),None,None,None)

  )
  val financialClassCw = financialClassCwOrig ++ FinancialClassChristushealth.financialClassCwChristushealth

  def checkCrossWalk(
                      customer: String,
                      source: String,
                      sourceType: String,
                      locationId: Option[Int],
                      financialClassIdOrig: Option[String]
                    ): Boolean = {

    val crosswalkLocationId = FinancialClass.financialClassCw.find(fin =>
      fin.customer.equals(customer)
        && fin.source.equalsIgnoreCase(source)
        && fin.sourceType.equalsIgnoreCase(sourceType)
        && fin.financialClassIdOrig.equalsIgnoreCase(financialClassIdOrig.getOrElse("None"))).map(_.locationId.getOrElse(0))

    val financialClassIdCrosswalk = if (crosswalkLocationId.getOrElse(0).equals(0)) {
      FinancialClass.financialClassCw.find(fin =>
        fin.customer.equals(customer)
          && fin.source.equalsIgnoreCase(source)
          && fin.sourceType.equalsIgnoreCase(sourceType)
          && fin.financialClass.equalsIgnoreCase(financialClassIdOrig.getOrElse("None")))
        .map(_.financialClassId)
    } else {
      FinancialClass.financialClassCw.find(fin =>
        fin.customer.equals(customer)
          && fin.source.equalsIgnoreCase(source)
          && fin.sourceType.equalsIgnoreCase(sourceType)
          && fin.locationId.equals(locationId)
          && fin.financialClassIdOrig.equalsIgnoreCase(financialClassIdOrig.getOrElse("None")))
        .map(_.financialClassId)
    }
    financialClassIdCrosswalk.isDefined
  }

  def assignFromCrosswalk(
                           customer: String,
                           source: String,
                           sourceType: String,
                           locationId: Option[Int],
                           financialClassIdOrig: Option[String]
                         ): Int = {

    val crosswalkLocationId = FinancialClass.financialClassCw.find(fin =>
      fin.customer.equals(customer)
        && fin.source.equalsIgnoreCase(source)
        && fin.sourceType.equalsIgnoreCase(sourceType)
        && fin.financialClassIdOrig.equalsIgnoreCase(financialClassIdOrig.getOrElse("None")))
      .map(_.locationId.getOrElse(0))

    val financialClassIdCrosswalk: Option[Int] = if (crosswalkLocationId.getOrElse(0).equals(0)) {
      FinancialClass.financialClassCw.find(fin =>
        fin.customer.equals(customer)
          && fin.source.equalsIgnoreCase(source)
          && fin.sourceType.equalsIgnoreCase(sourceType)
          && fin.financialClassIdOrig.equalsIgnoreCase(financialClassIdOrig.get))
        .map(_.financialClassId)
    } else {
      FinancialClass.financialClassCw.find(fin =>
        fin.customer.equals(customer)
          && fin.source.equalsIgnoreCase(source)
          && fin.sourceType.equalsIgnoreCase(sourceType)
          && fin.locationId.equals(locationId)
          && fin.financialClassIdOrig.equalsIgnoreCase(financialClassIdOrig.get))
        .map(_.financialClassId)
    }
    financialClassIdCrosswalk.get
  }
}

case class FinClassCwCreationException(exc: Throwable)
  extends Exception("Unable to create financial class crosswalk", exc)

case class FinClassLkpException(code: Int) extends Exception(s"No financial class value found for code '$code'")