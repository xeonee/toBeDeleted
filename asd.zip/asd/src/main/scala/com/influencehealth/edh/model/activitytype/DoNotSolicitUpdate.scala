package com.influencehealth.edh.model.activitytype

import com.influencehealth.edh.Constants

trait DoNotSolicitUpdate extends ActivityType {

  override val formatType: String = Constants.DoNotSolicitUpdateInfluenceHealthFormat
  override val defaultSource: String = Constants.DoNotSolicitUpdateInfluenceHealthDefaultSource
  override val defaultMessageType: String = Constants.DoNotSolicitUpdateDefaultMessageType
  override val defaultSourceType: String = Constants.DoNotSolicitUpdateDefaultSourceType
  override val defaultAddressType: String = Constants.DoNotSolicitUpdateDefaultAddressType
  override val defaultActivityType: String = Constants.DoNotSolicitUpdateActivityType
  override val defaultPersonType: String = Constants.DoNotSolicitUpdatePersonType

  override val cleanseStringColumnNames: Seq[String] = Seq(
    "customerId",
    "personId",
    "source",
    "sourceType",
    "sourceRecordId",
    "optOutDirectMail",
    "optOutDirectMailReasons",
    "optOutCall",
    "optOutCallReasons",
    "optOutEmail",
    "optOutEmailReasons",
    "optOutText",
    "optOutTextReasons"
  )

  override val nullColumnNames: Seq[String] = Seq.empty

  override val zipColumnNames: Seq[String] = Seq.empty

  override val mandatoryContactColumnsNames: Seq[String] = Seq.empty


}