package com.influencehealth.edh.load.activities


import com.influencehealth.edh.config.LoadJobConfig
import com.influencehealth.edh.model.Activity
import com.influencehealth.edh.validation.BaldurInputValidator
import com.influencehealth.edh.{Constants, CustomLazyLogging}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
  * Main class for loading cleansed activities from .parquet format to cleansed_activities table in datahub keyspace
  */
class LoadActivities(
                      val customer: String,
                      val activityType: String,
                      val jobType: String,
                      val s3Url: String,
                      val batchId: String,
                      val failOnError: Boolean,
                      val setOfCustomerServicingZipCodes: Set[String]
                    )(implicit sparkSession: SparkSession) extends CustomLazyLogging {

  def loadActivities: Dataset[Activity] = {

    val cliMainCommand = jobType.toString
    import sparkSession.implicits._
    logger.info(s"'cdp $cliMainCommand $activityType' job started for batch-id: $batchId")
    logger.info("Loading files from: " + s3Url)
    // Creating batch id to keep records idempotent eg: chomp-encounter-influencehealth-2017-09
    // Read all parquet files
    val activitiesDataFrame: DataFrame = ActivityLoader.readActivityFiles(
      sparkSession, s3Url, activityType, customer, setOfCustomerServicingZipCodes, batchId
    )

    // Rename columns to new activities postgres schema columns
    val aliasedDataFrame: DataFrame = ActivityLoader.aliasDataFrameColumns(activitiesDataFrame)
    aliasedDataFrame.persist(StorageLevel.MEMORY_ONLY_SER)

    // Lazy evaluation of dataframe means that as long as there is no call to action within the splitInvalidData method
    // if the data type activityType is of type Prospect the invalid dataframe will never actually materialize
    val validator = new BaldurInputValidator(aliasedDataFrame)

    val validRecords: DataFrame = if (activityType.toUpperCase != Constants.ProspectActivityType &&
                                      activityType.toUpperCase != Constants.NewMoverActivityType) {
      logger.info(s"Baldur InputValidation started for batchId: $batchId")
      val (invalidRecords: DataFrame, retValidRecords: DataFrame) = validator.splitInvalidData()
      if (invalidRecords.where(size($"errors") > 0).count() > 0) {
        validator.printErrorStats(invalidRecords)
        if (failOnError) {
          throw new RuntimeException(s"Baldur input validation failed. See logs above for error details.")
        }
        else {
          logger.warn(s"Baldur input validation failed. See logs above for error details for next time")
        }
      }
      else {
        logger.info(s"Baldur InputValidation finished successfully.")
      }
      retValidRecords
    } else {
      aliasedDataFrame
    }

    ActivityLoader.
      generateNewActivityColumns(validRecords, batchId, sparkSession).
      transform(Activity.transformToActivitySchema).
      as[Activity]
  }


}

object LoadActivities {
  def apply(loadJobConfig: LoadJobConfig)(implicit sparkSession: SparkSession): LoadActivities = new LoadActivities(
    loadJobConfig.customer,
    loadJobConfig.activityType,
    loadJobConfig.jobType,
    loadJobConfig.s3Url,
    loadJobConfig.batchId,
    loadJobConfig.failOnError,
    loadJobConfig.customerServiceAreas
  )
}
