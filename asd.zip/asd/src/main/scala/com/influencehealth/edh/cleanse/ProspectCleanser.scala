package com.influencehealth.edh.cleanse

import java.sql.Timestamp

import com.influencehealth.edh.Constants
import com.influencehealth.edh.dataframe.columns._
import com.influencehealth.edh.lookup_clients.beehiveToFinancialClass
import com.influencehealth.edh.model.activitytype.ActivityType
import com.influencehealth.edh.utils.{CleanseUtils, PersonUtils}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.{udf, _}
import org.joda.time.{LocalDateTime, Period, PeriodType}

class ProspectCleanser(val dateBatchReceived: String) extends DataCleanser {

  this: ActivityType =>


  override def cleanseData(
                            df: DataFrame,
                            customer: Option[String],
                            batchId: String
                          ): (DataFrame, DataFrame) = {

    // Apply default values for Required Columns if found NULL
    val defaultCodeForRequiredColumnsContainingNulls = assignDefaultValuesForRequiredColumnsContainingNulls(df).
      withColumn("source", lit(defaultSource)).
      transform(addSourceRecordId(_, batchId))

    // cleanses & filters Date column
    val dataFrameContainingValidDateColumns = formatDateColumns(defaultCodeForRequiredColumnsContainingNulls)

    // Cleanses String Column
    val dataFrameContainingCleansedStringColumns = cleanseStringColumns(dataFrameContainingValidDateColumns, cleanseStringColumnNames)

    // Cleanses Columns that have Amount values
    val dataFrameContainingCleansedAmountColumns = cleanseAmountColumns(dataFrameContainingCleansedStringColumns)

    // Cleanses Contact details: Phone numbers and emails
    val dataFrameContainingCleansedContactDetails = cleanseContactDetails(dataFrameContainingCleansedAmountColumns)

    // Cleanses other experian fields
    val dataFrameContainingCleansedOtherDetails = cleanseOtherDetails(dataFrameContainingCleansedContactDetails)

    // build PersonNumber
    val dataFrameContainingPersonNumberDetails = cleansePersonNumberDetails(dataFrameContainingCleansedOtherDetails)

    import df.sparkSession.implicits._
    val emptySequence: Seq[String] = Seq()
    val errorDataFrame: DataFrame = emptySequence.toDF

    val aliasedDataFrame: DataFrame = aliasData(dataFrameContainingPersonNumberDetails, customer)

    (aliasedDataFrame.transform(mapLanguageCodes), errorDataFrame)
  }

  override def formatDateColumns(df: DataFrame): DataFrame = {
    // Convert string date into Date type columns after validating the dates, known behavior

    df
      .withColumn("ncoaMoveUpdateDate", CleanseUtils.experianDate(df("ncoaMoveUpdateDateOrig")))
      .withColumn("activityDateOrig", CleanseUtils.experianDate(df("activityDateOrig")))
      .withColumn("mortgageHomePurchaseHomePurchaseDate",
        CleanseUtils.experianDate(df("mortgageHomePurchaseHomePurchaseDateOrig")))
      .withColumn("updatedAt",
        CleanseUtils.parseDate(df("updatedAt")))
      .withColumn("activityDate",
        date_format(unix_timestamp(lit(dateBatchReceived), "yyyy-MM").cast("timestamp"), "yyyy-MM-dd"))

  }

  override def cleanseStringColumns(df: DataFrame, stringColumnsToCleanse: Seq[String]): DataFrame = {
    stringColumnsToCleanse.foldLeft(df) {
      (accDF, column) => accDF.withColumn(s"$column", CleanseUtils.cleanseStringColumns(df(s"$column")))
    }
  }

  override def aliasData(df: DataFrame, customer: Option[String]): DataFrame = {
    df.withColumn("dateCreated", lit(Constants.Now.toString))
  }


  /** Cleanses the Amount column by removing special characters like $ ,
    *
    * @param df
    * @return
    **/
  private def cleanseAmountColumns(df: DataFrame): DataFrame = {
    df.
      withColumn("mortgageHomePurchaseHomePurchasePrice",
        CleanseUtils.cleanseAmountColumns(df("mortgageHomePurchaseHomePurchasePrice"))).
      withColumn("homeLandValue",
        CleanseUtils.cleanseAmountColumns(df("homeLandValue"))).
      withColumn("estimatedHomeValueOrig",
        CleanseUtils.cleanseAmountColumns(df("estimatedHomeValueOrig"))).
      withColumn("capeHomevalOohuMedianHomeValue",
        CleanseUtils.cleanseAmountColumns(df("capeHomevalOohuMedianHomeValue")))
  }

  /** Prepare person number columns
    *
    * @param df
    * @return dataFrame with alias
    **/
  private def cleansePersonNumberDetails(df: DataFrame): DataFrame = {

    val filteredAddressQualityIndicaorData = df.where(df("addressQualityIndicator") isin("E", "G"))

    val finalData = Seq(1, 2, 3, 4, 5, 6)
      .map(personNumber => buildPersonNumberDf(filteredAddressQualityIndicaorData, personNumber))
      .reduce(_.union(_))

    finalData.withColumn("deceasedFlag", update_deceased_flag(finalData("sourcePersonType")))

  }

  /** Applies and format experian columns
    *
    * @param df
    * @return dataFrame
    **/
  private def cleanseOtherDetails(df: DataFrame): DataFrame = {

    df.
      withColumn("person1SourcePersonType", df("person1PersonType")).
      withColumn("person2SourcePersonType", df("person2PersonType")).
      withColumn("person3SourcePersonType", df("person3PersonType")).
      withColumn("person4SourcePersonType", df("person4PersonType")).
      withColumn("person5SourcePersonType", df("person5PersonType")).
      withColumn("person6SourcePersonType", df("person6PersonType")).
      withColumn("person1DOB", CleanseUtils.experianDate(df("person1DOBOrig"))).
      withColumn("person2DOB", CleanseUtils.experianDate(df("person2DOBOrig"))).
      withColumn("person3DOB", CleanseUtils.experianDate(df("person3DOBOrig"))).
      withColumn("person4DOB", CleanseUtils.experianDate(df("person4DOBOrig"))).
      withColumn("person5DOB", CleanseUtils.experianDate(df("person5DOBOrig"))).
      withColumn("person6DOB", CleanseUtils.experianDate(df("person6DOBOrig"))).
      withColumn("person1CombinedAge",
        CleanseUtils.substringToInt(df("person1CombinedAgeOrig"), lit(1), lit(3))).
      withColumn("person2CombinedAge",
        CleanseUtils.substringToInt(df("person2CombinedAgeOrig"), lit(1), lit(3))).
      withColumn("person3CombinedAge",
        CleanseUtils.substringToInt(df("person3CombinedAgeOrig"), lit(1), lit(3))).
      withColumn("person4CombinedAge",
        CleanseUtils.substringToInt(df("person4CombinedAgeOrig"), lit(1), lit(3))).
      withColumn("person5CombinedAge",
        CleanseUtils.substringToInt(df("person5CombinedAgeOrig"), lit(1), lit(3))).
      withColumn("person6CombinedAge",
        CleanseUtils.substringToInt(df("person6CombinedAgeOrig"), lit(1), lit(3))).
      withColumn("person1EducationModel",
        CleanseUtils.substringToInt(df("person1EducationModelOrig"), lit(1), lit(2))).
      withColumn("person2EducationModel",
        CleanseUtils.substringToInt(df("person2EducationModelOrig"), lit(1), lit(2))).
      withColumn("person3EducationModel",
        CleanseUtils.substringToInt(df("person3EducationModelOrig"), lit(1), lit(2))).
      withColumn("person4EducationModel",
        CleanseUtils.substringToInt(df("person4EducationModelOrig"), lit(1), lit(2)))
      .withColumn("person5EducationModel",
        CleanseUtils.substringToInt(df("person5EducationModelOrig"), lit(1), lit(2)))
      .withColumn("person6EducationModel",
        CleanseUtils.substringToInt(df("person6EducationModelOrig"), lit(1), lit(2)))
      .withColumn("person1MaritalStatus",
        CleanseUtils.substring(df("person1MaritalStatusOrig"), lit(1), lit(2)))
      .withColumn("person2MaritalStatus",
        CleanseUtils.substring(df("person2MaritalStatusOrig"), lit(1), lit(2)))
      .withColumn("person3MaritalStatus",
        CleanseUtils.substring(df("person3MaritalStatusOrig"), lit(1), lit(2)))
      .withColumn("person4MaritalStatus",
        CleanseUtils.substring(df("person4MaritalStatusOrig"), lit(1), lit(2)))
      .withColumn("person5MaritalStatus",
        CleanseUtils.substring(df("person5MaritalStatusOrig"), lit(1), lit(2)))
      .withColumn("person6MaritalStatus",
        CleanseUtils.substring(df("person6MaritalStatusOrig"), lit(1), lit(2)))
      .withColumn("person1Race",
        CleanseUtils.race(df("person1EthnicExperianGroup")))
      .withColumn("person2Race",
        CleanseUtils.race(df("person2EthnicExperianGroup")))
      .withColumn("person3Race",
        CleanseUtils.race(df("person3EthnicExperianGroup")))
      .withColumn("person4Race",
        CleanseUtils.race(df("person4EthnicExperianGroup")))
      .withColumn("person5Race",
        CleanseUtils.race(df("person5EthnicExperianGroup")))
      .withColumn("person6Race",
        CleanseUtils.race(df("person6EthnicExperianGroup")))
      .withColumn("person1EthnicInsight",
        CleanseUtils.ethnicInsight(
          df("person1Ethnic"),
          df("person1EthnicExperianGroup"),
          df("person1EthnicReligion"),
          df("person1EthnicLanguage"),
          df("person1EthnicGroup"),
          df("person1EthnicCountryOfOrigin")))
      .withColumn("person2EthnicInsight",
        CleanseUtils.ethnicInsight(
          df("person2Ethnic"),
          df("person2EthnicExperianGroup"),
          df("person2EthnicReligion"),
          df("person2EthnicLanguage"),
          df("person2EthnicGroup"),
          df("person2EthnicCountryOfOrigin")))
      .withColumn("person3EthnicInsight",
        CleanseUtils.ethnicInsight(
          df("person3Ethnic"),
          df("person3EthnicExperianGroup"),
          df("person3EthnicReligion"),
          df("person3EthnicLanguage"),
          df("person3EthnicGroup"),
          df("person3EthnicCountryOfOrigin")))
      .withColumn("person4EthnicInsight",
        CleanseUtils.ethnicInsight(
          df("person4Ethnic"),
          df("person4EthnicExperianGroup"),
          df("person4EthnicReligion"),
          df("person4EthnicLanguage"),
          df("person4EthnicGroup"),
          df("person4EthnicCountryOfOrigin")))
      .withColumn("person5EthnicInsight",
        CleanseUtils.ethnicInsight(
          df("person5Ethnic"),
          df("person5EthnicExperianGroup"),
          df("person5EthnicReligion"),
          df("person5EthnicLanguage"),
          df("person5EthnicGroup"),
          df("person5EthnicCountryOfOrigin")))
      .withColumn("person6EthnicInsight",
        CleanseUtils.ethnicInsight(
          df("person6Ethnic"),
          df("person6EthnicExperianGroup"),
          df("person6EthnicReligion"),
          df("person6EthnicLanguage"),
          df("person5EthnicGroup"),
          df("person6EthnicCountryOfOrigin"))).
      withColumn("isChildPresent",
        CleanseUtils.isTrue(CleanseUtils.substring(df("presenceOfChildOrig"), lit(1), lit(2)))).
      withColumn("hasChildZeroToThree",
        CleanseUtils.isTrue(CleanseUtils.substring(df("childZeroToThreeBktOrig"), lit(1), lit(2)))).
      withColumn("hasChildFourToSix",
        CleanseUtils.isTrue(CleanseUtils.substring(df("childFourToSixBktOrig"), lit(1), lit(2)))).
      withColumn("hasChildSevenToNine",
        CleanseUtils.isTrue(CleanseUtils.substring(df("childSevenToNineBktOrig"), lit(1), lit(2)))).
      withColumn("hasChildTenToTwelve",
        CleanseUtils.isTrue(CleanseUtils.substring(df("childTenToTwelveBktOrig"), lit(1), lit(2)))).
      withColumn("hasChildThirteenToFifteen",
        CleanseUtils.isTrue(CleanseUtils.substring(df("childThirteenToFifteenBktOrig"), lit(1), lit(2)))).
      withColumn("hasChildSixteenToEighteen",
        CleanseUtils.isTrue(CleanseUtils.substring(df("childSixteenToEighteenBktOrig"), lit(1), lit(2)))).
      withColumn("estimatedHomeValue", CleanseUtils.homeValue(df("estimatedHomeValueOrig"))).
      withColumn("latitude", CleanseUtils.experianLat(df("latitudeOriginal"))).
      withColumn("longitude", CleanseUtils.experianLon(df("longitudeOriginal")))

  }

  /** coding values for columns (exclusion flag, patient type, er patients) that require have null values
    *
    * @param df
    * @return dataFrame
    **/
  override def assignDefaultValuesForRequiredColumnsContainingNulls(df: DataFrame): DataFrame = {
    df
      .withColumn("source", lit(defaultSource))
      .withColumn("sourceType", lit(defaultSourceType))
      .withColumn("activityType", lit(defaultActivityType))
      .withColumn("addressType", lit(defaultAddressType))
      .withColumn("messageType", lit(defaultMessageType))
  }

  /** Validates the email and phone number columns
    *
    * @param df
    * @return formated coloumn
    **/
  private def cleanseContactDetails(df: DataFrame): DataFrame = {
    df.withColumn("homePhone", CleanseUtils.cleanseAndParsePhone(df("phone1")))
      .withColumn("mobilePhone", CleanseUtils.cleanseAndParsePhone(df("phone2")))
  }

  def buildPersonNumberDf(dataFrame: DataFrame, personNumber: Int): DataFrame = {
    dataFrame
      .withColumn(SourcePersonId, col(s"person${personNumber}PersonId"))
      .withColumn(SourceRecordId, col(s"person${personNumber}PersonId"))
      .withColumn(FirstName, col(s"person${personNumber}FirstName"))
      .withColumn(MiddleName, col(s"person${personNumber}MiddleName"))
      .withColumn(LastName, col(s"person${personNumber}LastName"))
      .withColumn(Prefix, col(s"person${personNumber}NamePrefix"))
      .withColumn(PersonalSuffix, col(s"person${personNumber}NameSuffix"))
      .withColumn(SourceSex, col(s"person${personNumber}Sex"))
      .withColumn(SourcePersonType, col(s"person${personNumber}SourcePersonType"))
      .withColumn(DateOfBirth, col(s"person${personNumber}DOB"))
      .withColumn(SourceAge, col(s"person${personNumber}CombinedAge"))
      .withColumn(Education, col(s"person${personNumber}EducationModel"))
      .withColumn(MaritalStatus, map_to_marital_status(col(s"person${personNumber}MaritalStatus")))
      .withColumn(Occupation, col(s"person${personNumber}OccupationCode"))
      .withColumn(OccupationGroup, map_to_occupation_group(col(s"person${personNumber}OccupationGroup")))
      .withColumn(Religion, map_to_religion(col(s"person${personNumber}EthnicReligion")))
      .withColumn(Race, map_to_race(col(s"person${personNumber}Race")))
      .withColumn(EthnicInsight, col(s"person${personNumber}EthnicInsight"))
      .withColumn(IsoLanguageCode, col(s"person${personNumber}EthnicLanguage"))
      .withColumn(WealthRating, derive_wealth_rating(col("capeEducIspsaDecile")))
      .withColumn(DwellType, map_to_dwell_type(col(DwellType)))
      .withColumn(Sex, PersonUtils.sex(col(SourceSex)))
      .withColumn(SourceAge, ageUdf(col(DateOfBirth), col(SourceAge)))
      .withColumn(Education,map_to_education(col(Education)))
      .where(col(SourcePersonId).isNotNull && col(AddressId).isNotNull)
  }

  val ageUdf = udf((dateOfBirth: Timestamp, experianAge: Int) => {

    if(Option(dateOfBirth).nonEmpty){
      val dateOfBirthLocal = new LocalDateTime(dateOfBirth.getTime)
      val today: LocalDateTime = Constants.Today.toLocalDateTime

      Some(new Period(dateOfBirthLocal, today, PeriodType.yearMonthDay).getYears)
    } else if (Option(experianAge).nonEmpty) Some(experianAge)
    else None

  })

  val update_deceased_flag = udf[Boolean, String]((sourcePersonType: String) => {
    sourcePersonType.toUpperCase match {
      case "D" => true
      case _ => false
    }
  })

  // TODO: Convert this to return string and not integer
  val derive_wealth_rating: UserDefinedFunction = udf[Option[Int], String]((capeEducIspsaDecile: String) => {
    Option(capeEducIspsaDecile) match {
      case Some(x) => Some(x.toInt)
      case None => None
    }
  })

  val financial_class: UserDefinedFunction = udf[Option[String], Int, Int](
    (beehiveCluster: Int, age: Int) => {
      getFinancialClass(Option(beehiveCluster), Option(age))._2
    })

  val payer_type: UserDefinedFunction = udf[Option[String], Int, Int](
    (beehiveCluster: Int, age: Int) => {
      getFinancialClass(Option(beehiveCluster), Option(age))._3
    })

  val map_to_dwell_type: UserDefinedFunction = udf[Option[String], String](wealthRating => {
    Option(wealthRating).map(Constants.DwellTypeMapping(_))
  })

  val map_to_financial_class: UserDefinedFunction = udf[Option[String], Int, Int]((beehive, sourceAge) =>
    (beehive, sourceAge) match {
      case (_, age) if age > 65 =>
        Some(Constants.FinancialClassTargetPayerMedicare)
      case (beehive, _) if beehive >= 11 =>
        Some(Constants.FinancialClassTargetPayerProfitable)
      case (beehive, _) if 12 >= beehive && beehive <= 13 =>
        Some(Constants.FinancialClassTargetPayerUnprofitable)
      case (beehive, _) if 14 >= beehive && beehive <= 16 =>
        Some(Constants.FinancialClassTargetPayerProfitable)
      case (beehive, _) if beehive >= 17 && beehive <= 30 =>
        Some(Constants.FinancialClassTargetPayerUnprofitable)
      case _ => None
    })

  val map_to_payer_type: UserDefinedFunction = udf[Option[String], Int, Int]((beehive, sourceAge) =>
    (Option(beehive), Option(sourceAge)) match {
      case (_, Some(age)) if age > 65 => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(1), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(2), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(3), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(4), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(5), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(6), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(7), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(8), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(9), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(10), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(11), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(12), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(13), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(14), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(15), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(16), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(17), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(18), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(19), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(20), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(21), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(22), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(23), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(24), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(25), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(26), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(27), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(28), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(29), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case (Some(30), _) => Some(Constants.PayerTypeNotProfitableInferredDesc)
      case _ => None
    })

  val map_to_race: UserDefinedFunction = udf[Option[String], String](race => {
    Option(race).flatMap(Constants.RaceMapping.get)
  })

  val map_to_education: UserDefinedFunction = udf[Option[String], Int](education => {
    Option(education).flatMap(Constants.EducationMapping.get)
  })

  val map_to_marital_status: UserDefinedFunction = udf[Option[String], String](maritalStatus => {
    Option(maritalStatus).flatMap(Constants.MaritalStatusMapping.get)
  })

  val map_to_occupation_group: UserDefinedFunction = udf[Option[String], String](occupationGroup => {
    Option(occupationGroup).flatMap(Constants.OccupationGroupMapping.get)
  })

  val map_to_religion: UserDefinedFunction = udf[Option[String], String](religion => {
    Option(religion).flatMap(Constants.ReligionMapping.get)
  })


  /** Gets a Financial Class ID, Description and Payer Type value given a Beehive and Age attribute
    *
    * @param beehive Optional beehive code
    * @param age     Optional age
    * @return (financialClassId, financialClass, payerType) */
  def getFinancialClass(beehive: Option[Int], age: Option[Int]): (Option[Int], Option[String], Option[String]) = {
    (age, beehive) match {
      case (Some(x), _) if x >= 65 => (Some(9930), Some("target payer - medicare"), Some("mi"))
      case (_, Some(x)) => beehiveToFinancialClass.getOrElse(x, (None, None, None))
      case _ => (None, None, None)
    }
  }


}
