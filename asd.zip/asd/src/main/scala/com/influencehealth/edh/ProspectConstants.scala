package com.influencehealth.edh

import org.joda.time.DateTime

import scala.io.Source

object ProspectConstants {

  val today: DateTime = Constants.Today

  val presenceOfChildCodes: Map[String, String] =
    Map("Y" -> "45",
      "N" -> "44",
      "U" -> "44"
    )

  val incomeCodes: Map[String, String] =
    Map("A" -> "08",
      "B" -> "09",
      "C" -> "10",
      "D" -> "11",
      "E" -> "12",
      "F" -> "13",
      "G" -> "14",
      "H" -> "15",
      "I" -> "16",
      "J" -> "17",
      "K" -> "18",
      "L" -> "19",
      "U" -> "20"
    )

  val maritalStatusCodes: Map[String, String] =
    Map("S" -> "07",
      "M" -> "06",
      "U" -> "07")

  val educationCodes: Map[Int, String] =
    Map(3 -> "01",
      4 -> "02",
      1 -> "03",
      5 -> "04",
      2 -> "05"
    )


  val occupationCodes: Map[Int, String] =
    Map(0 -> "43",
      1 -> "37",
      2 -> "37",
      3 -> "37",
      4 -> "38",
      5 -> "38",
      6 -> "40",
      7 -> "39",
      8 -> "41",
      9 -> "42")

  val ageCodes : Map[Int,String] = Map(
    19->"21", 20->"22", 21->"22", 22->"22", 23->"22", 24->"22", 25->"23", 26->"23", 27->"23", 28->"23", 29->"23", 30->"24", 31->"24", 32->"24", 33->"24", 34->"24", 35->"25", 36->"25", 37->"25", 38->"25", 39->"25", 40->"26", 41->"26", 42->"26", 43->"26", 44->"26", 45->"27", 46->"27", 47->"27", 48->"27", 49->"27", 50->"28", 51->"28", 52->"28", 53->"28", 54->"28", 55->"29", 56->"29", 57->"29", 58->"29", 59->"29", 60->"30", 61->"30", 62->"30", 63->"30", 64->"30", 65->"31", 66->"31", 67->"31", 68->"31", 69->"31", 70->"32", 71->"32", 72->"32", 73->"32", 74->"32", 75->"33", 76->"33", 77->"33", 78->"33", 79->"33", 80->"33", 81->"33", 82->"33", 83->"33", 84->"33", 85->"33", 86->"33", 87->"33", 88->"33", 89->"33"
  )

  val lastNameCodes: Map[String, String] =
      Source.fromURL(getClass.getResource("/experian/beehive_ethnic_cw.csv"))
        .getLines()
        .filter(!_.isEmpty)
        .map { line =>
          val split = line.split(",")
          (split(0), split(1))
        }.toMap

  val combinedToCluster: Map[String, Int] =
    Source.fromURL(getClass.getResource("/experian/beehive_combined_code_cw.csv"))
      .getLines()
      .filter(!_.isEmpty)
      .map { line =>
        val split = line.split(",")
        (split(0), split(1).toInt)
      }.toMap

}
