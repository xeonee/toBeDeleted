package com.influencehealth.edh.enrich.activity.identity

import com.influencehealth.edh.linker._
import com.influencehealth.edh.config.EnrichJobConfig
import com.influencehealth.edh.dao.{DatabaseDao, PostgresDatabaseDao}
import com.influencehealth.edh.enrich.ActivityEnricher
import com.influencehealth.edh.identity.EnrichIdentity
import com.influencehealth.edh.model.Activity
import com.influencehealth.edh.utils.DataLakeUtilities
import org.apache.spark.sql.{Dataset, SparkSession}
import org.apache.spark.storage.StorageLevel

class EnrichIdentityStep(val name: String, val next: Option[ActivityEnricher])
                        (implicit enrichJobConfig: EnrichJobConfig, sparkSession: SparkSession)
  extends ActivityEnricher {

  override def enrich(activities: Dataset[Activity]): Dataset[Activity] = {

    import sparkSession.implicits._

    val databaseDao: DatabaseDao = new PostgresDatabaseDao(enrichJobConfig.databaseConfig.get)
    
    val inputActivityType = DataLakeUtilities.extractActivityTypeFromBatchId(enrichJobConfig.batchId.get)

    val validatedData: Dataset[Activity] = EnrichIdentity.validateActivities(activities, databaseDao,inputActivityType)

    val validatedDataCount = validatedData.count()

    logger.info(s"Number of validated input activities: $validatedDataCount")

    val inMemoryActivityLinker = new ActivityLinker(databaseDao, enrichJobConfig.customer)
      with ActivityLinkerImpl with ActivityInMemoryEntityDB

    val inMemoryLinkedActivities: Dataset[Activity] = inMemoryActivityLinker.linkRecords(validatedData)

    val  inMemoryMergedActivitiesCount = validatedDataCount - inMemoryLinkedActivities.count()

    val dbActivityLinker = new ActivityLinker(databaseDao, enrichJobConfig.customer)
      with ActivityLinkerImpl with ActivityPostgresEntityDB

    val linkedActivities: Dataset[Activity] = dbActivityLinker.linkRecords(inMemoryLinkedActivities)
    linkedActivities.persist(StorageLevel.MEMORY_ONLY_SER)

    logger.info(s"Activities After linking: ${linkedActivities.count()}")

    val activitiesWithPersonId: Dataset[Activity] = linkedActivities.filter(_.personId.isDefined)

    val activitiesWithoutPersonId: Dataset[Activity] = linkedActivities.filter(_.personId.isEmpty)

    val activitiesWithPersonIdCount = activitiesWithPersonId.count()
    logger.info(s"activitiesWithPersonId: $activitiesWithPersonIdCount")

    val activitiesWithoutPersonIdCount = activitiesWithoutPersonId.count()
    logger.info(s"activitiesWithoutPersonId: $activitiesWithoutPersonIdCount")

    logger.info(s"Total number of activities linked with existing activities are: " +
      s"${validatedDataCount - activitiesWithoutPersonIdCount - inMemoryMergedActivitiesCount}")
    logger.info(s"Total number of new activities are: $activitiesWithoutPersonIdCount")

    if (activitiesWithPersonIdCount > 0 && activitiesWithoutPersonIdCount > 0) {

      databaseDao.saveActivities(activitiesWithPersonId)

      val persons = EnrichIdentity.identifyRecords(activitiesWithoutPersonId, databaseDao, enrichJobConfig.customer)
      databaseDao.savePersons(persons)
      persons.flatMap(_.activities)

    } else if (activitiesWithPersonIdCount == 0 && activitiesWithoutPersonIdCount != 0) {

      val persons = EnrichIdentity.identifyRecords(activitiesWithoutPersonId, databaseDao, enrichJobConfig.customer)

      databaseDao.savePersons(persons)
      persons.flatMap(_.activities)

    } else {
      val persons = EnrichIdentity.identifyRecords(activitiesWithPersonId, databaseDao, enrichJobConfig.customer)
      databaseDao.savePersons(persons)
      activitiesWithPersonId
    }

  }
}

