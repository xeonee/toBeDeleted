package com.influencehealth.edh.refresh.reporting.transformer

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.{ArrayType, MapType, StructField, StructType}

trait BaseTransformer {

  def transformArrayTypes(dataFrame: DataFrame): DataFrame = ???

  def transformStructTypes(dataFrame: DataFrame): DataFrame = ???

  def dropComplexTypes(dataFrame: DataFrame): DataFrame = {
    val columnsToDrop = dataFrame.schema.flatMap{
      case StructField(name, ArrayType(_, _), _, _) => Some(name)
      case StructField(name, MapType(_, _, _), _, _) => Some(name)
      case StructField(name, StructType(_), _, _) => Some(name)
      case _ => None
    }
    dataFrame.drop(columnsToDrop:_*)
  }

}