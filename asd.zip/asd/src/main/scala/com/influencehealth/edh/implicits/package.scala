package com.influencehealth.edh

import java.sql.Timestamp

import org.joda.time.DateTime
import org.joda.time.format.ISODateTimeFormat

/** Implicit conversions and classes for the EDH project
  */
package object implicits {

  sealed case class DateTimeParseError(str: String, e: Throwable) extends Error(str, e)

  implicit class AnyExtensions(value: Any) {
    /** Checks if any given value is null or empty */
    @Deprecated
    def isNullOrEmpty: Boolean = {
      value match {
        case x: Option[_] => x.isEmpty || x.exists(_.isNullOrEmpty)
        case x: Iterable[_] => x.isEmpty || !x.exists(!_.isNullOrEmpty)
        case x: String => x == null || x.isEmpty
        case x: Double => x.isNaN
        case x: Long => x.toDouble.isNaN || x == 0.toLong
        case x: Int => x.toDouble.isNaN || x == 0
        case x: Float => x.isNaN
        case x => x == null
      }
    }

  }

  implicit class DateTimeExtensions(date: DateTime) {

    /** Converts a joda DateTime object to a java.sql.Timestamp object */
    def toTimestamp: Timestamp = if (date.isNullOrEmpty) null else new Timestamp(date.getMillis)

    /** Converts a joda DateTime object to string of yyyy-MM-dd'T'HH:mm:ss.SSSZZ */
    def toTimestampStr: String = if (date.isNullOrEmpty) null else ISODateTimeFormat.dateTime().print(date)

  }


}