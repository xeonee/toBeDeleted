package com.influencehealth.edh.refresh.reporting.transformer

import com.influencehealth.edh.model.Activity
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset}

class ActivityTransformer(
                           activityData: Dataset[Activity]
                         ) extends BaseTransformer with Serializable {

  import activityData.sparkSession.implicits._

  def activities: DataFrame = activityData.
    withColumn("person_record_id", concat_ws("::", $"customer_id", $"person_id")).
    transform(dropComplexTypes)

}