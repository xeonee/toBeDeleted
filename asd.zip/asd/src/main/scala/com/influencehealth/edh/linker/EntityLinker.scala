package com.influencehealth.edh.linker

import com.influencehealth.edh.model.PrimaryIdentity
import org.apache.spark.sql.Dataset

case class IdentityEntity[T](
                              origin: String,
                              entity: T
                            )

trait EntityLinker[T <: PrimaryIdentity] {

  def transformInput(inputDF: Dataset[T]): Dataset[IdentityEntity[T]]

  def linkRecords(transformedDF: Dataset[T]): Dataset[T]

  def prepareOutputData(candidatesForLinkage: => Dataset[T], linkedDF: Dataset[IdentityEntity[T]]): Dataset[T]

}
