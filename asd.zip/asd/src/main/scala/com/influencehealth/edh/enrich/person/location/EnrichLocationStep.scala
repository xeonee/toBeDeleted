package com.influencehealth.edh.enrich.person.location

import java.sql.Date
import java.time.LocalDate
import java.time.format.DateTimeFormatter

import com.influencehealth.edh.Constants
import com.influencehealth.edh.config.EnrichJobConfig
import com.influencehealth.edh.enrich.PersonEnricher
import com.influencehealth.edh.lookup_clients.support.ServiceArea
import com.influencehealth.edh.lookups.messages.Location
import com.influencehealth.edh.model.{Person, PersonLocation}
import org.apache.spark.sql.{Dataset, Encoder, Encoders, SparkSession}

class EnrichLocationStep(val name: String, val next: Option[PersonEnricher])
                        (implicit enrichJobConfig: EnrichJobConfig, sparkSession: SparkSession)
  extends PersonEnricher {

  implicit val sqlDateOrdering: Ordering[Date] = new Ordering[Date] {
    override def compare(x: Date, y: Date): Int = x.compareTo(y)
  }

  override def enrich(personsForLocationAssignment: Dataset[Person]): Dataset[Person] = {

    import personsForLocationAssignment.sparkSession.implicits._

    if (enrichJobConfig.customerLocations.size == 1) {
      val location = enrichJobConfig.customerLocations.head

      personsForLocationAssignment
        .map(person => person.copy(
          locations = Seq(PersonLocation(location.Name, 1))))
    } else {
      getLocationChangesForMultipleLocations(
        personsForLocationAssignment,
        enrichJobConfig.allOrApplicable,
        enrichJobConfig.customerLocations,
        enrichJobConfig.customerServiceAreas
      )
    }
  }

  /**
    * Calculates the distance between locations based on zip, lat and long. Then ranks the locations based on preference
    *
    * @param dataset
    * @param allOrApplicable
    * @param locations
    * @param serviceAreas
    * @return
    */
  def getLocationChangesForMultipleLocations(dataset: Dataset[Person],
                                             allOrApplicable: String,
                                             locations: Seq[Location],
                                             serviceAreas: Set[ServiceArea]
                                            ): Dataset[Person] = {

    import dataset.sparkSession.implicits._

    // RDD of persons to a location map, which includes the location's ID, person's
    // distance to location and service area value Starts by getting person master
    // values and filters to persons with data applicable for location scoring
    // Then it joins to the standard locations on the customer_id, and calculates
    // the person's distance to each location. Finally it joins to the service areas
    // tables on the customer_id, location_id and zip5 and gets the person's service
    // area value

    implicit val locationMetricEncoder: Encoder[LocationMetric] = Encoders.kryo[LocationMetric]

    dataset
      // Location distance calculations
      .map(buildLocationMetrics(locations, serviceAreas, _))
      // Ranking Locations
      .map { case (person, metrics) =>
      rankLocations(person, metrics, allOrApplicable)
    }
  }

  /**
    * Determines which location a person falls closest to by calculating their distance from each
    * location.
    *
    * Calls to the calculateDistances method require that lat and lon be populated on the input LocScorePerson.
    * Currently all calls to this method (LocationScoring) have been filtered by persons only having both values
    * present.
    *
    * @param
    * @return
    */
  def buildLocationMetrics(
                            locations: Seq[Location],
                            serviceAreas: Set[ServiceArea],
                            person: Person
                          ): (Person, Seq[LocationMetric]) = {

    var locationMetrics: Seq[LocationMetric] = Seq()

    if (locations.nonEmpty &&
      locations.length > 1 &&
      person.addressCoordinates.map(_.lat).nonEmpty &&
      person.addressCoordinates.map(_.lon).nonEmpty) {

      val personLatitude = person.addressCoordinates.get.lat
      val personLongitude = person.addressCoordinates.get.lon

      locationMetrics = locations.map { location =>
        val locationLatitude = location.Address.Lat.get
        val locationLongitude = location.Address.Lon.get
        val locationId: Int = location.Id
        val locationName: String = location.Name
        val distance: Float = calculateDistance(personLatitude, personLongitude, locationLatitude, locationLongitude)
        val serviceArea: Option[String] = serviceAreas.find {
          serviceArea => serviceArea.locationId.equals(locationId)
        }.map(_.serviceAreaName)
        calculateLocationMetrics(person, locationName, distance, serviceArea)
      }

    }
    (person, locationMetrics)
  }

  /**
    * Determines metrics based on zips, last 6 months, overall and non Encounters
    *
    * @param person
    * @param location
    * @param distance
    * @param serviceArea
    * @return
    */
  def calculateLocationMetrics(person: Person,
                               location: String,
                               distance: Double,
                               serviceArea: Option[String]
                              ): LocationMetric = {
    val (currentEncounterZipVisits, currentEncounterZipMaxDate) = getCurrentEncounterZipMetrics(person, location)
    val (sixMonthEncounterVisits, sixMonthEncounterMaxDate) = getSixMonthEncounterMetrics(person, location)
    val (overallEncounterVisits, overallEncounterMaxDate) = getOverallEncounterMetrics(person, location)
    val (nonEncounterVisits, nonEncounterMaxDate) = getNonEncounterMetrics(person, location)

    LocationMetric(
      location,
      distance,
      serviceArea,
      currentEncounterZipVisits,
      currentEncounterZipMaxDate,
      sixMonthEncounterVisits,
      sixMonthEncounterMaxDate,
      overallEncounterVisits,
      overallEncounterMaxDate,
      nonEncounterVisits,
      nonEncounterMaxDate
    )
  }

  /**
    * Calculate distance between two co-ordinates
    *
    * @param lat1
    * @param lon1
    * @param lat2
    * @param lon2
    * @return
    */
  def calculateDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Float = {

    val earthRadius = 6371000
    val dLat = Math.toRadians(lat2 - lat1)
    val dLng = Math.toRadians(lon2 - lon1)

    val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
        Math.sin(dLng / 2) * Math.sin(dLng / 2)

    val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))

    (earthRadius * c).toFloat
  }

  /**
    * Gets the latest encounter metrics based on servicing locations
    *
    * @param person
    * @param location
    * @return
    */
  def getCurrentEncounterZipMetrics(
                                     person: Person,
                                     location: String
                                   ): (Option[Int], Option[Date]) = {

    val locationActivities = person.activities.filter { activity =>
      activity.locationDesc.contains(location) && activity.activityType.contains(Constants.EncounterActivityType)
    }
    if (locationActivities.isEmpty) {
      (None, None)
    } else {
      val utilCurrentZipVisits = locationActivities.size
      val utilCurrentZipMaxDate = locationActivities.maxBy(person =>
        person.dateModified.getOrElse(person.activityDate)).activityDate

      (Some(utilCurrentZipVisits), Some(utilCurrentZipMaxDate))
    }
  }

  /**
    * Gets the latest encounter metrics from last 6 months
    *
    * @param person
    * @param location
    * @return
    */
  def getSixMonthEncounterMetrics(person: Person, location: String): (Option[Int], Option[Date]) = {
    val locationActivities = person.activities.filter { activity =>
      activity.activityType.contains(Constants.EncounterActivityType) && activity.locationDesc.contains(location) &&
        activity.activityDate.after(Date.valueOf(LocalDate.now().minusMonths(6)))
    }

    if (locationActivities.isEmpty) {
      (None, None)
    } else {
      val utilSixMonthLocationVisits = locationActivities.size
      val utilSixMonthLocationDate = locationActivities.maxBy(person =>
        person.dateModified.getOrElse(person.activityDate)).activityDate
      (Some(utilSixMonthLocationVisits), Some(utilSixMonthLocationDate))
    }
  }

  /**
    * Gets the overall encounter metrics
    *
    * @param person
    * @param location
    * @return
    */
  def getOverallEncounterMetrics(person: Person, location: String): (Option[Int], Option[Date]) = {
    val activities = person.activities.filter {
      activity => activity.activityType.contains(Constants.EncounterActivityType) && activity.locationDesc.contains(location)
    }
    if (activities.isEmpty) {
      (None, None)
    } else {
      val utilOverallVisits = activities.size
      val optUtilOverallMaxDate = activities.maxBy(_.activityDate).activityDate
      (Some(utilOverallVisits), Some(optUtilOverallMaxDate))
    }
  }

  /**
    * Gets the non encounter metrics
    *
    * @param person
    * @param location
    * @return
    */
  def getNonEncounterMetrics(person: Person, location: String): (Option[Int], Option[Date]) = {
    val locationActivities = person.activities.filter { activity =>
      activity.locationDesc.contains(location) && activity.activityType.contains(Constants.EncounterActivityType)
    }
    if (locationActivities.isEmpty) {
      (None, None)
    } else {
      val nonUtilRecords = locationActivities.size
      val nonUtilMaxDate = locationActivities.maxBy(_.activityDate).activityDate
      (Some(nonUtilRecords), Some(nonUtilMaxDate))
    }
  }

  /**
    * Ranks locations for persons
    *
    * @param person
    * @param location
    * @return
    */
  def rankLocations(person: Person, metrics: Seq[LocationMetric], allOrApplicable: String): Person = {

    try {

      val utilizationMetricsWithServiceArea: Seq[LocationMetric] = metrics.filter {
        metric => !metric.serviceArea.equals(Constants.NoServiceArea) && metric.utilOverallVisits > 0
      }
      val utilizationMetricsWithoutServiceArea: Seq[LocationMetric] = metrics.filter {
        metric => metric.serviceArea.equals(Constants.NoServiceArea) && metric.utilOverallVisits > 0
      }
      val nonUtilizationMetricsWithServiceArea: Seq[LocationMetric] = metrics.filter {
        metric => !metric.serviceArea.equals(Constants.NoServiceArea) && metric.utilOverallVisits == 0 && metric.nonUtilRecords > 0
      }
      val nonUtilizationMetricsWithoutServiceArea: Seq[LocationMetric] = metrics.filter {
        metric => metric.serviceArea.equals(Constants.NoServiceArea) && metric.utilOverallVisits == 0 && metric.nonUtilRecords > 0
      }
      val justServiceArea: Seq[LocationMetric] = metrics.filter {
        metric => !metric.serviceArea.equals(Constants.NoServiceArea) && metric.utilOverallVisits == 0 && metric.nonUtilRecords == 0
      }
      val justDistance: Seq[LocationMetric] = metrics.filter {
        metric => metric.serviceArea.equals(Constants.NoServiceArea) && metric.utilOverallVisits == 0 && metric.nonUtilRecords == 0
      }

      val listOfLocations: Seq[String] =
        (utilizationMetricsWithServiceArea.sorted.map(_.location)
          ++ utilizationMetricsWithoutServiceArea.sorted.map(_.location)
          ++ nonUtilizationMetricsWithServiceArea.sorted.map(_.location)
          ++ nonUtilizationMetricsWithoutServiceArea.sorted.map(_.location)
          ++ justServiceArea.sorted.map(_.location))

      // Checks if the assembled list of locations is empty. If it is, simply
      // take the closest ranked location and throw it into the list for the
      // person. If it isn't, return the listOfLocations value
      val finalList: List[PersonLocation] = allOrApplicable match {
        case "applicable" =>
          if (listOfLocations.isEmpty) {
            justDistance.sorted.map(_.location).headOption.map(PersonLocation(_, 1)).toList
          } else {
            listOfLocations.zipWithIndex.map {
              case (location, priority) => PersonLocation(location, priority)
            }.toList
          }
        case "all" => (listOfLocations ++ justDistance.sorted.map(_.location)).zipWithIndex.map {
          case (location, priority) => PersonLocation(location, priority)
        }.toList
      }

      person.copy(locations = finalList)
    } catch {
      case e: Throwable => throw new Error(s"Could not rank locations for person: ${person.toString}", e)
    }
  }

}

/*    1) Most visits at current zip code
      2) Most recent visit at current zip code
      3) Most visits in past 6 months
      4) Most visits overall
      5) Most recent visit overall
      6) A person's service area value for the location (e.g. Primary for location 1 > Secondary for location 2)
      7) A person's distance to the location
      8) Alphabetical
   */
case class LocationMetric(
                           location: String,
                           distance: Double,
                           serviceArea: String,
                           utilCurrentZipVisits: Int,
                           utilCurrentZipMaxDate: Int,
                           utilSixMonthVisits: Int,
                           utilSixMonthMaxDate: Int,
                           utilOverallVisits: Int,
                           utilOverallMaxDate: Int,
                           nonUtilRecords: Int,
                           nonUtilMaxDate: Int
                         ) extends Ordered[LocationMetric] {
  def compare(that: LocationMetric): Int = {
    val order = Ordering.Tuple9(
      Ordering.Int.reverse, // util current zip visits (descending)
      Ordering.Int.reverse, // util current zip max date (descending)
      Ordering.Int.reverse, // util six month visits (descending)
      Ordering.Int.reverse, // util overall visits (descending)
      Ordering.Int.reverse, // util overall max date (descending)
      Ordering.Int.reverse, // non-util max date (descending)
      Ordering.String, // service area (ascending)
      Ordering.Double, // distance (ascending)
      Ordering.String) // locationId (ascending)

    order.compare(
      (utilCurrentZipVisits, utilCurrentZipMaxDate, utilSixMonthVisits,
        utilOverallVisits, utilOverallMaxDate, nonUtilMaxDate, serviceArea, distance, location),
      (that.utilCurrentZipVisits, that.utilCurrentZipMaxDate, that.utilSixMonthVisits,
        that.utilOverallVisits, that.utilOverallMaxDate, that.nonUtilMaxDate, that.serviceArea,
        that.distance, that.location))
  }

}

object LocationMetric {

  // noinspection ScalaStyle
  def apply(location: String,
            distance: Double,
            serviceArea: Option[String],
            utilCurrentZipVisits: Option[Int],
            currentEncounterMaxDate: Option[Date],
            utilSixMonthVisits: Option[Int],
            currentSixMonthEncounterMaxDate: Option[Date],
            utilOverallVisits: Option[Int],
            overallEncounterMaxDate: Option[Date],
            nonUtilRecords: Option[Int],
            nonEncounterMaxDate: Option[Date]
           ): LocationMetric = {


    val utilCurrentZipMaxDateInt: Int = currentEncounterMaxDate.getOrElse(Constants.DefaultDate).toLocalDate.format(DateTimeFormatter.BASIC_ISO_DATE).toInt
    val utilSixMonthMaxDateInt: Int = currentSixMonthEncounterMaxDate.getOrElse(Constants.DefaultDate).toLocalDate.format(DateTimeFormatter.BASIC_ISO_DATE).toInt
    val utilOverallMaxDateInt: Int = overallEncounterMaxDate.getOrElse(Constants.DefaultDate).toLocalDate.format(DateTimeFormatter.BASIC_ISO_DATE).toInt
    val nonUtilMaxDateInt: Int = nonEncounterMaxDate.getOrElse(Constants.DefaultDate).toLocalDate.format(DateTimeFormatter.BASIC_ISO_DATE).toInt

    LocationMetric(
      location = location,
      distance = distance,
      serviceArea = serviceArea.getOrElse(Constants.NoServiceArea),
      utilCurrentZipVisits = utilCurrentZipVisits.getOrElse(0),
      utilCurrentZipMaxDate = utilCurrentZipMaxDateInt,
      utilSixMonthVisits = utilSixMonthVisits.getOrElse(0),
      utilSixMonthMaxDate = utilSixMonthMaxDateInt,
      utilOverallVisits = utilOverallVisits.getOrElse(0),
      utilOverallMaxDate = utilOverallMaxDateInt,
      nonUtilRecords = nonUtilRecords.getOrElse(0),
      nonUtilMaxDate = nonUtilMaxDateInt
    )
  }
}
