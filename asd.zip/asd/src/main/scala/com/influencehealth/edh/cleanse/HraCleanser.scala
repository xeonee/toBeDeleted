package com.influencehealth.edh.cleanse

import com.influencehealth.edh.Constants
import com.influencehealth.edh.model.activitytype.ActivityType
import com.influencehealth.edh.utils.{CleanseUtils, PersonUtils}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class HraCleanser(val dateBatchReceived: String) extends DataCleanser {

  this: ActivityType =>


  override def cleanseData(
                            df: DataFrame,
                            customer: Option[String],
                            batchId: String
                          ): (DataFrame, DataFrame) = {

    // Apply default values for Required Columns if found NULL
    val defaultCodeForRequiredColumnsContainingNulls: DataFrame = assignDefaultValuesForRequiredColumnsContainingNulls(df)

    // filters required columns that are not null
    val (dataFrameContainingNonNullColumns, dataFrameContainingNullColumns) =
      filterRequiredColumnsContainingInvalidValues(
        defaultCodeForRequiredColumnsContainingNulls, nullColumnNames, mandatoryContactColumnsNames)

    // cleanses & filters Date column
    val dataFrameContainingValidDateColumns = formatDateColumns(dataFrameContainingNonNullColumns)

    // Cleanses String Column
    val dataFrameContainingCleansedStringColumns = cleanseStringColumns(dataFrameContainingValidDateColumns,
      cleanseStringColumnNames)

    // Cleanses Contact details: Phone numbers and emails
    val dataFrameContainingCleansedContactDetails = cleanseContactDetails(dataFrameContainingCleansedStringColumns)


    // Cleanse zip5 column
    val cleansedZips = cleanseZips(dataFrameContainingCleansedContactDetails)

    // Aliases Data
    val aliasedData = aliasData(cleansedZips, customer)

    (aliasedData, dataFrameContainingNullColumns)

  }

  override def formatDateColumns(df: DataFrame): DataFrame = {
    import df.sqlContext.implicits._
    // Convert string date into Date type columns after validating the dates, known behavior

    val formattedDatesDataFrame = df
      .withColumn("dateOfBirth", CleanseUtils.timestampToDate(PersonUtils.validateInputDate(
        date_format(unix_timestamp($"dateOfBirth", "yyyy-MM-dd").cast("timestamp"), "yyyy-MM-dd"))))

    formattedDatesDataFrame
  }

  override def cleanseStringColumns(df: DataFrame, stringColumnsToBeCleansed: Seq[String]): DataFrame = {
    stringColumnsToBeCleansed.foldLeft(df)((curr, n) => curr.withColumn(n, CleanseUtils.cleanseStringColumns(curr(n))))
  }

  override def assignDefaultValuesForRequiredColumnsContainingNulls(df: DataFrame): DataFrame = {
    val addingColumnNames: DataFrame = df.
      withColumn("source", lit(defaultSource)).
      withColumn("sourceRecordId", col("transactionId")).
      withColumn("source", lit(defaultSource)).
      withColumn("sourceType", lit(defaultSourceType)).
      withColumn("messageType", lit(defaultMessageType))
    addingColumnNames
  }


  override def aliasData(df: DataFrame, customer: Option[String]): DataFrame = {
    val aliasedDf = super.aliasData(df, customer)
      .withColumn("activityId", df("transactionId"))
      .withColumn("activityDate", df("transactionDate"))
      .withColumn("activityGroupId", df("assessmentCode"))
      .withColumn("activityGroup", df("assessmentDescription"))

    import df.sqlContext.implicits._
    val formattedDatesDf = aliasedDf.withColumn("activityDate",
      when(col("activityDate").isNotNull, date_format(unix_timestamp($"activityDate", "yyyy-MM-dd")
        .cast("timestamp"), "yyyy-MM-dd")) otherwise Constants.Today.toString("yyyy-MM-dd"))

    formattedDatesDf
  }

  /** Validates the email and phone number columns
    *
    * @param df
    * @return formated coloumn
    **/
  private def cleanseContactDetails(df: DataFrame): DataFrame = {
    df
      .withColumn("emails", getStringToArray(CleanseUtils.cleanseAndValidateEmail(df("emails"))))
      .withColumn("phoneNumbers", CleanseUtils.cleanseAndParsePhones(col("phoneNumbers")))
  }

  /**
    * Filter out the required columns containing null values
    *
    * @param df
    * @param nullColumns
    * @return filtered dataFrame with columns which do not contain null for required columns &
    *         dirty dataFrame with columns that contains null for required columns
    */
  private def filterRequiredColumnsContainingNullValues(df: DataFrame, nullColumns: Seq[String]):
  (DataFrame, DataFrame) = {
    val methodOfContactNulls: Seq[String] = Seq("emails", "phoneNumbers", "address1")
    CleanseUtils.filterRequiredColumnsValues(df, nullColumns, methodOfContactNulls)
  }


  /** Cleanse zip values
    *
    * @param df
    * @return
    */
  private def cleanseZips(df: DataFrame): DataFrame = {
    val x = df.withColumn("zip4", CleanseUtils.get_zip4(df("zip5"))).
      withColumn("zip5", CleanseUtils.get_zip5(df("zip5")))
    x
  }

}
