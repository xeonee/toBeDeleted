package com.influencehealth.edh.refresh.reporting.transformer

import com.influencehealth.edh.model.{CollapseHistory, Person}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset}

class PersonTransformer(
                         personsData: Dataset[Person],
                         personArchiveData: Dataset[Person],
                         collapseHistoryData: Dataset[CollapseHistory]
                       ) extends BaseTransformer with Serializable {

  import personsData.sparkSession.implicits._

  def persons: DataFrame = personsData.
    withColumn("person_record_id",
      concat_ws("::", $"customer_id", $"person_id")).
    transform(_.drop("activities")).
    transform(transformArrayTypes).
    transform(transformStructTypes).
    transform(dropComplexTypes)

  def personArchives: DataFrame = personArchiveData.
    withColumn("person_record_id", concat_ws("::", $"customer_id", $"person_id")).
    where(!$"column_name".isin("recipes", "propensities")).
    transform(dropComplexTypes)

  def collapseHistory: DataFrame = collapseHistoryData.
    withColumn("person_record_id", concat_ws("::", $"customer_id", $"retained_person_id")).
    transform(dropComplexTypes)

}