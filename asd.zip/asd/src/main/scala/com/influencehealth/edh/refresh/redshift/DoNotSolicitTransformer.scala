package com.influencehealth.edh.refresh.redshift

import com.influencehealth.edh.model.DoNotSolicitEmail
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.apache.spark.storage.StorageLevel

private[redshift] class DoNotSolicitTransformer(doNotSolicitData: Dataset[DoNotSolicitEmail],
                                                sparkSession: SparkSession
                                               ) extends BaseTransformer with Serializable {

  val deNormalizedDoNotSolicitData: DataFrame = doNotSolicitData.toDF.
    persist(StorageLevel.MEMORY_ONLY)

  val doNotSolicit: DataFrame =
    deNormalizedDoNotSolicitData.transform(dropComplexTypes).transform(aliasColumnsToSnakeCase)

  val close: Unit = doNotSolicit.unpersist()
}
