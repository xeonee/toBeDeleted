package com.influencehealth.edh.utils.filesystem

import java.time.LocalDate

import com.influencehealth.edh.Constants

import scala.util.matching.Regex

case class PathInfo(bucketName: String,
                    source: String,
                    activityType: String,
                    activityFormat: String,
                    batchYear: Option[String],
                    batchMonth: Option[String],
                    batchDay: Option[String],
                    batchPhase: String
                   )

object PathInfo {

  def apply(inputFilePath: String, batchPhase : String): PathInfo = {
    val RawS3PathRegex = batchPhase match {
      case Constants.batchRawPhase => "(s3a:\\/\\/|s3n:\\/\\/|file:\\/\\/\\/)(cdp-data-[a-z]+)\\/([a-z_]+)\\/raw\\/([a-z]+)\\/([a-z]+)\\/([0-9]{4})-([0-9]{2})(-([0-9]{2}))?\\/".r(
        "fileType", "bucketName", "source", "activityType", "activityFormat", "batchYear", "batchMonth", "overall", "batchDay")
      case Constants.batchCleansedPhase => "(s3a:\\/\\/|s3n:\\/\\/|file:\\/\\/\\/)(cdp-data-[a-z]+)\\/([a-z_]+)\\/cleansed\\/([a-z]+)\\/([a-z]+)\\/([0-9]{4})-([0-9]{2})(-([0-9]{2}))?\\.parquet/".r(
        "fileType", "bucketName", "source", "activityType", "activityFormat", "batchYear", "batchMonth", "overall", "batchDay", "parquetExtension")
    }

    val pattern: Regex.Match = RawS3PathRegex.findFirstMatchIn(inputFilePath).get

    // val fileType: String = pattern.group("fileType")

    val bucketName: String = pattern.group("bucketName")

    val source: String = pattern.group("source")

    val activityType: String = pattern.group("activityType")

    val activityFormat: String = pattern.group("activityFormat")

    val batchYear = Option(pattern.group("batchYear"))

    val batchMonth = Option(pattern.group("batchMonth"))

    val batchDay = Option(pattern.group("batchDay"))

    new PathInfo(
      bucketName= bucketName,
      source = source,
      activityType = activityType,
      activityFormat = activityFormat,
      batchYear = batchYear,
      batchMonth = batchMonth,
      batchDay = batchDay,
      batchPhase = batchPhase
    )
  }

  def apply(batchId: String,
            bucketUrl: String,
            batchPhase: String): PathInfo = {
    val BatchIdRegex =
      "([a-z]+)\\-([a-z]+)\\-([a-z]+)\\-([0-9]{4})-([0-9]{2})(-([0-9]{2}))?".r(
        "source", "activityType", "activityFormat", "batchYear", "batchMonth", "overall", "batchDay")

    val pattern: Regex.Match = BatchIdRegex.findFirstMatchIn(batchId).get

    // val fileType: String = pattern.group("fileType")

    val bucketName: String = bucketUrl.replace("s3a://", "")

    val source: String = pattern.group("source")

    val activityType: String = pattern.group("activityType")

    val activityFormat: String = pattern.group("activityFormat")

    val batchYear = Option(pattern.group("batchYear"))

    val batchMonth = Option(pattern.group("batchMonth"))

    val batchDay = Option(pattern.group("batchDay"))

    new PathInfo(
      bucketName = bucketName,
      source = source,
      activityType = activityType,
      activityFormat = activityFormat,
      batchYear = batchYear,
      batchMonth = batchMonth,
      batchDay = batchDay,
      batchPhase = batchPhase
    )
  }

  def apply(source: String,
            activityType: String,
            activityFormat: String,
            sinceDate: LocalDate,
            bucketUrl: String,
            batchDays: Option[Int],
            batchPhase: String
           ): PathInfo = {

    val bucketName: String = bucketUrl.split("/").last

    new PathInfo(
      bucketName = bucketName,
      source = source,
      activityType = activityType,
      activityFormat = activityFormat,
      batchYear = Some(sinceDate.getYear.toString),
      batchMonth = Some(sinceDate.getMonth.toString),
      batchDay = if (batchDays.nonEmpty || activityType.contains("redox")) {Some(sinceDate.getDayOfMonth.toString)} else None,
      batchPhase = batchPhase
    )
  }

  def apply(source: String,
            activityType: String,
            activityFormat: String,
            bucketUrl: String,
            batchPhase: String
           ): PathInfo = {

    val bucketName: String = bucketUrl.split("/").last

    new PathInfo(
      bucketName = bucketName,
      source = source,
      activityType = activityType,
      activityFormat = activityFormat,
      batchYear = None,
      batchMonth = None,
      batchDay = None,
      batchPhase = batchPhase
    )
  }
}