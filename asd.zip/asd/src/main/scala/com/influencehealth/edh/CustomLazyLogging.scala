package com.influencehealth.edh

import com.typesafe.config.Config
import com.typesafe.scalalogging.LazyLogging


trait CustomLazyLogging {

  protected lazy val logger: LoggingUtils =  SingletonLazyLogging.logger

}

object SingletonLazyLogging {

  val logger: LoggingUtils =  new LoggingUtils()
}

case class CountMismatchException(message: String) extends Exception(message)


class LoggingUtils extends LazyLogging with Serializable {

  def info(message: String): Unit = logger.info(message)

  def info(message: String, args: Any*): Unit = logger.info(message, args)

  def warn(message: String): Unit = logger.info(message)

  def warn(message: String, args: Any*): Unit = logger.info(message, args)

  def debug(message: String): Unit = logger.debug(message)

  def debug(message: String, args: Any*): Unit = logger.debug(message, args)

  def error(message: String): Unit = logger.error(message)

  def error(message: String, args: Any*): Unit = logger.error(message, args)

  def warnCountMismatch(message: String)(implicit appConfig: Config): Unit = {
    if (appConfig.hasPath("app.countmismatch.error") && appConfig.getBoolean("app.countmismatch.error")) {
      throw CountMismatchException(message)
    } else {
      logger.warn(message)
    }
  }

  def warnCountMismatch(message: String, args: Any*)(implicit appConfig: Config): Unit = {
    if (appConfig.hasPath("app.countmismatch.error") && appConfig.getBoolean("app.countmismatch.error")) {
      throw CountMismatchException(message)
    } else {
      logger.warn(message, args)
    }
  }

}
