package com.influencehealth.edh.refresh.leads

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

import com.influencehealth.edh.config.RefreshJobConfig
import com.influencehealth.edh.dao.DatabaseDao
import com.influencehealth.edh.lookups.client.LookupsClient
import com.influencehealth.edh.model.schema.PersuadeLeadSchema
import com.influencehealth.edh.model.{IdentifiedLead, Person, UnIdentifiedLead}
import com.influencehealth.edh.{BaldurApplication, SuccessfulBaldurJob}
import com.typesafe.config.Config
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Dataset, SparkSession}
import org.joda.time.DateTime
import org.joda.time.format.{DateTimeFormat, DateTimeFormatterBuilder, ISODateTimeFormat}

import scala.util.{Success, Try}


object LeadsRefreshJob extends BaldurApplication[RefreshJobConfig] {

  private val StandardDateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd")
  var inputLeadsCount: Option[Long] = None


  override def runJob(
                       implicit sparkSession: SparkSession,
                       config: RefreshJobConfig,
                       databaseDao: DatabaseDao
                     ) = {

    import sparkSession.implicits._
    // Spark config
    // TODO: Configure to pass in load path
    val inputPath: String = "s3a://"

    val leads = loadLeads(inputPath, config.customer).repartition(16)

    inputLeadsCount = Some(leads.count)

    // Load persons from the cassandra person_master table.
    val dbPersons: Dataset[Person] = getPersons(databaseDao, config.customer)

    val matchedLeads: Dataset[IdentifiedLead] = matchLeadsWithDbPersons(leads, dbPersons)

    logger.info("Number of leads: " + leads.count())
    logger.info("Number of matched leads: " + matchedLeads.count())
    logger.info(s"Saving matched lead records to db")

    databaseDao.saveIdentifiedLeads(matchedLeads)

    val uniqueLeads = matchedLeads.select($"leadId").distinct().count()
    val totalPersons = matchedLeads.select($"personId").count()
    val uniquePersons = matchedLeads.select($"personId").distinct().count()

    val sixMonthsAgo = java.time.LocalDate.now().minusMonths(6).format(StandardDateFormat)
    val validLeads = matchedLeads
      .where($"created".leq(sixMonthsAgo))

    logger.info(s"Six months ago: $sixMonthsAgo")
    logger.info(s"Leads older than 6 months: ${validLeads.count()}")
    logger.info(s"Leads older than 6 months with personIds: ${validLeads.where($"personId".isNotNull).count()}")
    logger.info(s"Matched $uniqueLeads unique leads to $totalPersons and $uniquePersons persons")

  }

  override def buildConfig(appConfig: Config, lookupsClient: LookupsClient): RefreshJobConfig = {
    RefreshJobConfig(appConfig)
  }

  override def countInputRecords = {
    inputLeadsCount
  }

  override def countOutputRecords = {
    inputLeadsCount
  }

  /**
    * Identifies set of persons that contain the necessary information
    * to match input leads records
    *
    * @param datahubDao DAO for loading persons into memory
    * @return
    */
  def getPersons(datahubDao: DatabaseDao, customer: String): Dataset[Person] = {

    val persons = datahubDao.getPersonsByCustomer(customer)

    import persons.sparkSession.implicits._

    persons
      .where(
        """
          | (address1 IS NOT NULL AND zip5 IS NOT NULL AND firstName IS NOT NULL AND lastName IS NOT NULL) OR
          | (primaryEmail IS NOT NULL AND lastName IS NOT NULL AND firstName IS NOT NULL) OR
          | (primaryPhoneNumber IS NOT NULL AND lastName IS NOT NULL AND firstName IS NOT NULL) OR
          | (dateOfBirth IS NOT NULL AND lastName IS NOT NULL AND firstName IS NOT NULL) OR
          | (address1 IS NOT NULL AND zip5 IS NOT NULL AND lastName IS NOT NULL) OR
          | (zip5 IS NOT NULL AND firstName IS NOT NULL AND lastName IS NOT NULL) OR
          | (address1 IS NOT NULL AND zip5 IS NOT NULL AND firstName IS NOT NULL)
        """.stripMargin).
      withColumn("dateOfBirth", encode_date_of_birth($"dateOfBirth")).
      withColumn(
        "primaryPhoneNumber",
        regexp_replace($"primaryPhoneNumber", "\\+1", "")).
      withColumn(
        "primaryPhoneNumber",
        regexp_replace($"primaryPhoneNumber", "[^\\d]+", "")).
      filter(
        $"primaryPhoneNumber".isNull || $"primaryPhoneNumber" =!= lit("0000000000")).as[Person]

  }


  def loadLeads(leadFilePath: String, customer: String)(implicit spark: SparkSession): Dataset[UnIdentifiedLead] = {
    import spark.implicits._

    def cleanZip = udf((zip: String) => zip match {
      case null => None
      case x => x.trim match {
        case z if z.contains(".") => Some(z.slice(0, z.indexOf(".")))
        case z if z.nonEmpty => Some(z)
        case z => None
      }
    })

    spark.read
      .option("header", "true")
      // .option("inferSchema", "true") this breaks because the data can be messy
      .schema(PersuadeLeadSchema.schema)
      .csv(leadFilePath)
      .withColumn("customerKey", lit(customer).as("customerKey"))
      .withColumn("callerId", regexp_replace(col("callerId"), "\\+1", ""))
      .withColumn("callerId", regexp_replace(col("callerId"), "[^\\d]+", ""))
      .withColumn("phone", regexp_replace(col("phone"), "\\+1", ""))
      .withColumn("phone", regexp_replace(col("phone"), "[^\\d]+", ""))
      .filter(col("callerId").isNull || col("callerId") =!= "0000000000")
      .filter(col("phone").isNull || col("phone") =!= "0000000000")
      .withColumn("dob", encode_date_of_birth($"dob"))
      .withColumn("created", created_date($"created")) // TODO change this to use builtin date parsing if possible
      .withColumn("zip", cleanZip($"zip")).
      as[UnIdentifiedLead]
  }

  def matchLeadsWithDbPersons(
                               leads: Dataset[UnIdentifiedLead],
                               dbPersons: Dataset[Person]
                             ): Dataset[IdentifiedLead] = {

    import leads.sparkSession.implicits._

    // Match input leads with person_master customer based on the email, phone number or caller id
    // and first and last name
    val matchedLeads = leads
      .join(dbPersons,
        (upper(leads("firstName")) === upper(dbPersons("firstName"))
          && upper(leads("lastName")) === upper(dbPersons("lastName"))
          && leads("dob") === dbPersons("dateOfBirth"))
          || (upper(leads("firstName")) === upper(dbPersons("firstName"))
          && upper(leads("lastName")) === upper(dbPersons("lastName"))
          && leads("zip") === dbPersons("zip5"))
          || upper(leads("email")) === upper(dbPersons("primaryEmail"))
          || (leads("phone") === dbPersons("primaryPhoneNumber") ||
          leads("callerId") === dbPersons("primaryPhoneNumber")),
        "left_outer")
      .select(
        leads("leadId"),
        leads("firstName"),
        leads("lastName"),
        leads("street1"),
        leads("callerId"),
        leads("phone"),
        leads("email"),
        leads("city"),
        leads("state"),
        leads("zip"),
        leads("created"),
        leads("dob"),
        leads("customerKey"),
        col("personId"))


    matchedLeads.as[IdentifiedLead]
  }

  private val encode_date_of_birth = udf((dob: String) => {
    Option(dob).flatMap(encodeDob)
  })

  private val created_date = udf((dateString: String) =>
    Option(dateString).map(str =>
      java.sql.Date.valueOf(LocalDateTime.parse(str, DateTimeFormatter.ofPattern("M/d/yyyy H:mm")).toLocalDate))
  )

  private lazy val dateParsers = Array(
    ISODateTimeFormat.dateOptionalTimeParser().getParser,
    ISODateTimeFormat.dateHour().getParser,
    DateTimeFormat.forPattern("yyyy/MM/dd").getParser,
    DateTimeFormat.forPattern("MMddyyyy").getParser,
    DateTimeFormat.forPattern("yyyyMMdd").getParser,
    DateTimeFormat.forPattern("yyyy-MM-dd").getParser,
    DateTimeFormat.forPattern("MM/dd/yyyy").getParser,
    DateTimeFormat.forPattern("MM-dd-yyyy").getParser,
    DateTimeFormat.forPattern("yyyy-MM-dd H:mm:ss").getParser,
    DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ssZ").getParser,
    DateTimeFormat.forPattern("yyyy/MM/dd H:mm:ss").getParser,
    DateTimeFormat.forPattern("dd-MMM-yy").getParser,
    DateTimeFormat.forPattern("dd MMM yy").getParser,
    DateTimeFormat.forPattern("MMyyyy").getParser,
    DateTimeFormat.forPattern("MMyy").getParser,
    DateTimeFormat.forPattern("MM/yyyy").getParser,
    DateTimeFormat.forPattern("MM/yy").getParser)

  private lazy val dateTimeFormatter = new DateTimeFormatterBuilder().append(null, dateParsers).toFormatter

  def encodeDob(dob: String): Option[String] =
    Try(DateTime.parse(dob, dateTimeFormatter).toString("MMyyyy")) match {
      case Success(dobStr) if dobStr.forall(Character.isDigit) => Some(dobStr)
      case _ => None
    }

}
