package com.influencehealth.edh.model

import java.io.{ByteArrayInputStream, InputStream}
import java.sql.{Date, Timestamp}
import java.text.SimpleDateFormat
import java.util.TimeZone

import com.influencehealth.edh.utils.FirstNameRoot
import com.rockymadden.stringmetric.phonetic.SoundexAlgorithm
import org.apache.commons.codec.digest.DigestUtils

trait PrimaryIdentity {

  val customer: String

  val mrids: Seq[String]

  val firstName: Option[String]

  val middleName: Option[String]

  val lastName: Option[String]

  val personalSuffix: Option[String]

  val dateOfBirth: Option[Date]

  val dateCreated: Timestamp

  val sourceAge: Option[Int]

  val sex: Option[String]

  val address1: Option[String]

  val address2: Option[String]

  val streetSecondNumber: Option[String]

  val zip5: Option[String]

  val primaryEmail: Option[String]

  val primaryPhoneNumber: Option[String]

  val primaryPhoneNumberType: Option[String]

  def rootFirstName: Option[String] = FirstNameRoot.getRootName(firstName, sex)

  def soundexLastName: Option[String] = lastName.flatMap(SoundexAlgorithm.compute)

  def generatePersonId(): String = {

    if (firstName.isEmpty || lastName.isEmpty) {
      throw new RuntimeException(
        s"Tried to create invalid id. firstname(${firstName.getOrElse("EMPTY")}), " +
          s"lastname(${lastName.getOrElse("EMPTY")}), dateOfBirth(${dateOfBirth.getOrElse("EMPTY")})," +
          s" age(${sourceAge.getOrElse("EMPTY")}), and sex(${sex.getOrElse("EMPTY")}) must be populated.")
    }

    val timeZone: TimeZone = TimeZone.getTimeZone("UTC")
    var dateOfBirthString: String = ""

    if (!dateOfBirth.isEmpty || !sourceAge.isEmpty) {
      dateOfBirthString = dateOfBirth.
        map { date =>
          val dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm'Z'")
          dateFormat.setTimeZone(timeZone)
          dateFormat.format(date)
        }.map(_.toUpperCase)
        .getOrElse {
          val calculateDob = dateCreated.toLocalDateTime.minusYears(sourceAge.get)
          val dob = Timestamp.valueOf(calculateDob)
          val dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm'Z'")
          dateFormat.setTimeZone(timeZone)
          dateFormat.format(dob)
        }
    }

    val byteArray: Array[Byte] =
      customer.toString.getBytes() ++
        mrids.toList.sorted.map(_.getBytes()).foldLeft(Array.emptyByteArray)(_ ++ _) ++
        firstName.map(_.toUpperCase).getOrElse("").getBytes() ++
        middleName.map(_.toUpperCase).getOrElse("").getBytes() ++
        lastName.map(_.toUpperCase).getOrElse("").getBytes() ++
        personalSuffix.map(_.toUpperCase).getOrElse("").getBytes() ++
        dateOfBirthString.getBytes() ++
        sex.map(_.toUpperCase).getOrElse("").getBytes()

    val inputStream: InputStream = new ByteArrayInputStream(byteArray)

    DigestUtils.md5Hex(inputStream)
  }
}
