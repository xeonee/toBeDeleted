package com.influencehealth.edh.refresh.elasticsearch

import java.time.format.DateTimeFormatter
import java.time.{LocalDate, LocalDateTime}

import com.google.gson.{JsonObject, JsonParser}
import com.influencehealth.edh.BaldurApplication
import com.influencehealth.edh.config._
import com.influencehealth.edh.dao.DatabaseDao
import com.influencehealth.edh.lookups.client.LookupsClient
import com.typesafe.config.Config
import org.apache.spark.SparkFiles
import org.apache.spark.sql._
import org.elasticsearch.hadoop.EsHadoopIllegalArgumentException
import org.elasticsearch.spark.sql.EsSparkSQL

import scala.util.{Failure, Success, Try}

object ElasticsearchRefreshJob extends BaldurApplication[RefreshJobConfig] {

  var inputRecordCount: Option[Long] = None
  var outputRecordCount: Option[Long] = None

  override def runJob(
                       implicit sparkSession: SparkSession,
                       config: RefreshJobConfig,
                       databaseDao: DatabaseDao
                     ) = {

    val aliasName: String = config.customer

    // person-mapping.json and analyzers.json are added in spark submit script.
    val personMapping: JsonObject = getJsonFile("person-mapping.json")

    val analysisConfiguration: JsonObject = getJsonFile("analyzers.json")

    val elasticsearchConfig: ElasticsearchConfig = config.elasticsearchConfig

    val indexManager: IndexManager = new IndexManager(elasticsearchConfig)

    val elasticsearchDao: ElasticsearchDao = new ElasticsearchDao(elasticsearchConfig, personMapping)

    // Elasticsearch full refresh: creates a new index with customer_currentTimestamp. If index creation is
    // successful then it points the current index to the new created index.
    // Elasticsearch incremental refresh: upserts persons to the current index. If there is a failure in this process,
    // re-run the incremental update

    try {
      if (config.fullRefresh) {
        // TODO: Move this format to config
        val dateFormatter = DateTimeFormatter.ofPattern("YMMddHHmmss")
        val postfix = LocalDateTime.now().format(dateFormatter)
        val indexName: String = s"${config.customer}_$postfix"
        // create a new index, configure analyzer and apply person mappings
        indexManager.setupIndex(
          indexName,
          elasticsearchConfig.numberOfReplicas,
          elasticsearchConfig.numberOfShards,
          personMapping,
          analysisConfiguration
        )
        // Disable replicating index simultaneously as writing to it
        indexManager.disableRefreshAndReplicaForInitialLoad(indexName)
        // load all data in bulk into the new index
        bulkLoadAllCustomerData(indexName, config.customer, databaseDao, elasticsearchDao,
          sparkSession, elasticsearchConfig)
        // Re-enable replication of index
        indexManager.reenableRefreshAndReplicaAfterInitialLoad(indexName, elasticsearchConfig)

        val secondsToWaitInBetweenRequest = 60
        val maxNumberOfSecondsToWaitTotal = 30 * 60
        val numberOfRetriesToIssue = 30

        // point to the new created index
        indexManager.swapAlias(
          indexName, aliasName, secondsToWaitInBetweenRequest, maxNumberOfSecondsToWaitTotal, numberOfRetriesToIssue)
        // delete all older indexes
        indexManager.cleanUpOldIndices(config.customer)

      } else {
        if (config.batchId.nonEmpty && config.sinceDate.nonEmpty) {
          throw new RuntimeException("Specify either batchId or since date not both")
        }
        // incrementally updating the current index
        incrementallyRefreshIndex(config.customer, databaseDao, config.batchId, config.sinceDate, elasticsearchDao)
      }
    } catch {
      case err: Throwable =>
        logger.error("Failed to refresh index")
        throw err
    } finally {
      indexManager.close
    }

  }

  override def buildConfig(appConfig: Config, lookupsClient: LookupsClient): RefreshJobConfig = {
    RefreshJobConfig(appConfig)
  }

  override def countInputRecords = {
    inputRecordCount
  }

  override def countOutputRecords = {
    outputRecordCount
  }

  /**
    * Reading the json files into a json object
    * @param fileName
    * @return
    */
  private def getJsonFile(fileName: String): JsonObject = {
    Try(SparkFiles.get(fileName)) match {
      case Success(path) =>
        val source = scala.io.Source.fromFile(path)
        val parser: JsonParser = new JsonParser()
        val lines = try source.mkString finally source.close()
        parser.parse(lines).getAsJsonObject
      case Failure(e) =>
        throw new RuntimeException(s"Unable to read file $fileName", e)
    }
  }

  /**
    * Gets all data for a customer and inserts it to elastic search
    *
    * @param indexName
    * @param customer
    * @param databaseDao
    * @param elasticsearchDao
    */
  private def bulkLoadAllCustomerData(
                                       indexName: String,
                                       customer: String,
                                       databaseDao: DatabaseDao,
                                       elasticsearchDao: ElasticsearchDao,
                                       sparkSession: SparkSession,
                                       elasticsearchConfig: ElasticsearchConfig
                                     ): Unit = {
    val persons = databaseDao.getPersonsByCustomer(customer, full = false)
    if (!persons.head(1).nonEmpty) {
      throw new RuntimeException(s"No records present in the persons table for the input customer: $customer")
    }
    val activities = databaseDao.getActivitiesByCustomer(customer)
    // This try block added to catch known exception, that is when we run ES Refresh first time, EsSparkSQL.esDF method
    // will return cannot find mapping for given index error, hence added logic to save new index in ES after catching
    // this Exception.
    try{
      val bulkReadOptions: Map[String, String] = elasticsearchDao.buildBaseOptions(elasticsearchConfig) ++
        Map("es.read.field.include" -> "personId")
      val esToDF = EsSparkSQL.esDF(sparkSession, customer, bulkReadOptions)
      val totalExistingPersonsCount = esToDF.count()
      val commonPersons: DataFrame = esToDF.join(persons, Seq("personId"), "left_semi")
      val commonPersonsCount = commonPersons.count()
      val existingIndexPercentageInInputIndex = calculatePercentage(commonPersonsCount, totalExistingPersonsCount)
      if ((existingIndexPercentageInInputIndex >= elasticsearchConfig.thresholdValue) || elasticsearchConfig.force){
        elasticsearchDao.insertPersons(persons, activities, s"$indexName/person")
      }else{
        throw new RuntimeException(s"Existing Index data is having only $existingIndexPercentageInInputIndex% match " +
          s"with the new input index data, to save this index in elastic search, re-run the job with --force option")
      }
    }catch{
      case e: EsHadoopIllegalArgumentException => if (e.toString.contains(s"Cannot find mapping for $customer")){
        elasticsearchDao.insertPersons(persons, activities, s"$indexName/person")
      }else{
        throw new RuntimeException(e)
      }
      case err: Exception => throw err
    }
  }

  /**
    * Fetch persons based on batch-id/since and upserts them to the current index
    * @param customer
    * @param databaseDao
    * @param batchId
    * @param since
    * @param elasticsearchDao
    */
  private def incrementallyRefreshIndex(
                                         customer: String,
                                         databaseDao: DatabaseDao,
                                         batchId: Option[String] = None,
                                         since: Option[LocalDate] = None,
                                         elasticsearchDao: ElasticsearchDao
                                       ): Unit = {

    val (persons, activities) = if (batchId.nonEmpty) {
      (
        databaseDao.getPersonsByBatchId(batchId.get, full = false),
        databaseDao.getActivitiesRelatedToBatchUpdate(batchId.get))
    } else {
      (
        databaseDao.getPersonsUpdatedSince(since.get, customer, false),
        databaseDao.getActivitiesRelatedToUpdatedSince(since.get, customer))
    }

    elasticsearchDao.upsertPersons(persons, activities, s"$customer/person")
  }
  /**
    * calculates percentage
    *
    * @param valueCount numerator of the fraction
    * @param totalCount denominator of the franction
    */
  def calculatePercentage(valueCount: Long, totalCount: Long): Double = {
    val percent: Double = if (totalCount > 0) {
      (valueCount.toFloat / totalCount.toFloat) * 100.0
    }
    else {
      0.0
    }
    percent
  }

}
