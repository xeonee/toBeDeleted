package com.influencehealth.edh

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

import com.influencehealth.edh.config.DataScienceConfig
import com.influencehealth.edh.dao.DatabaseDao
import com.influencehealth.edh.lookups.client.LookupsClient
import com.influencehealth.edh.utils.PersonUtils
import com.typesafe.config.Config
import org.apache.spark.sql.{Column, SparkSession}

object DataScienceModelPull extends BaldurApplication[DataScienceConfig] {

  var inputRecordCount: Option[Long] = None
  var outputRecordCount: Option[Long] = None

  override def runJob(
                       implicit sparkSession: SparkSession,
                       config: DataScienceConfig,
                       databaseDao: DatabaseDao
                     ) = {

    import sparkSession.implicits._

    val customer: String = config.customer

    val columns: Seq[Column] = config.requiredColumns.map {
      case "age" =>
        PersonUtils.compute_age($"dateOfBirth", $"sourceAge", $"dateSourceAgeReceived")
      case columnName =>
        $"$columnName"
    }

    val persons = databaseDao.getPersonsByCustomer(customer, full = false).select(columns:_*)

    val inputPath = s"s3a://${config.inputS3Bucket}/$customer/${config.modelName}/".toLowerCase()

    val dateFormatter = DateTimeFormatter.ofPattern("YMMddHHMS")
    val postfix = LocalDateTime.now().format(dateFormatter)
    val fileName: String = s"${customer}_scored_$postfix.csv".toLowerCase()
    val delimiter: String = ","

    val scoredPersons = sparkSession.read.csv(s"$inputPath$fileName")

    databaseDao.getPersonsByCustomer(customer, full = false)
  }

  override def buildConfig(appConfig: Config, lookupsClient: LookupsClient) = {
    DataScienceConfig(appConfig)
  }

  override def countInputRecords = {
    inputRecordCount
  }

  override def countOutputRecords = {
    outputRecordCount
  }
}
