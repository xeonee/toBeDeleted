package com.influencehealth.edh.model

import java.sql.{Date, Timestamp}

import com.google.gson.reflect.TypeToken
import com.influencehealth.edh.Constants
import com.influencehealth.edh.model.Activity.{cleanseAddressCoordinates, cleanseRowCollectionField, cleanseRowField}
import com.influencehealth.edh.utils.SerializationUtils
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.{Column, DataFrame, Row}

import scala.collection.JavaConverters._
import scala.reflect.ClassTag
import scala.util.Try

case class Coordinates(
                        lat: Float,
                        lon: Float
                      )

case class PersonLocation(
                           location: String,
                           preference: Int
                         ) {
  override def toString: String = s"""{ "location": "${location.trim}", "preference": "$preference" }"""
}

case class PersonPhoneNumber(
                              phone: String,
                              phoneType: String = Constants.PhoneTypeMobile
                            ) {
  override def toString: String =
    s"""{ "phone": "${phone.trim}", "phoneType": "$phoneType" }"""
}

case class Person(
                   // Primary Identifiers
                   customer: String,
                   personId: String,
                   addressId: Option[String] = None,
                   dateCreated: Timestamp,
                   dateModified: Option[Timestamp] = None,
                   mrids: Seq[String] = Seq.empty,

                   // Demographic
                   sourceFirstName: Option[String] = None,
                   firstName: Option[String] = None,
                   sourceMiddleName: Option[String] = None,
                   middleName: Option[String] = None,
                   sourceLastName: Option[String] = None,
                   lastName: Option[String] = None,
                   prefix: Option[String] = None,
                   personalSuffix: Option[String] = None,
                   professionalSuffix: Option[String] = None,
                   dateOfBirth: Option[Date] = None,
                   dateOfDeath: Option[Date] = None,
                   isDeceased: Option[Boolean] = None,
                   sourceAge: Option[Int] = None,
                   dateSourceAgeReceived: Option[Date] = None,
                   sex: Option[String] = None,
                   hasSexConflict: Option[Boolean] = None,
                   financialClass: Option[String] = None,
                   payerType: Option[String] = None,
                   payerTypeDescription: Option[String] = None,
                   inferredPayerType: Option[String] = None,
                   maritalStatus: Option[String] = None,
                   race: Option[String] = None,
                   portalStatus: Option[String] = None,
                   religion: Option[String] = None,
                   isoLanguageCode: Option[String] = None,
                   isoLanguageDesc: Option[String] = None,
                   employer: Option[String] = None,
                   occupationGroup: Option[String] = None,
                   occupation: Option[String] = None,
                   primaryPhoneNumber: Option[String] = None,
                   primaryPhoneNumberType: Option[String] = None,
                   phoneNumbers: Seq[PersonPhoneNumber] = Seq.empty,
                   primaryEmail: Option[String] = None,
                   emails: Seq[String] = Seq.empty,
                   dwellType: Option[String] = None,
                   combinedOwner: Option[String] = None,
                   householdIncome: Option[String] = None,
                   recipientReliabilityCode: Option[Int] = None,
                   mailResponder: Option[String] = None,
                   lengthOfResidence: Option[Int] = None,
                   personsInLivingUnit: Option[Int] = None,
                   adultsInLivingUnit: Option[Int] = None,
                   childrenInLivingUnit: Option[Int] = None,
                   homeYearBuilt: Option[Int] = None,
                   homeLandValue: Option[Float] = None,
                   estimatedHomeValue: Option[String] = None,
                   hasDonatedToCharity: Option[Boolean] = None,
                   mosaicZip4: Option[String] = None,
                   mosaicGlobalZip4: Option[String] = None,
                   householdComposition: Option[String] = None,
                   isChildPresent: Option[Boolean] = None,
                   hasChildZeroToThree: Option[Boolean] = None,
                   hasChildFourToSix: Option[Boolean] = None,
                   hasChildSevenToNine: Option[Boolean] = None,
                   hasChildTenToTwelve: Option[Boolean] = None,
                   hasChildThirteenToFifteen: Option[Boolean] = None,
                   hasChildSixteenToEighteen: Option[Boolean] = None,
                   wealthRating: Option[Int] = None,
                   addressQualityIndicator: Option[String] = None,
                   education: Option[String] = None,
                   addressType: Option[String] = None,
                   isValidAddress: Option[Boolean] = None,

                   // Address Information
                   address1: Option[String] = None,
                   address2: Option[String] = None,
                   city: Option[String] = None,
                   state: Option[String] = None,
                   zip4: Option[String] = None,
                   zip5: Option[String] = None,
                   county: Option[String] = None,
                   carrierRoute: Option[String] = None,
                   deliveryPointCode: Option[String] = None,
                   streetPreDirection: Option[String] = None,
                   streetName: Option[String] = None,
                   streetPostDirection: Option[String] = None,
                   streetSuffix: Option[String] = None,
                   streetSecondNumber: Option[String] = None,
                   streetSecondUnit: Option[String] = None,
                   streetHouseNumber: Option[String] = None,
                   metropolitanStatisticalArea: Option[String] = None,
                   primaryMetropolitanStatisticalArea: Option[String] = None,
                   coreBasedStatisticalArea: Option[String] = None,
                   coreBasedStatisticalAreaType: Option[String] = None,
                   deliveryPointValidation: Option[String] = None,
                   countyCode: Option[String] = None,
                   censusBlock: Option[String] = None,
                   censusTract: Option[String] = None,
                   addressCoordinates: Option[Coordinates] = None,

                   // Activities
                   activities: Seq[Activity] = Seq.empty,

                   // Derived Fields
                   locations: Seq[PersonLocation] = Seq.empty,
                   addressPreference: Option[Int] = None,

                   // Do Not Solicit Information
                   isOptedOutDirectMail: Option[Boolean] = None,
                   isOptedOutCall: Option[Boolean] = None,
                   isOptedOutEmail: Option[Boolean] = None,
                   isOptedOutText: Option[Boolean] = None,
                   doNotSolicit: Option[Boolean] = None,
                   optOutDirectMailReasons: Seq[String] = Seq.empty,
                   optOutCallReasons: Seq[String] = Seq.empty,
                   optOutEmailReasons: Seq[String] = Seq.empty,
                   optOutTextReasons: Seq[String] = Seq.empty,

                   primaryCarePhysicianId: Option[String] = None,
                   hasPrimaryCarePhysician: Option[Boolean] = None,
                   isHealthSystemEmployee: Option[Boolean] = None,
                   beehiveCluster: Option[Int] = None,
                   sourceName: Option[String] = None,
                   personalUrl: Option[String] = None,
                   moveType: Option[String] = None,
                   moveMonth: Option[String] = None,
                   personType: Option[String] = None,
                   sourcePersonType: Option[String] = None,
                   mostRelevantActivityType: Option[String] = None,
                   mostRelevantActivityDate: Option[Date] = None

                 ) extends PrimaryIdentity

object Person {


  val Schema: StructType = StructType(Seq(
    // Primary Identifiers
    StructField("customer", StringType, nullable = false),
    StructField("personId", StringType, nullable = false),
    StructField("addressId", StringType, nullable = true),
    StructField("dateCreated", TimestampType, nullable = false),
    StructField("dateModified", TimestampType, nullable = true),
    StructField("mrids", ArrayType(StringType), nullable = true),

    // Demographic
    StructField("sourceFirstName", StringType, nullable = true),
    StructField("firstName", StringType, nullable = true),
    StructField("sourceMiddleName", StringType, nullable = true),
    StructField("middleName", StringType, nullable = true),
    StructField("sourceLastName", StringType, nullable = true),
    StructField("lastName", StringType, nullable = true),
    StructField("prefix", StringType, nullable = true),
    StructField("personalSuffix", StringType, nullable = true),
    StructField("professionalSuffix", StringType, nullable = true),
    StructField("dateOfBirth", DateType, nullable = true),
    StructField("dateOfDeath", DateType, nullable = true),
    StructField("isDeceased", BooleanType, nullable = true),
    StructField("sourceAge", IntegerType, nullable = true),
    StructField("dateSourceAgeReceived", DateType, nullable = true),
    StructField("sex", StringType, nullable = true),
    StructField("hasSexConflict", BooleanType, nullable = true),
    StructField("financialClass", StringType, nullable = true),
    StructField("payerType", StringType, nullable = true),
    StructField("payerTypeDescription", StringType, nullable = true),
    StructField("inferredPayerType", StringType, nullable = true),
    StructField("maritalStatus", StringType, nullable = true),
    StructField("race", StringType, nullable = true),
    StructField("portalStatus", StringType, nullable = true),
    StructField("religion", StringType, nullable = true),
    StructField("isoLanguageCode", StringType, nullable = true),
    StructField("isoLanguageDesc", StringType, nullable = true),
    StructField("employer", StringType, nullable = true),
    StructField("occupationGroup", StringType, nullable = true),
    StructField("occupation", StringType, nullable = true),
    StructField("primaryPhoneNumber", StringType, nullable = true),
    StructField("primaryPhoneNumberType", StringType, nullable = true),
    StructField("phoneNumbers", ArrayType(StructType(Seq(
      StructField("phone", StringType, nullable = true),
      StructField("phoneType", StringType, nullable = true)
    ))), nullable = true),
    StructField("primaryEmail", StringType, nullable = true),
    StructField("emails", StringType, nullable = true),
    StructField("dwellType", StringType, nullable = true),
    StructField("combinedOwner", StringType, nullable = true),
    StructField("householdIncome", StringType, nullable = true),
    StructField("recipientReliabilityCode", IntegerType, nullable = true),
    StructField("mailResponder", StringType, nullable = true),
    StructField("lengthOfResidence", IntegerType, nullable = true),
    StructField("personsInLivingUnit", IntegerType, nullable = true),
    StructField("adultsInLivingUnit", IntegerType, nullable = true),
    StructField("childrenInLivingUnit", IntegerType, nullable = true),
    StructField("homeYearBuilt", IntegerType, nullable = true),
    StructField("homeLandValue", FloatType, nullable = true),
    StructField("estimatedHomeValue", StringType, nullable = true),
    StructField("hasDonatedToCharity", BooleanType, nullable = true),
    StructField("mosaicZip4", StringType, nullable = true),
    StructField("mosaicGlobalZip4", StringType, nullable = true),
    StructField("householdComposition", StringType, nullable = true),
    StructField("isChildPresent", BooleanType, nullable = true),
    StructField("hasChildZeroToThree", BooleanType, nullable = true),
    StructField("hasChildFourToSix", BooleanType, nullable = true),
    StructField("hasChildSevenToNine", BooleanType, nullable = true),
    StructField("hasChildTenToTwelve", BooleanType, nullable = true),
    StructField("hasChildThirteenToFifteen", BooleanType, nullable = true),
    StructField("hasChildSixteenToEighteen", BooleanType, nullable = true),
    StructField("wealthRating", IntegerType, nullable = true),
    StructField("addressQualityIndicator", StringType, nullable = true),
    StructField("education", StringType, nullable = true),
    StructField("addressType", StringType, nullable = true),
    StructField("isValidAddress", BooleanType, nullable = true),

    // Address Information
    StructField("address1", StringType, nullable = true),
    StructField("address2", StringType, nullable = true),
    StructField("city", StringType, nullable = true),
    StructField("state", StringType, nullable = true),
    StructField("zip4", StringType, nullable = true),
    StructField("zip5", StringType, nullable = true),
    StructField("county", StringType, nullable = true),
    StructField("carrierRoute", StringType, nullable = true),
    StructField("deliveryPointCode", StringType, nullable = true),
    StructField("streetPreDirection", StringType, nullable = true),
    StructField("streetName", StringType, nullable = true),
    StructField("streetPostDirection", StringType, nullable = true),
    StructField("streetSuffix", StringType, nullable = true),
    StructField("streetSecondNumber", StringType, nullable = true),
    StructField("streetSecondUnit", StringType, nullable = true),
    StructField("streetHouseNumber", StringType, nullable = true),
    StructField("metropolitanStatisticalArea", StringType, nullable = true),
    StructField("primaryMetropolitanStatisticalArea", StringType, nullable = true),
    StructField("coreBasedStatisticalArea", StringType, nullable = true),
    StructField("coreBasedStatisticalAreaType", StringType, nullable = true),
    StructField("deliveryPointValidation", StringType, nullable = true),
    StructField("countyCode", StringType, nullable = true),
    StructField("censusBlock", StringType, nullable = true),
    StructField("censusTract", StringType, nullable = true),
    StructField("addressCoordinates", StructType(Seq(
      StructField("lat", FloatType, nullable = true),
      StructField("lon", FloatType, nullable = true)
    )), nullable = true),

    // Activities
    StructField("activities", ArrayType(Activity.Schema), nullable = true),
    // Derived Fields
    StructField("locations", ArrayType(StructType(Seq(
      StructField("location", StringType, nullable = true),
      StructField("preference", IntegerType, nullable = true)
    ))), nullable = true),
    StructField("addressPreference", IntegerType, nullable = true),

    // Do Not Solicit Information
    StructField("isOptedOutDirectMail", BooleanType, nullable = true),
    StructField("isOptedOutCall", BooleanType, nullable = true),
    StructField("isOptedOutEmail", BooleanType, nullable = true),
    StructField("isOptedOutText", BooleanType, nullable = true),
    StructField("doNotSolicit", BooleanType, nullable = true),
    StructField("optOutDirectMailReasons", ArrayType(StringType), nullable = true),
    StructField("optOutCallReasons", ArrayType(StringType), nullable = true),
    StructField("optOutEmailReasons", ArrayType(StringType), nullable = true),
    StructField("optOutTextReasons", ArrayType(StringType), nullable = true),

    StructField("primaryCarePhysicianId", StringType, nullable = true),
    StructField("hasPrimaryCarePhysician", BooleanType, nullable = true),
    StructField("isHealthSystemEmployee", BooleanType, nullable = true),
    StructField("beehiveCluster", IntegerType, nullable = true),
    StructField("sourceName", StringType, nullable = true),
    StructField("personalUrl", StringType, nullable = true),
    StructField("moveType", StringType, nullable = true),
    StructField("moveMonth", StringType, nullable = true),
    StructField("personType", StringType, nullable = true),
    StructField("sourcePersonType", StringType, nullable = true),
    StructField("mostRelevantActivityType", StringType, nullable = true),
    StructField("mostRelevantActivityDate", DateType, nullable = true)
  ))


  /**
    * Transforms a partial untyped activity schema into a complete activity schema with types converted
    *
    * @param df input dataframe
    * @return
    */
  def transformToPersonSchema(df: DataFrame): DataFrame = {
    // Transforms from current date type to activity schema type
    val transformedColumns: Seq[Column] =
      df.schema.map(struct => (struct, Person.Schema.find(_.name == struct.name))).flatMap {
        case (currentType, Some(actualType))
          if currentType.dataType == actualType.dataType => Some(df(currentType.name))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == DoubleType =>
          Some(df(currentType.name).cast(DoubleType))

        case (currentType, Some(actualType))
          if currentType.dataType == DoubleType && actualType.dataType == StringType =>
          Some(df(currentType.name).cast(StringType))

        case (currentType, Some(actualType))
          if currentType.dataType == IntegerType && actualType.dataType == LongType =>
          Some(df(currentType.name).cast(LongType))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == DateType =>
          Some(df(currentType.name).cast(DateType))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == BooleanType =>
          Some(df(currentType.name).cast(BooleanType))

        case (currentType, Some(actualType))
          if (currentType.dataType == StringType || currentType.dataType == DoubleType) &&
            actualType.dataType == DecimalType(Constants.DecimalTypePrecision, Constants.DecimalTypeScale) =>
          Some(df(currentType.name).cast(DecimalType(Constants.DecimalTypePrecision, Constants.DecimalTypeScale)))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == IntegerType =>
          Some(df(currentType.name).cast(IntegerType))

        case (currentType, Some(actualType))
          if currentType.dataType == LongType && actualType.dataType == IntegerType =>
          Some(df(currentType.name).cast(IntegerType))

        case (currentType, Some(actualType))
          if currentType.dataType == IntegerType && actualType.dataType == StringType =>
          Some(df(currentType.name).cast(StringType))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == TimestampType =>
          Some(df(currentType.name).cast(TimestampType))

        case (currentType, Some(actualType))
          if currentType.dataType == TimestampType && actualType.dataType == DateType =>
          Some(df(currentType.name).cast(DateType))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == ArrayType(StringType) =>
          Some(df(currentType.name).cast(ArrayType(StringType, actualType.nullable)))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == ArrayType(IntegerType) =>
          Some(df(currentType.name).cast(ArrayType(IntegerType, actualType.nullable)))

        case (currentType, Some(actualType))
          if currentType.dataType == ArrayType(IntegerType, false) &&
            actualType.dataType == ArrayType(IntegerType, true) =>
          Some(df(currentType.name).cast(ArrayType(IntegerType, actualType.nullable)))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == LongType =>
          Some(df(currentType.name).cast(LongType))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == FloatType =>
          Some(df(currentType.name).cast(FloatType))

        case (currentType, Some(actualType))
          if currentType.dataType == TimestampType && actualType.dataType == DateType =>
          Some(df(currentType.name).cast(DateType))

        case (currentType, Some(actualType))
          if currentType.dataType == DoubleType && actualType.dataType == FloatType =>
          Some(df(currentType.name).cast(FloatType))

        case (StructField(name, _: DecimalType, _, _), Some(StructField(_, _: DecimalType, _, _))) =>
          Some(df(name).cast(DecimalType(Constants.DecimalTypePrecision, Constants.DecimalTypeScale)))

        case (_, None) => None

        case (StructField(name, ArrayType(StringType, true), _, _), Some(
        StructField(_, ArrayType(
        StructType(
        Array(StructField(name1, StringType, _, _), StructField(name2, IntegerType, _, _))), true), _, _))) =>
          Some(
            from_json(
              concat_ws(" ", df(name)),
              StructType(
                Seq(
                  StructField("locations", ArrayType(StructType(Seq(
                    StructField("location", StringType, nullable = true),
                    StructField("preference", IntegerType, nullable = true)
                  ))), nullable = true)
                ))
            ) as name
          )
      }

    // Adding columns that are not present in the dataFrame but are present in the activity schema
    val missingColumns: Seq[Column] = Person.Schema.filter(x => !df.schema.fieldNames.contains(x.name))
      .map(x => lit(null).cast(x.dataType) as x.name)

    // Return all columns
    df.select(transformedColumns ++ missingColumns: _*)
  }


  def deriveFromActivity(activity: Activity): Person = {
    Person(
      // Primary Identifiers
      customer = activity.customer,
      personId = activity.personId.get,
      // addressId = activity.addressId,
      dateCreated = activity.dateCreated,
      dateModified = None,
      mrids = activity.mrids,

      // Demographic
      sourceFirstName = activity.sourceFirstName,
      firstName = activity.firstName,
      sourceMiddleName = activity.sourceMiddleName,
      middleName = activity.middleName,
      sourceLastName = activity.sourceLastName,
      lastName = activity.lastName,
      prefix = activity.prefix,
      personalSuffix = activity.personalSuffix,
      professionalSuffix = activity.professionalSuffix,
      dateOfBirth = activity.dateOfBirth,
      dateOfDeath = activity.dateOfDeath,
      isDeceased = activity.dateOfDeath match {
        case Some(_) => Some(true)
        case None => Some(false)
      },
      sourceAge = activity.sourceAge,
      dateSourceAgeReceived = Some(activity.activityDate),
      sex = activity.sex,
      financialClass = activity.financialClass,
      payerType = activity.payerType,
      payerTypeDescription = activity.payerTypeDescription,
      inferredPayerType = activity.inferredPayerType,
      maritalStatus = activity.maritalStatus,
      race = activity.race,
      portalStatus = activity.portalStatus,
      religion = activity.religion,
      isoLanguageCode = activity.isoLanguageCode,
      isoLanguageDesc = activity.isoLanguageDesc,
      employer = activity.employer,
      occupationGroup = activity.occupationGroup,
      occupation = activity.occupation,
      primaryPhoneNumber = activity.primaryPhoneNumber,
      primaryPhoneNumberType = activity.primaryPhoneNumberType,
      primaryEmail = activity.primaryEmail,
      dwellType = activity.dwellType,
      combinedOwner = activity.combinedOwner,
      householdIncome = activity.householdIncome,
      recipientReliabilityCode = activity.recipientReliabilityCode,
      mailResponder = activity.mailResponder,
      lengthOfResidence = activity.lengthOfResidence,
      personsInLivingUnit = activity.personsInLivingUnit,
      adultsInLivingUnit = activity.adultsInLivingUnit,
      childrenInLivingUnit = activity.childrenInLivingUnit,
      homeYearBuilt = activity.homeYearBuilt,
      homeLandValue = activity.homeLandValue,
      estimatedHomeValue = activity.estimatedHomeValue,
      hasDonatedToCharity = activity.hasDonatedToCharity,
      mosaicZip4 = activity.mosaicZip4,
      mosaicGlobalZip4 = activity.mosaicGlobalZip4,
      householdComposition = activity.householdComposition,
      isChildPresent = activity.isChildPresent,
      hasChildZeroToThree = activity.hasChildZeroToThree,
      hasChildFourToSix = activity.hasChildFourToSix,
      hasChildSevenToNine = activity.hasChildSevenToNine,
      hasChildTenToTwelve = activity.hasChildTenToTwelve,
      hasChildThirteenToFifteen = activity.hasChildThirteenToFifteen,
      hasChildSixteenToEighteen = activity.hasChildSixteenToEighteen,
      wealthRating = activity.wealthRating,
      addressQualityIndicator = activity.addressQualityIndicator,
      education = activity.education,
      addressType = activity.addressType,
      isValidAddress = activity.isValidAddress,

      // Address Information
      address1 = activity.address1,
      address2 = activity.address2,
      city = activity.city,
      state = activity.state,
      zip4 = activity.zip4,
      zip5 = activity.zip5,
      county = activity.county,
      carrierRoute = activity.carrierRoute,
      deliveryPointCode = activity.deliveryPointCode,
      streetPreDirection = activity.streetPreDirection,
      streetName = activity.streetName,
      streetPostDirection = activity.streetPostDirection,
      streetSuffix = activity.streetSuffix,
      streetSecondNumber = activity.streetSecondNumber,
      streetSecondUnit = activity.streetSecondUnit,
      streetHouseNumber = activity.streetHouseNumber,
      metropolitanStatisticalArea = activity.metropolitanStatisticalArea,
      primaryMetropolitanStatisticalArea = activity.primaryMetropolitanStatisticalArea,
      coreBasedStatisticalArea = activity.coreBasedStatisticalArea,
      coreBasedStatisticalAreaType = activity.coreBasedStatisticalAreaType,
      deliveryPointValidation = activity.deliveryPointValidation,
      countyCode = activity.countyCode,
      censusBlock = activity.censusBlock,
      censusTract = activity.censusTract,
      addressCoordinates = activity.addressCoordinates,

      // Contact fields
      phoneNumbers = Seq(
        (activity.mobilePhone, Constants.PhoneTypeMobile),
        (activity.homePhone, Constants.PhoneTypeHome),
        (activity.workPhone, Constants.PhoneTypeWork))
        .filter(_._1.isDefined)
        .flatMap { case (phoneNumber: Option[String], phoneNumberType: String) =>
          phoneNumber.map(p => PersonPhoneNumber(p, phoneNumberType))
        },
      emails = activity.email.toSeq,
      // Activities
      activities = Seq(activity),

      // Do Not Solicit Information
      isOptedOutDirectMail = activity.isOptedOutDirectMail,
      isOptedOutCall = activity.isOptedOutCall,
      isOptedOutEmail = activity.isOptedOutEmail,
      isOptedOutText = activity.isOptedOutText,
      doNotSolicit = activity.doNotSolicit,
      optOutDirectMailReasons = activity.optOutDirectMailReasons,
      optOutCallReasons = activity.optOutCallReasons,
      optOutEmailReasons = activity.optOutEmailReasons,
      optOutTextReasons = activity.optOutTextReasons,

      primaryCarePhysicianId = activity.primaryCarePhysicianId,
      hasPrimaryCarePhysician = activity.primaryCarePhysicianId match {
        case Some(_) => Some(true)
        case None => Some(false)
      },
      // healthSystemEmployee = activity.healthSystemEmployee,
      beehiveCluster = activity.beehiveCluster,
      sourceName = activity.sourceName,
      personalUrl = activity.personalUrl,
      hasSexConflict = Some(false),
      moveType = if (activity.experianMoveType.isEmpty) activity.ncoaMoveType
      else activity.experianMoveType,
      moveMonth = if (activity.experianMoveType.isEmpty) activity.ncoaMoveDate
      else activity.experianMoveMonth,
      personType = activity.activityType.map(Constants.activityTypeToPersonType),
      sourcePersonType = activity.sourcePersonType,
      mostRelevantActivityType = activity.activityType,
      mostRelevantActivityDate = Some(activity.activityDate)
    )
  }

  def buildPersonFromRow(row: Row): Person = {
    Person(
      // Primary Identifiers
      customer = row.getAs[String]("customer"),
      personId = row.getAs[String]("personId"),
      addressId = cleanseRowField[String](row, "addressId"),
      dateCreated = row.getAs[Timestamp]("dateCreated"),
      dateModified = cleanseRowField[Timestamp](row, "dateModified"),
      mrids = cleanseRowCollectionField[String](row, "mrids"),

      // Demographic
      sourceFirstName = cleanseRowField[String](row, "sourceFirstName"),
      firstName = cleanseRowField[String](row, "firstName"),
      sourceMiddleName = cleanseRowField[String](row, "sourceMiddleName"),
      middleName = cleanseRowField[String](row, "middleName"),
      sourceLastName = cleanseRowField[String](row, "sourceLastName"),
      lastName = cleanseRowField[String](row, "lastName"),
      prefix = cleanseRowField[String](row, "prefix"),
      personalSuffix = cleanseRowField[String](row, "personalSuffix"),
      professionalSuffix = cleanseRowField[String](row, "professionalSuffix"),
      dateOfBirth = cleanseRowField[Date](row, "dateOfBirth"),
      dateOfDeath = cleanseRowField[Date](row, "dateOfDeath"),
      isDeceased = cleanseRowField[Boolean](row, "isDeceased"),
      sourceAge = cleanseRowField[Int](row, "sourceAge"),

      dateSourceAgeReceived = cleanseRowField[Date](row, "dateSourceAgeReceived"),
      sex = cleanseRowField[String](row, "sex"),
      hasSexConflict = cleanseRowField[Boolean](row, "hasSexConflict"),
      financialClass = cleanseRowField[String](row, "financialClass"),
      payerType = cleanseRowField[String](row, "payerType"),
      payerTypeDescription = cleanseRowField[String](row, "payerTypeDescription"),
      inferredPayerType = cleanseRowField[String](row, "inferredPayerType"),
      maritalStatus = cleanseRowField[String](row, "maritalStatus"),
      race = cleanseRowField[String](row, "race"),
      portalStatus = cleanseRowField[String](row, "portalStatus"),
      religion = cleanseRowField[String](row, "religion"),
      isoLanguageCode = cleanseRowField[String](row, "isoLanguageCode"),
      isoLanguageDesc = cleanseRowField[String](row, "isoLanguageDesc"),
      employer = cleanseRowField[String](row, "employer"),
      occupationGroup = cleanseRowField[String](row, "occupationGroup"),
      occupation = cleanseRowField[String](row, "occupation"),
      primaryPhoneNumber = cleanseRowField[String](row, "primaryPhoneNumber"),
      primaryPhoneNumberType = cleanseRowField[String](row, "primaryPhoneNumberType"),
      primaryEmail = cleanseRowField[String](row, "primaryEmail"),
      dwellType = cleanseRowField[String](row, "dwellType"),
      combinedOwner = cleanseRowField[String](row, "combinedOwner"),
      householdIncome = cleanseRowField[String](row, "householdIncome"),
      recipientReliabilityCode = cleanseRowField[Int](row, "recipientReliabilityCode"),
      mailResponder = cleanseRowField[String](row, "mailResponder"),
      lengthOfResidence = cleanseRowField[Int](row, "lengthOfResidence"),
      personsInLivingUnit = cleanseRowField[Int](row, "personsInLivingUnit"),
      adultsInLivingUnit = cleanseRowField[Int](row, "adultsInLivingUnit"),
      childrenInLivingUnit = cleanseRowField[Int](row, "childrenInLivingUnit"),
      homeYearBuilt = cleanseRowField[Int](row, "homeYearBuilt"),
      homeLandValue = Try(cleanseRowField[Double](row, "homeLandValue").map(_.toFloat)).
        getOrElse(cleanseRowField[Float](row, "homeLandValue")),
      estimatedHomeValue = cleanseRowField[String](row, "estimatedHomeValue"),
      hasDonatedToCharity = cleanseRowField[Boolean](row, "hasDonatedToCharity"),
      mosaicZip4 = cleanseRowField[String](row, "mosaicZip4"),
      mosaicGlobalZip4 = cleanseRowField[String](row, "mosaicGlobalZip4"),
      householdComposition = cleanseRowField[String](row, "householdComposition"),
      isChildPresent = cleanseRowField[Boolean](row, "isChildPresent"),
      hasChildZeroToThree = cleanseRowField[Boolean](row, "hasChildZeroToThree"),
      hasChildFourToSix = cleanseRowField[Boolean](row, "hasChildFourToSix"),
      hasChildSevenToNine = cleanseRowField[Boolean](row, "hasChildSevenToNine"),
      hasChildTenToTwelve = cleanseRowField[Boolean](row, "hasChildTenToTwelve"),
      hasChildThirteenToFifteen = cleanseRowField[Boolean](row, "hasChildThirteenToFifteen"),
      hasChildSixteenToEighteen = cleanseRowField[Boolean](row, "hasChildSixteenToEighteen"),
      wealthRating = cleanseRowField[Int](row, "wealthRating"),
      addressQualityIndicator = cleanseRowField[String](row, "addressQualityIndicator"),
      education = cleanseRowField[String](row, "education"),
      addressType = cleanseRowField[String](row, "addressType"),
      isValidAddress = cleanseRowField[Boolean](row, "isValidAddress"),

      // Address Information
      address1 = cleanseRowField[String](row, "address1"),
      address2 = cleanseRowField[String](row, "address2"),
      city = cleanseRowField[String](row, "city"),
      state = cleanseRowField[String](row, "state"),
      zip4 = cleanseRowField[String](row, "zip4"),
      zip5 = cleanseRowField[String](row, "zip5"),
      county = cleanseRowField[String](row, "county"),
      carrierRoute = cleanseRowField[String](row, "carrierRoute"),
      deliveryPointCode = cleanseRowField[String](row, "deliveryPointCode"),
      addressCoordinates = cleanseAddressCoordinates(row, "addressCoordinates"),

      // For some reason, Float value are being read from Postgres as Double
      streetPreDirection = cleanseRowField[String](row, "streetPreDirection"),
      streetName = cleanseRowField[String](row, "streetName"),
      streetPostDirection = cleanseRowField[String](row, "streetPostDirection"),
      streetSuffix = cleanseRowField[String](row, "streetSuffix"),
      streetSecondNumber = cleanseRowField[String](row, "streetSecondNumber"),
      streetSecondUnit = cleanseRowField[String](row, "streetSecondUnit"),
      streetHouseNumber = cleanseRowField[String](row, "streetHouseNumber"),
      metropolitanStatisticalArea = cleanseRowField[String](row, "metropolitanStatisticalArea"),
      primaryMetropolitanStatisticalArea = cleanseRowField[String](row, "primaryMetropolitanStatisticalArea"),
      coreBasedStatisticalArea = cleanseRowField[String](row, "coreBasedStatisticalArea"),
      coreBasedStatisticalAreaType = cleanseRowField[String](row, "coreBasedStatisticalAreaType"),
      deliveryPointValidation = cleanseRowField[String](row, "deliveryPointValidation"),
      countyCode = cleanseRowField[String](row, "countyCode"),
      censusBlock = cleanseRowField[String](row, "censusBlock"),
      censusTract = cleanseRowField[String](row, "censusTract"),

      // Activities
      activities = if (row.schema.exists(_.name == "activities")) {
        cleanseRowCollectionField[Activity](row, "activities")
      } else {
        Seq.empty
      },

      // TODO: Figure out why the cleanseJsonArrayField can't work with the generics
      // Derived Fields
      locations = row.schema.find(_.name == "locations").get match {
        // Reading data from DB where the type is a JSON array returns a StringType
        // while reading data in memory and converting from row to Person class returns a ArrayType
        case StructField(_, StringType, _, _) => cleanseRowField[String](row, "locations").map(string =>
          SerializationUtils.gson.fromJson(string, new TypeToken[java.util.ArrayList[PersonLocation]]() {}.getType).
            asInstanceOf[java.util.ArrayList[PersonLocation]].asScala).
          getOrElse(Seq.empty[PersonLocation])
        case StructField(_, ArrayType(_, _), _, _) => cleanseRowField[Seq[String]](row, "locations").map { strings =>
          strings.flatMap { s =>
            Try(SerializationUtils.gson.fromJson[PersonLocation](s.trim, classOf[PersonLocation])).toOption}
        }.getOrElse(Seq.empty[PersonLocation])
      },

      phoneNumbers = row.schema.find(_.name == "phoneNumbers").get match {
        // Reading data from DB where the type is a JSON array returns a StringType
        // while reading data in memory and converting from row to Person class returns a ArrayType
        case StructField(_, StringType, _, _) => cleanseRowField[String](row, "phoneNumbers").map(string =>
          SerializationUtils.gson.fromJson(string, new TypeToken[java.util.ArrayList[PersonPhoneNumber]]() {}.getType).
            asInstanceOf[java.util.ArrayList[PersonPhoneNumber]].asScala).
          getOrElse(Seq.empty[PersonPhoneNumber])
        case StructField(_, ArrayType(_, _), _, _) => cleanseRowField[Seq[String]](row, "phoneNumbers").map { strings =>
          strings.map { s =>
            SerializationUtils.gson.fromJson[PersonPhoneNumber](s.trim, classOf[PersonPhoneNumber])
          }
        }.getOrElse(Seq.empty[PersonPhoneNumber])
      },

      emails = cleanseRowCollectionField[String](row, "emails"),

      addressPreference = cleanseRowField[Int](row, "addressPreference"),

      // Do Not Solicit Information
      isOptedOutDirectMail = cleanseRowField[Boolean](row, "isOptedOutDirectMail"),
      isOptedOutCall = cleanseRowField[Boolean](row, "isOptedOutCall"),
      isOptedOutEmail = cleanseRowField[Boolean](row, "isOptedOutEmail"),
      isOptedOutText = cleanseRowField[Boolean](row, "isOptedOutText"),
      doNotSolicit = cleanseRowField[Boolean](row, "doNotSolicit"),
      optOutDirectMailReasons = cleanseRowCollectionField[String](row, "optOutDirectMailReasons"),
      optOutCallReasons = cleanseRowCollectionField[String](row, "optOutCallReasons"),
      optOutEmailReasons = cleanseRowCollectionField[String](row, "optOutEmailReasons"),
      optOutTextReasons = cleanseRowCollectionField[String](row, "optOutTextReasons"),
      primaryCarePhysicianId = cleanseRowField[String](row, "primaryCarePhysician"),
      hasPrimaryCarePhysician = cleanseRowField[Boolean](row, "hasPrimaryCarePhysician"),
      isHealthSystemEmployee = cleanseRowField[Boolean](row, "isHealthSystemEmployee"),
      beehiveCluster = cleanseRowField[Int](row, "beehiveCluster"),
      sourceName = cleanseRowField[String](row, "sourceName"),
      personalUrl = cleanseRowField[String](row, "personalUrl"),
      moveType = cleanseRowField[String](row, "moveType"),
      moveMonth = cleanseRowField[String](row, "moveMonth"),
      personType = cleanseRowField[String](row, "personType"),
      sourcePersonType = cleanseRowField[String](row, "sourcePersonType"),
      mostRelevantActivityType = cleanseRowField[String](row, "mostRelevantActivityType"),
      mostRelevantActivityDate = cleanseRowField[Date](row, "mostRelevantActivityDate")
    )
  }

  def cleanseJsonArrayField[T](row: Row, columnName: String)(implicit ct: ClassTag[T]): Seq[T] = {
    row.schema.find(_.name == columnName).get match {
      // Reading data from DB where the type is a JSON array returns a StringType
      // while reading data in memory and converting from row to Person class returns a ArrayType
      case StructField(_, StringType, _, _) => cleanseRowField[String](row, columnName).map(string =>
        SerializationUtils.gson.fromJson(string, new TypeToken[java.util.ArrayList[T]]() {}.getType).
          asInstanceOf[java.util.ArrayList[T]].asScala).
        getOrElse(Seq.empty[T])
      case StructField(_, ArrayType(_, _), _, _) => cleanseRowField[Seq[String]](row, columnName).map { strings =>
        strings.map { s =>
          SerializationUtils.gson.fromJson[T](s.trim, ct.runtimeClass)
        }
      }.getOrElse(Seq.empty[T])
    }
  }

}


