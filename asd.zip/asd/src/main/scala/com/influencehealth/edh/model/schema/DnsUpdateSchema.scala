package com.influencehealth.edh.model.schema

import org.apache.spark.sql.types.{StringType, StructField, StructType}

object DnsUpdateSchema {

  val trueFlag: Boolean = true
  val falseFlag: Boolean = false

  val dnsUpdateSchema: StructType = StructType(
    Array(
      StructField("customerId", StringType, trueFlag),
      StructField("personId", StringType, trueFlag),
      StructField("source", StringType, trueFlag),
      StructField("sourceType", StringType, trueFlag),
      StructField("sourceRecordId", StringType, trueFlag),
      StructField("optOutDirectMail", StringType, trueFlag),
      StructField("optOutDirectMailReasons", StringType, trueFlag),
      StructField("optOutCall", StringType, trueFlag),
      StructField("optOutCallReasons", StringType, trueFlag),
      StructField("optOutEmail", StringType, trueFlag),
      StructField("optOutEmailReasons", StringType, trueFlag),
      StructField("optOutText", StringType, trueFlag),
      StructField("optOutTextReasons", StringType, trueFlag)
    )
  )
}
