package com.influencehealth.edh

import com.influencehealth.edh.config._
import com.influencehealth.edh.dao.DatabaseDao
import com.influencehealth.edh.lookup_clients.support.ServiceArea
import com.influencehealth.edh.lookups.client.LookupsClient
import com.influencehealth.edh.lookups.messages.Location
import com.influencehealth.edh.model.{Activity, Person}
import com.influencehealth.edh.updater.PersonUpdater
import com.typesafe.config.Config
import org.apache.spark.sql.{Dataset, SparkSession}
import org.apache.spark.storage.StorageLevel

object PersonRebuilderPipeline extends BaldurApplication[EnrichJobConfig] {

  var inputRecordCount: Option[Long] = None
  var outputRecordCount: Option[Long] = None

  override def runJob(implicit sparkSession: SparkSession, config: EnrichJobConfig, databaseDao: DatabaseDao) = {

    val customer: String = config.customer

    val activities: Dataset[Activity] = databaseDao.getActivitiesByCustomer(customer)
    activities.persist(StorageLevel.MEMORY_ONLY_SER)

    val activitiesCount = activities.count()
    logger.info(s"$activitiesCount Activities Loaded from Postgres")

    // Initialize enrichActivityPipeline

    // TODO Add PersonPipeline jobs if requirements change
    val personRebuilderPipeline = PersonRebuilderPipelineBuilder(
      Seq(Constants.EnrichAddressStepName, Constants.EnrichCareGroupsStepName, Constants.EnrichCrosswalksStepName,
        Constants.EnrichIdentityStepName): _*
    )

    val enrichedActivities: Dataset[Activity] = personRebuilderPipeline.startEnrichPipeline(activities)

    val newPersons: Dataset[Person] = PersonUpdater.rebuildPersons(customer, enrichedActivities)

    databaseDao.savePersons(newPersons)

    inputRecordCount = Some(activitiesCount)
    outputRecordCount = Some(newPersons.count)
  }

  override def buildConfig(appConfig: Config, lookupsClient: LookupsClient): EnrichJobConfig = {
    val customer: String = appConfig.getString("app.customer")
    val customerLocations: Seq[Location] = lookupsClient.
      getLocations.filter(_.ClientKey == customer)
    val customerServiceAreas: Set[ServiceArea] = customerLocations.flatMap(ServiceArea.create).toSet
    val databaseConfig: Option[DatabaseConfig] = Some(PostgresConfig(appConfig))
    val anchorConfig: Option[AnchorConfig] = Some(AnchorConfig(appConfig))
    val sg2Config: Option[SG2Config] = Some(SG2Config(appConfig))
    EnrichJobConfig(
      appConfig,
      customerLocations,
      customerServiceAreas,
      databaseConfig,
      anchorConfig,
      sg2Config
    )
  }

  override def countInputRecords = {
    inputRecordCount
  }

  override def countOutputRecords = {
    outputRecordCount
  }
}
