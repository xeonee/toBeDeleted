package com.influencehealth.edh.refresh.redshift

import com.influencehealth.edh.config.{RedshiftConfig, RefreshJobConfig}
import com.influencehealth.edh.dao._
import com.influencehealth.edh.enrich.DataNotFoundException
import com.influencehealth.edh.lookups.client.LookupsClient
import com.influencehealth.edh.model._
import com.influencehealth.edh.utils.DateTimeUtilities
import com.influencehealth.edh.{BaldurApplication, Constants}
import com.typesafe.config.Config
import org.apache.spark.sql.{Dataset, _}

object RefreshRedshiftApp extends BaldurApplication[RefreshJobConfig] {

  var inputRecordCount: Option[Long] = None
  var outputRecordCount: Option[Long] = None

  /**
    * Method run after config validation. Provides access to the sparkSession to create spark jobs and
    * pipelines
    *
    * @param sparkSession
    * @param config
    * @param databaseDao
    * @return
    */
  override def runJob(implicit sparkSession: SparkSession, config: RefreshJobConfig,
                      databaseDao: DatabaseDao): Unit = {

    val redshiftConfig: RedshiftConfig = config.redshiftConfig

    if (redshiftConfig.isFullRefresh.get && redshiftConfig.customer.isDefined) {
      logger.info(s"Running Refresh Redshift with truncate mode")
    } else {
      if(redshiftConfig.batchId.isDefined){
        logger.info(s"Running Refresh Redshift using data with batch-id: ${redshiftConfig.batchId.get}")
      }
      else if(redshiftConfig.refreshDateTime.isDefined && redshiftConfig.customer.isDefined){
        logger.info(s"Running Refresh Redshift using data since: ${redshiftConfig.refreshDateTime.get}")
      }
      else{
        throw new Exception("Redshift run mode not defined.")
      }
    }

    populateRedshift(redshiftConfig, databaseDao)

  }

  import sparkSession.implicits._

  /**
    * Get all activities based on customer, batch id and since date from database
    * @param redshiftConfig
    * @param databaseDao
    * @return
    */
  private def getActivities(redshiftConfig: RedshiftConfig, databaseDao: DatabaseDao): Dataset[Activity] = {
      if (redshiftConfig.isFullRefresh.get){
        databaseDao.getActivitiesByCustomer(redshiftConfig.customer.get)
      }
      else if (redshiftConfig.batchId.isDefined){
        databaseDao.getActivitiesByBatchId(redshiftConfig.batchId.get)
      }
      else if (redshiftConfig.refreshDateTime.isDefined){
        databaseDao.getActivitiesByCustomer(redshiftConfig.customer.get)
         .filter(row => DateTimeUtilities.isRecent(redshiftConfig.refreshDateTime.get.toString,
           row.dateCreated, row.dateModified).equals(true))
      }
      else throw new Exception("Redshift configuration not found")
  }

  /**
    * Get all persons from database based on person ids
    * @param redshiftConfig
    * @param databaseDao
    * @param activityPersonIds
    * @return
    */
  private def getPersons(redshiftConfig: RedshiftConfig, databaseDao: DatabaseDao,
                         activityPersonIds : DataFrame): Dataset[Person] = {

    if (redshiftConfig.batchId.isDefined || redshiftConfig.refreshDateTime.isDefined) {
      databaseDao.getPersonsByCustomer(redshiftConfig.customer.get, true).
        join(activityPersonIds, Seq("personId")).as[Person]
    } else {
      databaseDao.getPersonsByCustomer(redshiftConfig.customer.get)
    }
  }

  /**
    * Get all Do Not Solicit Emails based on customer, batch id and since date from database
    * @param redshiftConfig
    * @param databaseDao
    * @return
    */
  private def getDoNotSolicitEmails(redshiftConfig: RedshiftConfig,
                                    databaseDao: DatabaseDao): Dataset[DoNotSolicitEmail] = {

    if (redshiftConfig.isFullRefresh.get) {
      databaseDao.getDoNotSolicitEmailsByCustomer(redshiftConfig.customer.get)
    }
    else if (redshiftConfig.batchId.isDefined){
      databaseDao.getDoNotSolicitEmailsByBatchId(redshiftConfig.customer.get, redshiftConfig.batchId.get)
    }
    else if(redshiftConfig.refreshDateTime.isDefined){
      databaseDao.getDoNotSolicitEmailsByCustomer(redshiftConfig.customer.get).
        filter(row => DateTimeUtilities.isRecent(redshiftConfig.refreshDateTime.get.toString,
        row.dateCreated, row.dateModified).equals(true))
    }
    else throw new Exception("Redshift configuration not found")

  }

  /**
    * Get all Address based on customer, batch id from database
    * @param redshiftConfig
    * @param databaseDao
    * @return
    */
  private def getAddress(redshiftConfig: RedshiftConfig, databaseDao: DatabaseDao,
                         personAddresses: DataFrame): Dataset[Address] = {
    if (redshiftConfig.isFullRefresh.get) {
      databaseDao.getAddressesByCustomer(redshiftConfig.customer.get)
    }
    else if (redshiftConfig.batchId.isDefined) {
      databaseDao.getAddressesByCustomer(redshiftConfig.customer.get).
        join(personAddresses, Seq("addressId")).as[Address]
    }
    else if (redshiftConfig.refreshDateTime.isDefined){
      // TODO filter if date created/date modified is added
      databaseDao.getAddressesByCustomer(redshiftConfig.customer.get)
    }
    else throw new Exception("Redshift configuration not found")
  }

  /**
    * Get all Do Not Solicit Emails based on customer, since date from database
    * @param redshiftConfig
    * @param databaseDao
    * @return
    */
  private def getPersonArchives(redshiftConfig: RedshiftConfig, databaseDao: DatabaseDao): Dataset[Person] = {

    if (redshiftConfig.isFullRefresh.get) {
      databaseDao.getPersonArchivesByCustomer(redshiftConfig.customer.get)
    }
    else if(redshiftConfig.batchId.isDefined){
      // TODO filter if ever batch_id is added
      databaseDao.getPersonArchivesByCustomer(redshiftConfig.customer.get)
    }
    else if(redshiftConfig.refreshDateTime.isDefined){
      databaseDao.getPersonArchivesByCustomer(redshiftConfig.customer.get).
        filter(row => DateTimeUtilities.isRecent(redshiftConfig.refreshDateTime.get.toString,
        row.dateCreated, row.dateModified).equals(true))
    }
    else throw new Exception("Redshift configuration not found")
  }

  /**
    * Get all Collapse History based on customer from database
    * @param redshiftConfig
    * @param databaseDao
    * @return
    */
  private def getCollapseHistory(redshiftConfig: RedshiftConfig, databaseDao: DatabaseDao): Dataset[CollapseHistory] = {

    if (redshiftConfig.isFullRefresh.get) {
      databaseDao.getCollapseHistory(redshiftConfig.customer.get)
    }
    else if(redshiftConfig.batchId.isDefined){
      // TODO filter if ever batch_id is added
      databaseDao.getCollapseHistory(redshiftConfig.customer.get)
    }
    else if(redshiftConfig.refreshDateTime.isDefined){
      // TODO filter if date created/date modified is added
      databaseDao.getCollapseHistory(redshiftConfig.customer.get)
    }
    else throw new Exception("Redshift configuration not found")

  }

  /**
    * Populate temporary tables and use them to populate actual tables in redshift
    * @param redshiftConfig
    * @param databaseDao
    */
  private def populateRedshift(redshiftConfig: RedshiftConfig, databaseDao: DatabaseDao): Unit = {

    val dataWarehouseDao: DataWarehouseDao = new RedshiftDatabaseDao(redshiftConfig, s3client)

    val transmissionName = s"refresh_${redshiftConfig.customer.get}_${Constants.Today.toString("yyyyMMdd")}"

    val truncateMode: Boolean = redshiftConfig.isFullRefresh.getOrElse(false)

    val activities: Dataset[Activity] =
      populateTempTableForActivities(redshiftConfig, databaseDao, transmissionName, dataWarehouseDao)

    val persons: Dataset[Person] =
      populateTempTableForPersons(
        redshiftConfig, databaseDao, transmissionName, activities, dataWarehouseDao)

    populateTempTableForDoNotSolicitEmails(
      redshiftConfig, databaseDao, transmissionName, dataWarehouseDao)

    populateTempTableForAddress(
      redshiftConfig, databaseDao, transmissionName, dataWarehouseDao, persons)

    populateTempTableForPersonArchives(
      redshiftConfig, databaseDao, transmissionName, dataWarehouseDao)

    populateTempTableForCollapseHistory(
      redshiftConfig, databaseDao, transmissionName, dataWarehouseDao)

    saveCustomerDataToDataWarehouse(
      dataWarehouseDao, transmissionName, truncateMode, redshiftConfig.customer.get)

    logger.info("Successfully updated Redshift.")

  }

  /**
    * Populate temporary(transmission) Activities tables
    * @param redshiftConfig
    * @param databaseDao
    * @param transmissionName
    * @param dataWarehouseDao
    * @return
    */
  private def populateTempTableForActivities(redshiftConfig: RedshiftConfig,
                                             databaseDao: DatabaseDao,
                                             transmissionName: String,
                                             dataWarehouseDao: DataWarehouseDao): Dataset[Activity] ={


    val activities: Dataset[Activity] = getActivities(redshiftConfig, databaseDao)
    val activityTransformer: ActivityTransformer = new ActivityTransformer(activities, sparkSession)

    logger.info("Loading temporary tables in redshift with activity data")
    loadNormalizedActivitiesTempTables(activityTransformer, dataWarehouseDao, transmissionName)
    activities
  }

  /**
    * Populate temporary(transmission) Persons tables
    * @param redshiftConfig
    * @param databaseDao
    * @param transmissionName
    * @param activities
    * @param dataWarehouseDao
    * @return
    */
  private def populateTempTableForPersons(redshiftConfig: RedshiftConfig,
                                             databaseDao: DatabaseDao,
                                             transmissionName: String,
                                             activities: Dataset[Activity],
                                             dataWarehouseDao: DataWarehouseDao): Dataset[Person] = {

    val activityPersonIds: DataFrame = activities.select("personId").distinct
    if(redshiftConfig.isFullRefresh.getOrElse(false)){
      if(activityPersonIds.count() == 0) throw DataNotFoundException("There is no data to send to Redshift")
    }
    val persons: Dataset[Person] = getPersons(redshiftConfig, databaseDao, activityPersonIds)
    val personTransformer: PersonTransformer = new PersonTransformer(persons, sparkSession)
    logger.info("Loading temporary tables in redshift with person data")

      loadNormalizedPersonsTempTables(personTransformer, dataWarehouseDao, transmissionName)
    persons
  }

  /**
    * Populate temporary(transmission) Do not solicit emails tables
    * @param redshiftConfig
    * @param databaseDao
    * @param transmissionName
    * @param dataWarehouseDao
    */
  private def populateTempTableForDoNotSolicitEmails(redshiftConfig: RedshiftConfig,
                                                     databaseDao: DatabaseDao,
                                                     transmissionName: String,
                                                     dataWarehouseDao: DataWarehouseDao): Unit ={

    val doNotSolicitEmails:Dataset[DoNotSolicitEmail] = getDoNotSolicitEmails(redshiftConfig, databaseDao)
    val doNotSolicitEmailsTransformer: DoNotSolicitTransformer =
      new DoNotSolicitTransformer(doNotSolicitEmails, sparkSession)
    logger.info("Loading temporary tables in redshift with do not solicit emails")
    loadNormalizedDoNotSolicitEmailsTempTables(doNotSolicitEmailsTransformer, dataWarehouseDao, transmissionName)
  }

  /**
    * Populate temporary(transmission) Address tables
    * @param redshiftConfig
    * @param databaseDao
    * @param transmissionName
    * @param dataWarehouseDao
    * @param persons
    */
  private def populateTempTableForAddress(redshiftConfig: RedshiftConfig,
                                                    databaseDao: DatabaseDao,
                                                    transmissionName: String,
                                                    dataWarehouseDao: DataWarehouseDao,
                                                    persons: Dataset[Person]): Unit = {


    val personAddresses: DataFrame = persons.select("addressId").distinct
    val addresses :Dataset[Address] = getAddress(redshiftConfig, databaseDao, personAddresses)
    val addressesTransformer: AddressTransformer = new AddressTransformer(addresses, sparkSession)
    logger.info("Loading temporary tables in redshift with Address")
    loadNormalizedAddressesTempTables(addressesTransformer, dataWarehouseDao, transmissionName)

  }

  /**
    * Populate temporary(transmission) Person archives tables
    * @param redshiftConfig
    * @param databaseDao
    * @param transmissionName
    * @param dataWarehouseDao
    */
  private def populateTempTableForPersonArchives(redshiftConfig: RedshiftConfig,
                                          databaseDao: DatabaseDao,
                                          transmissionName: String,
                                          dataWarehouseDao: DataWarehouseDao): Unit = {

    val personArchives: Dataset[Person] = getPersonArchives(redshiftConfig, databaseDao)
    val personArchivesTransformer: PersonArchivesTransformer =
      new PersonArchivesTransformer(personArchives, sparkSession)
    logger.info("Loading temporary tables in redshift with Person Archives")
    loadNormalizedPersonArchivesTempTables(personArchivesTransformer, dataWarehouseDao, transmissionName)

  }

  /**
    * Populate temporary(transmission) collapse history tables
    * @param redshiftConfig
    * @param databaseDao
    * @param transmissionName
    * @param dataWarehouseDao
    */
  private def populateTempTableForCollapseHistory(redshiftConfig: RedshiftConfig,
                                                 databaseDao: DatabaseDao,
                                                 transmissionName: String,
                                                 dataWarehouseDao: DataWarehouseDao): Unit = {

    val collapseHistory: Dataset[CollapseHistory] = getCollapseHistory(redshiftConfig, databaseDao)
    val collapseHistoryTransformer: CollapseHistoryTransformer =
      new CollapseHistoryTransformer(collapseHistory, sparkSession)
    logger.info("Loading temporary tables in redshift with Collapse History")
    loadNormalizedCollapseHistoryTempTables(collapseHistoryTransformer, dataWarehouseDao, transmissionName)

  }

  /**
    * Executes sql file using Merge Method: Replacing Existing Rows
    * https://docs.aws.amazon.com/redshift/latest/dg/t_updating-inserting-using-staging-tables-.html
    * And updates redshift
    * @param dataWarehouseDao
    * @param transmissionName
    * @param truncateMode
    * @param customer
    */
  private def saveCustomerDataToDataWarehouse(dataWarehouseDao: DataWarehouseDao,
                                               transmissionName: String,
                                               truncateMode: Boolean,
                                               customer: String): Unit = {

    logger.info("Transactionally updating cdp schema")

    dataWarehouseDao.executeSQLFile("/sql/etl/redshift_customer_etl.sql", transmissionName, truncateMode, customer)

    logger.info(
      """
        |Successfully updated datawarehouse.
        |Failures from here only affect cleanup and can handled manually or left alone for the next refresh.
        |Cleaning up empty tables ...
        |""".stripMargin)

    dataWarehouseDao.cleanUpCustomerTempTables(transmissionName)
  }

  /**
    * Load temp tables for Persons
    * @param personTransformer
    * @param dataWarehouseDao
    * @param transmissionName
    */
  private def loadNormalizedPersonsTempTables(
                                               personTransformer: PersonTransformer,
                                               dataWarehouseDao: DataWarehouseDao,
                                               transmissionName: String): Unit = {
    dataWarehouseDao.
      loadTemporaryTable(personTransformer.persons, RedshiftDataWarehouseTables.PersonsTable, transmissionName)
    personTransformer.close
  }

  /**
    * Load temp tables for Activities
    * @param personTransformer
    * @param dataWarehouseDao
    * @param transmissionName
    */
  private def loadNormalizedActivitiesTempTables(
                                                  activityTransformer: ActivityTransformer,
                                                  dataWarehouseDao: DataWarehouseDao,
                                                  transmissionName: String): Unit = {
    dataWarehouseDao.
      loadTemporaryTable(activityTransformer.activities, RedshiftDataWarehouseTables.ActivitiesTable, transmissionName)
    activityTransformer.close
  }

  /**
    * Load temp tables for Do not solicit emails
    * @param personTransformer
    * @param dataWarehouseDao
    * @param transmissionName
    */
  private def loadNormalizedDoNotSolicitEmailsTempTables(
                                                  doNotSolicitEmailsTransformer: DoNotSolicitTransformer,
                                                  dataWarehouseDao: DataWarehouseDao,
                                                  transmissionName: String): Unit = {
    dataWarehouseDao.loadTemporaryTable(doNotSolicitEmailsTransformer.doNotSolicit,
        RedshiftDataWarehouseTables.DoNotSolicitEmailsTable, transmissionName)
    doNotSolicitEmailsTransformer.close
  }

  /**
    * Load temp tables for Addresses
    * @param personTransformer
    * @param dataWarehouseDao
    * @param transmissionName
    */
  private def loadNormalizedAddressesTempTables(addressTransformer: AddressTransformer,
                                                          dataWarehouseDao: DataWarehouseDao,
                                                          transmissionName: String): Unit = {
    dataWarehouseDao.
      loadTemporaryTable(addressTransformer.addresses, RedshiftDataWarehouseTables.AddressesTable, transmissionName)
    addressTransformer.close
  }

  /**
    * Load temp tables for Person Archives
    * @param personTransformer
    * @param dataWarehouseDao
    * @param transmissionName
    */
  private def loadNormalizedPersonArchivesTempTables(
                                                 personArchivesTransformer: PersonArchivesTransformer,
                                                 dataWarehouseDao: DataWarehouseDao,
                                                 transmissionName: String): Unit = {
    dataWarehouseDao.loadTemporaryTable(personArchivesTransformer.personArchives,
      RedshiftDataWarehouseTables.PersonArchivesTable, transmissionName)
    personArchivesTransformer.close
  }

  /**
    * Load temp tables for Collapse History
    * @param personTransformer
    * @param dataWarehouseDao
    * @param transmissionName
    */
  private def loadNormalizedCollapseHistoryTempTables(
                                                      collapseHistoryTransformer: CollapseHistoryTransformer,
                                                      dataWarehouseDao: DataWarehouseDao,
                                                      transmissionName: String): Unit = {
    dataWarehouseDao.loadTemporaryTable(collapseHistoryTransformer.collapseHistory,
        RedshiftDataWarehouseTables.CollapseHistoryTable, transmissionName)
    collapseHistoryTransformer.close
  }

  override def buildConfig(appConfig: Config, lookupsClient: LookupsClient): RefreshJobConfig =
    RefreshJobConfig(appConfig)

  override def countInputRecords: Option[Long] = inputRecordCount

  override def countOutputRecords: Option[Long] = outputRecordCount

}
