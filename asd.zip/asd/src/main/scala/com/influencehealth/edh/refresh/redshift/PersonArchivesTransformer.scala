package com.influencehealth.edh.refresh.redshift

import com.influencehealth.edh.model.Person
import org.apache.spark.sql.functions.{concat_ws, to_json}
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.apache.spark.storage.StorageLevel

private[redshift] class PersonArchivesTransformer (personArchivesData: Dataset[Person],
                                                   sparkSession: SparkSession
                                                  ) extends BaseTransformer with Serializable {
  import sparkSession.implicits._

  val columnsWithSizeMoreThan256: Map[String, Int] = Map(
    "mrids" -> 1024,
    "phone_numbers" -> 1024,
    "emails" -> 1024,
    "locations" -> 1024,
    "opt_out_direct_mail_reasons" -> 1024,
    "opt_out_call_reasons" -> 1024,
    "opt_out_email_reasons" -> 1024,
    "opt_out_text_reasons" -> 1024
  )

  val deNormalizedPersonArchives: DataFrame = personArchivesData.
    withColumn("personRecordId", concat_ws("::", $"customer", $"personId")).
    withColumn("mrids",  convertSequenceStringToString(personArchivesData("mrids"))).
    withColumn("phoneNumbers",  convertSequencePhoneNumbersToString(personArchivesData("phoneNumbers"))).
    withColumn("emails",  convertSequenceStringToString(personArchivesData("emails"))).
    withColumn("addressCoordinates",  to_json($"addressCoordinates").cast(StringType)).
    withColumn("locations",  convertSequencePersonLocationToString(personArchivesData("locations"))).
    withColumn("optOutDirectMailReasons",  convertSequenceStringToString(personArchivesData("optOutDirectMailReasons"))).
    withColumn("optOutCallReasons",  convertSequenceStringToString(personArchivesData("optOutCallReasons"))).
    withColumn("optOutEmailReasons",  convertSequenceStringToString(personArchivesData("optOutEmailReasons"))).
    withColumn("optOutTextReasons",  convertSequenceStringToString(personArchivesData("optOutTextReasons")))

  val personArchives: DataFrame = deNormalizedPersonArchives.
    drop("activities").
    transform(dropComplexTypes).
    transform(aliasColumnsToSnakeCase).
    transform(applyMetadataToTempTables(columnsWithSizeMoreThan256, _)).
    persist(StorageLevel.MEMORY_ONLY)

  val close: Unit = personArchives.unpersist()


}
