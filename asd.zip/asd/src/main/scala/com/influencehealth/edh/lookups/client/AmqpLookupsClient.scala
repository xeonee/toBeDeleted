package com.influencehealth.edh.lookups.client

import com.influencehealth.amqp.AmqpConfig
import com.influencehealth.edh.lookup_clients._
import com.influencehealth.edh.lookup_clients.support.ServiceArea
import com.influencehealth.edh.lookups.messages.{Customer, FinancialClass, Location}
import com.typesafe.config.Config

/**
  * AMQP implementation for interacting with the lookups microservice
  *
  * @param amqpConfig AMQP Configuration object
  */
case class AmqpLookupsClient(amqpConfig: AmqpConfig)
  extends LookupsClient with Serializable {

  private val AmqpAllLocationsRoute: String = "medseek.predict.services.locations_all.list.noAuth"

  private val AmqpCustomersRoute: String = "medseek.predict.services.listclients.list.noAuth"

  private val AmqpPutCustomersRoute: String = "medseek.predict.services.listclients.put.noAuth"

  private val AmqpGetFilterTypesRoute: String = "medseek.predict.services.filterTypes.get.noAuth"

  override def getIndexName(customerId: Int): Option[String] = {
    val clients = customers(AmqpCustomersRoute, amqpConfig)
    clients.find(_.Id == customerId).map(_.Key)
  }

  override def getLocations(): Seq[Location] = locations(AmqpAllLocationsRoute, amqpConfig).toSeq

  override def getCustomers(): Set[Customer] = customers(AmqpCustomersRoute, amqpConfig)

  override def getFinancialClasses(): Seq[FinancialClass] = filterTypes(AmqpGetFilterTypesRoute, amqpConfig)
    .getOrElse(throw new Error("Couldn't get filterTypes from lookups")).FinancialClass

  override def getServiceAreas: Set[ServiceArea] = serviceAreas(AmqpAllLocationsRoute, amqpConfig)
}

object AmqpLookupsClient {
  def apply(appConfig: Config): LookupsClient = {
    val amqpConfig = AmqpConfig(
      host = appConfig.getString("amqp.host"),
      vHost = appConfig.getString("amqp.vhost"),
      port = appConfig.getInt("amqp.port"),
      user = appConfig.getString("amqp.user"),
      pass = appConfig.getString("amqp.pass"),
      keyPass = appConfig.getString("amqp.keystore.password"),
      keyStore = appConfig.getString("amqp.keystore.path"),
      trustStore = appConfig.getString("amqp.truststore.path"),
      exchangeName = appConfig.getString("amqp.exchange"),
      useSsl = appConfig.getBoolean("amqp.use-ssl"),
      ttlMinutes = appConfig.getInt("amqp.ttl-mins"),
      qos = Option(appConfig.getInt("amqp.qos")),
      connectionTimeout = appConfig.getInt("amqp.connection-timeout"),
      handshakeTimeout = appConfig.getInt("amqp.handshake-timeout"),
      automaticRecovery = Option(appConfig.getBoolean("amqp.auto-recovery")).getOrElse(true)
    )
    AmqpLookupsClient(amqpConfig)
  }
}
