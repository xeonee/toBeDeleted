package com.influencehealth.edh.model.activitytype

import com.influencehealth.edh.Constants

trait NewMover extends ActivityType {

  override val formatType: String = Constants.NewMoverExperianFormat
  override val defaultSource: String = Constants.NewMoverExperianDefaultSource
  override val defaultMessageType: String = Constants.NewMoverDefaultMessageType
  override val defaultSourceType: String = Constants.NewMoverDefaultSourceType
  override val defaultAddressType: String = Constants.NewMoverDefaultAddressType
  override val defaultActivityType: String = Constants.NewMoverActivityType
  override val defaultPersonType: String = Constants.NewMoverPersonType

  override val cleanseStringColumnNames: Seq[String] = Seq(
    // NewMovers List
    "lastName",
    "firstName",
    "middleName",
    "sex"
  )
  override val nullColumnNames: Seq[String] = Seq.empty[String]

  override val zipColumnNames: Seq[String] = Seq.empty

  override val mandatoryContactColumnsNames: Seq[String] = Seq.empty

}
