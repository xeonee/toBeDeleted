package com.influencehealth.edh.model.activitytype

import com.influencehealth.edh.Constants

trait DoNotSolicit extends ActivityType {

  override val formatType: String = Constants.DoNotSolicitFoundationFormat
  override val defaultSource: String = Constants.DoNotSolicitDefaultSourceType
  override val defaultMessageType: String = Constants.DoNotSolicitDefaultMessageType
  override val defaultSourceType: String = Constants.DoNotSolicitDefaultSourceType
  override val defaultAddressType: String = Constants.DoNotSolicitDefaultAddressType
  override val defaultActivityType: String = Constants.DoNotSolicitActivityType
  override val defaultPersonType: String = Constants.DoNotSolicitPersonType

  override val cleanseStringColumnNames: Seq[String] = Seq(
    "lastName",
    "firstName",
    "middleName",
    "address1",
    "address2",
    "city",
    "state",
    "zip5",
    "sourceSex",
    "sourceDnsReason"
  )

  override val nullColumnNames: Seq[String] = Seq(
    "sourceType",
    "sourceDnsReason",
    "source",
    "sourceRecordId"
  )

  override val mandatoryContactColumnsNames: Seq[String] = Seq.empty


  override val zipColumnNames: Seq[String] = Seq.empty

}