package com.influencehealth.edh.utils

import java.io.{ByteArrayInputStream, InputStream}
import java.sql.Timestamp
import java.text.{DecimalFormat, SimpleDateFormat}
import java.time.format.{DateTimeFormatter, DateTimeFormatterBuilder}
import java.time.temporal.ChronoField
import java.time.{LocalDate, Year}
import java.util.Date

import com.influencehealth.edh.implicits.{DateTimeParseError, _}
import com.influencehealth.edh.Constants
import org.apache.commons.codec.digest.DigestUtils
import org.apache.commons.validator.routines.{DateValidator, EmailValidator}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.{udf, _}
import org.apache.spark.sql.types._
import org.joda.time.DateTime

import scala.collection.mutable
import scala.util.Try
import scala.util.matching.Regex

object CleanseUtils {

  val string_to_boolean: UserDefinedFunction = udf[Option[Boolean], String](str =>
    Option(str) match {
      case Some(str) if Seq("Y", "TRUE").contains(str) => Some(true)
      case Some(str) if Seq("N", "FALSE").contains(str) => Some(true)
      case _ => None
    }
  )


  val raceMap: Map[Int, String] = Map(
    1 -> Constants.RaceBlackOrAfricanAmerican,
    2 -> Constants.RaceBlackOrAfricanAmerican,
    3 -> Constants.RaceAsian,
    4 -> Constants.RaceAsian,
    5 -> Constants.RaceWhite,
    6 -> Constants.RaceWhite,
    7 -> Constants.RaceWhite,
    8 -> Constants.RaceWhite,
    9 -> Constants.RaceWhite,
    10 -> Constants.RaceWhite,
    11 -> Constants.RaceWhite,
    12 -> null,
    13 -> Constants.RaceHispanic,
    14 -> Constants.RaceAsian,
    15 -> Constants.RaceWhite,
    16 -> Constants.RaceWhite,
    17 -> Constants.RaceAsian,
    18 -> Constants.RaceWhite,
    19 -> Constants.RaceAsian,
    20 -> null,
    21 -> null,
    22 -> Constants.RaceWhite,
    23 -> Constants.RaceWhite,
    24 -> null,
    25 -> Constants.RaceWhite,
    26 -> Constants.RaceWhite,
    27 -> Constants.RaceWhite,
    28 -> Constants.RaceWhite,
    29 -> Constants.RaceWhite,
    30 -> Constants.RaceWhite,
    31 -> null,
    32 -> Constants.RaceAsian,
    33 -> Constants.RaceWhite
  )

  def cleanseStringColumn(columnName: String)(df: DataFrame): DataFrame = {
    df
      .transform(trimValue(columnName))
      .transform(removeFFFD(columnName))
      .transform(collapseSpaces(columnName))
      .transform(removeQuotes(columnName))
      .transform(removeNull(columnName))
      .transform(removeNone(columnName))
  }

  def trimValue(columnName: String)(df: DataFrame): DataFrame = {
    df.withColumn(columnName, trim(col(columnName)))
  }

  def removeFFFD(columnName: String)(df: DataFrame): DataFrame = {
    df.withColumn(columnName, regexp_replace(col(columnName), "\\uFFFD", " "))
  }

  def collapseSpaces(columnName: String)(df: DataFrame): DataFrame = {
    df.withColumn(columnName, regexp_replace(col(columnName), " +", " "))
  }

  def removeQuotes(columnName: String)(df: DataFrame): DataFrame = {
    df.withColumn(columnName, regexp_replace(col(columnName), "\"", ""))
  }

  def removeNull(columnName: String)(df: DataFrame): DataFrame = {
    df.withColumn(columnName, regexp_replace(col(columnName), "(?i)null", ""))
  }

  def removeNone(columnName: String)(df: DataFrame): DataFrame = {
    df.withColumn(columnName, regexp_replace(col(columnName), "(?i)None", ""))
  }

  /**
    * ensure a date is parsable and in a standard format
    *
    * @return
    */
  def parseDate: UserDefinedFunction = udf { (date: String) =>
    if (date == null || date.isEmpty) {
      date
    }
    else {
      try {
        DateTimeUtilities.convertToDateTime(date).toString
      }
      catch {
        case _: DateTimeParseError => ""
      }
    }
  }

  def parseTimestamp = udf { (date: String) =>
    Option(date).
      filter(_.trim.nonEmpty).
      map(Timestamp.valueOf)
  }

  /**
    * ensure a date is parsable with given format
    *
    * @return
    */
  def parseDateWithFormat(format: Option[String]): UserDefinedFunction = udf { (date: String) =>
    if (date == null || date.isEmpty) {
      date
    }
    else {
      try {
        DateTimeUtilities.convertToDateTime(date, format).toString
      }
      catch {
        case _: DateTimeParseError => ""
      }
    }
  }

  /**
    * helper method to validate a date string
    *
    * @return
    */
  def validateDate(date: String): Boolean = {
    try {
      DateTime.parse(date)
      true
    }
    catch {
      case _: IllegalArgumentException => false
    }
  }

  /**
    * parse and validate email address
    *
    * @return input email address if valid, else empty string
    */
  def cleanseAndValidateEmail: UserDefinedFunction = udf { (email: String) =>
    if (validateEmail(email)) email else null
  }

  def cleanseAndValidateEmails = udf((workEmail: String, personalEmail: String) => {
    List(workEmail, personalEmail).filter(x => x != null && x.nonEmpty && validateEmail(x))
  })

  def cleanseAndValidatePhoneNumbers = udf((homePhone: String, workPhone: String) => {
    List(homePhone, workPhone).filter(x => x != null && x.nonEmpty)
  })

  def cleanseAndConcatePhoneNumbers = udf((homePhone: String, workPhone: String, mobilePhone: String) => {
    List(homePhone, workPhone, mobilePhone).filter(x => x != null && x.trim.nonEmpty)
  })

  /**
    * validates email address using commons-validator
    *
    * @return
    */
  def validateEmail(email: String): Boolean = {
    EmailValidator.getInstance().isValid(email)
  }

  /**
    * parse and validate email address
    *
    * @return input email address if valid, else empty string
    */
  def cleanseAndValidateDate: UserDefinedFunction = udf { (date: String) =>
    DateValidator.getInstance.validate(date)
  }

  /**
    * uses com.googlecode.libphonenumber to parse and clean phone numbers
    *
    * @return the national number if parsed properly, else empty string
    */
  def cleanseAndParsePhone: UserDefinedFunction = udf { (phone: String) =>
    if (Option(phone).isDefined && phone.nonEmpty) {
      phone.trim.replaceAll("[^0-9]", "")
    } else null
  }

  /**
    * uses com.googlecode.libphonenumber to parse and clean phone numbers
    *
    * @return the national number if parsed properly, else empty string
    */
  def cleanseAndParsePhones: UserDefinedFunction = udf { (phoneNumbers: String) =>

    if (Option(phoneNumbers).isDefined && phoneNumbers.split(",").nonEmpty) {
      val phoneNumbersSeq = phoneNumbers.split(",")
      phoneNumbersSeq.map(phone => phone.trim.replaceAll("[^0-9]", ""))
    } else null
  }

  // Removing country code of 011 if it exists and the length of the phone number is at least 13 digits
  def removeCountryCode(phone: String): String = {
    if (phone.length >= 13 && phone.take(3).equals("011")) {
      phone.substring(3)
    } else {
      phone
    }
  }

  // Removing the "1" as it can be prepended to long-distance calls (length must be 11)
  def removeLongDistanceCode(phone: String): String = {
    if (phone.head.equals('1') && phone.length.equals(11)) {
      phone.substring(1)
    } else {
      phone
    }
  }

  def cleansePhone = removeCountryCode _ compose removeLongDistanceCode

  def validatePhoneNumbers(colName: String) = udf((phone: String) => {
    phone match {
      case x if x != null && x.trim.nonEmpty => {
        val stripped = x.trim.replace("-", "").replace(".", "").replace("(", "").replace(")", "")
        if (stripped.forall(_.isDigit)) {
          val cleansed = cleansePhone(stripped)
          cleansed match {
            case y if y.length == 7 || y.length == 10 => None
            case _ => Some(s"$phone is not a valid value for " + colName)
          }
        } else {
          Some(s"$phone is not a valid value for " + colName)
        }
      }
      case _ => None
    }
  })


  /**
    * cleanse amount strings
    *
    * @return
    */
  def cleanseAmountColumns: UserDefinedFunction = udf((doubleValue: String) => {
    if (doubleValue == null) {
      null
    }
    else {
      val amount: String = doubleValue.replace("$", "").replace(",", "")
      if (isPositiveNumeric(amount)) {
        val df: DecimalFormat = new DecimalFormat("00.00")
        df.setMaximumFractionDigits(2)
        df.format(amount.toFloat)
      }
      else {
        null
      }
    }
  })

  /**
    * converts timestamp to java.sql.Date
    *
    * @return
    */
  def timestampToDate: UserDefinedFunction = udf((dateOfBirth: Timestamp) => {
    if (dateOfBirth != null) {
      Some(new java.sql.Date(dateOfBirth.getTime))
    }
    else None
  })

  /**
    * cleanse a String value
    *
    * @return
    */
  def cleanseStringColumns: UserDefinedFunction = udf((stringValue: String) => {
    if (stringValue != null && !stringValue.isEmpty) {
      stringValue.trim.
        replaceAll("\\uFFFD", " ").
        replaceAll(" +", " ").
        replaceAll("\"", "").
        replaceAll("(?i)null", "").
        replaceAll("(?i)None", "") match {
        case x if !x.isEmpty => x
        case _ => null
      }
    }
    else null
  })


  /**
    * Formate a experian date
    *
    * @return
    */
  def experianDate: UserDefinedFunction = udf(f = (str: String) => {
    if (str == null || str.isEmpty) {
      str
    }
    else {
      try {
        var cleanseStr = ""
        val currentYear = Year.now.getValue
        if (str.length.equals(4)) {
          val strYear = DateTime.parse(str).getYear
          if (strYear <= currentYear) {
            cleanseStr = str.concat("0101")
          }
        }
        else if (str.length.equals(6)) {
          val strYear = DateTime.parse(str.substring(0, 4)).getYear
          val strMonth = str.substring(4, 6).toInt
          if (strYear <= currentYear && (strMonth >= 1 && strMonth <= 12)) {
            cleanseStr = str.concat("01")
          }
        }
        else {
          cleanseStr = DateTimeUtilities.convertToDateTime(str).toString
        }
        cleanseStr
      }
      catch {
        case _: DateTimeParseError => ""
      }
    }
  })

  /**
    * Formate a substing of String value to int
    *
    * @return
    */
  def substringToInt = udf((str: String, beginningIndex: Int, endingIndex: Int) => {
    if (!str.isNullOrEmpty) {
      Some(str.substring(beginningIndex, endingIndex).toInt)
    }
    else {
      None
    }
  })

  def isPositiveInteger: UserDefinedFunction = udf((number: Int) => {
    if (Option(number).isDefined && number > 0) {
      true
    } else false
  })

  /**
    * Formate a String value to substing
    *
    * @return
    */
  def substring = udf((str: String, beginningIndex: Int, endingIndex: Int) => {
    Try(Some(str.substring(beginningIndex, endingIndex))).getOrElse(None)
  })

  /**
    * Formate a String value to race
    *
    * @return
    */
  def race = udf((input: String) => {
    Option(input).flatMap(Constants.RaceMapping.get)
  })

  /**
    * Formate a experian String values
    *
    * @return
    */
  def ethnicInsight = udf((ethnicInput: String,
                           experianGroupInput: Int,
                           religionInput: String,
                           languageInput: String,
                           groupInput: String,
                           countryInput: String) => {
    val ethnic = if (ethnicInput.isNullOrEmpty) "00" else ethnicInput
    val experianGroup = {
      if (experianGroupInput.isNullOrEmpty) "31"
      else if (experianGroupInput < 10) s"0$experianGroupInput"
      else experianGroupInput.toString
    }
    val religion = if (religionInput.isNullOrEmpty) "X" else religionInput
    val language: String = Constants.StandardLanguageMap.getOrElse(languageInput, (null, null))._1
    val group = if (groupInput.isNullOrEmpty) "Z" else groupInput
    val country = if (countryInput.isNullOrEmpty) "00" else countryInput

    s"$ethnic$experianGroup$religion$language$group$country"
  })

  /**
    * Formate a String value to home value
    *
    * @return
    */
  def homeValue = udf((input: Float) => input match {
    case x if x.isNullOrEmpty => "U"
    case x if x > 0 && x < 50000 => "A"
    case x if x >= 50000 && x < 100000 => "B"
    case x if x >= 100000 && x < 150000 => "C"
    case x if x >= 150000 && x < 200000 => "D"
    case x if x >= 200000 && x < 250000 => "E"
    case x if x >= 250000 && x < 300000 => "F"
    case x if x >= 300000 && x < 350000 => "G"
    case x if x >= 350000 && x < 400000 => "H"
    case x if x >= 400000 && x < 450000 => "I"
    case x if x >= 450000 && x < 500000 => "J"
    case x if x >= 500000 => "K"
    case x => "U"
  })

  /**
    * Formate and combine two phone
    *
    * @return
    */
  def phones = udf((phone1: String, phone2: String) => (phone1, phone2) match {
    case (one, two) if !one.isNullOrEmpty && !two.isNullOrEmpty => Seq(one, two)
    case (one, two) if !one.isNullOrEmpty => Seq(one)
    case (one, two) if !two.isNullOrEmpty => Seq(two)
    case _ => Seq()
  })

  /**
    * Formate a String value to experian latitude
    *
    * @return
    */
  def experianLat = udf((str: String) => {
    if (str.isNullOrEmpty) None
    else {
      val (left, right) = str.splitAt(3)
      Some(s"$left.$right".toFloat)
    }
  })

  /**
    * Formate a String value to experian longitude
    *
    * @return
    */
  def experianLon = udf((str: String) => {
    if (str.isNullOrEmpty) None
    else {
      val (left, right) = str.splitAt(4)
      Some(s"$left.$right".toFloat)
    }
  })

  /**
    * Formate a String value to child age bucket
    *
    * @return
    */
  def childBuckets = udf((
                           childZeroToThreeBkt: String,
                           childFourToSixBkt: String,
                           childSevenToNineBkt: String,
                           childTenToTwelveBkt: String,
                           childThirteenToFifteenBkt: String,
                           childSixteenToEighteenBkt: String) => {
    val childAgeBucketMap = Map(
      "A" -> childZeroToThreeBkt,
      "B" -> childFourToSixBkt,
      "C" -> childSevenToNineBkt,
      "D" -> childTenToTwelveBkt,
      "E" -> childThirteenToFifteenBkt,
      "F" -> childSixteenToEighteenBkt
    )

    childAgeBucketMap.flatMap { case (code, value) =>
      if (!value.isNullOrEmpty && value.toUpperCase.contains("Y")) Some(code)
      else None
    }.toSeq
  })

  def stringifyCollectionColumns(errorsDF: DataFrame): DataFrame = {
    errorsDF.schema.
      foldLeft(errorsDF) { (df, column) =>
        column.dataType match {
          case ArrayType(StringType, _) =>
            df.withColumn(column.name, stringify_string_array(df(column.name)))
          case ArrayType(IntegerType, _) =>
            df.withColumn(column.name, stringify_int_array(df(column.name)))
          case _: MapType =>
            df.withColumn(column.name, stringify_map(df(column.name)))
          case ArrayType(StructType(_), _) =>
            df.drop(column.name)
          case _ =>
            df
        }
      }
  }

  val stringify_string_array: UserDefinedFunction = udf((vs: Seq[String]) =>
    if (vs.isNullOrEmpty) s"[]" else s"""[${vs.mkString(",").replace("null,", "").replace("null", "")}]""")

  val stringify_int_array: UserDefinedFunction = udf((vs: Seq[Int]) =>
    if (vs.isNullOrEmpty) s"[]" else s"""[${vs.mkString(",").replace("null,", "").replace("null", "")}]""")

  def stringify_map: UserDefinedFunction = udf((arg: Map[String, String]) => {
    if (arg == null || arg.isEmpty) " " else "[".concat(arg.mkString(",")).concat("]")
  })

  def checkPhonenumberEmailColumn(df: DataFrame): DataFrame = {
    (df.columns.contains("phoneNumbers"), df.columns.contains("emails")) match {
      case (hasPhonenumber, hasEmails) if (hasPhonenumber && !hasEmails) =>
        df.withColumn("phoneNumbers", split(df("phoneNumbers"), ","))
      case (hasPhonenumber, hasEmails) if (!hasPhonenumber && hasEmails) =>
        df.withColumn("emails", split(df("emails"), ","))
      case (hasPhonenumber, hasEmails) if (hasPhonenumber && hasEmails) =>
        df.withColumn("phoneNumbers", split(df("phoneNumbers"), ",")).withColumn("emails", split(df("emails"), ","))
      case _ => df
    }

  }

  /**
    * UDF to remove all null values from a sequence of Strings.
    *
    * @return
    */
  def remove_null_from_seq: UserDefinedFunction = udf((array: Seq[String]) => array.filterNot(_ == null))

  def filterRequiredColumnsValues(df: DataFrame, nullValueColumns: Seq[String], methodOfContactNulls: Seq[String]):
  (DataFrame, DataFrame) = {

    import df.sqlContext.implicits._

    val errorDF = df.withColumn("errors", array(nullValueColumns.map {
      c: String => when(col(c).isNull, s"$c is empty")
    }: _*)).withColumn("errors", remove_null_from_seq($"errors"))


    // If method is called from a job which sends State value, filter it for the valid values
    val actualDFState = df.columns.map(_.toLowerCase).contains("state") match {
      case true =>
        val invalidStateDf = errorDF.withColumn("invalidState", validateState($"state"))
        invalidStateDf.withColumn("errors", concat_udf($"errors", array($"invalidState")))
          .withColumn("errors", remove_null_from_seq($"errors"))
          .drop("invalidState")

      case _ => errorDF
    }

    // If method is called from a job which sends sex value, filter it for the valid values
    var actualDF = df.columns.contains("sourceSex") match {
      case true =>
        val invalidSexDf = actualDFState.withColumn("invalidSex", validate_sex($"sourceSex"))
        invalidSexDf.withColumn("errors", concat_udf($"errors", array($"invalidSex")))
          .withColumn("errors", remove_null_from_seq($"errors"))
          .drop("invalidSex")

      case _ => actualDFState
    }

    // If method is called from a job which sends phone values, filter them for the valid values
    val phoneColumns = Seq("homePhone", "workPhone", "mobilePhone")

    phoneColumns.foreach(column => {
      actualDF = df.columns.contains(column) match {
        case true =>
          val invalidPhoneDf = actualDF.withColumn("invalidPhone", validatePhoneNumbers(column)(col(s"$column")))
          invalidPhoneDf.withColumn("errors", concat_udf($"errors", array($"invalidPhone")))
            .withColumn("errors", remove_null_from_seq($"errors"))
            .drop("invalidPhone")

        case _ => actualDF
      }
    }
    )

    val errorDataFrame = actualDF.filter("size(errors) != 0")
    val cleansedDataFrame = actualDF.filter("size(errors) = 0").drop("errors")

    val isPhoneNull = col(methodOfContactNulls(0)).isNull
    val isAddressNull = col(methodOfContactNulls(1)).isNull

    val filterContactFromActualDF = cleansedDataFrame.withColumn("ERRORS", array(when(isPhoneNull && isAddressNull,
      s"${methodOfContactNulls(0)} is empty, ${methodOfContactNulls(1)} is empty"))
    ).withColumn("ERRORS", remove_null_from_seq($"ERRORS"))

    val errorDataFrameFromContact = filterContactFromActualDF.filter("size(errors) != 0")
    val finalCleansedDataFrame = filterContactFromActualDF.filter("size(errors) = 0").drop("errors")

    val finalErrorDataFrame = errorDataFrame.union(errorDataFrameFromContact)

    (finalCleansedDataFrame, finalErrorDataFrame)
  }

  /** extract zip5 values from zip column */
  def get_zip5: UserDefinedFunction = udf((zip5: String) => {
    if (zip5 != null && zip5.nonEmpty) {
      val zip5WithoutSpaces = zip5.replaceAll("\\s+", "")
      zip5WithoutSpaces match {
        case x if x.length >= 5 && isAllDigits(x) => x.substring(0, 5)
        case x if x.contains("-") && !x.startsWith("-") && isAllDigits(x.split("-")(0))
          && x.split("-")(0).length == 5 => x.split("-")(0)
        case _ => null
      }
    }
    else {
      null
    }
  })

  /** extract zip4 values from zip column */
  def get_zip4: UserDefinedFunction = udf((zip: String) => {
    if (zip != null && zip.nonEmpty) {
      val zipsWithoutSpaces = zip.replaceAll("\\s+", "")
      zipsWithoutSpaces match {
        case x if x.length == 9 && isAllDigits(x) => x.substring(5, 9)
        case x if x.length > 5 && x.contains("-") && x.split("-").size > 1 && x.split("-")(1) != null &&
          x.split("-")(1).nonEmpty && isAllDigits(x.split("-")(1)) && x.split("-")(1).length == 4 =>
          x.split("-")(1)
        case _ => null
      }
    }
    else {
      null
    }
  })

  def isAllDigits(x: String): Boolean = x forall Character.isDigit

  // def isPositiveNumeric(str: String): Boolean = str.matches("\\d+(\\.\\d+)?")

  def isPositiveNumeric(str: String) = Try(str.toDouble).isSuccess && (str.toDouble >= 0)

  def cleanse_phone_numbers: UserDefinedFunction = udf((phoneNumbers: String) => {
    if (phoneNumbers != null && phoneNumbers.nonEmpty) {
      phoneNumbers.replaceAll("[\\.|,|\\-|;|\\(|\\)|']", "")
    }
    else {
      null
    }
  })

  val inputDateFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")

  /**
    * get previous month from date
    *
    * @return
    */
  def getPreviousMonth(x: String): String =
    LocalDate.parse(x, inputDateFormat).minusMonths(1).toString
      .replaceAll("[^0-9]", "").substring(0, 6)


  /**
    * this curried version of dateParser takes a map of columnName as key and dateFormat as value and can be called
    * on multiple date columns of a dataframe.
    *
    * @param dateColumnsMap
    * @return
    */
  def format_date(dateColumnsMap: Map[String, String]) = udf((date: String, columnName: String) => {
    if (date != null && !date.isEmpty) {
      val dateFormat: SimpleDateFormat =
        new SimpleDateFormat(dateColumnsMap.getOrElse(columnName, "yyyy-MM-dd hh:mm:ss"))
      val parsedDate: Date = dateFormat.parse(s"$date")
      Some(new java.sql.Timestamp(parsedDate.getTime))
    }
    else None
  })

  /**
    * converts timestamp to java.sql.Date
    *
    * @return
    */
  def timestamp_to_date: UserDefinedFunction = udf((dateOfBirth: Timestamp) => {
    if (dateOfBirth != null) {
      Some(new java.sql.Date(dateOfBirth.getTime))
    }
    else None
  })

  /**
    * split the string with "," and convert into array
    *
    * @return
    */
  def getStringToArray: UserDefinedFunction = udf((str: String) => {
    str match {
      case x if x.isNullOrEmpty => null
      case y => y.split(",")
    }
  })

  /**
    * generates unique source record id based on generated rowId and input batchId
    *
    * @return sourceRecordId
    */
  def generateSourceRecordId: UserDefinedFunction = udf((rowId: String, batchId: String) => {
    val byteArray: Array[Byte] =
      rowId.toString.getBytes() ++
        batchId.toString.getBytes()
    val inputStream: InputStream = new ByteArrayInputStream(byteArray)
    DigestUtils.md5Hex(inputStream)
  })


  /**
    * converts MM/dd/yyyy input string to yyyy-MM-dd format
    *
    * @return
    */

  def parseStringToDate(x: String): String = {
    val dateTimeFormatter = new DateTimeFormatterBuilder().
      parseCaseInsensitive().parseLenient().
      parseDefaulting(ChronoField.DAY_OF_MONTH, 1).
      appendPattern("[yyyy-MM]").
      appendPattern("[yyyy-MM-dd]").
      appendPattern("[MM/dd/yyyy]").
      toFormatter()

    LocalDate.parse(x, dateTimeFormatter).toString
  }

  /**
    * if sex value does not exists in Constants.definedSex, return with error "inputSex is not valid sex"
    *
    * @return
    */
  val validate_sex: UserDefinedFunction = udf((inputSex: String) => {
    Option(inputSex).
      filterNot(x => inputSex.trim.isEmpty || Constants.DefinedSex.contains(x.trim.toUpperCase))
      .map(s => s"$s is not valid value for sex")
  })

  /**
    * merge two array type columns in a dataframe
    */
  val concat_udf = udf((firstArray: mutable.WrappedArray[String], secondArray: mutable.WrappedArray[String]) => {
    firstArray ++ secondArray
  })

  // Validates the input state and guarantorState values by using the defined states in the Constants.
  // If the input values are not present in the defined states, will send these records to error file.
  def validateState: UserDefinedFunction = udf((inputState: String) => {
    inputState match {
      case x if x == null || x.isEmpty || !Constants.DefinedState.contains(x.toUpperCase) => None
      case _ => Some(inputState)
    }
  })

  /**
    * validate an inputEmail value against regex: something@something.something
    *
    * @return a boolean value base on inputEmail value is valid email or not.
    */
  def isValidEmail: UserDefinedFunction = udf((email: String) => {
    val pattern: Regex = """[A-Za-z0-9._-]+@([\w\.])+[.]+([A-Za-z]{2,10})""".r
    pattern.unapplySeq(email).isDefined
  })

  /**
    * validate an inputString value and if string is Y then return true else false
    *
    * @return a boolean value based on inputString value.
    */
  def isTrue: UserDefinedFunction = udf((inputString: String) => {
    if (inputString == "Y") {
      true
    }else false
  })


}
