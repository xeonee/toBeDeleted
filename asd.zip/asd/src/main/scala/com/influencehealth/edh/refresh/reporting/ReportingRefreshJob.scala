package com.influencehealth.edh.refresh.reporting

import com.influencehealth.edh.{BaldurApplication, SuccessfulBaldurJob}
import com.influencehealth.edh.config.RefreshJobConfig
import com.influencehealth.edh.dao.DatabaseDao
import com.influencehealth.edh.lookups.client.LookupsClient
import com.influencehealth.edh.model.{Activity, Address, CollapseHistory, Person}
import com.typesafe.config.Config
import org.apache.spark.sql.{Dataset, SparkSession}

object ReportingRefreshJob extends BaldurApplication[RefreshJobConfig] {

  var inputRecordCount: Option[Long] = None
  var outputRecordCount: Option[Long] = None

  override def runJob(implicit sparkSession: SparkSession, config: RefreshJobConfig, databaseDao: DatabaseDao) = {

    val customer: String = config.customer

    // Load in person data with latest changes

    val persons: Dataset[Person] = databaseDao.getPersonsByCustomer(customer, full = false)

    val activities: Dataset[Activity] = databaseDao.getActivitiesByCustomer(customer)

    val addresses: Dataset[Address] = databaseDao.getAddressesByCustomer(customer)

    val personArchives: Dataset[Person] = databaseDao.getPersonArchivesByCustomer(customer)

    val collapseHistory: Dataset[CollapseHistory] = databaseDao.getCollapseHistory(customer)

    // val reportingDatabase: DatabaseDao = new RedshiftDatabaseDao(redshiftConfig)

    //    DatabaseDao.MassTransactionBuilder.
    //      add(persons, "persons", Seq("customer", "person_id"), "date_modified").
    //      add(activities, "activities", Seq("customer", "activity_id"), "date_modified").
    //      add(addresses, "addresses", Seq("customer", "address_id"), "date_modified").
    //      add(collapseHistory, "collapse_history", Seq("customer", "current_person_id", "deleted_person_id"), "deleted_at").
    //      add(personArchives, "person_archives", Seq("customer", "person_id"), "date_modified").
    //      execute(reportingDatabase)

  }

  override def buildConfig(appConfig: Config, lookupsClient: LookupsClient): RefreshJobConfig = {
    RefreshJobConfig(appConfig)
  }

  override def countInputRecords = {
    inputRecordCount
  }

  override def countOutputRecords = {
    outputRecordCount
  }

}
