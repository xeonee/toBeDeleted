package com.influencehealth.edh.enrich.person.residence

import com.influencehealth.edh.Constants
import com.influencehealth.edh.config.EnrichJobConfig
import com.influencehealth.edh.dao.{DatabaseDao, PostgresDatabaseDao}
import com.influencehealth.edh.enrich.PersonEnricher
import com.influencehealth.edh.model.{Address, AddressIdentity, Coordinates, Person}
import com.influencehealth.edh.utils.PersonUtils
import org.apache.spark.sql.{Dataset, SparkSession}


case class UnidentifiedAddress(customer: String,
                               address1: String,
                               address2: Option[String],
                               city: String,
                               state: String,
                               zip5: String,
                               zip4: Option[String],
                               addressCoordinates: Coordinates
                              ) extends AddressIdentity

class EnrichResidenceStep(val name: String, val next: Option[PersonEnricher])
                         (implicit enrichJobConfig: EnrichJobConfig, sparkSession: SparkSession)

  extends PersonEnricher {

  override def enrich(dataset: Dataset[Person]): Dataset[Person] = {

    val databaseDao: DatabaseDao = new PostgresDatabaseDao(enrichJobConfig.databaseConfig.get)

    import dataset.sparkSession.implicits._

    val potentiallyAddressablePersons: Dataset[UnidentifiedAddress] = buildUnidentifiedAddresses(dataset)

    val addressesInApplicableZipCodes: Dataset[Address] =
      getAddressesForUnIdentifiedAddressZips(potentiallyAddressablePersons, databaseDao)

    val finalAddresses: Dataset[(Address, Boolean)] =
      getFinalAddress(potentiallyAddressablePersons, addressesInApplicableZipCodes)

    val addressByCustomer = databaseDao.getAddressesByCustomer(enrichJobConfig.customer)

    saveNewAddressFromFinalAddresses(finalAddresses, addressByCustomer, databaseDao)

    val personsWithIdentifiedAddresses: Dataset[Person] = getPersonsWithMatchingFinalAddresses(finalAddresses, dataset)

    // filter these residence for address preference
    personsWithIdentifiedAddresses
      .groupByKey(person => person.addressId.getOrElse(person.personId))
      .flatMapGroups {
        case (_, personsAtAddress) =>
          val personsAtAddressList: List[Person] = personsAtAddress.toList
          if (personsAtAddressList.length == 1) {
            updatePresenceOfChildInformation(personsAtAddressList)
          } else {
            updatePresenceOfChildInformation(updateAddressPreferenceWithFamilyType(personsAtAddressList))
          }
      }

  }

  /**
    * Returns dataset of distinct UnidentifiedAddress for persons having no addressId.
    *
    * @param persons Dataset[Person]
    * @return Dataset [UnidentifiedAddress]
    */
  def buildUnidentifiedAddresses(persons: Dataset[Person]): Dataset[UnidentifiedAddress] = {
    import persons.sparkSession.implicits._
    persons.flatMap { person =>
      if (person.addressId.isEmpty &&
        person.address1.isDefined &&
        person.city.isDefined &&
        person.state.isDefined &&
        person.zip5.isDefined &&
        person.addressCoordinates.isDefined &&
        person.isValidAddress.getOrElse(false)
      ) {
        Some(UnidentifiedAddress(
          person.customer,
          person.address1.get,
          person.address2,
          person.city.get,
          person.state.get,
          person.zip5.get,
          person.zip4,
          person.addressCoordinates.get
        ))
      } else {
        None
      }
    }.distinct() // Required because incoming records could contain family members living at the same address
  }

  /**
    * Get Address data for unidentified addresses' zip codes
    *
    * @param unidentifiedAddresses
    * @param databaseDao
    * @return
    */
  def getAddressesForUnIdentifiedAddressZips(unidentifiedAddresses: Dataset[UnidentifiedAddress],
                                             databaseDao: DatabaseDao): Dataset[Address] = {
    import unidentifiedAddresses.sparkSession.implicits._

    val distinctZipCodes: Set[String] = unidentifiedAddresses.map(_.zip5).distinct().collect().toSet
    databaseDao.searchAddressesByZipCodes(distinctZipCodes)
  }

  /**
    * Returns a dataset of tuples containing addresses & a boolean value (true for new address & false for old address)
    *
    * @param unidentifiedAddresses
    * @param addressesInApplicableZipCodes Addresses servicing unidentified Addresses' zipcodes
    * @return Dataset[(Address, true for new address & false for old address)]
    */
  def getFinalAddress(unidentifiedAddresses: Dataset[UnidentifiedAddress],
                      addressesInApplicableZipCodes: Dataset[Address]): Dataset[(Address, Boolean)] = {
    import unidentifiedAddresses.sparkSession.implicits._
    unidentifiedAddresses.joinWith(addressesInApplicableZipCodes,
      unidentifiedAddresses("customer") === addressesInApplicableZipCodes("customer") &&
        unidentifiedAddresses("address1") === addressesInApplicableZipCodes("address1") &&
        unidentifiedAddresses("address2") <=> addressesInApplicableZipCodes("address2") &&
        unidentifiedAddresses("city") === addressesInApplicableZipCodes("city") &&
        unidentifiedAddresses("state") === addressesInApplicableZipCodes("state") &&
        unidentifiedAddresses("zip4") <=> addressesInApplicableZipCodes("zip4") &&
        unidentifiedAddresses("zip5") === addressesInApplicableZipCodes("zip5") &&
        unidentifiedAddresses("addressCoordinates.lat") === addressesInApplicableZipCodes("addressCoordinates.lat") &&
        unidentifiedAddresses("addressCoordinates.lon") === addressesInApplicableZipCodes("addressCoordinates.lon")
      , "left"
    ).map {
      case (_: UnidentifiedAddress, identifiedAddress: Address) => (identifiedAddress, false)
      case (unidentifiedAddress: UnidentifiedAddress, null) => (Address(
        customer = unidentifiedAddress.customer,
        addressId = unidentifiedAddress.generateAddressId, // Creating address_id
        address1 = unidentifiedAddress.address1.trim,
        address2 = if (unidentifiedAddress.address2.nonEmpty && !unidentifiedAddress.address2.get.trim.equals("")) {
          Some(unidentifiedAddress.address2.get.trim)
        } else None,
        city = unidentifiedAddress.city.trim,
        state = unidentifiedAddress.state.trim,
        zip4 = unidentifiedAddress.zip4,
        zip5 = unidentifiedAddress.zip5,
        addressCoordinates = unidentifiedAddress.addressCoordinates
      ), true)
    }
  }

  /**
    * Filter new addresses which contain new address_id (boolean flag = true) and save them to addresses table
    *
    * @param finalAddresses
    * @return
    */
  def saveNewAddressFromFinalAddresses(finalAddresses: Dataset[(Address, Boolean)], addressByCustomer: Dataset[Address],
                                       databaseDao: DatabaseDao): Unit = {
    import finalAddresses.sparkSession.implicits._
    // The new addresses that need a UUID generated
    val newAddressRecords: Dataset[Address] = finalAddresses.filter(_._2).map(_._1)

    val validAddress: Dataset[Address] = dropDuplicateAddressId(newAddressRecords, addressByCustomer)
    databaseDao.saveAddresses(validAddress)
  }

  /**
    * joining with Address table to filter out addressIDs already present.
    * @param newAddressRecords
    * @param addressByCustomer
    * @return Dataset[Address]
    */
  def dropDuplicateAddressId(newAddressRecords: Dataset[Address],
                             addressByCustomer: Dataset[Address]): Dataset[Address] = {
    import newAddressRecords.sparkSession.implicits._
    newAddressRecords.dropDuplicates("addressId")
      .join(addressByCustomer, Seq("addressId"), "left_anti")
      .as[Address]
  }

  /**
    * Returns Persons matching the list of final addresses
    *
    * @param finalAddresses
    * @param persons
    * @return
    */
  def getPersonsWithMatchingFinalAddresses(finalAddresses: Dataset[(Address, Boolean)],
                                           persons: Dataset[Person]): Dataset[Person] = {

    import finalAddresses.sparkSession.implicits._

    // finalAddresses may contain duplicate addresses which will cause an issue while joining with persons data.
    val addresses: Dataset[Address] = finalAddresses.map(_._1).dropDuplicates("addressId")

    persons.joinWith(
      addresses,
      persons("customer") === addresses("customer") &&
        persons("address1") === addresses("address1") &&
        persons("address2") <=> addresses("address2") &&
        persons("city") === addresses("city") &&
        persons("state") === addresses("state") &&
        persons("zip4") <=> addresses("zip4") &&
        persons("zip5") === addresses("zip5") &&
        persons("addressCoordinates.lat") === addresses("addressCoordinates.lat") &&
        persons("addressCoordinates.lon") === addresses("addressCoordinates.lon"),
      "left"
    ).map(joinedRecords => (joinedRecords._1, Option(joinedRecords._2))).
      map {
        case (person, Some(address)) => person.copy(addressId = Some(address.addressId))
        case (person, None) => person
      }

  }

  /**
    * Assign Address Preferences  based on sorting the persons with age & sex
    *
    * @param persons
    * @return
    */
  def assignAddressPreference(persons: List[Person]): List[Person] = {

    val personsAndAddressPreference: List[(Person, Int)] = persons.sortBy(p => genderAgeSort(p)).zipWithIndex
    val personsWithAddressPreference: List[(Person, Int)] =
      personsAndAddressPreference.map(x => (x._1.copy(addressPreference = Some(x._2)), x._2))

    personsWithAddressPreference.map(x => x._1)
  }

  // TODO this logic to add after the confirmation from product team is made on whether or not we want to assign family type to patient personTypes
  /**
    * Assigns family person based on TBD
    *
    * @param persons
    * @return
    */
  def assignFamilyPersonType(persons: List[Person]): List[Person] = {
    val personsWithFamilyPersonType = persons.map(person => {
      val familyType = person.personType match {
        case Some(Constants.PersonTypePatient) => Some(Constants.PersonTypePatient) // assign family member type
        case Some(x) => Some(x)
        case None => None
      }
      person.copy(personType = familyType)
    })
    personsWithFamilyPersonType
  }

  /**
    * Returns priority based on sex and age
    *
    * @param person
    * @return
    */
  def genderAgeSort(person: Person): Int = {
    if (person.sourceAge.nonEmpty && person.sex.nonEmpty) {
      if (person.sourceAge.get > 18 && person.sourceAge.get < 65 && person.sex.get == Constants.SexFemale) 1
      else if (person.sourceAge.get > 18 && person.sourceAge.get < 65 && person.sex.get == Constants.SexMale) 2
      else if (person.sourceAge.get >= 65 && person.sex.get == Constants.SexFemale) 3
      else if (person.sourceAge.get >= 65 && person.sex.get == Constants.SexMale) 4
      else if (person.sourceAge.get <= 18 && person.sex.get == Constants.SexFemale) 5
      else if (person.sourceAge.get <= 18 && person.sex.get == Constants.SexMale) 6
      else 7
    }
    else {
      8
    }
  }

  /**
    * Assigns presence of child flag for a household and populates the corresponding child's age bucket
    *
    * @return
    */
  def updatePresenceOfChildInformation: List[Person] => List[Person] =
    assignPresenceOfChildInAHousehold _ andThen assignChildAgeBucket

  /**
    * Assigns address preference with family type
    *
    * @return
    */
  def updateAddressPreferenceWithFamilyType: List[Person] => List[Person] =
    assignAddressPreference _ andThen assignFamilyPersonType


  /**
    * Assigns presence of child in a household
    *
    * @param personsInHousehold
    * @return
    */
  def assignPresenceOfChildInAHousehold(personsInHousehold: List[Person]): List[Person] = {
    val presenceOfChildFlag: Boolean = personsInHousehold.exists(x => isChildPresent(x))
    personsInHousehold.map(_.copy(isChildPresent = Some(presenceOfChildFlag)))
  }

  /**
    * Returns true if the person is/has a child in their household
    * For Prospect data, we should not process below method as it will override the input prospect file data.
    *
    * @param person
    * @return
    */
  def isChildPresent(person: Person): Boolean = {
    val currentAge: Option[Int] =
      PersonUtils.computeAge(person.dateOfBirth, person.sourceAge, person.dateSourceAgeReceived)
    person.personType match {
      case Some("PROSPECT") => person.isChildPresent.getOrElse(false)
      case _ => currentAge.exists(_ < 18) && person.isDeceased.exists(!_)
    }
  }

  /**
    * Returns true if the person current age is in input range
    * For Prospect data, we should not process below method as it will override the input prospect file data.
    *
    * @param person
    * @return true or false
    */
  def isChildPresentInInputBucket(person: Person, beginningAge: Int, endingAge:Int, bucketName: String): Boolean = {
    person.personType match {
      case Some("PROSPECT") => bucketName match {
        case "hasChildZeroToThree" => person.hasChildZeroToThree.getOrElse(false)
        case "hasChildFourToSix" => person.hasChildFourToSix.getOrElse(false)
        case "hasChildSevenToNine" => person.hasChildSevenToNine.getOrElse(false)
        case "hasChildTenToTwelve" => person.hasChildTenToTwelve.getOrElse(false)
        case "hasChildThirteenToFifteen" => person.hasChildThirteenToFifteen.getOrElse(false)
        case "hasChildSixteenToEighteen" => person.hasChildSixteenToEighteen.getOrElse(false)
      }
      case _ => val currentAge: Option[Int] = PersonUtils.computeAge(
        person.dateOfBirth, person.sourceAge, person.dateSourceAgeReceived
      )
        currentAge.exists(y => y >= beginningAge && y <= endingAge) && person.isDeceased.exists(!_)
    }
  }

  /**
    * populates child age bucket based on age
    *
    * @param personsInHousehold
    * @return
    */
  def assignChildAgeBucket(personsInHousehold: List[Person]): List[Person] = {

    val child0To3Bkt: Boolean = personsInHousehold.exists(person => isChildPresentInInputBucket(
      person, 0, 3,"hasChildZeroToThree"))
    val child4To6Bkt: Boolean = personsInHousehold.exists(person => isChildPresentInInputBucket(
      person, 4, 6,"hasChildFourToSix"))
    val child7To9Bkt: Boolean = personsInHousehold.exists(person => isChildPresentInInputBucket(
      person, 7, 9,"hasChildSevenToNine"))
    val child10To12Bkt: Boolean = personsInHousehold.exists(person => isChildPresentInInputBucket(
      person, 10, 12,"hasChildTenToTwelve"))
    val child13To15Bkt: Boolean = personsInHousehold.exists(person => isChildPresentInInputBucket(
      person, 13, 15,"hasChildThirteenToFifteen"))
    val child16To18Bkt: Boolean = personsInHousehold.exists(person => isChildPresentInInputBucket(
      person, 16, 18,"hasChildSixteenToEighteen"))

    personsInHousehold.map(person => person.copy(
      hasChildZeroToThree = Some(child0To3Bkt),
      hasChildFourToSix = Some(child4To6Bkt),
      hasChildSevenToNine = Some(child7To9Bkt),
      hasChildTenToTwelve = Some(child10To12Bkt),
      hasChildThirteenToFifteen = Some(child13To15Bkt),
      hasChildSixteenToEighteen = Some(child16To18Bkt)))
  }
}
