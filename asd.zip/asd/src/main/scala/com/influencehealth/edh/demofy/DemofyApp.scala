package com.influencehealth.edh.demofy

import com.influencehealth.edh.BaldurApplication
import com.influencehealth.edh.config.DemoJobConfig
import com.influencehealth.edh.lookups.client.LookupsClient
import com.typesafe.config.Config
import org.apache.spark.sql.{Dataset, SparkSession}
import com.influencehealth.edh.model.{Activity, Person}
import com.influencehealth.edh.dao.DatabaseDao
import org.apache.spark.storage.StorageLevel

object DemofyApp extends BaldurApplication[DemoJobConfig] {
  var inputRecordCount: Option[Long] = None
  var outputRecordCount: Option[Long] = None

  override def runJob(
                       implicit sparkSession: SparkSession,
                       config: DemoJobConfig,
                       databaseDao: DatabaseDao
                     ): Unit = {
    val customerName: String = config.customer
    val s3BucketUrl: String = config.bucketUrl

    logger.info("Demofy Start")

    // Initialization
    val initializedInputs: Map[String, Any] = DemoDataGenerator.getInitializedValues(
      sparkSession, databaseDao, customerName, s3BucketUrl)

    // Generate Demo data
    val demoDataFrame: Dataset[Activity] = DemoDataGenerator.buildDemoDataset(initializedInputs)

    import demoDataFrame.sparkSession.implicits._
    val persons: Dataset[Person] = demoDataFrame.map{ activity =>
      val newActivity = activity.copy(personId = Some(activity.generatePersonId()))
      Person.deriveFromActivity(newActivity)}.persist(StorageLevel.MEMORY_AND_DISK)

    // Save persons
    databaseDao.savePersons(persons)

    val activities = persons.flatMap(_.activities)

    // save demo data
    databaseDao.saveActivities(activities)

    logger.info("Demo data successfully generated and saved to datahub.activities and datahub.persons")
    }

  override def countInputRecords = {
    inputRecordCount
  }

  override def countOutputRecords = {
    outputRecordCount
  }

  override def buildConfig(appConfig: Config, lookupsClient: LookupsClient): DemoJobConfig = {
    DemoJobConfig(appConfig)
  }
}