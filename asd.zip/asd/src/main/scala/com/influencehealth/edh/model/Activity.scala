package com.influencehealth.edh.model

import java.sql.{Date, Timestamp}

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.influencehealth.edh.Constants
import com.influencehealth.edh.utils.SerializationUtils
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{ArrayType, _}
import org.apache.spark.sql.{Column, DataFrame, Row}

import scala.collection.JavaConverters._
import scala.reflect.ClassTag
import scala.util.Try

case class SG2(careGroupCode: Option[String] = None,
               careGroupDescription: Option[String] = None,
               serviceLineGroup: Option[String] = None,
               careFamily: Option[String] = None,
               procedure: Option[String] = None,
               procedureGroup: Option[String] = None,
               mentalHealthConditions: Option[String] = None,
               addictionAdult: Option[String] = None,
               behavioralHealthConditionsAdult: Option[String] = None,
               diabetesAdult: Option[String] = None,
               cardiacDiseaseAdult: Option[String] = None,
               pulmonaryDiseaseAdult: Option[String] = None,
               adultChronicConditionsCount: Option[String] = None,
               asthmaPediatric: Option[String] = None,
               behavioralHealthConditionsPediatric: Option[String] = None,
               complexCardiacConditionsPediatric: Option[String] = None,
               pediatricComplexConditionsCount: Option[String] = None,
               trauma: Option[String] = None,
               procedureGroupCategory: Option[String] = None,
               sportsMedicine: Option[String] = None,
               painServices: Option[String] = None,
               primaryCareAllAdults: Option[String] = None,
               primaryCareGeriatrics: Option[String] = None,
               primaryCarePediatrics: Option[String] = None,
               serviceLine: Option[String] = None
              )

case class ActivityMedicalCode(
                                medicalCode: String,
                                medicalCodeType: String,
                                sequenceNumber: Int
                              )

case class AssessmentResults(
                              variable: String,
                              value: String
                            )

case class Activity(
                     // Primary Identifiers
                     customer: String,
                     activityId: String,
                     personId: Option[String] = None,
                     batchId: String,
                     sourceRecordId: Option[String] = None,
                     sourcePersonId: Option[String] = None,
                     source: Option[String] = None,
                     sourceType: Option[String] = None,
                     sourceName: Option[String] = None,
                     dateModified: Option[Timestamp] = None,
                     dateCreated: Timestamp,
                     mergedActivityIds: Seq[String] = Seq.empty,
                     mergedBatchIds: Seq[String] = Seq.empty,

                     // Activity Location Specific Information
                     locationCode: Option[String] = None,
                     locationDesc: Option[String] = None,
                     sourceLocationDesc: Option[String] = None,
                     hospital: Option[String] = None,
                     businessUnit: Option[String] = None,
                     site: Option[String] = None,
                     clinic: Option[String] = None,
                     practiceLocation: Option[String] = None,
                     facility: Option[String] = None,
                     sourceErPatient: Option[String] = None,
                     isErPatient: Option[Boolean] = None,

                     // Visit Specific Information
                     providers: Seq[String] = Seq.empty,
                     financialClass: Option[String] = None,
                     payerType: Option[String] = None,
                     payerTypeDescription: Option[String] = None,
                     inferredPayerType: Option[String] = None,
                     sourcePatientType: Option[String] = None,
                     patientType: Option[String] = None,
                     sourceFinancialClass: Option[String] = None,
                     insurance: Option[String] = None,
                     admitDate: Option[Date] = None,
                     dischargeDate: Option[Date] = None,
                     finalBillDate: Option[Date] = None,
                     sourceDischargeStatus: Option[String] = None,
                     dischargeStatus: Option[String] = None,
                     lengthOfStay: Option[Int] = None,
                     charges: Option[java.math.BigDecimal] = None,
                     cost: Option[java.math.BigDecimal] = None,
                     grossMargin: Option[java.math.BigDecimal] = None,
                     contributionMargin: Option[java.math.BigDecimal] = None,
                     profit: Option[java.math.BigDecimal] = None,
                     systolic: Option[Double] = None,
                     diastolic: Option[Double] = None,
                     height: Option[Double] = None,
                     weight: Option[Double] = None,
                     bodyMassIndex: Option[Double] = None,
                     guarantorFirstName: Option[String] = None,
                     guarantorLastName: Option[String] = None,
                     guarantorMiddleName: Option[String] = None,
                     assessmentResults: Seq[AssessmentResults] = Seq.empty,

                     currentProceduralTerminologyCodes: Seq[ActivityMedicalCode] = Seq.empty,
                     diagnosisCodes: Seq[ActivityMedicalCode] = Seq.empty,
                     procedureCodes: Seq[ActivityMedicalCode] = Seq.empty,
                     medicalSeverityDiagnosisRelatedGroup: Option[Int] = None,
                     // Activity Metadata
                     activityType: Option[String] = None,
                     activity: Option[String] = None,
                     activityGroup: Option[String] = None,
                     activityLocation: Option[String] = None,
                     // once we update cleanse job so they send activityDate as date we can update this field type
                     activityDate: Date,

                     // Demographic Data
                     sourceFirstName: Option[String] = None,
                     sourceLastName: Option[String] = None,
                     sourceMiddleName: Option[String] = None,
                     firstName: Option[String] = None,
                     lastName: Option[String] = None,
                     middleName: Option[String] = None,
                     prefix: Option[String] = None,
                     personalSuffix: Option[String] = None,
                     professionalSuffix: Option[String] = None,
                     sourceSex: Option[String] = None,
                     sex: Option[String] = None,
                     dateOfBirth: Option[Date] = None,
                     dateOfDeath: Option[Date] = None,
                     sourceMaritalStatus: Option[String] = None,
                     maritalStatus: Option[String] = None,
                     sourceRace: Option[String] = None,
                     race: Option[String] = None,
                     ethnicInsight: Option[String] = None,
                     religion: Option[String] = None,
                     isoLanguageCode: Option[String] = None,
                     isoLanguageDesc: Option[String] = None,
                     occupation: Option[String] = None,
                     occupationGroup: Option[String] = None,
                     dwellType: Option[String] = None,
                     combinedOwner: Option[String] = None,
                     householdIncome: Option[String] = None,
                     recipientReliabilityCode: Option[Int] = None,
                     mailResponder: Option[String] = None,
                     lengthOfResidence: Option[Int] = None,
                     personsInLivingUnit: Option[Int] = None,
                     adultsInLivingUnit: Option[Int] = None,
                     childrenInLivingUnit: Option[Int] = None,
                     homeYearBuilt: Option[Int] = None,
                     homeLandValue: Option[Float] = None,
                     estimatedHomeValue: Option[String] = None,
                     hasDonatedToCharity: Option[Boolean] = None,
                     mosaicZip4: Option[String] = None,
                     mosaicGlobalZip4: Option[String] = None,
                     householdComposition: Option[String] = None,
                     wealthRating: Option[Int] = None,
                     addressQualityIndicator: Option[String] = None,
                     education: Option[String] = None,
                     sourceAge: Option[Int] = None,
                     beehiveCluster: Option[Int] = None,
                     isChildPresent: Option[Boolean] = None,
                     hasChildZeroToThree: Option[Boolean] = None,
                     hasChildFourToSix: Option[Boolean] = None,
                     hasChildSevenToNine: Option[Boolean] = None,
                     hasChildTenToTwelve: Option[Boolean] = None,
                     hasChildThirteenToFifteen: Option[Boolean] = None,
                     hasChildSixteenToEighteen: Option[Boolean] = None,
                     sourcePersonType: Option[String] = None,

                     // Contact Information
                     homePhone: Option[String] = None,
                     mobilePhone: Option[String] = None,
                     workPhone: Option[String] = None,
                     workPhoneExtension: Option[String] = None,
                     email: Option[String] = None,

                     // Address
                     address1: Option[String] = None,
                     address2: Option[String] = None,
                     city: Option[String] = None,
                     state: Option[String] = None,
                     zip5: Option[String] = None,
                     zip4: Option[String] = None,
                     country: Option[String] = None,
                     county: Option[String] = None,
                     carrierRoute: Option[String] = None,
                     deliveryPointCode: Option[String] = None,
                     streetPreDirection: Option[String] = None,
                     streetName: Option[String] = None,
                     streetPostDirection: Option[String] = None,
                     streetSuffix: Option[String] = None,
                     streetSecondNumber: Option[String] = None,
                     streetSecondUnit: Option[String] = None,
                     streetHouseNumber: Option[String] = None,
                     metropolitanStatisticalArea: Option[String] = None,
                     primaryMetropolitanStatisticalArea: Option[String] = None,
                     coreBasedStatisticalArea: Option[String] = None,
                     coreBasedStatisticalAreaType: Option[String] = None,
                     deliveryPointValidation: Option[String] = None,
                     countyCode: Option[String] = None,
                     censusBlock: Option[String] = None,
                     censusTract: Option[String] = None,
                     addressType: Option[String] = None,
                     isValidAddress: Option[Boolean] = None,
                     ncoaMoveType: Option[String] = None,
                     ncoaMoveDate: Option[String] = None,
                     addressCoordinates: Option[Coordinates] = None,

                     // New Movers
                     movedFromZip5: Option[String] = None,
                     movedToZip5: Option[String] = None,
                     experianMoveType: Option[String] = None,
                     experianMoveMonth: Option[String] = None,
                     hasMovedAway: Option[Boolean] = None,

                     // Do Not Solicit Information
                     isOptedOutDirectMail: Option[Boolean] = None,
                     isOptedOutCall: Option[Boolean] = None,
                     isOptedOutEmail: Option[Boolean] = None,
                     isOptedOutText: Option[Boolean] = None,
                     doNotSolicit: Option[Boolean] = None,
                     optOutDirectMailReasons: Seq[String] = Seq.empty,
                     optOutCallReasons: Seq[String] = Seq.empty,
                     optOutEmailReasons: Seq[String] = Seq.empty,
                     optOutTextReasons: Seq[String] = Seq.empty,

                     // Other
                     personalUrl: Option[String] = None,
                     reason: Option[String] = None,
                     employer: Option[String] = None,
                     messageType: Option[String] = None,
                     primaryCarePhysicianId: Option[String] = None,
                     sourceExclusionFlag: Option[String] = None,
                     sourceDoNotSolicitReason: Option[String] = None,
                     sourceClient: Option[String] = None,
                     exclusionFlag: Option[String] = None,
                     portalStatus: Option[String] = None,
                     // SG2
                     sg2: Option[SG2] = None
                   ) extends PrimaryIdentity {

  override val primaryEmail: Option[String] = email

  override val primaryPhoneNumber: Option[String] = mobilePhone.orElse(homePhone)

  val primaryPhoneNumberType: Option[String] = mobilePhone.map(_ => "MOBILE").orElse(homePhone.map(_ => "HOME"))

  override val mrids: Seq[String] = sourcePersonId.map(sourcePersonId =>
    s"$customer.${source.getOrElse("None")}.${sourceType.getOrElse("None")}.$sourcePersonId").toSeq

}


object Activity {

  val gson = new Gson()
  val gsonMapType = new TypeToken[java.util.Map[String, String]] {}.getType

  val Schema: StructType = StructType(Seq(
    // Primary Identifiers
    StructField("customer", StringType, nullable = false),
    StructField("activityId", StringType, nullable = false),
    StructField("personId", StringType, nullable = true),
    StructField("batchId", StringType, nullable = false),
    StructField("sourceRecordId", StringType, nullable = true),
    StructField("sourcePersonId", StringType, nullable = true),
    StructField("source", StringType, nullable = true),
    StructField("sourceType", StringType, nullable = true),
    StructField("sourceName", StringType, nullable = true),
    StructField("dateModified", TimestampType, nullable = true),
    StructField("dateCreated", TimestampType, nullable = false),
    StructField("mergedActivityIds", ArrayType(StringType), nullable = true),
    StructField("mergedBatchIds", ArrayType(StringType), nullable = true),

    // Activity Location Specific Information
    StructField("locationCode", StringType, nullable = true),
    StructField("locationDesc", StringType, nullable = true),
    StructField("sourceLocationDesc", StringType, nullable = true),
    StructField("hospital", StringType, nullable = true),
    StructField("businessUnit", StringType, nullable = true),
    StructField("site", StringType, nullable = true),
    StructField("clinic", StringType, nullable = true),
    StructField("practiceLocation", StringType, nullable = true),
    StructField("facility", StringType, nullable = true),
    StructField("sourceErPatient", StringType, nullable = true),
    StructField("isErPatient", BooleanType, nullable = true),

    // Visit Specific Information
    StructField("providers", ArrayType(StringType), nullable = true),
    StructField("financialClass", StringType, nullable = true),
    StructField("payerType", StringType, nullable = true),
    StructField("payerTypeDescription", StringType, nullable = true),
    StructField("inferredPayerType", StringType, nullable = true),
    StructField("sourcePatientType", StringType, nullable = true),
    StructField("patientType", StringType, nullable = true),
    StructField("sourceFinancialClass", StringType, nullable = true),
    StructField("insurance", StringType, nullable = true),
    StructField("admitDate", DateType, nullable = true),
    StructField("dischargeDate", DateType, nullable = true),
    StructField("finalBillDate", DateType, nullable = true),
    StructField("sourceDischargeStatus", StringType, nullable = true),
    StructField("dischargeStatus", StringType, nullable = true),
    StructField("lengthOfStay", IntegerType, nullable = true),
    StructField("charges", DecimalType(Constants.DecimalTypePrecision, Constants.DecimalTypeScale), nullable = true),
    StructField("cost", DecimalType(Constants.DecimalTypePrecision, Constants.DecimalTypeScale), nullable = true),
    StructField("grossMargin", DecimalType(Constants.DecimalTypePrecision, Constants.DecimalTypeScale), nullable = true),
    StructField("contributionMargin",
      DecimalType(Constants.DecimalTypePrecision, Constants.DecimalTypeScale), nullable = true),
    StructField("profit", DecimalType(Constants.DecimalTypePrecision, Constants.DecimalTypeScale), nullable = true),
    StructField("systolic", DoubleType, nullable = true),
    StructField("diastolic", DoubleType, nullable = true),
    StructField("height", DoubleType, nullable = true),
    StructField("weight", DoubleType, nullable = true),
    StructField("bodyMassIndex", DoubleType, nullable = true),
    StructField("guarantorFirstName", StringType, nullable = true),
    StructField("guarantorLastName", StringType, nullable = true),
    StructField("guarantorMiddleName", StringType, nullable = true),
    StructField("assessmentResults", ArrayType(StructType(Seq(
      StructField("variable", StringType, nullable = true),
      StructField("value", StringType, nullable = true)
    ))), nullable = true),
    StructField("currentProceduralTerminologyCodes", ArrayType(StructType(Seq(
      StructField("medicalCode", StringType, nullable = true),
      StructField("medicalCodeType", StringType, nullable = true),
      StructField("sequenceNumber", IntegerType, nullable = true)
    ))), nullable = true),
    StructField("diagnosisCodes", ArrayType(StructType(Seq(
      StructField("medicalCode", StringType, nullable = true),
      StructField("medicalCodeType", StringType, nullable = true),
      StructField("sequenceNumber", IntegerType, nullable = true)
    ))), nullable = true),
    StructField("procedureCodes", ArrayType(StructType(Seq(
      StructField("medicalCode", StringType, nullable = true),
      StructField("medicalCodeType", StringType, nullable = true),
      StructField("sequenceNumber", IntegerType, nullable = true)
    ))), nullable = true),
    StructField("medicalSeverityDiagnosisRelatedGroup", IntegerType, nullable = true),
    // Activity Metadata
    StructField("activityType", StringType, nullable = true),
    StructField("activity", StringType, nullable = true),
    StructField("activityGroup", StringType, nullable = true),
    StructField("activityLocation", StringType, nullable = true),
    StructField("activityDate", DateType, nullable = false),

    // Demographic Data
    StructField("sourceFirstName", StringType, nullable = true),
    StructField("sourceLastName", StringType, nullable = true),
    StructField("sourceMiddleName", StringType, nullable = true),
    StructField("firstName", StringType, nullable = true),
    StructField("lastName", StringType, nullable = true),
    StructField("middleName", StringType, nullable = true),
    StructField("prefix", StringType, nullable = true),
    StructField("personalSuffix", StringType, nullable = true),
    StructField("professionalSuffix", StringType, nullable = true),
    StructField("sourceSex", StringType, nullable = true),
    StructField("sex", StringType, nullable = true),
    StructField("dateOfBirth", DateType, nullable = true),
    StructField("dateOfDeath", DateType, nullable = true),
    StructField("sourceMaritalStatus", StringType, nullable = true),
    StructField("maritalStatus", StringType, nullable = true),
    StructField("sourceRace", StringType, nullable = true),
    StructField("race", StringType, nullable = true),
    StructField("ethnicInsight", StringType, nullable = true),
    StructField("religion", StringType, nullable = true),
    StructField("isoLanguageCode", StringType, nullable = true),
    StructField("isoLanguageDesc", StringType, nullable = true),
    StructField("occupation", StringType, nullable = true),
    StructField("occupationGroup", StringType, nullable = true),
    StructField("dwellType", StringType, nullable = true),
    StructField("combinedOwner", StringType, nullable = true),
    StructField("householdIncome", StringType, nullable = true),
    StructField("recipientReliabilityCode", IntegerType, nullable = true),
    StructField("mailResponder", StringType, nullable = true),
    StructField("lengthOfResidence", IntegerType, nullable = true),
    StructField("personsInLivingUnit", IntegerType, nullable = true),
    StructField("adultsInLivingUnit", IntegerType, nullable = true),
    StructField("childrenInLivingUnit", IntegerType, nullable = true),
    StructField("homeYearBuilt", IntegerType, nullable = true),
    StructField("homeLandValue", FloatType, nullable = true),
    StructField("estimatedHomeValue", StringType, nullable = true),
    StructField("hasDonatedToCharity", BooleanType, nullable = true),
    StructField("mosaicZip4", StringType, nullable = true),
    StructField("mosaicGlobalZip4", StringType, nullable = true),
    StructField("householdComposition", StringType, nullable = true),
    StructField("wealthRating", IntegerType, nullable = true),
    StructField("addressQualityIndicator", StringType, nullable = true),
    StructField("education", StringType, nullable = true),
    StructField("sourceAge", IntegerType, nullable = true),
    StructField("beehiveCluster", IntegerType, nullable = true),
    StructField("isChildPresent", BooleanType, nullable = true),
    StructField("hasChildZeroToThree", BooleanType, nullable = true),
    StructField("hasChildFourToSix", BooleanType, nullable = true),
    StructField("hasChildSevenToNine", BooleanType, nullable = true),
    StructField("hasChildTenToTwelve", BooleanType, nullable = true),
    StructField("hasChildThirteenToFifteen", BooleanType, nullable = true),
    StructField("hasChildSixteenToEighteen", BooleanType, nullable = true),
    StructField("sourcePersonType", StringType, nullable = true),

    // Contact Information
    StructField("homePhone", StringType, nullable = true),
    StructField("mobilePhone", StringType, nullable = true),
    StructField("workPhone", StringType, nullable = true),
    StructField("workPhoneExtension", StringType, nullable = true),
    StructField("email", StringType, nullable = true),

    // Address
    StructField("address1", StringType, nullable = true),
    StructField("address2", StringType, nullable = true),
    StructField("city", StringType, nullable = true),
    StructField("state", StringType, nullable = true),
    StructField("zip5", StringType, nullable = true),
    StructField("zip4", StringType, nullable = true),
    StructField("country", StringType, nullable = true),
    StructField("county", StringType, nullable = true),
    StructField("carrierRoute", StringType, nullable = true),
    StructField("deliveryPointCode", StringType, nullable = true),
    StructField("streetPreDirection", StringType, nullable = true),
    StructField("streetName", StringType, nullable = true),
    StructField("streetPostDirection", StringType, nullable = true),
    StructField("streetSuffix", StringType, nullable = true),
    StructField("streetSecondNumber", StringType, nullable = true),
    StructField("streetSecondUnit", StringType, nullable = true),
    StructField("streetHouseNumber", StringType, nullable = true),
    StructField("metropolitanStatisticalArea", StringType, nullable = true),
    StructField("primaryMetropolitanStatisticalArea", StringType, nullable = true),
    StructField("coreBasedStatisticalArea", StringType, nullable = true),
    StructField("coreBasedStatisticalAreaType", StringType, nullable = true),
    StructField("deliveryPointValidation", StringType, nullable = true),
    StructField("countyCode", StringType, nullable = true),
    StructField("censusBlock", StringType, nullable = true),
    StructField("censusTract", StringType, nullable = true),
    StructField("addressType", StringType, nullable = true),
    StructField("isValidAddress", BooleanType, nullable = true),
    StructField("ncoaMoveType", StringType, nullable = true),
    StructField("ncoaMoveDate", StringType, nullable = true),
    StructField("addressCoordinates", StructType(Seq(
      StructField("lat", FloatType, nullable = true),
      StructField("lon", FloatType, nullable = true)
    )), nullable = true),

    // New Movers
    StructField("movedFromZip5", StringType, nullable = true),
    StructField("movedToZip5", StringType, nullable = true),
    StructField("experianMoveType", StringType, nullable = true),
    StructField("experianMoveMonth", StringType, nullable = true),
    StructField("hasMovedAway", BooleanType, nullable = true),

    // Do Not Solicit Information
    StructField("isOptedOutDirectMail", BooleanType, nullable = true),
    StructField("isOptedOutCall", BooleanType, nullable = true),
    StructField("isOptedOutEmail", BooleanType, nullable = true),
    StructField("isOptedOutText", BooleanType, nullable = true),
    StructField("doNotSolicit", BooleanType, nullable = true),
    StructField("optOutDirectMailReasons", ArrayType(StringType), nullable = true),
    StructField("optOutCallReasons", ArrayType(StringType), nullable = true),
    StructField("optOutEmailReasons", ArrayType(StringType), nullable = true),
    StructField("optOutTextReasons", ArrayType(StringType), nullable = true),

    // Other
    StructField("personalUrl", StringType, nullable = true),
    StructField("reason", StringType, nullable = true),
    StructField("employer", StringType, nullable = true),
    StructField("messageType", StringType, nullable = true),
    StructField("primaryCarePhysicianId", StringType, nullable = true),
    StructField("sourceExclusionFlag", StringType, nullable = true),
    StructField("sourceDoNotSolicitReason", StringType, nullable = true),
    StructField("sourceClient", StringType, nullable = true),
    StructField("exclusionFlag", StringType, nullable = true),
    StructField("portalStatus", StringType, nullable = true),

    StructField("sg2", StructType(Seq(
      StructField("careGroupCode", StringType, nullable = true),
      StructField("careGroupDescription", StringType, nullable = true),
      StructField("serviceLineGroup", StringType, nullable = true),
      StructField("serviceLine", StringType, nullable = true),
      StructField("careFamily", StringType, nullable = true),
      StructField("procedure", StringType, nullable = true),
      StructField("procedureGroup", StringType, nullable = true),
      StructField("mentalHealthConditions", StringType, nullable = true),
      StructField("addictionAdult", StringType, nullable = true),
      StructField("behavioralHealthConditionsAdult", StringType, nullable = true),
      StructField("diabetesAdult", StringType, nullable = true),
      StructField("cardiacDiseaseAdult", StringType, nullable = true),
      StructField("pulmonaryDiseaseAdult", StringType, nullable = true),
      StructField("adultChronicConditionsCount", StringType, nullable = true),
      StructField("asthmaPediatric", StringType, nullable = true),
      StructField("behavioralHealthConditionsPediatric", StringType, nullable = true),
      StructField("complexCardiacConditionsPediatric", StringType, nullable = true),
      StructField("pediatricComplexConditionsCount", StringType, nullable = true),
      StructField("trauma", StringType, nullable = true),
      StructField("procedureGroupCategory", StringType, nullable = true),
      StructField("sportsMedicine", StringType, nullable = true),
      StructField("painServices", StringType, nullable = true),
      StructField("primaryCareAllAdults", StringType, nullable = true),
      StructField("primaryCareGeriatrics", StringType, nullable = true),
      StructField("primaryCarePediatrics", StringType, nullable = true)
    )), nullable = true)
  ))

  def cleanseRowField[T](row: Row, fieldName: String): Option[T] = {
    Try(row.getAs[T](fieldName)).toOption.flatMap(Option(_))
  }

  def cleanseRowCollectionField[T](row: Row, fieldName: String): Seq[T] = {
    Option(row.getSeq[T](row.fieldIndex(fieldName))).getOrElse(Seq.empty[T])
  }

  def cleanseMedicalCode(row: Row, fieldName: String): Seq[ActivityMedicalCode] = {

    def extract[T: ClassTag](list: Seq[Any]): Option[Seq[T]] = {
      val isAppropriateType: Boolean = list.headOption.exists {
        case _: T => true
        case _ => false
      }
      if (isAppropriateType) {
        Some(list.flatMap {
          case element: T => Some(element)
          case _ => None
        })
      } else {
        None
      }
    }

    val value = row.get(row.fieldIndex(fieldName))

    Option(value).map {
      case jsonStringArray: String =>
        SerializationUtils.gson.fromJson(
          jsonStringArray.asInstanceOf[String], new TypeToken[java.util.ArrayList[ActivityMedicalCode]]() {}.getType).
          asInstanceOf[java.util.ArrayList[ActivityMedicalCode]].asScala
      case sequenceOfUnknownType: Seq[Any] =>
        extract[Row](sequenceOfUnknownType).map { rows =>
          rows.map { rowItem =>
            ActivityMedicalCode(
              medicalCode = cleanseRowField[String](rowItem, "medicalCode").get,
              medicalCodeType = cleanseRowField[String](rowItem, "medicalCodeType").get,
              sequenceNumber = cleanseRowField[Int](rowItem, "sequenceNumber").get
            )
          }
        }.orElse(extract[ActivityMedicalCode](sequenceOfUnknownType)).getOrElse(Seq.empty[ActivityMedicalCode])
    }.getOrElse(Seq.empty[ActivityMedicalCode])

  }

  def cleanseAddressCoordinates(row: Row, fieldName: String): Option[Coordinates] = {

    val value = row.get(row.fieldIndex(fieldName))

    Option(value).flatMap {
      case string: String =>
          // (0,0) - refers to the "Null Island" a location in the Gulf of Guinea off the west African coast
          // No person should ever have an address there
          if (string == "(0,0)") {
            None
          } else {
            val stringCoordinates: Seq[String] = string.split(",")
            val lon = stringCoordinates.head.replace("(", "").toFloat
            val lat = stringCoordinates.last.replace(")", "").toFloat
            Some(Coordinates(lat = lat, lon = lon))
          }
      case struct: Row =>
        Option(struct).map { s =>
          Coordinates(
            lat = s.getAs[Float]("lat"),
            lon = s.getAs[Float]("lon")
          )
        }

      case addressCoordinates: Coordinates => Option(addressCoordinates)
    }
  }


  def buildFromRow(row: Row): Activity = {

    Activity(
      // Unique Identifiers
      customer = row.getAs[String]("customer"),
      batchId = row.getAs[String]("batchId"),
      personId = cleanseRowField[String](row, "personId"),
      source = cleanseRowField(row, "source"),
      sourceType = cleanseRowField(row, "sourceType"),
      sourceRecordId = cleanseRowField(row, "sourceRecordId"),

      // Internal Dates
      dateCreated = row.getAs[Timestamp]("dateCreated"),
      mergedActivityIds = cleanseRowCollectionField[String](row, "mergedActivityIds"),
      mergedBatchIds = cleanseRowCollectionField[String](row, "mergedBatchIds"),
      dateModified = cleanseRowField[Timestamp](row, "dateModified"),
      activityDate = Try(row.getAs[Date]("activityDate"))
        .getOrElse(new java.sql.Date(row.getAs[Timestamp]("activityDate").getTime())),

      // Activity Columns
      activityType = cleanseRowField(row, "activityType"),
      providers = cleanseRowCollectionField[String](row, "providers"),
      isErPatient = cleanseRowField[Boolean](row, "isErPatient"),
      financialClass = cleanseRowField[String](row, "financialClass"),
      payerType = cleanseRowField[String](row, "payerType"),
      payerTypeDescription = cleanseRowField[String](row, "payerTypeDescription"),
      patientType = cleanseRowField[String](row, "patientType"),
      dischargeStatus = cleanseRowField[String](row, "dischargeStatus"),
      lengthOfStay = cleanseRowField[Int](row, "lengthOfStay"),

      // Source Activity fields
      sourcePatientType = cleanseRowField[String](row, "sourcePatientType"),
      sourceSex = cleanseRowField[String](row, "sourceSex"),
      sourceMaritalStatus = cleanseRowField[String](row, "sourceMaritalStatus"),
      sourceRace = cleanseRowField[String](row, "sourceRace"),
      sourceErPatient = cleanseRowField[String](row, "sourceErPatient"),
      sourceExclusionFlag = cleanseRowField[String](row, "sourceExclusionFlag"),
      sourceDischargeStatus = cleanseRowField[String](row, "sourceDischargeStatus"),
      sourceClient = cleanseRowField[String](row, "sourceClient"),
      sourceDoNotSolicitReason = cleanseRowField[String](row, "sourceDoNotSolicitReason"),
      sourceFinancialClass = cleanseRowField[String](row, "sourceFinancialClass"),
      sourceFirstName = cleanseRowField[String](row, "sourceFirstName"),
      sourceLastName = cleanseRowField[String](row, "sourceLastName"),
      sourceMiddleName = cleanseRowField[String](row, "sourceMiddleName"),

      // External Identifiers
      sourcePersonId = cleanseRowField[String](row, "sourcePersonId"),

      // External dates
      admitDate = cleanseRowField[Date](row, "admitDate"),
      dischargeDate = cleanseRowField[Date](row, "dischargeDate"),
      finalBillDate = cleanseRowField[Date](row, "finalBillDate"),

      // External Attributes
      locationCode = cleanseRowField[String](row, "locationCode"),
      locationDesc = cleanseRowField[String](row, "locationDesc"),
      sourceLocationDesc = cleanseRowField[String](row, "sourceLocationDesc"),
      hospital = cleanseRowField[String](row, "hospital"),
      businessUnit = cleanseRowField[String](row, "businessUnit"),
      site = cleanseRowField[String](row, "site"),
      clinic = cleanseRowField[String](row, "clinic"),
      practiceLocation = cleanseRowField[String](row, "practiceLocation"),
      facility = cleanseRowField[String](row, "facility"),
      employer = cleanseRowField[String](row, "employer"),

      // Financials
      insurance = cleanseRowField[String](row, "insurance"),

      charges = cleanseRowField[java.math.BigDecimal](row, "charges"),

      cost = cleanseRowField[java.math.BigDecimal](row, "cost"),

      grossMargin = cleanseRowField[java.math.BigDecimal](row, "grossMargin"),

      contributionMargin = cleanseRowField[java.math.BigDecimal](row, "contributionMargin"),

      profit = cleanseRowField[java.math.BigDecimal](row, "profit"),

      // Biometrics
      systolic = cleanseRowField[Double](row, "systolic"),
      diastolic = cleanseRowField[Double](row, "diastolic"),
      height = cleanseRowField[Double](row, "height"),
      weight = cleanseRowField[Double](row, "weight"),
      bodyMassIndex = cleanseRowField[Double](row, "bodyMassIndex"),

      // Gurantor Information
      guarantorFirstName = cleanseRowField[String](row, "guarantorFirstName"),
      guarantorLastName = cleanseRowField[String](row, "guarantorLastName"),
      guarantorMiddleName = cleanseRowField[String](row, "guarantorMiddleName"),

      // Activity fields derived from external attributes
      activityId = row.getAs[String]("activityId"),
      activity = cleanseRowField[String](row, "activity"),
      activityGroup = cleanseRowField[String](row, "activityGroup"),
      activityLocation = cleanseRowField[String](row, "activityLocation"),

      // Assessment
      assessmentResults = row.schema.find(_.name == "assessmentResults").get match {
        // Reading data from DB where the type is a JSON array returns a StringType
        // while reading data in memory and converting from row to Person class returns a ArrayType
        case StructField(_, StringType, _, _) =>
          cleanseRowField[String](row, "assessmentResults").map(string =>
            SerializationUtils.gson.fromJson(
              string, new TypeToken[java.util.ArrayList[AssessmentResults]]() {
              }.getType).
              asInstanceOf[java.util.ArrayList[AssessmentResults]].asScala).
            getOrElse(Seq.empty[AssessmentResults])
        case StructField(_, ArrayType(_, _), _, _) =>
          cleanseRowField[Seq[String]](row, "assessmentResults").map {
            strings =>
              strings.map {
                s =>
                  SerializationUtils.gson.fromJson[AssessmentResults](s.trim, classOf[AssessmentResults])
              }
          }.getOrElse(Seq.empty[AssessmentResults])
      },

      // Demographic Data
      firstName = cleanseRowField[String](row, "firstName"),
      middleName = cleanseRowField[String](row, "middleName"),
      lastName = cleanseRowField[String](row, "lastName"),
      prefix = cleanseRowField[String](row, "prefix"),
      personalSuffix = cleanseRowField[String](row, "personalSuffix"),
      professionalSuffix = cleanseRowField[String](row, "professionalSuffix"),
      dateOfBirth = cleanseRowField[Date](row, "dateOfBirth"),
      sourceAge = cleanseRowField[Int](row, "sourceAge"),
      sex = cleanseRowField[String](row, "sex"),
      maritalStatus = cleanseRowField[String](row, "maritalStatus"),
      beehiveCluster = cleanseRowField[Int](row, "beehiveCluster"),
      primaryCarePhysicianId = cleanseRowField[String](row, "primaryCarePhysicianId"),

      // Contact Information
      homePhone = cleanseRowField[String](row, "homePhone"),
      mobilePhone = cleanseRowField[String](row, "mobilePhone"),
      workPhone = cleanseRowField[String](row, "workPhone"),
      workPhoneExtension = cleanseRowField[String](row, "workPhoneExtension"),
      email = cleanseRowField[String](row, "email"),

      // Family Information
      isChildPresent = cleanseRowField[Boolean](row, "isChildPresent"),
      hasChildZeroToThree = cleanseRowField[Boolean](row, "hasChildZeroToThree"),
      hasChildFourToSix = cleanseRowField[Boolean](row, "hasChildFourToSix"),
      hasChildSevenToNine = cleanseRowField[Boolean](row, "hasChildSevenToNine"),
      hasChildTenToTwelve = cleanseRowField[Boolean](row, "hasChildTenToTwelve"),
      hasChildThirteenToFifteen = cleanseRowField[Boolean](row, "hasChildThirteenToFifteen"),
      hasChildSixteenToEighteen = cleanseRowField[Boolean](row, "hasChildSixteenToEighteen"),

      // Experian Data
      ethnicInsight = cleanseRowField[String](row, "ethnicInsight"),
      race = cleanseRowField[String](row, "race"),
      religion = cleanseRowField[String](row, "religion"),
      isoLanguageCode = cleanseRowField[String](row, "isoLanguageCode"),
      isoLanguageDesc = cleanseRowField[String](row, "isoLanguageDesc"),
      occupationGroup = cleanseRowField[String](row, "occupationGroup"),
      occupation = cleanseRowField[String](row, "occupation"),
      dwellType = cleanseRowField[String](row, "dwellType"),
      combinedOwner = cleanseRowField[String](row, "combinedOwner"),
      householdIncome = cleanseRowField[String](row, "householdIncome"),
      recipientReliabilityCode = cleanseRowField[Int](row, "recipientReliabilityCode"),
      mailResponder = cleanseRowField[String](row, "mailResponder"),
      lengthOfResidence = cleanseRowField[Int](row, "lengthOfResidence"),
      personsInLivingUnit = cleanseRowField[Int](row, "personsInLivingUnit"),
      adultsInLivingUnit = cleanseRowField[Int](row, "adultsInLivingUnit"),
      childrenInLivingUnit = cleanseRowField[Int](row, "childrenInLivingUnit"),
      homeYearBuilt = cleanseRowField[Int](row, "homeYearBuilt"),
      homeLandValue = Try(cleanseRowField[Double](row, "homeLandValue").map(_.toFloat)).
        getOrElse(cleanseRowField[Float](row, "homeLandValue")),
      estimatedHomeValue = cleanseRowField[String](row, "estimatedHomeValue"),
      hasDonatedToCharity = cleanseRowField[Boolean](row, "hasDonatedToCharity"),
      mosaicZip4 = cleanseRowField[String](row, "mosaicZip4"),
      mosaicGlobalZip4 = cleanseRowField[String](row, "mosaicGlobalZip4"),
      householdComposition = cleanseRowField[String](row, "householdComposition"),
      wealthRating = cleanseRowField[Int](row, "wealthRating"),
      addressQualityIndicator = cleanseRowField[String](row, "addressQualityIndicator"),
      education = cleanseRowField[String](row, "education"),

      // Address Info Enriched via CASS/NCOA
      country = cleanseRowField[String](row, "country"),
      county = cleanseRowField[String](row, "county"),
      carrierRoute = cleanseRowField[String](row, "carrierRoute"),
      deliveryPointCode = cleanseRowField[String](row, "deliveryPointCode"),
      streetPreDirection = cleanseRowField[String](row, "streetPreDirection"),
      streetName = cleanseRowField[String](row, "streetName"),
      streetPostDirection = cleanseRowField[String](row, "streetPostDirection"),
      streetSuffix = cleanseRowField[String](row, "streetSuffix"),
      streetSecondNumber = cleanseRowField[String](row, "streetSecondNumber"),
      streetSecondUnit = cleanseRowField[String](row, "streetSecondUnit"),
      streetHouseNumber = cleanseRowField[String](row, "streetHouseNumber"),
      metropolitanStatisticalArea = cleanseRowField[String](row, "metropolitanStatisticalArea"),
      primaryMetropolitanStatisticalArea = cleanseRowField[String](row, "primaryMetropolitanStatisticalArea"),
      coreBasedStatisticalArea = cleanseRowField[String](row, "coreBasedStatisticalArea"),
      coreBasedStatisticalAreaType = cleanseRowField[String](row, "coreBasedStatisticalAreaType"),
      deliveryPointValidation = cleanseRowField[String](row, "deliveryPointValidation"),
      countyCode = cleanseRowField[String](row, "countyCode"),
      censusBlock = cleanseRowField[String](row, "censusBlock"),
      censusTract = cleanseRowField[String](row, "censusTract"),
      ncoaMoveType = cleanseRowField[String](row, "ncoaMoveType"),
      ncoaMoveDate = cleanseRowField[String](row, "ncoaMoveDate"),
      addressCoordinates = cleanseAddressCoordinates(row, "addressCoordinates"),
      movedFromZip5 = cleanseRowField[String](row, "movedFromZip5"),
      movedToZip5 = cleanseRowField[String](row, "movedToZip5"),
      experianMoveType = cleanseRowField[String](row, "experianMoveType"),
      experianMoveMonth = cleanseRowField[String](row, "experianMoveMonth"),
      hasMovedAway = cleanseRowField[Boolean](row, "hasMovedAway"),
      // Original Address Info
      addressType = cleanseRowField[String](row, "addressType"),
      isValidAddress =  cleanseRowField[Boolean](row, "isValidAddress"),
      address1 = cleanseRowField[String](row, "address1"),
      address2 = cleanseRowField[String](row, "address2"),
      city = cleanseRowField[String](row, "city"),
      state = cleanseRowField[String](row, "state"),
      zip5 = cleanseRowField[String](row, "zip5"),
      zip4 = cleanseRowField[String](row, "zip4"),

      // Influence Health Enrichments
      messageType = cleanseRowField[String](row, "messageType"),
      sourcePersonType = cleanseRowField[String](row, "sourcePersonType"),

      // External Reasons
      reason = cleanseRowField[String](row, "reason"),

      // External Metadata
      sourceName = cleanseRowField[String](row, "sourceName"),
      personalUrl = cleanseRowField[String](row, "personalUrl"),

      // DNS values
      doNotSolicit = cleanseRowField[Boolean](row, "doNotSolicit"),
      isOptedOutDirectMail = cleanseRowField[Boolean](row, "isOptedOutDirectMail"),
      optOutDirectMailReasons = cleanseRowCollectionField[String](row, "optOutDirectMailReasons"),
      isOptedOutCall = cleanseRowField[Boolean](row, "isOptedOutCall"),
      optOutCallReasons = cleanseRowCollectionField[String](row, "optOutCallReasons"),
      isOptedOutEmail = cleanseRowField[Boolean](row, "isOptedOutEmail"),
      optOutEmailReasons = cleanseRowCollectionField[String](row, "optOutEmailReasons"),
      isOptedOutText = cleanseRowField[Boolean](row, "isOptedOutText"),
      optOutTextReasons = cleanseRowCollectionField[String](row, "optOutTextReasons"),
      dateOfDeath = cleanseRowField[Date](row, "dateOfDeath"),
      // Other
      portalStatus = cleanseRowField[String](row, "portalStatus"),
      inferredPayerType = cleanseRowField[String](row, "inferredPayerType"),
      exclusionFlag = cleanseRowField[String](row, "exclusionFlag"),
      medicalSeverityDiagnosisRelatedGroup = cleanseRowField[Int](row, "medicalSeverityDiagnosisRelatedGroup"),
      currentProceduralTerminologyCodes =
        cleanseMedicalCode(row, "currentProceduralTerminologyCodes"),
      diagnosisCodes =
        cleanseMedicalCode(row, "diagnosisCodes"),
      procedureCodes =
        cleanseMedicalCode(row, "procedureCodes"),
      sg2 = if (Seq(
        cleanseRowField[String](row, "careGroupCode"),
        cleanseRowField[String](row, "careGroupDescription"),
        cleanseRowField[String](row, "serviceLineGroup"),
        cleanseRowField[String](row, "careFamily"),
        cleanseRowField[String](row, "procedure"),
        cleanseRowField[String](row, "procedureGroup"),
        cleanseRowField[String](row, "mentalHealthConditions"),
        cleanseRowField[String](row, "addictionAdult"),
        cleanseRowField[String](row, "behavioralHealthConditionsAdult"),
        cleanseRowField[String](row, "diabetesAdult"),
        cleanseRowField[String](row, "cardiacDiseaseAdult"),
        cleanseRowField[String](row, "pulmonaryDiseaseAdult"),
        cleanseRowField[String](row, "adultChronicConditionsCount"),
        cleanseRowField[String](row, "asthmaPediatric"),
        cleanseRowField[String](row, "behavioralHealthConditionsPediatric"),
        cleanseRowField[String](row, "complexCardiacConditionsPediatric"),
        cleanseRowField[String](row, "pediatricComplexConditionsCount"),
        cleanseRowField[String](row, "trauma"),
        cleanseRowField[String](row, "procedureGroupCategory"),
        cleanseRowField[String](row, "sportsMedicine"),
        cleanseRowField[String](row, "painServices"),
        cleanseRowField[String](row, "primaryCareAllAdults"),
        cleanseRowField[String](row, "primaryCareGeriatrics"),
        cleanseRowField[String](row, "primaryCarePediatrics"),
        cleanseRowField[String](row, "serviceLine")
      ).exists(_.isDefined)) {
        Some(SG2(
          cleanseRowField[String](row, "careGroupCode"),
          cleanseRowField[String](row, "careGroupDescription"),
          cleanseRowField[String](row, "serviceLineGroup"),
          cleanseRowField[String](row, "careFamily"),
          cleanseRowField[String](row, "procedure"),
          cleanseRowField[String](row, "procedureGroup"),
          cleanseRowField[String](row, "mentalHealthConditions"),
          cleanseRowField[String](row, "addictionAdult"),
          cleanseRowField[String](row, "behavioralHealthConditionsAdult"),
          cleanseRowField[String](row, "diabetesAdult"),
          cleanseRowField[String](row, "cardiacDiseaseAdult"),
          cleanseRowField[String](row, "pulmonaryDiseaseAdult"),
          cleanseRowField[String](row, "adultChronicConditionsCount"),
          cleanseRowField[String](row, "asthmaPediatric"),
          cleanseRowField[String](row, "behavioralHealthConditionsPediatric"),
          cleanseRowField[String](row, "complexCardiacConditionsPediatric"),
          cleanseRowField[String](row, "pediatricComplexConditionsCount"),
          cleanseRowField[String](row, "trauma"),
          cleanseRowField[String](row, "procedureGroupCategory"),
          cleanseRowField[String](row, "sportsMedicine"),
          cleanseRowField[String](row, "painServices"),
          cleanseRowField[String](row, "primaryCareAllAdults"),
          cleanseRowField[String](row, "primaryCareGeriatrics"),
          cleanseRowField[String](row, "primaryCarePediatrics"),
            cleanseRowField[String](row, "serviceLine")

        ))
      } else {
        if (cleanseRowField[SG2](row, "sg2").isDefined) {
          cleanseRowField[SG2](row, "sg2")
        } else None
      }
    )
  }

  /**
    * Transforms a partial untyped activity schema into a complete activity schema with types converted
    *
    * @param df input dataframe
    * @return
    */
  def transformToActivitySchema(df: DataFrame): DataFrame = {
    // Transforms from current date type to activity schema type
    val transformedColumns: Seq[Column] =
      df.schema.map(struct => (struct, Activity.Schema.find(_.name == struct.name))).flatMap {
        case (currentType, Some(actualType))
          if currentType.dataType == actualType.dataType => Some(df(currentType.name))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == DoubleType =>
          Some(df(currentType.name).cast(DoubleType))

        case (currentType, Some(actualType))
          if currentType.dataType == DoubleType && actualType.dataType == StringType =>
          Some(df(currentType.name).cast(StringType))

        case (currentType, Some(actualType))
          if currentType.dataType == IntegerType && actualType.dataType == LongType =>
          Some(df(currentType.name).cast(LongType))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == DateType =>
          Some(df(currentType.name).cast(DateType))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == BooleanType =>
          Some(df(currentType.name).cast(BooleanType))

        case (currentType, Some(actualType))
          if (currentType.dataType == StringType || currentType.dataType == DoubleType) &&
            actualType.dataType == DecimalType(Constants.DecimalTypePrecision, Constants.DecimalTypeScale) =>
          Some(df(currentType.name).cast(DecimalType(Constants.DecimalTypePrecision, Constants.DecimalTypeScale)))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == IntegerType =>
          Some(df(currentType.name).cast(IntegerType))

        case (currentType, Some(actualType))
          if currentType.dataType == LongType && actualType.dataType == IntegerType =>
          Some(df(currentType.name).cast(IntegerType))

        case (currentType, Some(actualType))
          if currentType.dataType == IntegerType && actualType.dataType == StringType =>
          Some(df(currentType.name).cast(StringType))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == TimestampType =>
          Some(df(currentType.name).cast(TimestampType))

        case (currentType, Some(actualType))
          if currentType.dataType == TimestampType && actualType.dataType == DateType =>
          Some(df(currentType.name).cast(DateType))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == ArrayType(StringType) =>
          Some(df(currentType.name).cast(ArrayType(StringType, actualType.nullable)))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == ArrayType(IntegerType) =>
          Some(df(currentType.name).cast(ArrayType(IntegerType, actualType.nullable)))

        case (currentType, Some(actualType))
          if currentType.dataType == ArrayType(IntegerType, false) &&
            actualType.dataType == ArrayType(IntegerType, true) =>
          Some(df(currentType.name).cast(ArrayType(IntegerType, actualType.nullable)))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == LongType =>
          Some(df(currentType.name).cast(LongType))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == FloatType =>
          Some(df(currentType.name).cast(FloatType))

        case (currentType, Some(actualType))
          if currentType.dataType == TimestampType && actualType.dataType == DateType =>
          Some(df(currentType.name).cast(DateType))

        case (currentType, Some(actualType))
          if currentType.dataType == DoubleType && actualType.dataType == FloatType =>
          Some(df(currentType.name).cast(FloatType))

        case (StructField(name, _: DecimalType, _, _), Some(StructField(_, _: DecimalType, _, _))) =>
          Some(df(name).cast(DecimalType(Constants.DecimalTypePrecision, Constants.DecimalTypeScale)))

        case (currentType, None) => None
      }

    // Adding columns that are not present in the dataFrame but are present in the activity schema
    val missingColumns: Seq[Column] = Activity.Schema.filter(x => !df.schema.fieldNames.contains(x.name))
      .map(x => lit(null).cast(x.dataType) as x.name)

    // Return all columns
    df.select(transformedColumns ++ missingColumns: _*)
  }

  /**
    * Transforms a partial untyped activity schema into a complete activity schema with types converted
    * and errors column.
    *
    * @param df input dataframe
    * @return
    */
  def transformToErrorActivitySchema(df: DataFrame): DataFrame = {
    // Transforms from current date type to activity schema type
    val transformedColumns: Seq[Column] =
      df.schema.map(struct => (struct, Activity.Schema.find(_.name == struct.name))).flatMap {
        case (currentType, Some(actualType))
          if currentType.dataType == actualType.dataType => Some(df(currentType.name))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == DoubleType =>
          Some(df(currentType.name).cast(DoubleType))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == DateType =>
          Some(df(currentType.name).cast(DateType))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == BooleanType =>
          Some(df(currentType.name).cast(BooleanType))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType &&
            actualType.dataType == DecimalType(Constants.DecimalTypePrecision, Constants.DecimalTypeScale) =>
          Some(df(currentType.name).cast(DecimalType(Constants.DecimalTypePrecision, Constants.DecimalTypeScale)))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == IntegerType =>
          Some(df(currentType.name).cast(IntegerType))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == TimestampType =>
          Some(df(currentType.name).cast(TimestampType))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == ArrayType(StringType) =>
          Some(df(currentType.name).cast(ArrayType(StringType, actualType.nullable)))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == ArrayType(IntegerType) =>
          Some(df(currentType.name).cast(ArrayType(IntegerType, actualType.nullable)))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == LongType =>
          Some(df(currentType.name).cast(LongType))

        case (currentType, Some(actualType))
          if currentType.dataType == StringType && actualType.dataType == FloatType =>
          Some(df(currentType.name).cast(FloatType))

        case (StructField(name, _: DecimalType, _, _), Some(StructField(_, _: DecimalType, _, _))) =>
          Some(df(name).cast(DecimalType(Constants.DecimalTypePrecision, Constants.DecimalTypeScale)))

        case (StructField(currentName, currentType, _, _), Some(StructField(actualName, actualType, _, _)))
          if currentName == actualName && currentType == actualType => Some(df(actualName))
        case (currentType, None) => None
      }

    // Adding columns that are not present in the dataFrame but are present in the activity schema
    val missingColumns: Seq[Column] = Activity.Schema.filter(x => !df.schema.fieldNames.contains(x.name))
      .map(x => lit(null).cast(x.dataType) as x.name)

    // adding error column
    val errorColumn: Seq[Column] = df.schema.filter(_.name == "errors").map(s => col(s.name))

    // Return all columns
    df.select(transformedColumns ++ missingColumns ++ errorColumn: _*)
  }
}