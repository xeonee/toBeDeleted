package com.influencehealth.edh.model.activitytype

import com.influencehealth.edh.Constants

trait Redox extends ActivityType {

  override val formatType: String = Constants.EncounterInfluenceHealthFormat
  override val defaultSource: String = Constants.EncounterInfluenceHealthDefaultSource
  override val defaultMessageType: String = Constants.EncounterDefaultMessageType
  override val defaultSourceType: String = Constants.EncounterDefaultSourceType
  override val defaultAddressType: String = Constants.EncounterDefaultAddressType
  override val defaultActivityType: String = Constants.EncounterActivityType
  override val defaultPersonType: String = Constants.EncounterPersonType

  override val cleanseStringColumnNames: Seq[String] = Seq.empty

  override val nullColumnNames: Seq[String] = Seq.empty

  override val zipColumnNames: Seq[String] = Seq.empty

  override val mandatoryContactColumnsNames: Seq[String] = Seq.empty


}