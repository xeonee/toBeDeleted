package com.influencehealth.edh.model.schema

import org.apache.spark.sql.types.{StringType, StructField, StructType}

object NewMoversSchema {

  // the structure of the newmover file
  val schema: StructType = StructType(Array(
    StructField("prefix", StringType, nullable = true),
    StructField("firstName", StringType, nullable = true),
    StructField("middleName", StringType, nullable = true),
    StructField("lastName", StringType, nullable = true),
    StructField("suffix", StringType, nullable = true),
    StructField("address2", StringType, nullable = true),
    StructField("address1", StringType, nullable = true),
    StructField("city", StringType, nullable = true),
    StructField("state", StringType, nullable = true),
    StructField("zip5", StringType, nullable = true),
    StructField("movedFromZip5", StringType, nullable = true),
    StructField("sex", StringType, nullable = true),
    StructField("age", StringType, nullable = true),
    StructField("householdIncome", StringType, nullable = true),
    StructField("sourceMaritalStatus", StringType, nullable = true),
    StructField("presenceOfChild", StringType, nullable = true)
  ))

}
