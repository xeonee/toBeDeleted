package com.influencehealth.edh.utils


import java.sql.Timestamp
import java.text.{DateFormat, SimpleDateFormat}
import java.util.{Calendar, Date, TimeZone}

import com.influencehealth.edh.implicits.DateTimeParseError
import org.joda.time.DateTime
import org.joda.time.format.{DateTimeFormat, DateTimeFormatterBuilder, ISODateTimeFormat}
import play.api.http.MediaRange.parse

object DateTimeUtilities {

  private lazy val defaultTimezone = TimeZone.getTimeZone("UTC")
  private lazy val dateParsers = Array(
    ISODateTimeFormat.dateTime().getParser, // yyyy-MM-dd'T'HH:mm:ss.SSSZZ
    ISODateTimeFormat.dateTimeNoMillis().getParser, // yyyy-MM-dd'T'HH:mm:ssZZ
    ISODateTimeFormat.basicDateTime().getParser, // yyyyMMdd'T'HHmmss.SSSZ
    ISODateTimeFormat.basicDateTimeNoMillis().getParser, // yyyyMMdd'T'HHmmssZ
    DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss.SSSZ").getParser,
    DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss.SSS").getParser,
    DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ssZ").getParser,
    DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss").getParser,
    ISODateTimeFormat.basicDate().getParser, // yyyyMMdd
    ISODateTimeFormat.date().getParser, // yyyy-MM-dd
    DateTimeFormat.forPattern("MM/dd/yyyy").getParser)

  private lazy val dateTimeFormatter = new DateTimeFormatterBuilder().append(null, dateParsers).toFormatter

  private def parseIntoCalendar(str: String, format: Option[String]): Calendar = {
    val formatter = (format match {
      case None => dateTimeFormatter
      case _ => DateTimeFormat.forPattern(format.get)
    }).withZoneUTC()

    val parsed = formatter.parseDateTime(str)
    val date: java.util.Date = parsed.toDate
    val cal = Calendar.getInstance(defaultTimezone)
    cal.setTime(date)
    val offset = cal.getTimeZone.getOffset(cal.getTimeInMillis)
    cal.add(Calendar.MILLISECOND, offset)

    cal
  }

  def convertToDateTime(str: String, format: Option[String] = None): DateTime = {
    try new DateTime(parseIntoCalendar(str, format))
    catch {
      case e: Throwable => throw DateTimeParseError(
        s"String value $str not cast properly to a org.joda.DateTime", e)
    }
  }

  def isRecent(sinceDate: String, dateCreated: Timestamp, dateModified: Option[Timestamp]): Boolean = {

    val formatter: DateFormat = new SimpleDateFormat("yyyy-MM-dd")
    val date: Date = formatter.parse(sinceDate)
    val sinceTimestamp: java.sql.Timestamp  = new Timestamp(date.getTime)

    if ((dateModified.isDefined && dateModified.get.after(sinceTimestamp)) || dateCreated.after(sinceTimestamp)) {
      true
    }
    else{
      false
    }

  }
  
}
