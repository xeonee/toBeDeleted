package com.influencehealth.edh.enrich.person.donotsolicit

import com.influencehealth.edh.config.EnrichJobConfig
import com.influencehealth.edh.enrich.PersonEnricher
import com.influencehealth.edh.model.Person
import org.apache.spark.sql.{Dataset, SparkSession}

class EnrichDoNotSolicitStep (val name: String, val next: Option[PersonEnricher])
                             (implicit enrichJobConfig: EnrichJobConfig, sparkSession: SparkSession)
  extends PersonEnricher {
  override def enrich(dataset: Dataset[Person]): Dataset[Person] = dataset
}
