package com.influencehealth.edh.utils

import java.time.LocalDate

import com.influencehealth.edh.Constants
import com.influencehealth.edh.Constants._

import scala.util.matching.Regex

object DataLakeUtilities {

  // RAW: s3://edh-prod-data/northwell/raw/encounter/influencehealth/2018-03/
  // BATCH-ID: chomp-encounter-influencehealth-v1-2018-03

  val s3BucketUrl = """(s3a|s3n)\://([a-zA-z]+)-([a-zA-z]+)-([a-zA-z]+)"""
  val rawString = "raw"
  val cleansedString = "cleansed"
  val errorString = "error"
  val commonRegex = """([a-zA-z-]+)""" // general, customer, source/activity type
  val s3Batch = """(20\d{2}|19\d{2}|0(?!0)\d|[1-9]\d)\-(1[0-2]|0[1-9])"""
  val s3BatchDate = """(20\d{2}|19\d{2}|0(?!0)\d|[1-9]\d)\-(1[0-2]|0[1-9])-(0[1-9]|1[0-9]|2[0-9]|3[0-1])"""
  val s3BucketURLRegex: Regex = s"$s3BucketUrl(|/)".r
  val rawS3UrlRegex: Regex = s"$s3BucketUrl/$commonRegex/$rawString/$commonRegex/$commonRegex/$s3Batch/".r
  val rawS3UrlDailyRegex: Regex = s"$s3BucketUrl/$commonRegex/$rawString/$commonRegex/$commonRegex/$s3BatchDate/".r
  val cleansedS3UrlRegex: Regex = s"$s3BucketUrl/$commonRegex/$cleansedString/$commonRegex/$commonRegex/$s3Batch.parquet/".r
  val commonOutputOfCleansedRegex: Regex = s"$s3BucketUrl/$commonRegex/$commonRegex/$commonRegex/$commonRegex/$s3Batch(|.parquet)/".r
  val batchIdRegex: Regex = s"$commonRegex-$commonRegex-$commonRegex-$s3Batch".r
  val errorS3UrlRegex: Regex = s"$s3BucketUrl/$commonRegex/$errorString/$commonRegex/$commonRegex/$s3Batch/".r
  val cleansedS3UrlRegexRedox: Regex = s"$s3BucketUrl/$commonRegex/$cleansedString/$commonRegex/$commonRegex/$s3BatchDate.parquet/".r
  val commonOutputOfCleansedRegexRedox: Regex = s"$s3BucketUrl/$commonRegex/$commonRegex/$commonRegex/$commonRegex/$s3BatchDate(|.parquet)/".r
  val batchIdRegexWithDate: Regex = s"$commonRegex-$commonRegex-$commonRegex-$s3BatchDate".r
  val s3BatchWithYearAndMonth: Regex = s"$commonRegex-$commonRegex-$commonRegex-$s3Batch".r
  val batchWithYearAndMonth: Regex = s3Batch.r
  val batchWithDate: Regex = s3BatchDate.r


  /**
    * Returns a boolean value for matching S3 raw batch directories urls
    *
    * @param s3RawBatchDirectoryUrl input raw batch directories urls
    * @return
    */
  def validateRawS3ObjectKeys(s3RawBatchDirectoryUrl: String): Boolean = {
    rawS3UrlRegex.unapplySeq(s3RawBatchDirectoryUrl).isDefined ||
      rawS3UrlDailyRegex.unapplySeq(s3RawBatchDirectoryUrl).isDefined
  }

  /**
    * Returns a boolean value for matching S3 cleansed batch directories urls
    *
    * @param s3CleansedBatchDirectoryUrl input cleansed batch directories urls
    * @return
    */
  def validateCleansedS3ObjectKeys(s3CleansedBatchDirectoryUrl: String): Boolean = {
    cleansedS3UrlRegex.unapplySeq(s3CleansedBatchDirectoryUrl).isDefined ||
      cleansedS3UrlRegexRedox.unapplySeq(s3CleansedBatchDirectoryUrl).isDefined
  }

  /**
    * Returns a boolean value for matching batch id
    *
    * @param batchId input cleansed batch directories urls
    * @return
    */
  def validateBatchId(batchId: String): Boolean = {
    s3BatchWithYearAndMonth.unapplySeq(batchId).isDefined ||
      batchIdRegexWithDate.unapplySeq(batchId).isDefined
  }


  /**
    * Returns bucket name for provided s3 bucket url
    *
    * @param s3BucketUrl s3 bucket url that is configured in application confs eg: s3a://edh-data-staging/
    * @return
    */
  def getS3BucketName(s3BucketUrl: String): String = {
    if (s3BucketURLRegex.unapplySeq(s3BucketUrl).isDefined) s3BucketUrl.split("/")(2)
    else throw new RuntimeException(s"getS3BucketName: S3 URL ($s3BucketUrl) does not match the expected URL type.")
  }

  /**
    * Returns a batch Id when provided a cleansed or raw batch directory url
    *
    * @param s3CleansedOrCleansedBatchDirectoryUrl s3 cleansed/raw batch directory urls
    *                                              eg: s3a://edh-data-staging/chomp/raw/encounter/2016-09/
    *                                              eg:s3a://edh-data-staging/chomp/cleansed/encounter/2016-09.parquet/
    * @return
    */
  def getBatchId(customer: String, s3CleansedOrCleansedBatchDirectoryUrl: String): String = {
    if (commonOutputOfCleansedRegex.unapplySeq(s3CleansedOrCleansedBatchDirectoryUrl).isDefined ||
      commonOutputOfCleansedRegexRedox.unapplySeq(s3CleansedOrCleansedBatchDirectoryUrl).isDefined) {
      customer.concat("-").concat(extractActivityTypeFromS3Url(s3CleansedOrCleansedBatchDirectoryUrl)).
        concat("-").concat(extractFormatFromS3Bucket(s3CleansedOrCleansedBatchDirectoryUrl)).concat("-").
        concat(extractBatchNameFromS3RawBatchUrl(s3CleansedOrCleansedBatchDirectoryUrl).replace(".parquet", ""))
    }
    else throw new RuntimeException(s"getBatchId: S3 URL ($s3CleansedOrCleansedBatchDirectoryUrl) " +
      s"does not match the expected URL type.")
  }

  /**
    * Returns a batch Id when provided a raw
    *
    * @param s3url s3 url raw
    * @return
    */
  def getBatchIdFromS3Url(s3url: String, activityType: String, customer: String): String = {
    activityType.toUpperCase match {
      case Constants.NewMoverExperianDefaultSource | Constants.ProspectDefaultMessageType =>
        s"$customer-${extractActivityTypeFromS3Url(s3url)}-${extractFormatFromS3Bucket(s3url)}-${extractBatchNameFromS3RawBatchUrl(s3url)}"
      case _ => s"${extractSourceFromS3RawBatchUrl(s3url)}-${extractActivityTypeFromS3Url(s3url)}-${extractFormatFromS3Bucket(s3url)}-${extractBatchNameFromS3RawBatchUrl(s3url)}"
    }
  }

  /**
    * Returns a batch Id when provided a raw
    *
    * @param s3url s3 url raw
    * @return
    */
  def extractBatchIdFromS3Url(s3url: String, customer: String): String = {
    s"$customer-${extractActivityTypeFromS3Url(s3url)}-" +
      s"${extractFormatFromS3Bucket(s3url)}-${extractBatchNameFromS3RawBatchUrl(s3url.replace(".parquet",""))}"
  }

  /**
    * Returns Bucket name from a raw S3 batch URL
    *
    * @param s3Url
    * @return
    */
  def extractActivityTypeFromS3Url(s3Url: String): String = {
    s3Url.split("/")(5)
  }

  /**
    * Returns Bucket name from a raw S3 batch URL
    *
    * @param s3Url
    * @return
    */
  def extractBucketNameFromS3RawBatchUrl(s3Url: String): String = {
    s3Url.split("/")(2)
  }

  /**
    * Returns Batch name from a raw S3 batch URL
    *
    * @param s3Url
    * @return
    */
  def extractBatchNameFromS3RawBatchUrl(s3Url: String): String = {
    s3Url.split("/")(7)
  }

  /**
    * Returns Bucket name with client key from a raw S3 batch URL
    * Eg: s3a://edh-data-staging/chomp
    *
    * @param s3Url
    * @return
    */
  def extractBucketNameWithClientKeyFromS3RawBatchUrl(s3Url: String): String = {
    s3Url.split("/raw")(0)
  }

  /**
    * Returns Customer name from a raw S3 batch URL
    *
    * @param s3Url
    * @return
    */
  def extractSourceFromS3RawBatchUrl(s3Url: String): String = {
    s3Url.split("/")(3)
  }

  /**
    * Builds an output S3 path for cleansed parquet files
    *
    * @param s3Url
    * @return
    */
  def buildS3PathForCleansedOutput(s3Url: String): String = {
    s3Url.replace("/raw/", "/cleansed/").replaceAll("/$", ".parquet/")
  }

  /**
    * Builds an output S3 path for error csv files
    *
    * @param s3Url
    * @return
    */
  def buildS3PathForErrorOutput(s3Url: String, dataSource: String): String = {
    val currentLocalDate: LocalDate = LocalDate.now()
    s3Url.replace("/raw/", "/error/") + currentLocalDate.toString + s"-$dataSource"
  }

  /**
    * Extracts the intermediate prefix path for the source Raw files that need to be archived
    *
    * @param s3Url
    * @return
    */
  def extractS3SourcePrefixForFileArchival(s3Url: String): String = {
    s3Url.split(extractBucketNameFromS3RawBatchUrl(s3Url).concat("/"))(1)
  }

  /**
    * Extracts the intermediate prefix path for the source cleansed files that need to be deleted
    *
    * @param s3Url
    * @return
    */
  def extractS3SourcePrefixForDeletingExistingFiles(s3Url: String): String = {
    if (commonOutputOfCleansedRegex.unapplySeq(s3Url).isDefined ||
      commonOutputOfCleansedRegexRedox.unapplySeq(s3Url).isDefined) {
      s3Url.split(extractBucketNameFromS3RawBatchUrl(s3Url).concat("/"))(1)
    }
    else throw new RuntimeException(s"extractS3SourcePrefixForDeletingExistingFiles: S3 URL ($s3Url) " +
      s"does not match the expected URL type.")
  }

  /**
    * Builds the intermediate prefix path for Destination Raw files  archived files
    *
    * @param s3Url
    * @return
    */
  def buildS3DestinationPrefixForFileArchival(s3Url: String, dataSource: String): String = {
    if (rawS3UrlRegex.unapplySeq(s3Url).isDefined) {
      extractSourceFromS3RawBatchUrl(s3Url).concat(s"/archive/$dataSource/")
    }
    else throw new RuntimeException(s"buildS3DestinationPrefixForFileArchival: S3 URL ($s3Url) " +
      s"does not match the expected URL type.")
  }

  /**
    * Extracts batch date from batch id
    *
    * @param batchId
    * @return
    */
  def extractBatchDateFromBatchId(batchId: String): String = {
    if (batchIdRegex.unapplySeq(batchId).isDefined) {
      batchId.split("-")(3).concat("-").concat(batchId.split("-")(4))
    }
    else if (batchIdRegexWithDate.unapplySeq(batchId).isDefined) {
      batchId.split("-")(3).concat("-").concat(batchId.split("-")(4)).concat("-").concat(batchId.split("-")(5))
    }
    else throw new RuntimeException(s"extractBatchDateFromBatchId: Batch id ($batchId) " +
      s"does not match the expected batch id.")
  }

  /**
    * Extracts format from input s3 url
    *
    * @param s3url
    * @return
    */
  def extractFormatFromS3Url(s3url: String): String = {
    s3url.split("/")(6)
  }


  /**
    * Build cleansed Batch URL Path
    *
    * @param batchDate
    * @return
    */
  def buildS3CleansedBatchUrl(batchDate: String, customer: String, bucketName: String, activityType: String,
                              format: String): String = {
    activityType match {
      case "prospect" => s"s3a://$bucketName/experian/cleansed/$activityType/$format/$batchDate.parquet/"
      case "deceased" => s"s3a://$bucketName/social_security_administration/cleansed/deathmaster/$format/" +
        s"$batchDate.parquet/"
      case "newmovers" => s"s3a://$bucketName/experian/cleansed/$activityType/$format/$batchDate.parquet/"
      case _ => s"s3a://$bucketName/$customer/cleansed/$activityType/$format/$batchDate.parquet/"
    }
  }

  /**
    * Build error Batch URL Path
    *
    * @param batchDate
    * @return
    */
  def buildS3ErrorBatchUrl(batchDate: String, customer: String, bucketName: String, activityType: String,
                           format: String): String = {
    s"s3a://$bucketName/$customer/error/$activityType/$format/$batchDate/"
  }

  /**
    * Build archived source file's Batch URL Path
    *
    * @param batchDate
    * @return
    */
  def buildS3CleansedMetadataUrl(batchDate: String, customer: String, bucketName: String,
                                 activityType: String, format: String): String = {
    activityType match {
      case "prospect" => s"s3a://$bucketName/experian/raw/$activityType/$format/$batchDate/"
      case "deceased" => s"s3a://$bucketName/social_security_administration/raw/deathmaster/$format/" +
        s"$batchDate/"
      case "newmovers" => s"s3a://$bucketName/newmovers/raw/prospect/$format/$batchDate/"
      case _ =>  s"s3a://$bucketName/$customer/raw/$activityType/$format/$batchDate/"
    }
  }

  /**
    * Extracts Format from S3 url
    *
    * @param s3Url
    * @return
    */
  def extractFormatFromS3Bucket(s3Url: String): String = {
    s3Url.split("/")(6)
  }

  /**
    * Extracts Format from batch-id url
    *
    * @param batchId
    * @return
    */
  def extractFormatFromBatchId(batchId: String): String = {
    batchId.split("-")(2)
  }

  def extractCustomerFromBatchId(batchId: String): String = {
    batchId.split("-")(0)
  }

  /**
    * Returns the valid url for cleansed S3 file path or else null
    *
    * @param s3CleansedUrl
    * @return
    */
  def validateS3CleansedFilesBatchUrl(s3CleansedUrl: String): String = {
    if (cleansedS3UrlRegex.unapplySeq(s3CleansedUrl).isDefined ||
      cleansedS3UrlRegexRedox.unapplySeq(s3CleansedUrl).isDefined) {
      s3CleansedUrl
    }
    else null
  }

  /**
    * Returns the valid url for error S3 file path or else null
    *
    * @param s3ErrorUrl
    * @return
    */
  def validateS3ErrorFilesBatchUrl(s3ErrorUrl: String): String = {
    if (errorS3UrlRegex.unapplySeq(s3ErrorUrl).isDefined) {
      s3ErrorUrl
    }
    else null
  }

  /**
    * Returns the Date received the batch file assuming day as 01
    *
    * @param s3Url
    * @return
    */
  def generateDateForDataReceived(s3Url: String): String ={
    val batchSplitter = extractBatchNameFromS3RawBatchUrl(s3Url).split("-")
    s"${batchSplitter(1)}/01/${batchSplitter(0)}"
  }

  /**
    * Returns the string after bucket name till batch name
    * Eg: chomp/raw/encounter/influencehealth/2017-09/
    * @param s3Url
    * @return
    */
  def getObjectNameForBatchUrls(s3Url: String): String ={
    val bucketName = s3Url.split("/")(2)
    s3Url.split(s"$bucketName/")(1)
  }

  /**
    * Extracts Activity type from batch id
    *
    * @param batchId
    * @return
    */
  def extractActivityTypeFromBatchId(batchId: String): String = {
    batchId.split("-")(1)
  }

  /**
    * Build cleansed Batch URL Path
    *
    * @param batchDate
    * @return
    */
  def buildS3RawBatchUrl(mainCommand: String, batchDate: String, source: String, bucketName: String,
                         activityType: String, format: String): String = {
    mainCommand match {
      case "cleanse" => s"s3a://$bucketName/$source/raw/$activityType/$format/$batchDate/"
      case "load" => s"s3a://$bucketName/$source/cleansed/$activityType/$format/$batchDate.parquet/"
      case _ => null
    }
  }


  def getSourceFromActivityType(activityType: String, customer: String): String = {
    activityType.toUpperCase match {
      case ProspectActivityType | NewMoverActivityType => ProspectExperianSource.toLowerCase
      case DeceasedActivityType => SocialSecurityAdministrationDefaultSource.toLowerCase
      case _ => customer
    }
  }

  def buildBatchIdFromS3Url(source: String, activityType: String, s3Url: String): String = {
    s"$source-$activityType-${extractFormatFromS3Bucket(s3Url)}-${extractBatchNameFromS3RawBatchUrl(s3Url)}".replace(".parquet", "")
  }

  /**
    * Extracts format from input s3 url
    *
    * @param url
    * @return
    */
  def extractFormatFromProjectUrl(url: String): String = {
    url.split("/")(2)
  }

  /**
    * Build S3 Raw URL for load check
    *
    * @param batchId
    * @return
    */
  def buildRawS3Url(batchId: String, s3Bucket: String): String = {
    val dataSource = getDataSourceFromBatchId(batchId)
    val batchIdSplitter = batchId.split("-")
    if (batchIdRegexWithDate.unapplySeq(batchId).isDefined) {
      s"s3a://$s3Bucket/$dataSource/raw/${batchIdSplitter(1)}/${batchIdSplitter(2)}/${batchIdSplitter(3)}-${batchIdSplitter(4)}-${batchIdSplitter(5)}/"
    }
    else if (batchIdRegex.unapplySeq(batchId).isDefined) {
      s"s3a://$s3Bucket/$dataSource/raw/${batchIdSplitter(1)}/${batchIdSplitter(2)}/${batchIdSplitter(3)}-${batchIdSplitter(4)}/"
    }
    else {
      throw new Exception("Batch id doesn't match the expected format <customer>-<activityType>-<format>-<batch>")
    }
  }

  /**
    * Build S3 cleansed URL for load check
    *
    * @param batchId
    * @return
    */
  def buildCleansedS3Url(batchId: String, s3Bucket: String): String = {
    val dataSource = getDataSourceFromBatchId(batchId)
    val batchIdSplitter = batchId.split("-")
    if (batchIdRegexWithDate.unapplySeq(batchId).isDefined) {
      s"s3a://$s3Bucket/$dataSource/cleansed/${batchIdSplitter(1)}/${batchIdSplitter(2)}/${batchIdSplitter(3)}-${batchIdSplitter(4)}-${batchIdSplitter(5)}.parquet/"
    }
    else if (batchIdRegex.unapplySeq(batchId).isDefined) {
      s"s3a://$s3Bucket/$dataSource/cleansed/${batchIdSplitter(1)}/${batchIdSplitter(2)}/${batchIdSplitter(3)}-${batchIdSplitter(4)}.parquet/"
    }
    else {
      throw new Exception("Batch id doesn't match the expected format <customer>-<activityType>-<format>-<batch>")
    }
  }

  /**
    * Build S3 error URL for load check
    *
    * @param batchId
    * @return
    */
  def buildErrorS3Url(batchId: String, s3Bucket: String): String = {
    val dataSource = getDataSourceFromBatchId(batchId)
    val batchIdSplitter = batchId.split("-")
    dataSource match {
      case x if x == batchIdSplitter(0) =>
        if (batchIdRegexWithDate.unapplySeq(batchId).isDefined) {
          s"s3a://$s3Bucket/$dataSource/error/${batchIdSplitter(1)}/${batchIdSplitter(2)}/${batchIdSplitter(3)}-${batchIdSplitter(4)}-${batchIdSplitter(5)}/"
        }
        else if (batchIdRegex.unapplySeq(batchId).isDefined) {
          s"s3a://$s3Bucket/$dataSource/error/${batchIdSplitter(1)}/${batchIdSplitter(2)}/${batchIdSplitter(3)}-${batchIdSplitter(4)}/"
        }
        else {
          throw new Exception("Batch id doesn't match the expected format <customer>-<activityType>-<format>-<batch>")
        }
      case _ => null
    }
  }

  def getDataSourceFromBatchId(batchId: String): String = {
    val activityType = batchId.split("-")(1)
    activityType match {
      case "prospect" | "newmovers" => "experian"
      case "deceased" => "social_security_administration"
      case _ => batchId.split("-")(0) // customer
    }
  }

  // get bucket keys in format: s3a://cdp-data-qa
  def getBucketKeysFromS3URL(s3Url: String) = {
    if (rawS3UrlRegex.unapplySeq(s3Url).isDefined) {
      s"s3a://${s3Url.split("/")(2)}"
    } else throw new RuntimeException(s"$s3Url does not match the expected URL type.")
  }


  def buildBatchLevelInputPaths(inputFilePath: String): String = {
    if(rawS3UrlRegex.unapplySeq(inputFilePath).isEmpty){
      val splitter = inputFilePath.split("/")
      s"${splitter(0)}/${splitter(1)}/${splitter(2)}/${splitter(3)}/${splitter(4)}/${splitter(5)}/${splitter(6)}/${splitter(7)}/"
    }
    else{
      inputFilePath
    }
  }


}