package com.influencehealth.edh.enrich.activity.crosswalks.helper

import com.typesafe.scalalogging.LazyLogging

case class LocationCrosswalk(
                              customer: String,
                              source: String,
                              sourceType: String,
                              hospitalId: Option[String],
                              businessUnitId: Option[String],
                              siteId: Option[String],
                              clinicId: Option[String],
                              practiceLocationId: Option[String],
                              locationId: Int
) extends Serializable

object LocationCrosswalk extends LazyLogging {

  val Meditech: String = "Meditech"
  val AllScripts: String = "ALLSCRIPTS"
  val Hospital: String = "Hospital"

  val locationCwData: Seq[LocationCrosswalk] = Seq(
    LocationCrosswalk("HCA", Meditech, Hospital, Some("COCDL"), None, None, None, None, 483),
    LocationCrosswalk("HCA", Meditech, Hospital, Some("COCPL"), None, None, None, None, 484),
    LocationCrosswalk("HCA", Meditech, Hospital, Some("COCAR"), None, None, None, None, 485),
    LocationCrosswalk("HCA", Meditech, Hospital, Some("COCNH"), None, None, None, None, 486),
    LocationCrosswalk("HCA", Meditech, Hospital, Some("COCLE"), None, None, None, None, 487),
    LocationCrosswalk("HCA", Meditech, Hospital, Some("COCDR"), None, None, None, None, 488),
    LocationCrosswalk("HCA", Meditech, Hospital, Some("COCMK"), None, None, None, None, 489),
    LocationCrosswalk("HCA", Meditech, Hospital, Some("COCPZ"), None, None, None, None, 490),
    LocationCrosswalk("HCA", Meditech, Hospital, Some("COCDAE"), None, None, None, None, 491),
    LocationCrosswalk("HCA", Meditech, Hospital, Some("COCMCB"), None, None, None, None, 492),
    LocationCrosswalk("HCA", Meditech, Hospital, Some("COCDLCHILD"), None, None, None, None, 493),
    LocationCrosswalk("HCA", Meditech, Hospital, Some("1"), None, None, None, None, 1),
    LocationCrosswalk("HCA", Meditech, Hospital, Some("3"), None, None, None, None, 3)
  )
}

case class LocationCwCreationException(exc: Throwable)
  extends Exception("Unable to create location crosswalk", exc)

case class MissingOrigLocCwRefException(line: String)
  extends Exception(s"Missing reference to at least 1 original location value in the following line: '$line'")