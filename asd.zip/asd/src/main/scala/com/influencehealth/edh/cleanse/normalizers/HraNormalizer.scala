package com.influencehealth.edh.cleanse.normalizers

import com.influencehealth.edh.Constants
import com.influencehealth.edh.dao._
import org.apache.spark.sql.{DataFrame}
import org.apache.spark.sql.functions.{broadcast, _}

object HraNormalizer {

  val HraHeader: String = "HEADER*"
  val HraDetail: String = "DETAIL*"

  val HraHeaderV2: String = "Header*"
  val HraDetailV2: String = "Detail*"

  /**
    * Join the HraHeader and HraDetail dataFrames based on transactionId
    *
    * @param listContainingHraHeaderData
    * @param listContainingHraDetailData
    * @return a dataFrame of resultant join condition
    */
  def joinHraHeaderAndHraDetailDataFrames(
                                           listContainingHraHeaderData: Map[HRAFileType, DataFrame],
                                           listContainingHraDetailData: Map[HRAFileType, DataFrame]
                                         ): DataFrame = {

    var listContainingHraHeaderDfs: DataFrame = null
    var listContainingHraDetailDfs: List[DataFrame] = List()

    for (x <- listContainingHraHeaderData) {
      listContainingHraHeaderDfs = x._2
    }

    for (x <- listContainingHraDetailData) {
      listContainingHraDetailDfs = listContainingHraDetailDfs :+ x._2
    }

    // joining HraHeader and HraDetail dfs
    val joinedDFs = listContainingHraDetailDfs.foldLeft(
      broadcast(listContainingHraHeaderDfs))((a, b) => a.join(b, Seq("transactionId"), "left"))

    joinedDFs
  }

  /** format dataframe to add MapType column "assessmentResults"
    *
    * @param df
    * @return formated coloumn
    * */
  private def createMapTypeDataFrame(df: DataFrame, format: String): DataFrame = {

    if(format.equalsIgnoreCase(Constants.HraHealthWareFormat)){
      val possibleValues = Seq("id", "email", "date_of_birth", "first_name", "middle_initial", "last_name",
        "address_1", "address_2", "city", "state", "zip", "phone")

      // deleting the variable column rows, which rows are already present in the header file as columns
      val filterVariableDF = df.where(possibleValues.map(col("questionDescription") =!= _).reduce(_ && _)).
        filter(col("answerDescription").isNotNull)

      val dfWithCampaignID  = filterVariableDF.dropDuplicates("transactionId")
        .withColumn("questionDescription", lit("campaignId"))
        .withColumn("answerDescription", col("campaignId"))

      val dfWithAssessmentCode  = filterVariableDF.dropDuplicates("transactionId")
        .withColumn("questionDescription", lit("assessmentCode"))
        .withColumn("answerDescription", col("assessmentCode"))

      val unionDf = dfWithCampaignID.union(dfWithAssessmentCode).union(filterVariableDF)

      // groupBy and combine the variable and value column into new column "assessmentResults"
      val createCombinedColumnDF = unionDf.groupBy(col("transactionId")).
        agg(collect_list(struct(col("questionDescription") as "variable",
          col("answerDescription") as "value")) as "assessmentResults")

      val distinctAssessmentResultsDf = createCombinedColumnDF.select("transactionId","assessmentResults").distinct

      // join the groupBy Dataframe which has map data and the main dataframe
      val finalDFForQA = distinctAssessmentResultsDf
        .join(unionDf, Seq("transactionId"))
        .filter(col("campaignId").isNotNull)
        .drop("questionDescription", "answerDescription")
        .distinct

      finalDFForQA
    }
    else{
      val possibleValues = Seq("id", "email", "date_of_birth", "first_name", "middle_initial", "last_name",
        "address_1", "address_2", "city", "state", "zip_code", "phone_1")

      // deleting the variable column rows, which rows are already present in the header file as columns
      val filterVariableDF = df.where(possibleValues.map(col("variable") =!= _).reduce(_ && _)).
        filter(col("value").isNotNull)

      val dfWithAssessmentCode  = filterVariableDF.dropDuplicates("transactionId")
        .withColumn("variable", lit("assessmentCode"))
        .withColumn("value", col("assessmentCode"))

      val unionDf = dfWithAssessmentCode.union(filterVariableDF)
      // groupBy and combine the variable and value column into new column "assessmentResults"
      val createCombinedColumnDF = unionDf.groupBy(col("transactionId")).
        agg(collect_list(struct(col("variable") as "variable",
                                col("value") as "value")) as "assessmentResults")

      val finalDFForQA = unionDf.drop("variable", "value")
        .distinct.join(createCombinedColumnDF, Seq("transactionId"))
      finalDFForQA
    }
  }

  def joinAllHraDataFrames(inputList: Map[HRAFileType, DataFrame], format: String): DataFrame = {

    // separate HraHeader and HraDetail dataFrames
    val listContainingHraHeaderData: Map[HRAFileType, DataFrame] =
      inputList.filter(x => x._1 == HRAHeaderV1 || x._1 == HRAHeaderV2)

    val listContainingHraDetailData: Map[HRAFileType, DataFrame] =
      inputList.filter(x => x._1 == HRADetailV1 || x._1 == HRADetailV2)

    // join HraHeader & HraDetail dataFrames on transactionId
    val joinedHraHeaderAndHraDetailDf: DataFrame = joinHraHeaderAndHraDetailDataFrames(listContainingHraHeaderData, listContainingHraDetailData)

    val normalizedDataFrame: DataFrame = createMapTypeDataFrame(joinedHraHeaderAndHraDetailDf, format)

    normalizedDataFrame
  }


}
