package com.influencehealth.edh

import com.influencehealth.edh.config.EnrichJobConfig
import com.influencehealth.edh.enrich.ActivityEnricher
import com.influencehealth.edh.enrich.activity.address.EnrichAddressStep
import com.influencehealth.edh.enrich.activity.caregrouper.EnrichCareGrouperStep
import com.influencehealth.edh.enrich.activity.crosswalks.EnrichCrosswalksStep
import com.influencehealth.edh.enrich.activity.identity.EnrichIdentityStep
import com.influencehealth.edh.model.Activity
import org.apache.spark.sql.{Dataset, SparkSession}

class PersonRebuilder(val contentEnricher: ActivityEnricher)
                            (implicit enrichJobConfig: EnrichJobConfig, sparkSession: SparkSession) {

  def startEnrichPipeline(dataset: Dataset[Activity]): Dataset[Activity] = {

    contentEnricher.process(dataset)
  }

}

object PersonRebuilderPipelineBuilder {

  def apply(enrichSteps: String*)
           (implicit enrichJobConfig: EnrichJobConfig, sparkSession: SparkSession): PersonRebuilder = {

    val contentEnricher: ActivityEnricher = transformStepsToPipeline(enrichSteps)
    new PersonRebuilder(contentEnricher)
  }

  def transformStepsToPipeline(enrichSteps : Seq[String])
                              (implicit enrichJobConfig: EnrichJobConfig, sparkSession: SparkSession): ActivityEnricher = {

    def loop(next: Option[ActivityEnricher],steps: Seq[String]): Option[ActivityEnricher] = {
      if(steps.isEmpty){
        next
      } else {
        steps.head match {
          case Constants.EnrichAddressStepName =>
            loop(Some(new EnrichAddressStep(name = "EnrichAddress", next)),steps.tail)
          case Constants.EnrichCareGroupsStepName =>
            loop(Some(new EnrichCareGrouperStep(name = "EnrichCareGroups", next)),steps.tail)
          case Constants.EnrichCrosswalksStepName =>
            loop(Some(new EnrichCrosswalksStep(name = "EnrichCrosswalks", next)),steps.tail)
          case  Constants.EnrichIdentityStepName =>
            loop(Some(new EnrichIdentityStep(name = "EnrichIdentity", next)),steps.tail)
        }
      }
    }
    loop(None,enrichSteps.reverse) match {
      case Some(activityEnricher) => activityEnricher
      case None => throw new Exception("Couldn't build pipeline")
    }
  }

}
