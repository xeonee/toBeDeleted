package com.influencehealth.edh.model.activitytype

import com.influencehealth.edh.Constants

trait Referral extends ActivityType {

  override val formatType: String = Constants.ReferralInfluenceHealthFormat
  override val defaultSource: String = Constants.ReferralDefaultSource
  override val defaultMessageType: String = Constants.ReferralDefaultMessageType
  override val defaultSourceType: String = Constants.ReferralDefaultSourceType
  override val defaultAddressType: String = Constants.ReferralDefaultAddressType
  override val defaultActivityType: String = Constants.ReferralActivityType
  override val defaultPersonType: String = Constants.ReferralPersonType

  override val nullColumnNames: Seq[String] = Seq(
    "firstName",
    "lastName",
    "source",
    "sourceRecordId"
  )

  override val cleanseStringColumnNames: Seq[String] = Seq(
    "lastName",
    "firstName",
    "city",
    "state",
    "zip5",
    "address1",
    "spanishReqFlag",
    "warmTransFlag",
    "referralTypeCode",
    "referralTypeCodeSub",
    "ccFacNo",
    "facName",
    "topic",
    "subTopic",
    "ccPhysNo",
    "physLastName",
    "physFirstName",
    "physMi",
    "specialty",
    "officeName",
    "officeAddress1",
    "officeAddress2",
    "officeCity",
    "officeState",
    "officeZip",
    "apptMadeFlag",
    "apptDateTime",
    "apptOfficeName",
    "apptOfficeAddress1",
    "apptOfficeCity",
    "apptOfficeState",
    "apptOfficeZip",
    "altPhysName",
    "apptNotMadeReason",
    "ccRegNo",
    "className",
    "classDateTime",
    "ccSvcNo",
    "svcName"
  )

  override val mandatoryContactColumnsNames: Seq[String] = Seq(
    "homeArea",
    "address1"
  )

  override val zipColumnNames: Seq[String] = Seq(
    "zip5"
  )

}
