package com.influencehealth.edh.model.schema

import org.apache.spark.sql.types.{StringType, StructField, StructType}

object PersuadeLeadSchema {

  val schema: StructType = StructType(
    Array(
      StructField("leadId", StringType, true),
      StructField("firstName", StringType, true),
      StructField("lastName", StringType, true),
      StructField("street1", StringType, true),
      StructField("callerId", StringType, true),
      StructField("phone", StringType, true),
      StructField("email", StringType, true),
      StructField("city", StringType, true),
      StructField("state", StringType, true),
      StructField("zip", StringType, true),
      StructField("created", StringType, true),
      StructField("dob", StringType, true)
    )
  )

}
