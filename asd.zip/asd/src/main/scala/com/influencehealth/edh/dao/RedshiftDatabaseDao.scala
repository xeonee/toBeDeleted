
package com.influencehealth.edh.dao

import java.io.InputStream
import java.sql.{Connection, DriverManager, Statement}
import java.util.Properties

import com.amazonaws.services.s3.AmazonS3
import com.influencehealth.edh.CustomLazyLogging
import com.influencehealth.edh.config.RedshiftConfig
import mojolly.inflector.Inflector
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

import scala.io.Source

class RedshiftDatabaseDao(config: RedshiftConfig, s3client: AmazonS3)(
    implicit sparkSession: SparkSession) extends DataWarehouseDao with CustomLazyLogging {

  import sparkSession.implicits._

  val requiredCustomerTables: Set[String] = Set(
    RedshiftDataWarehouseTables.PersonsTable,
    RedshiftDataWarehouseTables.ActivitiesTable,
    RedshiftDataWarehouseTables.AddressesTable,
    RedshiftDataWarehouseTables.DoNotSolicitEmailsTable,
    RedshiftDataWarehouseTables.PersonArchivesTable,
    RedshiftDataWarehouseTables.CollapseHistoryTable
  )

  val redshiftSchema: String = config.schema
  val redshiftTempS3Dir: String = s"s3a://${config.tempBucketName}" // Will contain PHI
  val redshiftUser: String = config.user
  val redshiftPassword: String = config.password
  val redshiftConnectionString: String = config.connectionString

  logger.info(s"Redshift Schema: $redshiftSchema")
  logger.info(s"Redshift Temporary S3 Bucket: $redshiftTempS3Dir")

  Class.forName("com.amazon.redshift.jdbc.Driver")
  val connectionProperties: Properties = new Properties()
  connectionProperties.setProperty("user", redshiftUser)
  connectionProperties.setProperty("password", redshiftPassword)

  val connection: Connection = DriverManager.getConnection(redshiftConnectionString, connectionProperties)

  var loadedTempTables: Set[String] = Set.empty

  /**
    * Load temporary (transmission) table
    * @param data
    * @param tableName
    * @param transmissionName
    */
  override def loadTemporaryTable(data: DataFrame, tableName: String, transmissionName: String): Unit = {
    saveTable(s"${transmissionName}_$tableName", data)
  }

  /**
    * Build & execute sql query
    * @param data
    * @param tableName
    * @param transmissionName
    */
  def executeSQLFile(path: String, transmissionName: String, truncateMode: Boolean, customer: String): Unit = {
    val inputStream: InputStream = getClass.getResourceAsStream(path)
    val sql = Source.fromInputStream(inputStream).
      getLines().
      mkString("\n").
      replace("transmission_", s"${transmissionName}_").  // refresh_customerName
      replace("redshiftSchema", s"$redshiftSchema").
      replace("customer_value", s"$customer")

    val sqlFinal = truncateMode match {
      case true =>  sql.replace("--DELETE", s"DELETE")
      case _ => sql
    }
    executeQuery(sqlFinal)
  }

  /**
    * Cleanup  customer temp tables
    * @param transmissionName
    */
  override def cleanUpCustomerTempTables(transmissionName: String): Unit = {
    val sql: String = requiredCustomerTables.
      map(tableName => s"DROP TABLE $redshiftSchema.${transmissionName}_$tableName;").mkString("\n")

    executeQuery(sql)
  }

  /**
    * Close Database connection
    */
  def close(): Unit = {
    connection.close()
  }

  /**
    * Execute sql query
    * @param sql
    * @param connection
    * @return
    */
  private def executeQuery(sql: String, connection: Connection = connection) = {
    val statement: Statement = connection.createStatement()
    try {
      statement.execute(sql)
    } catch {
      case e: Exception =>
        statement.close()
        connection.close()
        throw e
    }
  }

  /**
    * Save data in redshift format to Redshift using temp directory
    * @param tableName
    * @param dataFrame
    * @param mode
    */
  override def saveTable(tableName: String, dataFrame: DataFrame, mode: SaveMode = SaveMode.Overwrite): Unit = {
    dataFrame
      .write
      .format("com.databricks.spark.redshift")
      .option("url", redshiftConnectionString)
      .option("dbtable", s"$redshiftSchema.$tableName")
      .option("tempdir", s"$redshiftTempS3Dir")
      .option("extracopyoptions", "timeformat 'YYYY-MM-DD HH24:MI:SS' COMPUPDATE OFF STATUPDATE OFF")
      .mode(mode)
      .save()
  }

  def aliasColumnsToCamelCase(dataFrame: DataFrame): DataFrame = {
    val aliasedColumns = dataFrame.columns.map(col => $"$col" as Inflector.camelize(col))

    dataFrame.select(aliasedColumns: _*)
  }
}

object RedshiftDataWarehouseTables {

  val PersonsTable: String = "persons"

  val ActivitiesTable: String = "activities"

  val UnidentifiableActivities: String = "unidentifiable_activities"

  val AddressesTable: String = "addresses"

  val DoNotSolicitEmailsTable: String = "do_not_solicit_emails"

  val PersonArchivesTable: String = "person_archives"

  val CollapseHistoryTable: String = "collapse_history"

}