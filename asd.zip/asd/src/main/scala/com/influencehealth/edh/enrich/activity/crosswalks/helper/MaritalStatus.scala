package com.influencehealth.edh.enrich.activity.crosswalks.helper

import com.influencehealth.edh.Constants

case class MaritalStatus(
  customer: String,
  source: String,
  sourceType: String,
  sourceMaritalStatus: String,
  maritalStatus: String
) extends Serializable

object MaritalStatus {

  val maritalStatusCw: Seq[MaritalStatus] = Seq(
    MaritalStatus("default", "default", "default", "m", Constants.MaritalStatusMarried),
    MaritalStatus("default", "default", "default", "s", Constants.MaritalStatusSingle),
    MaritalStatus("default", "default", "default", "w", Constants.MaritalStatusWidowed),
    MaritalStatus("default", "default", "default", "x", Constants.MaritalStatusSeparated),
    MaritalStatus("default", "default", "default", "d", Constants.MaritalStatusDivorced),
    MaritalStatus("default", "default", "default", "p", Constants.MaritalStatusLifePartner)
  )
}

case class MaritalStatusCwCreationException(exc: Throwable)
  extends Exception("Unable to create marital status crosswalk", exc)

case class InvalidMaritalStatusValue(value: String)
  extends Exception(s"The following value does not match any standard marital status value: '$value'")