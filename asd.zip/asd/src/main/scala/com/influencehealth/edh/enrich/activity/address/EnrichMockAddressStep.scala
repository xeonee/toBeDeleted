package com.influencehealth.edh.enrich.activity.address


import com.influencehealth.edh.Constants
import com.influencehealth.edh.config.EnrichJobConfig
import com.influencehealth.edh.enrich.ActivityEnricher
import com.influencehealth.edh.model.Activity
import com.influencehealth.edh.utils.DataLakeUtilities
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.FloatType
import org.apache.spark.sql.{Dataset, SparkSession}

class EnrichMockAddressStep(val name: String, val next: Option[ActivityEnricher])
                           (implicit enrichJobConfig: EnrichJobConfig, sparkSession: SparkSession)
  extends ActivityEnricher {

  override def enrich(ds: Dataset[Activity]): Dataset[Activity] = {
    import sparkSession.implicits._

    val anchorData = ds.toDF()

    val inputAnchorDataCount = anchorData.count
    if (inputAnchorDataCount <= 0) {
      throw new RuntimeException(
        s"No Records was fetched from Postgres by Enrich Anchor for batch: ${enrichJobConfig.batchId}")
    }

    val mockActivities = anchorData
      .withColumn("latitude", lit("43.16074"))
      .withColumn("longitude", lit("-77.56778"))
      .withColumn("isValidAddress", lit(true))
      .withColumn("dateModified", lit(current_timestamp()))
      .withColumn("zip4", lit("7040"))
      .withColumn("addressCoordinates",
        struct($"latitude".cast(FloatType) as "lat", $"longitude".cast(FloatType) as "lon"))
      .drop("latitude", "longitude")

    val finalMockActivities =
      DataLakeUtilities.extractActivityTypeFromBatchId(enrichJobConfig.batchId.get).toUpperCase match {
      case Constants.DeceasedActivityType => {
        mockActivities.withColumn("zip5", lit("7040"))
          .withColumn("address1", lit("demo address"))
          .as[Activity]
      }
      case _ => {
        mockActivities.where($"zip5".isNotNull && $"address1".isNotNull)
        .as[Activity]
      }
    }
    finalMockActivities
  }
}

