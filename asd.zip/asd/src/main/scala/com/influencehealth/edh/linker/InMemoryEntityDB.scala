package com.influencehealth.edh.linker

import com.influencehealth.edh.model.{Activity, Person}
import com.influencehealth.edh.personmatching.PersonMatcher
import org.apache.spark.sql.Dataset
import org.apache.spark.util.LongAccumulator

trait InMemoryEntityDB[T] extends EntityDB[T] {

  override val MAX_ITERATION: Int = 3

}

trait PersonInMemoryEntityDB extends InMemoryEntityDB[Person] {

  this: PersonLinkerImpl =>

  val accumulator: LongAccumulator

  override def mergeCandidatesOnBlockingKeys(
                                              linkageCandidates: Dataset[IdentityEntity[Person]]
                                            ): Dataset[IdentityEntity[Person]] = {

    linkageCandidates.
      transform(linkRecordsOnPerfectMatch).
      transform(linkRecordsOnEmailMatch).
      transform(linkRecordsOnPhoneMatch).
      transform(linkRecordsOnNickNameMatch).
      transform(linkRecordsOnNameChangeMatch)

  }


  def linkRecordsOnPerfectMatch(
                                 candidatesForLinkage: Dataset[IdentityEntity[Person]]
                               ): Dataset[IdentityEntity[Person]] = {

    import candidatesForLinkage.sparkSession.implicits._

    candidatesForLinkage.
      groupByKey { person => {
        (
          person.entity.customer,
          person.entity.address1.getOrElse(person.entity.personId),
          person.entity.zip5.getOrElse(person.entity.personId),
          person.entity.rootFirstName.getOrElse(person.entity.personId),
          person.entity.soundexLastName.getOrElse(person.entity.personId)
        )
      }
      }.flatMapGroups { (_, coGroupedCandidates) =>
      mergeMatchedCollapsedCandidates(accumulator, coGroupedCandidates, PersonMatcher.PerfectMatch)
    }
  }

  def linkRecordsOnEmailMatch(
                               candidatesForLinkage: Dataset[IdentityEntity[Person]]
                             ): Dataset[IdentityEntity[Person]] = {

    import candidatesForLinkage.sparkSession.implicits._

    candidatesForLinkage.
      groupByKey { person =>
        (
          person.entity.customer,
          person.entity.rootFirstName.getOrElse(person.entity.personId),
          person.entity.soundexLastName.getOrElse(person.entity.personId),
          person.entity.primaryPhoneNumber.getOrElse(person.entity.personId)
        )
      }.flatMapGroups { (_, coGroupedCandidates) =>
      mergeMatchedCollapsedCandidates(accumulator, coGroupedCandidates, PersonMatcher.EMailMatch)
    }
  }

  def linkRecordsOnPhoneMatch(
                               candidatesForLinkage: Dataset[IdentityEntity[Person]]
                             ): Dataset[IdentityEntity[Person]] = {

    import candidatesForLinkage.sparkSession.implicits._

    candidatesForLinkage.groupBy($"customer", $"rootFirstName", $"soundexLastName")

    candidatesForLinkage.
      groupByKey { person =>
        (
          person.entity.customer,
          person.entity.rootFirstName.getOrElse(person.entity.personId),
          person.entity.soundexLastName.getOrElse(person.entity.personId),
          person.entity.primaryEmail.getOrElse(person.entity.personId)
        )
      }.flatMapGroups { (_, coGroupedCandidates) =>
      mergeMatchedCollapsedCandidates(accumulator, coGroupedCandidates, PersonMatcher.PhoneMatch)
    }
  }

  def linkRecordsOnNickNameMatch(
                                  candidatesForLinkage: Dataset[IdentityEntity[Person]]
                                ): Dataset[IdentityEntity[Person]] = {

    import candidatesForLinkage.sparkSession.implicits._

    candidatesForLinkage.
      groupByKey { person =>
        (
          person.entity.customer,
          person.entity.address1.getOrElse(person.entity.personId),
          person.entity.zip5.getOrElse(person.entity.personId),
          person.entity.soundexLastName.getOrElse(person.entity.personId)
        )
      }.flatMapGroups((_, coGroupedCandidates) =>
      mergeMatchedCollapsedCandidates(accumulator, coGroupedCandidates, PersonMatcher.NickNameMatch)
    )
  }


  def linkRecordsOnNameChangeMatch(
                                    candidatesForLinkage: Dataset[IdentityEntity[Person]]
                                  ): Dataset[IdentityEntity[Person]] = {

    import candidatesForLinkage.sparkSession.implicits._

    candidatesForLinkage.
      groupByKey(person =>
        (
          person.entity.customer,
          person.entity.address1.getOrElse(person.entity.personId),
          person.entity.zip5.getOrElse(person.entity.personId),
          person.entity.rootFirstName.getOrElse(person.entity.personId)
        )
      ).flatMapGroups { case (_, coGroupedCandidates) =>
      mergeMatchedCollapsedCandidates(accumulator, coGroupedCandidates, PersonMatcher.LastNameChangeMatch)
    }
  }

}

trait ActivityInMemoryEntityDB extends InMemoryEntityDB[Activity] {

  this: ActivityLinkerImpl =>

  override def mergeCandidatesOnBlockingKeys(
                                              linkageCandidates: Dataset[IdentityEntity[Activity]]
                                            ): Dataset[IdentityEntity[Activity]] = {

    val linkingFunctions: List[Dataset[IdentityEntity[Activity]] => Dataset[IdentityEntity[Activity]]] = List(
      linkRecordsOnSource
    )

    linkingFunctions.foldLeft(linkageCandidates) { (dataset, function) => function(dataset) }
  }


  def linkRecordsOnSource(
                           candidatesForLinkage: Dataset[IdentityEntity[Activity]]
                         ): Dataset[IdentityEntity[Activity]] = {

    import candidatesForLinkage.sparkSession.implicits._

    candidatesForLinkage.groupByKey(activity => {
      (
        activity.entity.customer,
        activity.entity.source.getOrElse(activity.entity.activityId),
        activity.entity.sourceRecordId.getOrElse(activity.entity.activityId)
      )
    }).reduceGroups((row1, row2) => mergeCandidates(row1, row2)).
      map(_._2)
  }
}

