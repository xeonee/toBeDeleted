package com.influencehealth.edh.model.schema

import org.apache.spark.sql.types.{StringType, StructField, StructType}

object EmployeeRosterSchema {

  val employeeRosterSchema: StructType = StructType(
    Array(
      StructField("employeeId", StringType, false),
      StructField("npi", StringType, true), // TODO: Figure out why the fixture had all nulls for this field
      StructField("prefix", StringType, true),
      StructField("lastName", StringType, true),
      StructField("firstName", StringType, true),
      StructField("middleName", StringType, true),
      StructField("personalSuffix", StringType, true),
      StructField("professionalSuffix", StringType, true),
      StructField("address1", StringType, true),
      StructField("address2", StringType, true),
      StructField("city", StringType, true),
      StructField("state", StringType, true),
      StructField("zip5", StringType, true),
      StructField("country", StringType, true),
      StructField("sourceSex", StringType, true),
      StructField("dateOfBirth", StringType, true),
      StructField("homePhone", StringType, true),
      StructField("mobilePhone", StringType, true),
      StructField("workPhone", StringType, true),
      StructField("workEmail", StringType, true),
      StructField("personalEmail", StringType, true),
      StructField("raceCode", StringType, true),
      StructField("raceDesc", StringType, true),
      StructField("hospitalId", StringType, true),
      StructField("hospitalDesc", StringType, true),
      StructField("businessUnit", StringType, true),
      StructField("businessUnitDesc", StringType, true),
      StructField("siteId", StringType, true),
      StructField("siteDesc", StringType, true),
      StructField("clinicId", StringType, true),
      StructField("clinicDesc", StringType, true),
      StructField("practiceLocationId", StringType, true),
      StructField("practiceLocationDesc", StringType, true),
      StructField("jobTitleCode", StringType, false),
      StructField("jobTitleDesc", StringType, false),
      StructField("jobFamilyCode", StringType, true),
      StructField("jobFamilyDesc", StringType, true),
      StructField("statusCode", StringType, true),
      StructField("statusCodeDesc", StringType, true),
      StructField("dateHired", StringType, true),
      StructField("terminationDate", StringType, true)
    )
  )
}
