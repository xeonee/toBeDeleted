package com.influencehealth.edh.linker

import com.influencehealth.edh.dao.DatabaseDao
import com.influencehealth.edh.model.{Activity, Person}
import com.influencehealth.edh.personmatching.PersonMatcher
import org.apache.spark.sql.{Dataset, SparkSession}
import org.apache.spark.util.LongAccumulator

import scala.reflect.ClassTag

trait PostgresEntityDB[T] extends EntityDB[T] {

  override val MAX_ITERATION: Int = 1

  val databaseDao: DatabaseDao

  def fetch(databaseDao: DatabaseDao, sparkSession: SparkSession): Dataset[IdentityEntity[T]]

  override def get(inputDF: Dataset[IdentityEntity[T]]): Dataset[IdentityEntity[T]] = {
    val result: Dataset[IdentityEntity[T]] = fetch(databaseDao,inputDF.sparkSession)
    inputDF.union(result)
  }

}

trait PersonPostgresEntityDB extends PostgresEntityDB[Person] {

  this: PersonLinkerImpl =>

  val customer: String

  val accumulator: LongAccumulator

  override def fetch(databaseDao: DatabaseDao, sparkSession: SparkSession): Dataset[IdentityEntity[Person]] = {

    import sparkSession.implicits._

    databaseDao.getPersonsByCustomer(customer).map(IdentityEntity[Person]("person", _))
  }

  override def mergeCandidatesOnBlockingKeys(
                                              linkageCandidates: Dataset[IdentityEntity[Person]]
                                            ): Dataset[IdentityEntity[Person]] = {

    val linkingFunctions: List[Dataset[IdentityEntity[Person]] => Dataset[IdentityEntity[Person]]] = List(
      linkRecordsOnPerfectMatch,
      linkRecordsOnEmailMatch,
      linkRecordsOnPhoneMatch,
      linkRecordsOnNickNameMatch,
      linkRecordsOnNameChangeMatch
    )

    linkingFunctions.foldLeft(linkageCandidates) { (dataset, function) => function(dataset) }
  }


  def linkRecordsOnPerfectMatch(
                                 candidatesForLinkage: Dataset[IdentityEntity[Person]]
                               ): Dataset[IdentityEntity[Person]] = {

    import candidatesForLinkage.sparkSession.implicits._
    candidatesForLinkage.
      groupByKey { person => {
        (
          person.entity.customer,
          person.entity.address1.getOrElse(person.entity.personId),
          person.entity.zip5.getOrElse(person.entity.personId),
          person.entity.rootFirstName.getOrElse(person.entity.personId),
          person.entity.soundexLastName.getOrElse(person.entity.personId)
        )
      }
      }.flatMapGroups { (_, coGroupedCandidates) =>
      mergeMatchedCollapsedCandidates(accumulator, coGroupedCandidates, PersonMatcher.PerfectMatch)
    }
  }

  def linkRecordsOnEmailMatch(
                               candidatesForLinkage: Dataset[IdentityEntity[Person]]
                             ): Dataset[IdentityEntity[Person]] = {

    import candidatesForLinkage.sparkSession.implicits._

    candidatesForLinkage.
      groupByKey { person =>
        (
          person.entity.customer,
          person.entity.rootFirstName.getOrElse(person.entity.personId),
          person.entity.soundexLastName.getOrElse(person.entity.personId),
          person.entity.primaryPhoneNumber.getOrElse(person.entity.personId)
        )
      }.flatMapGroups { (_, coGroupedCandidates) =>
      mergeMatchedCollapsedCandidates(accumulator, coGroupedCandidates, PersonMatcher.EMailMatch)
    }
  }

  def linkRecordsOnPhoneMatch(
                               candidatesForLinkage: Dataset[IdentityEntity[Person]]
                             ): Dataset[IdentityEntity[Person]] = {

    import candidatesForLinkage.sparkSession.implicits._

    candidatesForLinkage.
      groupByKey { person =>
        (
          person.entity.customer,
          person.entity.rootFirstName.getOrElse(person.entity.personId),
          person.entity.soundexLastName.getOrElse(person.entity.personId),
          person.entity.primaryEmail.getOrElse(person.entity.personId)
        )
      }.flatMapGroups { (_, coGroupedCandidates) =>
      mergeMatchedCollapsedCandidates(accumulator, coGroupedCandidates, PersonMatcher.PhoneMatch)
    }
  }

  def linkRecordsOnNickNameMatch(
                                  candidatesForLinkage: Dataset[IdentityEntity[Person]]
                                ): Dataset[IdentityEntity[Person]] = {

    import candidatesForLinkage.sparkSession.implicits._

    candidatesForLinkage.
      groupByKey { person =>
        (
          person.entity.customer,
          person.entity.address1.getOrElse(person.entity.personId),
          person.entity.zip5.getOrElse(person.entity.personId),
          person.entity.soundexLastName.getOrElse(person.entity.personId)
        )
      }.flatMapGroups((_, coGroupedCandidates) =>
      mergeMatchedCollapsedCandidates(accumulator, coGroupedCandidates, PersonMatcher.NickNameMatch)
    )
  }


  def linkRecordsOnNameChangeMatch(
                                    candidatesForLinkage: Dataset[IdentityEntity[Person]]
                                  ): Dataset[IdentityEntity[Person]] = {

    import candidatesForLinkage.sparkSession.implicits._

    candidatesForLinkage.
      groupByKey(person =>
        (
          person.entity.customer,
          person.entity.address1.getOrElse(person.entity.personId),
          person.entity.zip5.getOrElse(person.entity.personId),
          person.entity.rootFirstName.getOrElse(person.entity.personId)
        )
      ).flatMapGroups { case (_, coGroupedCandidates) =>
      mergeMatchedCollapsedCandidates(accumulator, coGroupedCandidates, PersonMatcher.LastNameChangeMatch)
    }
  }
}

trait ActivityPostgresEntityDB extends PostgresEntityDB[Activity] {

  this: ActivityLinkerImpl =>

  val customer: String


  override def fetch(databaseDao: DatabaseDao, sparkSession: SparkSession): Dataset[IdentityEntity[Activity]] = {

    import sparkSession.implicits._

    databaseDao.getActivitiesByCustomer(customer).map(IdentityEntity[Activity]("db_activity", _))
  }

  override def mergeCandidatesOnBlockingKeys(
                                              linkageCandidates: Dataset[IdentityEntity[Activity]]
                                            ): Dataset[IdentityEntity[Activity]] = {

    val linkingFunctions: List[Dataset[IdentityEntity[Activity]] => Dataset[IdentityEntity[Activity]]] = List(
      linkRecordsOnSource
    )
    linkingFunctions.foldLeft(linkageCandidates) { (dataset, function) => function(dataset) }
  }


  def linkRecordsOnSource(
                           candidatesForLinkage: Dataset[IdentityEntity[Activity]]
                         ): Dataset[IdentityEntity[Activity]] = {

    import candidatesForLinkage.sparkSession.implicits._

    candidatesForLinkage.groupByKey(activity => {
      (
        activity.entity.customer,
        activity.entity.source.getOrElse(activity.entity.activityId),
        activity.entity.sourceRecordId.getOrElse(activity.entity.activityId)
      )
    }).reduceGroups((row1, row2) => mergeCandidates(row1, row2)).
      map(_._2)

  }

}
