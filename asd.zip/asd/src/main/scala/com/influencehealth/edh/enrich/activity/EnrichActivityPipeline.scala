package com.influencehealth.edh.enrich.activity

import com.influencehealth.edh.Constants
import com.influencehealth.edh.config.EnrichJobConfig
import com.influencehealth.edh.enrich.activity.address.EnrichAddressStep
import com.influencehealth.edh.enrich.activity.address.EnrichMockAddressStep
import com.influencehealth.edh.enrich.activity.crosswalks.EnrichCrosswalksStep
import com.influencehealth.edh.enrich.ActivityEnricher
import com.influencehealth.edh.enrich.activity.caregrouper.EnrichCareGrouperStep
import com.influencehealth.edh.enrich.activity.dns.DnsEnrichStep
import com.influencehealth.edh.enrich.activity.identity.EnrichIdentityStep
import com.influencehealth.edh.model.Activity
import org.apache.spark.sql.{Dataset, SparkSession}


class EnrichActivityPipeline(val contentEnricher: ActivityEnricher)
                            (implicit enrichJobConfig: EnrichJobConfig, sparkSession: SparkSession) {

  def startEnrichPipeline(dataset: Dataset[Activity]): Dataset[Activity] = {
    contentEnricher.process(dataset)
  }

}

object EnrichActivityPipelineBuilder {

  def apply(enrichStep: String)
           (implicit enrichJobConfig: EnrichJobConfig, sparkSession: SparkSession): EnrichActivityPipeline = {
    val contentEnricher: ActivityEnricher = enrichStep match {
      case Constants.EnrichAddressStepName | Constants.EnrichFirstStepName =>
        val enrichIdentity = new EnrichIdentityStep(name = "EnrichIdentity", None)
        val enrichCrosswalks = new EnrichCrosswalksStep(name = "EnrichCrosswalks", Some(enrichIdentity))
        val enrichCareGroups = new EnrichCareGrouperStep(name = "EnrichCareGroups", Some(enrichCrosswalks))
        new EnrichAddressStep(name = "EnrichAddress", Some(enrichCareGroups))
      case Constants.EnrichCareGroupsStepName =>
        val enrichIdentity = new EnrichIdentityStep(name = "EnrichIdentity", None)
        val enrichCrosswalks = new EnrichCrosswalksStep(name = "EnrichCrosswalks", Some(enrichIdentity))
        new EnrichCareGrouperStep(name = "EnrichCareGroups", Some(enrichCrosswalks))
      case Constants.EnrichCrosswalksStepName =>
        val enrichIdentity = new EnrichIdentityStep(name = "EnrichIdentity", None)
        new EnrichCrosswalksStep(name = "EnrichCrosswalks", Some(enrichIdentity))
      case Constants.EnrichIdentityStepName =>
        new EnrichIdentityStep(name = "EnrichIdentity", None)
      case Constants.EnrichMockAddressStepName =>
        val enrichIdentity = new EnrichIdentityStep(name = "EnrichIdentity", None)
        val enrichCrosswalks = new EnrichCrosswalksStep(name = "EnrichCrosswalks", Some(enrichIdentity))
        val enrichCareGroups = new EnrichCareGrouperStep(name = "EnrichCareGroups", Some(enrichCrosswalks))
        new EnrichMockAddressStep(name = "EnrichMockAddress", Some(enrichCareGroups))
      case Constants.DnsEnrichStepName => new DnsEnrichStep(name = "DNSSKIP", None)
      case _ => throw new Exception("UNKNOWN ENRICH STEP")
    }
    new EnrichActivityPipeline(contentEnricher)
  }

}
