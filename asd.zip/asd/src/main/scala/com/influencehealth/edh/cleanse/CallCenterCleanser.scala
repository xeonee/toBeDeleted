package com.influencehealth.edh.cleanse

import com.influencehealth.edh.model.activitytype.ActivityType
import com.influencehealth.edh.utils.{CleanseUtils, PersonUtils}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

trait CallCenterCleanser extends DataCleanser {

  this: ActivityType =>

  override val dateBatchReceived: String

  override def cleanseData(
                            df: DataFrame,
                            customer: Option[String],
                            batchId: String
                          ): (DataFrame, DataFrame) = {

    val aliasedData = aliasData(df, customer)

    // Apply default values for Required Columns if found NULL
    val defaultCodeForRequiredColumnsContainingNulls = assignDefaultValuesForRequiredColumnsContainingNulls(aliasedData).
      withColumn("source", lit(defaultSource)).
      transform(addSourceRecordId(_, batchId))

    // filters required columns that are not null
    val (dataFrameContainingNonNullColumns, dataFrameContainingNullColumns) =
      filterRequiredColumnsContainingInvalidValues(defaultCodeForRequiredColumnsContainingNulls, nullColumnNames,
        mandatoryContactColumnsNames)

    // cleanses & filters Date column
    val dataFrameContainingValidDateColumns = formatDateColumns(dataFrameContainingNonNullColumns)

    // Cleanses String Column
    val dataFrameContainingCleansedStringColumns = cleanseStringColumns(dataFrameContainingValidDateColumns, cleanseStringColumnNames)

    // Cleanses Contact details: Phone numbers and emails
    val dataFrameContainingCleansedContactDetails = cleanseContactDetails(dataFrameContainingCleansedStringColumns)

    // Cleanse zip5 column
    val cleansedZips = cleanseZips(dataFrameContainingCleansedContactDetails, zipColumnNames)

    // map language code
    val mappedLanguageCodesDf = cleansedZips.transform(mapLanguage)

    (mappedLanguageCodesDf.transform(mapLanguageCodes), dataFrameContainingNullColumns)

  }

  /**
    * THIS IS TEMPORARY WORKAROUND TO MAP LANGUAGE VALUE "ENG" TO "01"
    *
    * @param df
    * @return
    */
  private def mapLanguage(df: DataFrame): DataFrame = {
    if (df.columns.contains("isoLanguageCode")) {
      df.withColumn("isoLanguageCode", when(df("isoLanguageCode") === "ENG", "01") otherwise null)
    } else df
  }

  override def cleanseStringColumns(df: DataFrame, stringColumnsToBeCleansed: Seq[String]): DataFrame = {
    stringColumnsToBeCleansed.foldLeft(df)((curr, n) => curr.withColumn(n, CleanseUtils.cleanseStringColumns(curr(n))))
  }


  override def assignDefaultValuesForRequiredColumnsContainingNulls(df: DataFrame): DataFrame = {
    df.
      withColumn("source", lit(defaultSource)).
      withColumn("sourceType", lit(defaultSourceType)).
      withColumn("addressType", lit(defaultAddressType))
  }

  /** Validates the email and phone number columns
    *
    * @param df
    * @return formated coloumn
    **/
  private def cleanseContactDetails(df: DataFrame): DataFrame = {
    df.withColumn("emails", getStringToArray(CleanseUtils.cleanseAndValidateEmail(df("emails"))))
      .withColumn("phoneNumbers", CleanseUtils.cleanseAndParsePhones(col("phoneNumber")))
  }

  //  val stringify: UserDefinedFunction = udf((vs: Seq[String]) =>
  //    s"""[${vs.mkString(",").replace("null,", "").replace("null", "")}]""")

  /** Cleanse zip values
    *
    * @param df
    * @return
    */
  private def cleanseZips(df: DataFrame, zipColumns: Seq[String]): DataFrame = {
    zipColumns.foldLeft(df)((curr, n) => curr.withColumn(n, CleanseUtils.get_zip5(curr(n))))
  }



}

class BerylCallCenterCleanser(val dateBatchReceived: String) extends CallCenterCleanser {

  this: ActivityType =>

  override def aliasData(df: DataFrame, customer: Option[String]): DataFrame = {
    super.aliasData(df, customer).
      withColumn("activityType", lit(defaultActivityType)).
      withColumn("activityDate", df("createdDateTime"))
  }

  override def formatDateColumns(df: DataFrame): DataFrame = {

    import df.sqlContext.implicits._
    import org.apache.spark.sql.functions.{when, _}
    // Convert string date into Date type columns after validating the dates, known behavior

    val dfWithActivityDate = df.withColumn("activityDate", when(col("activityDate").isNotNull,
      PersonUtils.validateInputDate(date_format(unix_timestamp($"activityDate", "yy-MM-dd HH:mm:ss")
        .cast("timestamp"), "yyyy-MM-dd HH:mm:ss"))) otherwise lit(CleanseUtils.parseStringToDate(dateBatchReceived)))

    val formattedDatesDataFrame = dfWithActivityDate
      .withColumn("dateOfBirth", CleanseUtils.timestamp_to_date(PersonUtils.validateInputDate(
        date_format(unix_timestamp($"dateOfBirth", "MM/dd/yy").cast("timestamp"), "yyyy-MM-dd"))))

    formattedDatesDataFrame
  }

}

class ConiferCallCenterCleanser(val dateBatchReceived: String) extends CallCenterCleanser {

  this: ActivityType =>

  override def aliasData(df: DataFrame, customer: Option[String]): DataFrame = {
    super.aliasData(df, customer).
      withColumn("activityType", lit(defaultActivityType)).
      withColumn("physicianNationalProviderIdentifier", df("NPI")).
      withColumn("serviceLines", getStringToArray(df("serviceLine"))).
      withColumn("insurance", df("insurance")).
      withColumn("physicianFullName", df("physicianName")).
      withColumn("hospital", df("hospital")).
      withColumn("messageType", df("referralType")).
      withColumn("activityDate", df("date")).
      withColumn("address1", df("address"))
  }

  override def formatDateColumns(df: DataFrame): DataFrame = {
    import df.sqlContext.implicits._
    import org.apache.spark.sql.functions.{when, _}
    // Convert string date into Date type columns after validating the dates, known behavior

    val dfWithActivityDate = df.withColumn("activityDate",
      when(col("activityDate").isNotNull,
        PersonUtils.
          validateInputDate(date_format(unix_timestamp($"activityDate", "MM/dd/yy").cast("timestamp"),
            "yyyy-MM-dd"))) otherwise lit(CleanseUtils.parseStringToDate(dateBatchReceived)))

    val formattedDatesDataFrame = dfWithActivityDate
      .withColumn("dateOfBirth", CleanseUtils.timestamp_to_date(PersonUtils.validateInputDate(
        date_format(unix_timestamp($"dateOfBirth", "MM/dd/yy").cast("timestamp"), "yyyy-MM-dd"))))

    formattedDatesDataFrame
  }

}





