package com.influencehealth.edh.enrich.person

import com.influencehealth.edh.Constants
import com.influencehealth.edh.config.EnrichJobConfig
import com.influencehealth.edh.enrich.PersonEnricher
import com.influencehealth.edh.enrich.person.location.EnrichLocationStep
import com.influencehealth.edh.enrich.person.residence.EnrichResidenceStep
import com.influencehealth.edh.model.Person
import org.apache.spark.sql.{Dataset, SparkSession}


class EnrichPersonPipeline(val contentEnricher: PersonEnricher)
                          (implicit enrichJobConfig: EnrichJobConfig, sparkSession: SparkSession) {

  def startEnrichPipeline(dataset: Dataset[Person]): Dataset[Person] = {
    contentEnricher.process(dataset)
  }

}

object EnrichPersonPipelineBuilder {

  def apply(enrichStep: String)
           (implicit enrichJobConfig: EnrichJobConfig, sparkSession: SparkSession): EnrichPersonPipeline = {
    val contentEnricher: PersonEnricher = enrichStep match {
      case Constants.EnrichResidenceStepName | Constants.EnrichFirstStepName =>

        val enrichLocations = new EnrichLocationStep(name = "EnrichLocations", None)
        new EnrichResidenceStep(name = "EnrichResidence", Some(enrichLocations))

      case Constants.EnrichLocationsStepName =>
        new EnrichLocationStep(name = "EnrichLocations", None)

      case _ => throw new Exception("UNKNOWN ENRICH STEP")
    }
    new EnrichPersonPipeline(contentEnricher)
  }

}
