package com.influencehealth.edh.enrich.activity.crosswalks.helper

import com.influencehealth.edh.Constants

case class Sex(
                customer: String,
                source: String,
                sourceType: String,
                sourceSex: String,
                sex: String
              ) extends Serializable

object Sex {
  val sexCw: Seq[Sex] = Seq(
    Sex("default", "default", "default", "m", Constants.SexMale),
    Sex("default", "default", "default", "f", Constants.SexFemale),
    Sex("default", "default", "default", "male", Constants.SexMale),
    Sex("default", "default", "default", "female", Constants.SexFemale),
    Sex("default", "default", "default", "unknown", null),
    Sex("default", "default", "default", "u", null)
  )
}

case class SexCwCreationException(exc: Throwable)
  extends Exception("Unable to create sex crosswalk", exc)

case class InvalidSexValue(value: String)
  extends Exception(s"The following value does not match any standard sex value: '$value'")