package com.influencehealth.edh.updater

import com.influencehealth.edh.model.{Activity, Person}
import com.influencehealth.edh.linker.{PersonInMemoryEntityDB, PersonLinker, PersonLinkerImpl}
import org.apache.spark.sql.Dataset
import org.apache.spark.util.LongAccumulator


object PersonUpdater {

  def getPersons(activities: Dataset[Activity]): Dataset[Person] = {

    import activities.sparkSession.implicits._

    activities
      .sort("activityDate")
      .map(a => Person.deriveFromActivity(a))
      .groupByKey(p => p.personId)
      .reduceGroups{ (person1, person2) =>
        val Seq(oldestPerson, newestPerson) = Seq(person1, person2).sortBy(_.dateCreated.getTime)
        PersonUpdaterImpl.updatePerson(oldestPerson, newestPerson)
      }.map(_._2)
  }

  def rebuildPersons(customer: String,activities: Dataset[Activity]): Dataset[Person] = {

    import activities.sparkSession.implicits._

    /* activities
      .sort("activityDate")
      .map(a => Person.deriveFromActivity(a))
      .groupByKey(p => p.personId)
      .reduceGroups{ (person1, person2) =>
        val Seq(oldestPerson, newestPerson) = Seq(person1, person2).sortBy(_.dateCreated.getTime)
        PersonUpdaterImpl.updatePerson(oldestPerson, newestPerson)
      }.map(_._2) */

    val accumulator: LongAccumulator =
      activities.sparkSession.sparkContext.longAccumulator("Collapse Accumulator")

    val inMemoryPersonLinker = new PersonLinker(accumulator, null, customer, "activityId")
      with PersonLinkerImpl with PersonInMemoryEntityDB

    val persons = activities
      .sort("activityDate")
      .map(a => Person.deriveFromActivity(a))
      .transform( persons => inMemoryPersonLinker.linkRecords(persons))

    persons.groupByKey(p => p.personId).reduceGroups { (person1, person2) =>
      val Seq(oldestPerson, newestPerson) = Seq(person1, person2).sortBy(_.dateCreated.getTime)
      PersonUpdaterImpl.updatePerson(oldestPerson, newestPerson)
    }.map(_._2)

  }
}
