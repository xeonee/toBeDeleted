package com.influencehealth.edh.refresh.elasticsearch

import java.io.InputStream
import java.net.SocketTimeoutException
import java.nio.file.{Files, Paths}
import java.security.KeyStore

import com.google.gson.JsonElement
import com.influencehealth.edh.config.ElasticsearchConfig
import com.typesafe.scalalogging.LazyLogging
import org.apache.http.HttpHost
import org.apache.http.auth.{AuthScope, UsernamePasswordCredentials}
import org.apache.http.impl.client.BasicCredentialsProvider
import org.apache.http.impl.nio.client.HttpAsyncClientBuilder
import org.apache.http.ssl.SSLContexts
import org.elasticsearch.action.admin.cluster.health.ClusterHealthRequest
import org.elasticsearch.action.admin.indices.alias.IndicesAliasesRequest
import org.elasticsearch.action.admin.indices.alias.IndicesAliasesRequest.AliasActions
import org.elasticsearch.action.admin.indices.close.CloseIndexRequest
import org.elasticsearch.action.admin.indices.create.{CreateIndexRequest, CreateIndexResponse}
import org.elasticsearch.action.admin.indices.delete.DeleteIndexRequest
import org.elasticsearch.action.admin.indices.mapping.put.PutMappingRequest
import org.elasticsearch.action.admin.indices.open.OpenIndexRequest
import org.elasticsearch.action.admin.indices.settings.put.UpdateSettingsRequest
import org.elasticsearch.action.support.master.AcknowledgedResponse
import org.elasticsearch.client.RestClientBuilder.HttpClientConfigCallback
import org.elasticsearch.client.{RequestOptions, RestClient, RestHighLevelClient}
import org.elasticsearch.cluster.health.ClusterHealthStatus
import org.elasticsearch.common.settings.Settings
import org.elasticsearch.common.unit.TimeValue
import org.elasticsearch.common.xcontent.XContentType

import scala.collection.JavaConverters._
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration._
import scala.concurrent.{Await, Future}
import scala.language.postfixOps

class IndexManager(elasticsearchConfig: ElasticsearchConfig) extends LazyLogging {

  val timeout: String = elasticsearchConfig.timeout.getOrElse("2m")

  case class IndexNotReadyException(string: String) extends Exception(string)

  private val esClient: RestHighLevelClient = getIndicesClient(
    elasticsearchConfig.node,
    elasticsearchConfig.useSsl,
    elasticsearchConfig.user,
    elasticsearchConfig.password,
    elasticsearchConfig.keyStorePath,
    elasticsearchConfig.keystorePass
  )

  /**
    * REST Indices Client configuration
    *
    * @param node
    * @param useSsl
    * @param user
    * @param password
    * @param keyStorePath
    * @param keystorePass
    * @return RestHighLevelClient
    */
  private def getIndicesClient(
                                node: String,
                                useSsl: Boolean,
                                user: String,
                                password: String,
                                keyStorePath: Option[String],
                                keystorePass: Option[String]
                              ): RestHighLevelClient = {
    if (useSsl) {
      val credentialsProvider = new BasicCredentialsProvider
      credentialsProvider.setCredentials(AuthScope.ANY, new UsernamePasswordCredentials(user, password))

      val truststore = KeyStore.getInstance("JKS")
      val path = Paths.get(keyStorePath.get)
      lazy val is: InputStream = Files.newInputStream(path)
      try {
        truststore.load(is, keystorePass.get.toCharArray)
      } catch {
        case e: Throwable =>
          logger.error("Failed to access truststore", e)
      } finally {
        is.close()
      }
      val sslBuilder = SSLContexts.custom.loadTrustMaterial(truststore, null)
      val sslContext = sslBuilder.build
      val builder = RestClient.builder(new HttpHost(node, 9200, "https")).
        setMaxRetryTimeoutMillis(90000000).
        setHttpClientConfigCallback((new HttpClientConfigCallback() {
          @Override
          def customizeHttpClient(httpClientBuilder: HttpAsyncClientBuilder): HttpAsyncClientBuilder = {
            httpClientBuilder.
              setSSLContext(sslContext).
              setDefaultCredentialsProvider(credentialsProvider)
          }
        }))

      new RestHighLevelClient(builder)
    } else {
      new RestHighLevelClient(RestClient.builder(
        new HttpHost(node, 9200, "http")
      ))
    }
  }

  /**
    * Sets up the new idex.
    * 1. initialize Index
    * 2. set Total Number Of Shards Per Node (Partition)
    * 3. Configure analyzers.json
    * 4. Apply person mapping
    *
    * @param indexName
    * @param numberOfReplicas
    * @param numberOfShards
    * @param personMapping
    * @param analysisConfiguration
    */
  def setupIndex(
                  indexName: String,
                  numberOfReplicas: Int, // per record
                  numberOfShards: Int, // partition
                  personMapping: JsonElement,
                  analysisConfiguration: JsonElement
                ): Unit = {

    // Open Index = open for use
    // Close Index = not open to use and some dev work/patch is being applied to it

    val numberOfShardsPerNode = numberOfShards + (numberOfShards * numberOfReplicas) / 6 // partition per node

    initializeIndex(indexName, numberOfReplicas, numberOfShards)

    setTotalNumberOfShardsPerNode(indexName, numberOfShardsPerNode)

    // like configuring DB
    configureIndexAnalyzers(indexName, analysisConfiguration)

    // like applying DB schema
    addMapping(indexName, personMapping)

  }

  /**
    * initialize a new index
    * 1. create index request with shards, replicas & cache enabling properties
    * 2. Test sending the request for an acknowledgement in response
    * Conf Ref: https://www.elastic.co/guide/en/elasticsearch/reference/current/index-modules.html
    *
    * @param indexName
    * @param numberOfReplicas
    * @param numberOfShards
    */
  private def initializeIndex(
                               indexName: String,
                               numberOfReplicas: Int,
                               numberOfShards: Int
                             ): Unit = {
    val createIndexRequest: CreateIndexRequest = new CreateIndexRequest(indexName)

    createIndexRequest.settings(Settings.builder().
      put("index.number_of_shards", numberOfShards).
      put("index.number_of_replicas", numberOfReplicas).
      put("index.requests.cache.enable", true).
      build())

    createIndexRequest.timeout(timeout)

    val createIndexResponse: CreateIndexResponse = esClient.indices().create(createIndexRequest, RequestOptions.DEFAULT)

    if (!createIndexResponse.isAcknowledged) {
      throw new Exception("Index creation has yet to be acknowledged")
    }

    if (!createIndexResponse.isShardsAcknowledged) {
      throw new Exception("Shards have yet to acknowledge index creation")
    }
  }

  /**
    * Apply index.routing.allocation.total_shards_per_node
    *
    * @param indexName
    * @param numberOfShardsPerNode
    */
  private def setTotalNumberOfShardsPerNode(
                                             indexName: String,
                                             numberOfShardsPerNode: Int
                                           ): Unit = {

    // TODO add this step to initializeIndex's createIndexRequest step itself
    val updateTotalShardsPerNodeRequest: UpdateSettingsRequest = new UpdateSettingsRequest(indexName)
    updateTotalShardsPerNodeRequest.settings(Settings.builder().
      put("index.routing.allocation.total_shards_per_node", numberOfShardsPerNode).
      build())

    updateTotalShardsPerNodeRequest.timeout(timeout)

    val updateTotalShardsPerNodeResponse: AcknowledgedResponse =
      esClient.indices().putSettings(updateTotalShardsPerNodeRequest, RequestOptions.DEFAULT)

    if (!updateTotalShardsPerNodeResponse.isAcknowledged) {
      throw new Exception("Failed to update the total shards per node")
    }
  }

  /**
    * Apply analyzers.json
    *
    * @param indexName
    * @param analysisConfiguration
    */
  private def configureIndexAnalyzers(
                                       indexName: String,
                                       analysisConfiguration: JsonElement
                                     ): Unit = {
    // Closing index to apply analyzers
    val closeIndexRequest: CloseIndexRequest = new CloseIndexRequest()
    closeIndexRequest.indices(indexName)
    val closeIndexResponse = esClient.indices().close(closeIndexRequest, RequestOptions.DEFAULT)

    if (!closeIndexResponse.isAcknowledged) {
      throw new Exception("Failed to close index")
    }

    val updateAnalyzersRequest: UpdateSettingsRequest = new UpdateSettingsRequest(indexName)

    // apply analyzer confs
    updateAnalyzersRequest.settings(analysisConfiguration.toString, XContentType.JSON)

    updateAnalyzersRequest.timeout(timeout)

    val updateAnalyzersResponse: AcknowledgedResponse =
      esClient.indices().putSettings(updateAnalyzersRequest, RequestOptions.DEFAULT)

    if (!updateAnalyzersResponse.isAcknowledged) {
      throw new Exception("Failed to add analyzers")
    }

    val openIndexRequest: OpenIndexRequest = new OpenIndexRequest()
    openIndexRequest.indices(indexName)
    val openIndexResponse = esClient.indices().open(openIndexRequest, RequestOptions.DEFAULT)

    if (!openIndexResponse.isAcknowledged) {
      throw new Exception("Failed to open index")
    }
  }

  /**
    * Applying person-mapping.json schema
    *
    * @param indexName
    * @param personMapping
    */
  private def addMapping(indexName: String, personMapping: JsonElement): Unit = {
    val addMappingRequest: PutMappingRequest = new PutMappingRequest(indexName)

    addMappingRequest.`type`("person")

    addMappingRequest.source(personMapping.toString, XContentType.JSON)

    addMappingRequest.timeout(timeout)

    val addMappingResponse: AcknowledgedResponse =
      esClient.indices().putMapping(addMappingRequest, RequestOptions.DEFAULT)

    if (!addMappingResponse.isAcknowledged) {
      throw new Exception("Failed to add mapping")
    }
  }

  /**
    * Disabling replication while refreshing(writing to the index) to avoid slowing down the process
    *
    * @param indexName
    */
  def disableRefreshAndReplicaForInitialLoad(indexName: String): Unit = {
    val disableRefreshAndReplicasRequest: UpdateSettingsRequest = new UpdateSettingsRequest(indexName)
    disableRefreshAndReplicasRequest.settings(Settings.builder().
      put("index.refresh_interval", -1).
      put("index.number_of_replicas", 0).
      build())

    disableRefreshAndReplicasRequest.timeout(timeout)

    val disableResponse: AcknowledgedResponse =
      esClient.indices().putSettings(disableRefreshAndReplicasRequest, RequestOptions.DEFAULT)

    if (!disableResponse.isAcknowledged) {
      throw new Exception("Failed to disable refresh interval and number of replicas")
    }
  }

  /**
    * Enabling replication of current index
    *
    * @param indexName
    * @param elasticsearchConfig
    */
  def reenableRefreshAndReplicaAfterInitialLoad(
                                                 indexName: String,
                                                 elasticsearchConfig: ElasticsearchConfig
                                               ): Unit = {
    val reenableRequest: UpdateSettingsRequest = new UpdateSettingsRequest(indexName)
    reenableRequest.settings(Settings.builder().
      put("index.refresh_interval", "1s"). // Set the value back to the default
      put("index.number_of_replicas", elasticsearchConfig.numberOfReplicas).
      build())

    reenableRequest.timeout(timeout)

    val reenableResponse: AcknowledgedResponse =
      esClient.indices().putSettings(reenableRequest, RequestOptions.DEFAULT)

    if (!reenableResponse.isAcknowledged) {
      throw new Exception("Failed to re-enable refresh interval and number of replicas")
    }

  }

  /**
    * Confirms the new index created has a status = GREEN & then enable replication
    *
    * @param indexName
    * @param aliasName
    * @param secondsToWait
    * @param maxSecondsToWait
    * @param numberOfRetries
    */
  def swapAlias(
                 indexName: String,
                 aliasName: String,
                 secondsToWait: Long,
                 maxSecondsToWait: Long,
                 numberOfRetries: Int
               ): Unit = {

    def isIndexReady = {
      val clusterHealthRequest = new ClusterHealthRequest()
      clusterHealthRequest.
        waitForGreenStatus().
        timeout(TimeValue.timeValueMinutes(secondsToWait))

      val status = esClient.cluster().health(clusterHealthRequest, RequestOptions.DEFAULT).getStatus
      status.equals(ClusterHealthStatus.GREEN)
    }

    def blockForGreenIndex(numberOfRetries: Int, deadline: Deadline) = {

      def recursiveBlock(numberOfRetriesLeft: Int): Unit = {
        if (numberOfRetriesLeft == 0 || deadline.isOverdue()) {
          throw new RuntimeException("Too many retries")
        } else {
          try {
            val indexIsReady = Await.result(Future(isIndexReady), deadline.timeLeft)
            if (!indexIsReady) {
              Thread.sleep(secondsToWait * 1000)
              recursiveBlock(numberOfRetriesLeft - 1)
            }
          } catch {
            case e: SocketTimeoutException =>
              // Seems to have issues with socket while waiting for response
              recursiveBlock(numberOfRetries - 1)
            case e: Throwable =>
              throw e
          }
        }
      }

      recursiveBlock(numberOfRetries)
    }

    def issueAliasSwapRequest = {
      val request = new IndicesAliasesRequest()
      val aliasActions = new AliasActions(AliasActions.Type.ADD).
        index(indexName).
        alias(aliasName)
      request.addAliasAction(aliasActions)
      val response = esClient.indices.updateAliases(request, RequestOptions.DEFAULT)
      if (!response.isAcknowledged) {
        throw new IndexNotReadyException("Failed to update alias")
      }
    }

    blockForGreenIndex(numberOfRetries, maxSecondsToWait.seconds.fromNow)

    issueAliasSwapRequest

  }

  /**
    * Removes all old indexes after sorting by indexes timestamp & dropping the latest
    *
    * @param customer
    */
  def cleanUpOldIndices(customer: String): Unit = {
    val response = esClient.cluster().health(new ClusterHealthRequest(), RequestOptions.DEFAULT)
    val indexNames = response.getIndices.asScala.filterKeys(_.startsWith(s"${customer}_")).keys.toSeq
    indexNames.sortBy(_.split("_")(1).toLong).dropRight(1).foreach {
      indexName =>
        val request = new DeleteIndexRequest(indexName)
        esClient.indices().delete(request, RequestOptions.DEFAULT)
    }
  }

  /**
    * Close connection
    */
  def close: Unit = {
    esClient.close()
  }


}
