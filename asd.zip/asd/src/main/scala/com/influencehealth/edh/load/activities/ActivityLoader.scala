package com.influencehealth.edh.load.activities

import com.influencehealth.edh.utils.DataLakeUtilities
import com.influencehealth.edh.{Constants, CustomLazyLogging}
import org.apache.commons.codec.digest.DigestUtils
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

object ActivityLoader extends CustomLazyLogging {

  private val randomize = scala.util.Random

  /**
    * Reads parquet files
    *
    * @param sparkSession
    * @param s3CleansedBatchUrls
    * @return
    */
  def readActivityFiles(sparkSession: SparkSession, s3CleansedBatchUrls: String, activityType: String,
                        customer: String, zip5s: Set[String], batchId: String): DataFrame = {
    val activityDataFrame = sparkSession.read.parquet(s3CleansedBatchUrls).withColumn("batchId", lit(batchId))
    activityType.toUpperCase match {
      case Constants.NewMoverExperianDefaultSource | Constants.ProspectDefaultMessageType =>
        activityDataFrame.filter(row => zip5s.contains(row.getAs[String]("zip5"))).
          withColumn("customer", lit(customer))
      case _ => activityDataFrame
    }
  }

  /**
    * Alias column names with cassandra column names
    * Adds batch id to create a batch identifier
    *
    * @param df
    * @param sparkSession
    * @return
    */
  def aliasDataFrameColumns(df: DataFrame): DataFrame = {

    // For cassandra
    df.
      withColumnRenamed("childZeroToThreeBkt", "hasChildZeroToThree").
      withColumnRenamed("childFourToSixBkt", "hasChildFourToSix").
      withColumnRenamed("childSevenToNineBkt", "hasChildSevenToNine").
      withColumnRenamed("childTenToTwelveBkt", "hasChildTenToTwelve").
      withColumnRenamed("childThirteenToFifteenBkt", "hasChildThirteenToFifteen").
      withColumnRenamed("childSixteenToEighteenBkt", "hasChildSixteenToEighteen").
      withColumnRenamed("presenceOfChild", "isChildPresent").
      withColumnRenamed("deceasedFlag", "isDeceased").
      withColumnRenamed("age", "sourceAge")
  }

  def generateNewActivityColumns(df: DataFrame, batchId: String, sparkSession: SparkSession): DataFrame = {

    val columnsNotToBeHashed: Seq[String] = Seq("dateCreated")
    val hashColumns: Seq[String] = df.columns.filterNot(s => columnsNotToBeHashed.contains(s))
    // For cassandra
    val dfContainingNewColumns = df.
      withColumn("activityId", md5FromRow(struct(hashColumns.map(col): _*))).
      withColumn("batchId", lit(batchId)).
      withColumn("isValidAddress", lit(false))

    val finalDF = dfContainingNewColumns.dropDuplicates(Seq("activityId"))
    val droppedRows = dfContainingNewColumns.count() - finalDF.count()

    if (droppedRows > 0) {
      logger.warn(s"$droppedRows Duplicate activities were dropped")
    }

    val format = DataLakeUtilities.extractFormatFromBatchId(batchId)

    format match {
      case "redox" => finalDF.drop("__index_level_0__")
      case _ => finalDF
    }
  }

  /**
    * Generates md5 from the content of a Row
    */
  def md5FromRow: UserDefinedFunction = udf((r: Row) => {
    val input = r.mkString
    DigestUtils.md5Hex(input.getBytes)
  })
}
