package com.influencehealth.edh.dao

import java.sql.{Connection, DriverManager, ResultSet, Statement}
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Properties

import com.google.gson.Gson
import com.influencehealth.edh.CustomLazyLogging
import com.influencehealth.edh.config.DatabaseConfig
import com.influencehealth.edh.dataframe.columns._
import com.influencehealth.edh.model.{Activity, _}
import mojolly.inflector.Inflector
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession, _}
import org.flywaydb.core.Flyway

import scala.collection.JavaConverters._
import scala.collection.mutable.ListBuffer
import scala.reflect.ClassTag


case class PostgresConstraint(
                               tableName: String,
                               constraintName: String,
                               constraintType: String,
                               constraintDefinition: String
                             )

class PostgresDatabaseDao(config: DatabaseConfig)(

  implicit sparkSession: SparkSession) extends DatabaseDao with CustomLazyLogging {

  import sparkSession.implicits._

  val PostgresDriver: String = "org.postgresql.Driver"

  val PersonsTable: String = "persons"

  val ActivitiesTable: String = "activities"

  val UnidentifiableActivities: String = "unidentifiable_activities"

  val AddressesTable: String = "addresses"

  val EpdbListPersonsTable: String = "epdb_list_persons"

  val DoNotSolicitEmailsTable: String = "do_not_solicit_emails"

  val PersonArchivesTable: String = "person_archives"

  val JobHistoryTable: String = "job_history"

  val CollapseHistoryTable: String = "collapse_history"

  val DefaultBatchSize: Int = 1000

  val postgresHost: String = config.host

  val postgresPort: Int = config.port

  val postgresUser: String = config.user

  val postgresPassword: String = config.password

  val postgresSchema: String = config.schema

  val postgresDatabase: String = config.database

  val sslMode: Option[String] = config.sslMode

  val sslRootCert: Option[String] = config.sslRootCert

  val batchSize: Option[Int] = config.batchSize

  val UngroupableActivities: String = "ungroupable_activities"


  // Checking to make sure postgres driver is available
  Class.forName(PostgresDriver)

  val url: String = if (config.useSsl) {
    s"jdbc:postgresql://$postgresHost:$postgresPort/$postgresDatabase?sslmode=${sslMode.get}&sslrootcert=${sslRootCert.get}"
  } else {
    s"jdbc:postgresql://$postgresHost:$postgresPort/$postgresDatabase"
  }

  reOrderDrivers()

  validateSchemaVersion

  val connectionProperties: Properties = buildConnectionProperties

  private def reOrderDrivers(): Unit = {
    // Redshift driver is loaded before postgres driver in some cases because the two will allow for the same
    // jdbc connection string
    DriverManager.getDrivers().asScala.toSeq.
      find(d => d.getClass().getName().equals("com.amazon.redshift.jdbc.Driver")).
      foreach { d =>
        DriverManager.deregisterDriver(d)
        DriverManager.registerDriver(d)
      }

    // DriverManager.getDrivers().asScala.toSeq.foreach(d => println(d.getClass.getName))
  }

  private def validateSchemaVersion(): Unit = {
    val flyway: Flyway = new Flyway()

    flyway.setDataSource(url, postgresUser, postgresPassword)

    flyway.setSchemas(postgresSchema)

    flyway.setLocations(s"classpath://postgres")

    flyway.validate()

  }

  private def buildConnectionProperties: Properties = {
    val connectionProperties = new Properties()
    connectionProperties.put("user", postgresUser)
    connectionProperties.put("password", postgresPassword)
    connectionProperties.put("stringtype", "unspecified")
    connectionProperties.put("driver", PostgresDriver)

    if (config.useSsl) {
      connectionProperties.put("sslmode", sslMode.get)
      connectionProperties.put("sslrootcert", sslRootCert.get)
    }

    connectionProperties
  }

  override def saveTable[T](dataset: Dataset[T], table: String): Unit = {
    dataset.toDF().
      repartition(8).
      transform(prepComplexTypesForSave).
      transform(aliasColumnsToSnakeCase).
      write.
      mode(SaveMode.Append).
      option("numPartitions", 8).
      option("batchsize", batchSize.getOrElse(DefaultBatchSize)).
      option("user", postgresUser).
      option("password", postgresPassword).
      jdbc(url, s"$postgresSchema.$table", connectionProperties)
  }


  override def transactionalSaveTable[T](
                                          dataset: Dataset[T],
                                          table: String,
                                          unloggedTable: String,
                                          primaryKey: String
                                        ): Unit = {

    val createQuery =
      s""" CREATE UNLOGGED TABLE $postgresSchema.$unloggedTable (like $postgresSchema.$table)""".stripMargin

    executeQuery(createQuery)

    saveTable(dataset, unloggedTable)

    val columns = dataset.toDF().transform(prepComplexTypesForSave).transform(aliasColumnsToSnakeCase).columns
    // TODO Migration: Check if the dataset columns matches the table columns

    val tableConstraints: Seq[PostgresConstraint] = getConstraints(table)

    val createUnloggedTablePrimaryConstraintsQueries: Seq[String] = tableConstraints
      .filter(c => c.tableName == table && c.constraintType == "p")
      .map { c =>
        s"""
           |ALTER TABLE
           |  $postgresSchema.$unloggedTable
           |ADD CONSTRAINT ${unloggedTable}_${c.constraintName} ${c.constraintDefinition}""".stripMargin
      }

    val createUnloggedTableForeignConstraintsQueries: Seq[String] = tableConstraints
      .filter(c => c.tableName == table && c.constraintType == "f")
      .map { c =>
        s"""
           |ALTER TABLE
           |  $postgresSchema.$unloggedTable
           |ADD CONSTRAINT ${unloggedTable}_${c.constraintName} ${c.constraintDefinition}
           |""".stripMargin
      }

    val upsertQuery: Seq[String] = Seq(
      s"""
          with "insert_persons" as (
            SELECT ${columns.mkString(" ,")} FROM $postgresSchema.$unloggedTable
          )
          INSERT INTO $postgresSchema.$table (${columns.mkString(", ")})
            SELECT ${columns.mkString(" ,")} FROM insert_persons
          ON CONFLICT ($primaryKey) DO UPDATE
          SET ${columns.filter(c => c != "customer" && c != primaryKey).map(c => s"$c = excluded.$c").mkString(" ,")}
          """.stripMargin)

    val dropUnloggedTableQuery: Seq[String] = Seq(
      s""" DROP TABLE $postgresSchema.$unloggedTable""".stripMargin
    )

    executeQueries(
      Seq(
        createUnloggedTablePrimaryConstraintsQueries,
        createUnloggedTableForeignConstraintsQueries,
        upsertQuery,
        dropUnloggedTableQuery
      ).filter(_.nonEmpty).flatten: _*)

  }

  override def loadTable[T: ClassTag](table: String): Dataset[T] = {

    implicit val implicitEncoder: Encoder[T] = Encoders.kryo[T]

    sparkSession.read
      .jdbc(url, s"$postgresSchema.$table", connectionProperties)
      .as[T]
  }

  override def getActivitiesByBatchId(batchId: String): Dataset[Activity] = {

    val sqlQuery =
      s"""
         |(
         |  SELECT $postgresSchema.$ActivitiesTable.*
         |  FROM $postgresSchema.$ActivitiesTable
         |  WHERE $postgresSchema.$ActivitiesTable.batch_id = '$batchId'
         |  ORDER BY date_created ASC
         |) activities
      """.stripMargin

    sparkSession.read.
      option("user", postgresUser).
      option("password", postgresPassword).
      jdbc(url,
        sqlQuery,
        connectionProperties).
      transform(aliasColumnsToCamelCase).
      map(Activity.buildFromRow)

  }


  override def getUnidentifiableActivitiesByBatchId(batchId: String): Dataset[Activity] = {

    val sqlQuery =
      s"""
         |(
         |  SELECT $postgresSchema.$UnidentifiableActivities.*
         |  FROM $postgresSchema.$UnidentifiableActivities
         |  WHERE $postgresSchema.$UnidentifiableActivities.batch_id = '$batchId'
         |  ORDER BY date_created ASC
         |) activities
      """.stripMargin

    sparkSession.read.
      option("user", postgresUser).
      option("password", postgresPassword).
      jdbc(url,
        sqlQuery,
        connectionProperties).
      transform(aliasColumnsToCamelCase).
      map(Activity.buildFromRow)

  }

  override def getUngroupableActivitiesByBatchId(batchId: String): Dataset[Activity] = {

    val sqlQuery =
      s"""
         |(
         |  SELECT $postgresSchema.$UngroupableActivities.*
         |  FROM $postgresSchema.$UngroupableActivities
         |  WHERE $postgresSchema.$UngroupableActivities.batch_id = '$batchId'
         |  ORDER BY date_created ASC
         |) activities
      """.stripMargin

    sparkSession.read.
      option("user", postgresUser).
      option("password", postgresPassword).
      jdbc(url,
        sqlQuery,
        connectionProperties).
      transform(aliasColumnsToCamelCase).
      map(Activity.buildFromRow)

  }

  override def getPersonsByBatchId(batchId: String, full: Boolean): Dataset[Person] = {

    val sqlQuery =
      s"""
         |(
         |  SELECT $postgresSchema.$PersonsTable.*, null as activities
         |  FROM $postgresSchema.$PersonsTable
         |  JOIN (
         |          SELECT DISTINCT person_id
         |          FROM $postgresSchema.$ActivitiesTable
         |          WHERE $postgresSchema.$ActivitiesTable.batch_id = '$batchId'
         |       ) as A
         |            ON $postgresSchema.$PersonsTable.person_id = A.person_id
         |  ORDER BY date_created ASC
         |) persons""".stripMargin


    val persons = sparkSession.read.
      option("user", postgresUser).
      option("password", postgresPassword).
      jdbc(url,
        sqlQuery,
        connectionProperties).
      transform(aliasColumnsToCamelCase).
      map(Person.buildPersonFromRow)

    if (full) {
      val groupedActivities: Dataset[(String, Seq[Activity])] = getActivitiesRelatedToBatchUpdate(batchId).
        groupByKey(a => a.personId.get).mapGroups { (personId: String, activites: Iterator[Activity]) =>
        (personId, activites.toSeq)
      }
      persons.
        joinWith(groupedActivities, persons("personId") === groupedActivities("_1"), "left").
        map { case (person, activities) =>
          person.copy(activities = Option(activities).map(_._2).getOrElse(Seq.empty))
        }

    } else {
      persons
    }
  }

  override def searchAddressesByZipCodes(distinctZipCodes: Set[String]): Dataset[Address] = {
    if (distinctZipCodes.nonEmpty) {
      val sqlQuery =
        s"""
           |(SELECT *
           |FROM $postgresSchema.$AddressesTable
           |WHERE zip5 IN (${distinctZipCodes.map(z => s"'$z'").mkString(",")}) ) filtered_addresses""".stripMargin

      sparkSession.read.
        option("user", postgresUser).
        option("password", postgresPassword).
        jdbc(url,
          sqlQuery,
          connectionProperties).
        transform(aliasColumnsToCamelCase).
        map(Address.buildFromRow)
    } else {
      sparkSession.emptyDataset[Address]
    }
  }

  override def saveAddresses(addresses: Dataset[Address]): Unit = {
    saveTable(addresses, AddressesTable)
  }

  override def savePersons(persons: Dataset[Person]): Unit = {
    transactionalSaveTable(
      persons, PersonsTable, s"unlogged_${PersonsTable}_${System.currentTimeMillis()}", "person_id"
    )
  }

  def aliasColumnsToSnakeCase(dataFrame: DataFrame): DataFrame = {
    val aliasedColumns = dataFrame.columns.map(col => $"$col" as Inflector.underscore(col))

    dataFrame.select(aliasedColumns: _*)
  }

  def aliasColumnsToCamelCase(dataFrame: DataFrame): DataFrame = {
    val aliasedColumns = dataFrame.columns.map(col => $"$col" as Inflector.camelize(col))

    dataFrame.select(aliasedColumns: _*)
  }

  override def saveActivities(activities: Dataset[Activity]): Unit = {
    transactionalSaveTable(
      activities, ActivitiesTable, s"unlogged_${ActivitiesTable}_${System.currentTimeMillis()}", "activity_id"
    )
  }

  override def saveUnidentifiableActivities(invalidAddressRecords: Dataset[UnIdentifiableActivity]): Unit = {
    val batchId = invalidAddressRecords.first().batchId
    executeQuery(
      s"""DELETE FROM
         |    $postgresSchema.$UnidentifiableActivities
         |WHERE ${Inflector.underscore(BatchId)} = '$batchId'""".stripMargin)
    saveTable(invalidAddressRecords, UnidentifiableActivities)
  }

  override def saveUngroupableActivities(ungroupableRecords: Dataset[UnIdentifiableActivity]): Unit = {
    val batchId = ungroupableRecords.first().batchId
    executeQuery(
      s"""DELETE FROM
         |    $postgresSchema.$UngroupableActivities
         |WHERE ${Inflector.underscore(BatchId)} = '$batchId'""".stripMargin)
    saveTable(ungroupableRecords, UngroupableActivities)
  }

  private def verifyTableMatchesModel[T](dataset: Dataset[T], tableName: String, columnsToIgnore: Seq[String]): Unit = {

    // Get columns from table in database
    val databaseColumns: Set[String] = getDatabaseTableColumnNames(tableName).toSet

    // Get columns from DataFrame
    val dataFrameColumns: Set[String] = dataset.toDF.
      transform(aliasColumnsToSnakeCase).columns.toSet

    if (!dataFrameColumns.subsetOf(databaseColumns)) {
      throw new Exception(s"DataFrame for table $tableName is missing ${
        (dataFrameColumns -- databaseColumns).mkString(",")
      }")
    }
  }

  private def getConstraints(tableName: String): Seq[PostgresConstraint] = {

    val sql =
      s"""
         |SELECT rel.relname as table, con.conname,con.contype,pg_get_constraintdef(con.oid) as constraintdef
         |FROM pg_catalog.pg_constraint con
         |       INNER JOIN pg_catalog.pg_class rel
         |         ON rel.oid = con.conrelid
         |       INNER JOIN pg_catalog.pg_namespace nsp
         |         ON nsp.oid = connamespace
         |WHERE nsp.nspname = '$postgresSchema'
         |  AND rel.relname = '$tableName'
         |  AND con.contype = 'p'
         |UNION
         |SELECT rel.relname as table, con.conname,con.contype,pg_get_constraintdef(con.oid) as constraintdef
         |FROM pg_catalog.pg_constraint con
         |       INNER JOIN pg_catalog.pg_class rel
         |         ON rel.oid = con.conrelid
         |       INNER JOIN pg_catalog.pg_namespace nsp
         |         ON nsp.oid = connamespace
         |WHERE nsp.nspname = '$postgresSchema'
         |  AND (( con.contype = 'f' AND pg_get_constraintdef(con.oid) ilike '%$tableName%' )
         |      OR ( rel.relname = '$tableName' AND con.contype = 'f' ));
       """.stripMargin

    val resultSet = executeSQL(sql)
    val columns: Seq[String] = 1 to 4 map resultSet.getMetaData.getColumnName
    val result: Iterator[Seq[String]] = Iterator.continually(resultSet).takeWhile(_.next()).map { rs =>
      columns map rs.getString
    }

    result.map(r => PostgresConstraint(r.head, r(1), r(2), r(3))).toSeq

  }


  override def getActivitiesByCustomer(customer: String): Dataset[Activity] = {
    sparkSession.read.
      option("user", postgresUser).
      option("password", postgresPassword).
      jdbc(url,
        s"$postgresSchema.$ActivitiesTable",
        connectionProperties).
      where($"customer" === customer).
      sort("date_created").
      transform(aliasColumnsToCamelCase).
      map(Activity.buildFromRow)
  }

  override def getPersonsByCustomer(customer: String, withActivities: Boolean): Dataset[Person] = {
    val persons = sparkSession.read.
      option("user", postgresUser).
      option("password", postgresPassword).
      jdbc(url,
        s"$postgresSchema.$PersonsTable",
        connectionProperties).
      where($"customer" === customer).
      sort("date_created").
      transform(aliasColumnsToCamelCase).
      map(Person.buildPersonFromRow)

    if (withActivities) {
      val groupedActivities: Dataset[(String, Seq[Activity])] = getActivitiesByCustomer(customer).
        groupByKey(a => a.personId.get).mapGroups { (personId: String, activities: Iterator[Activity]) =>
        (personId, activities.toSeq)
      }

      persons.
        joinWith(groupedActivities, persons("personId") === groupedActivities("_1"), "left").
        map { case (person, activities) =>
          person.copy(activities = Option(activities).map(_._2).getOrElse(Seq.empty))
        }

    } else {
      persons
    }
  }

  private def prepComplexTypesForSave(dataFrame: DataFrame): DataFrame = {
    val columns: Seq[Column] = dataFrame.schema.
      filter(_.name != "activities").
      flatMap {
        case StructField(_, MapType(_, _, _), _, _) =>
          throw new Exception("Map types are not allowed. They cause issues in the elasticsearch mapping")
        case StructField(name, ArrayType(StructType(_), _), _, _) =>
          Seq(array_to_json(dataFrame(name)) as name)
        case StructField("addressCoordinates", dataType, nullable, metadata) =>
          // (0,0) - refers to the "Null Island" a location in the Gulf of Guinea off the west African coast
          // No person should ever have an address there
          Seq(
            coalesce(concat(
              lit("("),
              dataFrame("addressCoordinates.lon"),
              lit(","),
              dataFrame("addressCoordinates.lat"),
              lit(")")
            ), lit("(0,0)")) as "addressCoordinates")
        case StructField(name, dataType, _, _) if dataType.isInstanceOf[StructType] =>
          flattenSchema(dataType.asInstanceOf[StructType], Option(name))
        case StructField(name, _, _, _) =>
          Seq(dataFrame(name))
      }
    dataFrame.select(columns: _*)
  }

  private def flattenSchema(schema: StructType, prefix: Option[String] = None): Seq[Column] = {
    schema.fields.flatMap(f => {
      val colName: Option[String] = if (prefix.isEmpty) Some(f.name) else Some(s"${prefix.get}.${f.name}")
      f.dataType match {
        case st: StructType => flattenSchema(st, colName)
        case _ => Seq(col(colName.get) as f.name)
      }
    })
  }

  def array_to_json = udf[String, Seq[Row]] { seq =>
    val gson = new Gson()
    if (Option(seq).isEmpty || seq.isEmpty) {
      gson.toJson(List.empty.asJava)
    } else {
      val retValue: java.util.List[Object] = seq.map {
        case r if r.schema == StructType(Seq(
          StructField("location", StringType, nullable = true),
          StructField("preference", IntegerType, nullable = true)
        )) =>
          Map(
            "location" -> r.getAs[String]("location"),
            "preference" -> r.getAs[Int]("preference")
          ).asJava
        case r if r.schema == StructType(Seq(
          StructField("phone", StringType, nullable = true),
          StructField("phoneType", StringType, nullable = true)
        )) =>
          Map(
            "phone" -> r.getAs[String]("phone"),
            "phoneType" -> r.getAs[String]("phoneType")
          ).asJava
        case r if r.schema == StructType(Seq(
          StructField("variable", StringType, nullable = true),
          StructField("value", StringType, nullable = true)
        )) =>
          Map(
            "value" -> r.getAs[String]("value"),
            "variable" -> r.getAs[String]("variable")
          ).asJava
        case r if r.schema == StructType(Seq(
          StructField("medicalCode", StringType, nullable = true),
          StructField("medicalCodeType", StringType, nullable = true),
          StructField("sequenceNumber", IntegerType, nullable = true)
        )) =>
          Map(
            "medicalCode" -> r.getAs[String]("medicalCode"),
            "medicalCodeType" -> r.getAs[String]("medicalCodeType"),
            "sequenceNumber" -> r.getAs[String]("sequenceNumber")
          ).asJava
        case r => r
      }.asJava
      gson.toJson(retValue)
    }
  }

  private def executeQuery(sql: String): Boolean = {
    val connection: Connection = DriverManager.getConnection(url, connectionProperties)
    val statement: Statement = connection.createStatement()
    try {
      statement.execute(sql)
    } catch {
      case e: Exception =>
        statement.close()
        connection.close()
        throw e
    }
  }

  private def executeSQL(sql: String) = {
    val connection: Connection = DriverManager.getConnection(url, connectionProperties)
    val statement: Statement = connection.createStatement()
    try {
      statement.executeQuery(sql)
    } catch {
      case e: Exception =>
        logger.info(s"Executing using hostname: ${connection.getMetaData.getURL.split("\\?").head}")
        logger.info(s"Executing against redshift schema, ${connection.getSchema}, on failure")
        statement.close()
        connection.close()
        throw e
    }
  }

  override def savePersonsAndActivities(persons: Dataset[Person], personActivities: Dataset[Activity]): Unit = {
    savePersons(persons)
    saveActivities(personActivities)
  }

  override def deleteEpdbListPersons(customer: String): Unit = {
    val sql =
      s""" DELETE FROM $postgresSchema.$EpdbListPersonsTable WHERE customer = '$customer'  """.stripMargin

    executeQuery(sql)
  }

  override def deleteDoNotSolicitEmails(customer: String): Unit = {
    val sql =
      s""" DELETE FROM $postgresSchema.$DoNotSolicitEmailsTable WHERE customer = '$customer'  """.stripMargin

    executeQuery(sql)
  }

  override def deleteCustomersPersons(customer: String): Unit = {
    val sql =
      s""" DELETE FROM $postgresSchema.$PersonsTable WHERE customer = '$customer'  """.stripMargin

    executeQuery(sql)
  }

  override def deleteCustomersPersonArchives(customer: String): Unit = {
    val sql =
      s""" DELETE FROM $postgresSchema.$PersonArchivesTable WHERE customer = '$customer'  """.stripMargin

    executeQuery(sql)
  }

  override def deleteCustomersCollapseHistory(customer: String): Unit = {
    val sql =
      s""" DELETE FROM $postgresSchema.$CollapseHistoryTable WHERE customer = '$customer'  """.stripMargin

    executeQuery(sql)
  }

  override def deleteCustomersAddresses(customer: String): Unit = {
    val sql =
      s""" DELETE FROM $postgresSchema.$DoNotSolicitEmailsTable WHERE customer = '$customer'  """.stripMargin

    executeQuery(sql)
  }

  override def deleteCustomersActivities(customer: String): Unit = {
    val sql =
      s""" DELETE FROM $postgresSchema.$ActivitiesTable WHERE customer = '$customer'  """.stripMargin

    executeQuery(sql)
  }

  override def truncateDB(): Unit = {
    val sql =
      s""" TRUNCATE TABLE $postgresSchema.$ActivitiesTable, $postgresSchema.$PersonsTable CASCADE""".stripMargin

    executeQuery(sql)
  }

  override def deleteCustomersUnidentifiedActivities(customer: String): Unit = {
    val sql =
      s""" DELETE FROM $postgresSchema.$UnidentifiableActivities WHERE customer = '$customer'  """.stripMargin

    executeQuery(sql)
  }

  def vacuumDB() = {
    val sql = ""
  }

  override def collapsePersons(persons: Dataset[Person], deletedPersons: Dataset[Person]): Unit = ???

  override def getAddressesByCustomer(customer: String): Dataset[Address] = {
    sparkSession.read.
      option("user", postgresUser).
      option("password", postgresPassword).
      jdbc(url, s"$postgresSchema.$AddressesTable", connectionProperties).
      where($"customer" === customer).
      transform(aliasColumnsToCamelCase).
      map(Address.buildFromRow)
  }

  override def getPersonArchivesByCustomer(customer: String): Dataset[Person] = {
    val sqlQuery =
      s"""
         |(
         |  SELECT *
         |  FROM $postgresSchema.$PersonArchivesTable
         |  WHERE customer = '$customer'
         |)persons""".stripMargin


    sparkSession.read.
      option("user", postgresUser).
      option("password", postgresPassword).
      jdbc(url,
        sqlQuery,
        connectionProperties).
      transform(aliasColumnsToCamelCase).
      map(Person.buildPersonFromRow)
  }

  override def getCollapseHistory(customer: String): Dataset[CollapseHistory] = {
    val sqlQuery =
      s"""
         |(
         |  SELECT *
         |  FROM $postgresSchema.$CollapseHistoryTable
         |  WHERE customer = '$customer'
         |)collapse_history""".stripMargin


  sparkSession.read.
    option("user", postgresUser).
    option("password", postgresPassword).
    jdbc(url,
      sqlQuery,
      connectionProperties).
    transform(aliasColumnsToCamelCase).
    map(CollapseHistory.buildFromRow)
}

  override def saveJobHistory(dataset: Dataset[JobHistory]): Unit = {
    saveTable(dataset, JobHistoryTable)
  }

  override def searchJobHistoryByBatchId(batchId: String): List[JobHistory] = {
    val sql =
      s"""
         |SELECT *
         |FROM $postgresSchema.$JobHistoryTable
         |WHERE batch_id = '$batchId'
         |ORDER BY time_finished ASC;
      """.stripMargin

    val resultSet: ResultSet = executeSQL(sql)
    val jobHistoryRecords: ListBuffer[JobHistory] = ListBuffer()

    if (resultSet.next()) {
      jobHistoryRecords +=
        JobHistory(resultSet.getString("customer"),
          Some(resultSet.getString("activity_type")),
          Some(resultSet.getString("batch_id")),
          Some(resultSet.getDate("since_date")),
          resultSet.getString("job_type"),
          resultSet.getString("job_command"),
          Some(resultSet.getString("input_file")),
          resultSet.getTimestamp("time_started"),
          resultSet.getTimestamp("time_finished"),
          resultSet.getString("user"),
          Some(resultSet.getInt("number_of_input_records")),
          Some(resultSet.getInt("number_of_updated_records")),
          resultSet.getString("job_status"))
    }

    jobHistoryRecords.toList
  }

  override def saveIdentifiedLeads(matchedLeads: Dataset[IdentifiedLead]): Unit = {


    val customer: String = matchedLeads.head.customer
    // val deletePreaction = s"delete from %s where customer_key = '$customer'"
    transactionalOverwriteTable(
      matchedLeads, "leads", s"unlogged_leads_${customer}_${LocalDate.now.toEpochDay}", "person_id")
  }

  def transactionalOverwriteTable[T](
                                      dataset: Dataset[T],
                                      table: String,
                                      unloggedTable: String,
                                      primaryKey: String
                                    ): Unit = {

    val createQuery =
      s""" CREATE UNLOGGED TABLE $postgresSchema.$unloggedTable (like $postgresSchema.$table)""".stripMargin

    executeQuery(createQuery)

    saveTable(dataset, unloggedTable)

    val columns = dataset.toDF().transform(prepComplexTypesForSave).transform(aliasColumnsToSnakeCase).columns
    // TODO Migration: Check if the dataset columns matches the table columns

    val tableConstraints: Seq[PostgresConstraint] = getConstraints(table)

    val createUnloggedTablePrimaryConstraintsQueries: Seq[String] = tableConstraints
      .filter(c => c.tableName == table && c.constraintType == "p")
      .map { c =>
        s"""
           |ALTER TABLE
           |  $postgresSchema.$unloggedTable
           |ADD CONSTRAINT ${unloggedTable}_${c.constraintName} ${c.constraintDefinition}""".stripMargin
      }

    val createUnloggedTableForeignConstraintsQueries: Seq[String] = tableConstraints
      .filter(c => c.tableName == table && c.constraintType == "f")
      .map { c =>
        s"""
           |ALTER TABLE
           |  $postgresSchema.$unloggedTable
           |ADD CONSTRAINT ${unloggedTable}_${c.constraintName} ${c.constraintDefinition}
           |""".stripMargin
      }

    val upsertQuery: Seq[String] = Seq(
      s"""
          with "insert_persons" as (
            SELECT ${columns.mkString(" ,")} FROM $postgresSchema.$unloggedTable
          )
          INSERT INTO $postgresSchema.$table (${columns.mkString(", ")})
            SELECT ${columns.mkString(" ,")} FROM insert_persons
          ON CONFLICT ($primaryKey) DO UPDATE
          SET ${columns.filter(c => c != "customer" && c != primaryKey).map(c => s"$c = excluded.$c").mkString(" ,")}
          """.stripMargin)

    val dropUnloggedTableQuery: Seq[String] = Seq(
      s""" DROP TABLE $postgresSchema.$unloggedTable""".stripMargin
    )

    executeQueries(
      Seq(
        createUnloggedTablePrimaryConstraintsQueries,
        createUnloggedTableForeignConstraintsQueries,
        upsertQuery,
        dropUnloggedTableQuery
      ).filter(_.nonEmpty).flatten: _*)

  }

  override def getPersonsUpdatedSince(since: LocalDate, customer: String, full: Boolean = true): Dataset[Person] = {
    val dateTimeFormatter = DateTimeFormatter.ISO_LOCAL_DATE
    val dateTimeString = dateTimeFormatter.format(since)
    val sqlQuery =
      s"""
         |(
         |  SELECT $postgresSchema.$PersonsTable.*, null as activities
         |  FROM $postgresSchema.$PersonsTable
         |  JOIN (
         |          SELECT DISTINCT person_id
         |          FROM $postgresSchema.$ActivitiesTable
         |          WHERE $postgresSchema.$ActivitiesTable.date_modified >= '$dateTimeString' AND
         |                $postgresSchema.$ActivitiesTable.customer = '$customer'
         |       ) as A
         |            ON $postgresSchema.$PersonsTable.person_id = A.person_id
         |  ORDER BY date_created ASC
         |) persons""".stripMargin


    val persons = sparkSession.read.
      option("user", postgresUser).
      option("password", postgresPassword).
      jdbc(url,
        sqlQuery,
        connectionProperties).
      transform(aliasColumnsToCamelCase).
      map(Person.buildPersonFromRow)

    if (full) {
      val groupedActivities: Dataset[(String, Seq[Activity])] = getActivitiesRelatedToUpdatedSince(since, customer).
        groupByKey(a => a.personId.get).mapGroups { (personId: String, activites: Iterator[Activity]) =>
        (personId, activites.toSeq)
      }
      persons.
        joinWith(groupedActivities, persons("personId") === groupedActivities("_1"), "left").
        map { case (person, activities) =>
          person.copy(activities = Option(activities).map(_._2).getOrElse(Seq.empty))
        }

    } else {
      persons
    }
  }

  override def getDoNotSolicitEmailsByCustomer(customer: String): Dataset[DoNotSolicitEmail] = {
    val sqlQuery =
      s"""
         |(
         |  SELECT *
         |  FROM $postgresSchema.$DoNotSolicitEmailsTable
         |  WHERE customer = '$customer'
         |) emails""".stripMargin

    sparkSession.read.
      option("user", postgresUser).
      option("password", postgresPassword).
      jdbc(url,
        sqlQuery,
        connectionProperties).
      transform(aliasColumnsToCamelCase).
      map(DoNotSolicitEmail.buildDoNotSolicitEmailsFromRow)
  }

  override def getDoNotSolicitEmailsByBatchId(customer: String, batchId: String): Dataset[DoNotSolicitEmail] = {
    val sqlQuery =
      s"""
         |(
         |  SELECT *
         |  FROM $postgresSchema.$DoNotSolicitEmailsTable
         |  WHERE customer = '$customer' AND batch_id = '$batchId'
         |)emails""".stripMargin

    sparkSession.read.
      option("user", postgresUser).
      option("password", postgresPassword).
      jdbc(url,
        sqlQuery,
        connectionProperties).
      transform(aliasColumnsToCamelCase).
      map(DoNotSolicitEmail.buildDoNotSolicitEmailsFromRow)
  }

  def getDatabaseTableColumnNames(tableName: String): Seq[String] = {

    val sqlQuery =
      s"""
         |SELECT column_name
         |FROM information_schema.columns
         |WHERE table_schema = '$postgresSchema'
         |  AND table_name   = '$tableName'
    """.stripMargin

    val resultSet = executeSQL(sqlQuery)

    def resultSetToList(resultSet: ResultSet, seq: Seq[String] = Seq.empty): Seq[String] = {
      if (resultSet.next()) {
        resultSet.getString("column_name") +: resultSetToList(resultSet, seq)
      } else {
        seq
      }
    }

    resultSetToList(resultSet)

  }

  /**
    * Executes a string of sql queries as a transaction
    *
    * @param sqlQueries list of sql queries to execute as part of a transaction
    */
  def executeQueries(sqlQueries: String*): Unit = {

    val connection: Connection = DriverManager.getConnection(url, connectionProperties)
    connection.setAutoCommit(false)

    val rollbackPoint = connection.setSavepoint()
    val statement: Statement = connection.createStatement()
    sqlQueries.foreach(statement.addBatch)
    try {

      statement.executeBatch()
      connection.commit()
    } catch {
      case e: Exception =>
        statement.close()
        connection.rollback(rollbackPoint)
        connection.close()
        throw e
    }
  }

  override def getActivitiesRelatedToUpdatedSince(since: LocalDate, customer: String): Dataset[Activity] = {
    val dateTimeFormatter = DateTimeFormatter.ISO_LOCAL_DATE
    val dateTimeString = dateTimeFormatter.format(since)
    val sqlQuery =
      s"""
         |(
         |  SELECT *
         |  FROM $postgresSchema.$ActivitiesTable
         |  WHERE $postgresSchema.$ActivitiesTable.person_id IN (SELECT DISTINCT person_id
         |                                       FROM $postgresSchema.$ActivitiesTable
         |                                       WHERE $postgresSchema.$ActivitiesTable.date_modified >= '$dateTimeString' AND
         |                                             $postgresSchema.$ActivitiesTable.customer = '$customer')
         |) activities
      """.stripMargin

    sparkSession.read.
      option("user", postgresUser).
      option("password", postgresPassword).
      jdbc(url,
        sqlQuery,
        connectionProperties).
      transform(aliasColumnsToCamelCase).
      map(Activity.buildFromRow)
  }

  override def getActivitiesRelatedToBatchUpdate(batchId: String): Dataset[Activity] = {
    val sqlQuery =
      s"""
         |(
         |  SELECT *
         |  FROM $postgresSchema.$ActivitiesTable
         |  WHERE $postgresSchema.$ActivitiesTable.person_id IN (SELECT DISTINCT person_id
         |                                       FROM $postgresSchema.$ActivitiesTable
         |                                       WHERE $postgresSchema.$ActivitiesTable.batch_id = '$batchId')
         |) activities
      """.stripMargin

    sparkSession.read.
      option("user", postgresUser).
      option("password", postgresPassword).
      jdbc(url,
        sqlQuery,
        connectionProperties).
      transform(aliasColumnsToCamelCase).
      map(Activity.buildFromRow)
  }

  override def saveDoNotSolicitEmails(dnsemails: Dataset[DoNotSolicitEmail]): Unit = {
    transactionalSaveTable(dnsemails, DoNotSolicitEmailsTable,
      s"unlogged_${DoNotSolicitEmailsTable}_${System.currentTimeMillis()}", "email"
    )
  }
}
