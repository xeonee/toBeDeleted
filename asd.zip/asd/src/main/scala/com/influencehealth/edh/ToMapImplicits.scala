package com.influencehealth.edh

import com.influencehealth.edh.model.{Activity, Person}


object ToMapImplicits {

  def personToMap(person: Person): Map[String, Any] = {
    val fieldNames = person.getClass.getDeclaredFields.map(_.getName)
    val vals = person.productIterator.toSeq
    fieldNames.zip(vals).toMap map {
      case (k, Some(v)) => k -> v
      case (k, None) => k -> null
      case (k, v) => k -> v
    }
  }

  def activityToMap(activity: Activity): Map[String, Any] = {
    val fieldNames = activity.getClass.getDeclaredFields.map(_.getName)
    val vals: Seq[Any] = activity.productIterator.toSeq
    fieldNames.zip(vals).toMap map {
      case (k, Some(v)) => k -> v
      case (k, None) => k -> null
      case (k, v) => k -> v
    }
  }

}