package com.influencehealth.edh.utils

import java.io.{File, IOException}
import java.net.URI
import java.nio.file.Paths
import java.text.SimpleDateFormat

import com.influencehealth.edh.implicits._
import com.influencehealth.edh.{CustomLazyLogging, Constants}
import org.apache.commons.io.FileUtils
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs._
import org.apache.hadoop.io.IOUtils
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

import scala.collection.mutable.ArrayBuffer


object FileUtilities extends CustomLazyLogging {

  val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss")


  def merge(srcPath: String, dstPath: String): Unit = {
    val hadoopConfig = new Configuration()
    val hdfs = FileSystem.get(hadoopConfig)
    FileUtil.copyMerge(hdfs, new Path(srcPath), hdfs, new Path(dstPath), true, hadoopConfig, null)
  }

  /**
    * Merges temp part files into an output file in S3
    *
    * @param srcPath
    * @param dstPath
    * @param s3BucketPath
    * @param conf
    * @param headerRow
    */
  def mergeS3(srcPath: String, dstPath: String, s3BucketPath: String, conf: Configuration =
  new Configuration(), headerRow: String): Unit = {

    val fileSystem = FileSystem.get(new URI(s3BucketPath), conf)

    fileSystem.delete(new Path(dstPath), false)

    copyMergeWithHeader(fileSystem, new Path(srcPath), fileSystem, new Path(dstPath), true, conf, headerRow)
  }

  /**
    * copyMergeWithHeader method is similar to the copyMerge in FileUtil, however we have introduced new method
    * to include header record while merging the temp files
    *
    * @param srcFS        temporary path where the partitioned files are written by spark
    * @param srcDir       source Directory
    * @param dstFS        destination File System
    * @param dstFile      destination file path
    * @param deleteSource if the deleteSource, it will delete the sourceDirectory
    * @param conf         configuration details
    * @param header       which can be added to the output file if the header is non empty
    */
  def copyMergeWithHeader(srcFS: FileSystem,
                          srcDir: Path,
                          dstFS: FileSystem,
                          dstFile: Path,
                          deleteSource: Boolean,
                          conf: Configuration,
                          header: String): Unit = {
    val dstFilePath = checkDest(srcDir.getName, dstFS, dstFile, false)
    if (srcFS.getFileStatus(srcDir).isDirectory) {
      val out: FSDataOutputStream = dstFS.create(dstFilePath)
      if (header.nonEmpty) {
        out.write((header + "\n").getBytes("UTF-8"))
      }
      try {
        val contents: Array[FileStatus] = srcFS.listStatus(srcDir)
        for (i <- 0 until contents.length if !contents(i).isDirectory) {
          val in: FSDataInputStream = srcFS.open(contents(i).getPath)
          try IOUtils.copyBytes(in, out, conf, false)
          finally in.close()
        }
      } finally out.close()
      if (deleteSource) srcFS.delete(srcDir, true)
    }
  }

  /**
    * This method is to validate the destination, while saving error output file. which is invoked by
    * copyMergeWithHeader and returns the destination path
    *
    * @param srcName   sourceDirectory name
    * @param dstFS     destination File System
    * @param dst       destination path
    * @param overwrite overwrite true or false
    */
  private def checkDest(srcName: String,
                        dstFS: FileSystem,
                        dst: Path,
                        overwrite: Boolean): Path = {
    if (dstFS.exists(dst)) {
      val sdst: FileStatus = dstFS.getFileStatus(dst)
      if (sdst.isDirectory) {
        if (null == srcName) {
          throw new IOException("Target " + dst + " is a directory")
        }
        checkDest(null.asInstanceOf[String],
          dstFS,
          new Path(dst, srcName),
          overwrite)
      }
      if (!overwrite) {
        throw new IOException("Target " + dst + " already exists")
      }
    }
    dst
  }

  def zip(out: String, files: Iterable[String]) = {
    import java.io.{BufferedInputStream, FileInputStream, FileOutputStream}
    import java.util.zip.{ZipEntry, ZipOutputStream}

    val outputFile = new File(out)
    val outputParent = new File(outputFile.getParent)

    if (!outputParent.isDirectory || !outputParent.exists) outputParent.mkdirs

    val zip = new ZipOutputStream(new FileOutputStream(out))

    files.foreach { name =>
      zip.putNextEntry(new ZipEntry(name))
      val in = new BufferedInputStream(new FileInputStream(name))
      var b = in.read()
      while (b > -1) {
        zip.write(b)
        b = in.read()
      }
      in.close()
      zip.closeEntry()
    }
    zip.close()
  }

  /**
    * Moves files from inputPath to outputPath and renames them with the passed in timeStamp. This was copied over
    * from our cleanse/intake process so it could be reused. It automatically excludes .crc and _SUCCESS Files.
    *
    * @param inputPath     the path of input files
    * @param outputPath    the path to move the files in the inputPath
    * @param inputFileName used in renaming the files as they are moved to the outputPath
    * @return Array of String that contains the filenames of the files that were moved
    */
  def moveFiles(inputPath: String, outputPath: String, inputFileName: String): Array[String] = {
    val now = Constants.Today.toTimestampStr.replace("-", "").replace(":", "")
    val directory = new File(inputPath)
    var fileNamesArray = ArrayBuffer[String]()
    directory.listFiles()
      .filter(x => !x.getName.endsWith(".crc") && !x.getName.equalsIgnoreCase("_SUCCESS"))
      .zipWithIndex.foreach { case (file, index) => {
      val fileName = s"${outputPath}_file${inputFileName.replace("_", "")}-part$index-$now.txt"
      fileNamesArray += fileName
      FileUtils.moveFile(file, new File(fileName))
    }
    }

    fileNamesArray.toArray
  }


  /**
    * Writes a anchor file. This assumes the dataframe is already padded to 100 records.
    * No schema is enforced with this method. Each field of the dataframe represents a field in the file.
    *
    * @param sparkSession   sparkSession for functions and padding
    * @param outputPath     the path that the anchor file will ultimately reside in when the process finishes
    * @param tempPath       the temporary path to use when creating the files. We first write to temp files and then
    *                       move the files to outputPath as logical transaction so that some files arent picked up
    *                       before they are finished writing
    * @param fileNamePrefix the prefix to append to the output files
    * @param data           the input data frame to be written
    * @param fileCount      how many files to coalesce the data over
    * @param fileName       fileName
    */
  def writeMinimalAnchorFile(
                              sparkSession: SparkSession,
                              outputPath: String,
                              tempPath: String,
                              fileNamePrefix: String,
                              data: DataFrame,
                              fileCount: Int,
                              fileName: String
                            ): Unit = {

    logger.info("Creating file for Anchor: " + fileName)

    val outputFilePath = Paths.get(outputPath, fileName).toFile.getCanonicalPath
    val tempFilePath = Paths.get(tempPath, fileName).toFile.getCanonicalPath
    val outputCrcFile = Paths.get(outputPath, s".$fileName.crc").toFile.getCanonicalFile

    logger.info("Creating file for Anchor Processing: " + outputFilePath)

    data.write
      .option("header", "false")
      .option("delimiter", "|")
      .option("quote", null)
      .csv(tempFilePath)

    FileUtilities.merge(tempFilePath, outputFilePath)
    outputCrcFile.delete()
    FileUtils.deleteDirectory(new File(tempFilePath))
  }

  /**
    * Writes a care groupers file. This assumes the dataframe is already padded to 100 records.
    * No schema is enforced with this method. Each field of the dataframe represents a field in the file.
    *
    * @param sparkSession   sparkSession for functions and padding
    * @param outputPath     the path that the anchor file will ultimately reside in when the process finishes
    * @param tempPath       the temporary path to use when creating the files. We first write to temp files and then
    *                       move the files to outputPath as logical transaction so that some files arent picked up
    *                       before they are finished writing
    * @param fileNamePrefix the prefix to append to the output files
    * @param data           the input data frame to be written
    * @param customer       the customer (from lookups) that this data belongs to
    */
  def writeCareGrouperFile(
                            outputPath: String,
                            tempPath: String,
                            fileNamePrefix: String,
                            data: DataFrame,
                            customer: String,
                            fileType: String,
                            fileName: String
                          ) {

    logger.info(s"Creating file careGrouper file for $fileType : " + fileName)

    val outputFilePath = Paths.get(outputPath, fileName).toFile.getCanonicalPath
    val tempFilePath = Paths.get(tempPath, fileName).toFile.getCanonicalPath
    val outputCrcFile = Paths.get(outputPath, s".$fileName.crc").toFile.getCanonicalFile

    logger.info("Creating file: " + outputFilePath)

    data.write
      .option("header", "true")
      .option("delimiter", "|")
      .csv(tempFilePath)

    FileUtilities.merge(tempFilePath, outputFilePath)
    outputCrcFile.delete()
    FileUtils.deleteDirectory(new File(tempFilePath))

  }

  /**
    *
    * @param sparkSession - SparkSession object
    * @param filePath     - Path to file on local filesystem, s3, HDFS
    * @param delimiter    - Delimiter used to parse the file
    * @param schema       - Schema to apply to file after parsed in by SparkSession
    * @return - DataFrame containing file at provided file path, parsed using delimiter, with schema applied to it
    */
  def readDelimitedFile(
                         sparkSession: SparkSession,
                         filePath: String,
                         delimiter: String,
                         schema: StructType
                       ): DataFrame = {
    sparkSession
      .read
      .format("csv")
      .option("delimiter", delimiter)
      .option("header", "false")
      .schema(schema)
      .load(filePath)
  }

  /**
    * Saves data to S3 in one file
    *
    * @param sparkSession
    * @param sampledData      sampled data frame which needs to be saved.
    * @param delimiter
    * @param outputFile       The required filename for output files
    * @param outputFolderPath The required output folder path
    * @return nothing
    */
  def saveCsvToS3(
                   sparkSession: SparkSession,
                   sampledData: DataFrame,
                   delimiter: String,
                   outputFile: String,
                   outputFolderPath: String,
                   isHeader: Boolean
                 ): String = {

    val outputDirectory: String = outputFolderPath.replace(" ", "-").concat("/")

    val outputFolderTempName: String = outputDirectory.concat("temp/")
    val tempPartitioningFilesPath = outputFolderTempName.concat(outputFile).concat(".csv")
    val completeOutputFilePath = outputDirectory.concat(outputFile.toLowerCase()).concat(".csv").toLowerCase()
    val crcFilesPath = outputDirectory.concat(".").concat(outputFile).concat(".csv.crc") // generated after merging

    val headerRow = sampledData.columns.mkString(",")

    sampledData.write.mode("overwrite").
      option("header", "false").
      option("quote", null).
      option("delimiter", delimiter).
      csv(tempPartitioningFilesPath)

    saveFile(sparkSession, outputFolderPath,
      tempPartitioningFilesPath, completeOutputFilePath, outputFile, crcFilesPath, headerRow)

    completeOutputFilePath
  }

  def saveParquetToS3(
                       sparkSession: SparkSession,
                       data: DataFrame,
                       outputFile: String,
                       outputFolderPath: String,
                       maxParquetPartitions: Int,
                       executorCores: Int
                     ): String = {
    val outputDirectory: String = outputFolderPath.replace(" ", "-").concat("/")
    val completeOutputFilePath = outputDirectory.concat(outputFile.toLowerCase()).concat(".parquet").toLowerCase()

    val rePartitionedMappedDataFrame =
      SparkOptimizer.repartitionDataFrames(data, maxParquetPartitions, executorCores)
    rePartitionedMappedDataFrame.write.mode(SaveMode.Overwrite).parquet(completeOutputFilePath)

    completeOutputFilePath
  }


  /**
    * merges the temp file to produce one output file
    * Deletes the .crc files & temp files
    *
    * @param sparkSession
    * @param outputFolderPath             Path to save the output folder path for distinguishing between S3 & fileSystem
    * @param tempPartitionedFilesPath     temporary path where the partitioned files are written by spark
    *                                     (deletes these files after merge)
    * @param outputFolderWithFileNamePath (output folder directory path + output file name + file extension)
    *                                     for the output file
    * @param outputFileName               output file name for logger
    * @param crcFilesPath                 output crc path generated while merging files. (deletes these files)
    * @return nothing
    */
  private def saveFile(
                        sparkSession: SparkSession,
                        outputFolderPath: String,
                        tempPartitionedFilesPath: String,
                        outputFolderWithFileNamePath: String,
                        outputFileName: String,
                        crcFilesPath: String,
                        headerRow: String
                      ): Unit = {

    if (outputFolderPath.startsWith("s3a://") || outputFolderPath.startsWith("s3n://")) {
      // merges the temp file to produce output file
      FileUtilities.mergeS3(tempPartitionedFilesPath, outputFolderWithFileNamePath,
        outputFolderPath, sparkSession.sparkContext.hadoopConfiguration, headerRow)

      logger.info(s"Saved $outputFileName file to location: " + outputFolderWithFileNamePath)

      // Deletes the .crc files
      FileSystem.get(new URI(outputFolderPath),
        sparkSession.sparkContext.hadoopConfiguration).delete(new Path(crcFilesPath), true)
      // Deletes the temp files
      FileSystem.get(new URI(outputFolderPath),
        sparkSession.sparkContext.hadoopConfiguration).delete(new Path(tempPartitionedFilesPath), true)
    }
    else {
      // merges the temp file to produce output file
      FileUtilities.merge(tempPartitionedFilesPath, outputFolderWithFileNamePath)
      // Deletes the .crc files
      new File(crcFilesPath).delete()
      // Deletes the temp files
      FileUtils.deleteDirectory(new File(tempPartitionedFilesPath))
    }
  }

  /**
    * Gets a list of file names with specified file extension present in a directory
    *
    * @param directory
    * @param fileExtension
    * @return
    */
  def getListOfFileNames(directory: String, fileExtension: String): List[String] = {
    var listOfFileNames: List[String] = List()
    val d = new File(directory)
    if (d.exists && d.isDirectory) {
      val list: List[File] = d.listFiles.filter(_.isFile).toList
      list.foreach(x => {
        if (x.getName.contains(fileExtension)) {
          listOfFileNames = listOfFileNames :+ directory.concat(x.getName)
        }
      })
      listOfFileNames
    } else {
      List[String]()
    }
  }

}
