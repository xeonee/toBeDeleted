package com.influencehealth.edh.model.crosswalk

import com.influencehealth.edh.Constants

case class Sex(
                sourceSex: String,
                sex: String
              ) extends Serializable

object Sex {

  val sexCw: Seq[Sex] = Seq(
    Sex("m", Constants.SexMale),
    Sex("f", Constants.SexFemale),
    Sex("male", Constants.SexMale),
    Sex("female", Constants.SexFemale),
    Sex("U", Constants.UNKNOWN)
  )

}

case class SexCwCreationException(exc: Throwable)
  extends Exception("Unable to create sex crosswalk", exc)

case class InvalidSexValue(value: String)
  extends Exception(s"The following value does not match any standard sex value: '$value'")