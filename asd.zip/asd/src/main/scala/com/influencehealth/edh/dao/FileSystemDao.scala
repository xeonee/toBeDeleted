package com.influencehealth.edh.dao

import java.time.LocalDate

import com.influencehealth.edh.config.CleanseJobConfig
import com.influencehealth.edh.model.Activity
import com.influencehealth.edh.model.schema.HraSchema
import com.influencehealth.edh.utils.filesystem.PathInfo
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, Dataset, SaveMode}

import scala.collection.mutable

sealed trait FileType extends Serializable


sealed trait EncounterFileType extends FileType

object DemographicFile extends EncounterFileType

object DiagnosisFile extends EncounterFileType

object CurrentProceduralTerminologyFile extends EncounterFileType

object FacilityFile extends EncounterFileType

object VisitFile extends EncounterFileType

object PrognosisFile extends EncounterFileType

object GuarantorFile extends EncounterFileType

object BiometricFile extends EncounterFileType

object PhysicianFile extends EncounterFileType

object FinancialFile extends EncounterFileType

sealed trait HRAFileType extends FileType

object HRAHeaderV1 extends HRAFileType

object HRADetailV1 extends HRAFileType

object HRAHeaderV2 extends HRAFileType

object HRADetailV2 extends HRAFileType

trait FileSystemDao extends Serializable {

  val Demographic: String = "demog"
  val CurrentProceduralTerminology: String = "cpt"
  val Diagnosis: String = "dx"
  val Prognosis: String = "px"
  val Facility: String = "facility"
  val Visit: String = "visit"
  val Guarantor: String = "guarantor"
  val Biometric: String = "biometric"
  val Physician: String = "physician"
  val Financial: String = "financial"
  val DetailFile: String = "DETAIL"
  val DetailFileV2: String = "Detail"
  val CallCenter: String = "callcenter"
  val HraHeader: String = "HEADER*"
  val HraDetail: String = "DETAIL*"
  val HraHeaderV2: String = "Header**"
  val HraDetailV2: String = "Detail*"

  val FieldSizesForDeceased: Array[Int] = Array(1, 9, 20, 4, 15, 15, 1, 8, 8)

  val FieldSizesForProspect: Array[Int] = Array(10, 2, 2, 5, 4, 3, 4, 13, 28, 10, 2, 28, 4, 2, 6, 8, 4, 30, 30, 2, 1, 3,
    25, 7, 9, 10, 1, 6, 6, 1, 10, 1, 10, 10, 13, 1, 1, 2, 3, 1, 1, 1, 2, 1, 8, 1, 2, 1, 1, 1, 2, 1, 1, 1, 8, 10, 1, 15,
    1, 20, 6, 6, 5, 2, 2, 1, 2, 1, 2, 2, 1, 8, 2, 2, 3, 2, 2, 3, 2, 1, 1, 10, 1, 15, 1, 20, 6, 6, 5, 2, 2, 1, 2, 1, 2,
    2, 1, 8, 2, 2, 3, 2, 2, 3, 2, 1, 1, 10, 1, 15, 1, 20, 6, 6, 5, 2, 2, 1, 2, 1, 2, 2, 1, 8, 2, 2, 3, 2, 2, 3, 2, 1, 1,
    10, 1, 15, 1, 20, 6, 6, 5, 2, 2, 1, 2, 1, 2, 2, 1, 8, 2, 2, 3, 2, 2, 3, 2, 1, 1, 10, 1, 15, 1, 20, 6, 6, 5, 2, 2, 1,
    2, 1, 2, 2, 1, 8, 2, 2, 3, 2, 2, 3, 2, 1, 1, 10, 1, 15, 1, 20, 6, 6, 5, 2, 2, 1, 2, 1, 2, 2, 1, 8, 2, 2, 3, 2, 2, 3,
    2, 1, 14, 1, 17, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 4, 8, 4, 4, 2,
    12, 7, 4, 3, 1, 4, 1, 1, 1, 1, 1, 6, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 7, 3, 3, 1, 1, 2, 1, 3, 4, 27, 58, 5, 1, 3,
    2, 2, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 7, 4, 4, 4, 4, 4, 4, 4, 4, 4, 3, 4, 4, 4, 4, 4, 4, 7, 4,
    2, 4, 4, 4, 1, 1, 6)

  val ListOfRequiredFilesForHra: List[(HRAFileType, String, StructType)] = List(
    (HRAHeaderV1, "*HEADER", HraSchema.hraHeaderSchema),
    (HRADetailV1, "*DETAIL", HraSchema.hraDetailSchema))

  val ListOfRequiredFilesForHealthwareHra: List[(HRAFileType, String, StructType)] = List(
    (HRAHeaderV2, "*Header", HraSchema.hraHeaderV2Schema),
    (HRADetailV2, "*Detail", HraSchema.hraDetailV2Schema))

  def saveParquetFile(
                       dataFrame: DataFrame,
                       outputPath: String,
                       maxParquetPartitions: Int,
                       executorCores: Int ,
                       saveMode: SaveMode // ,
                       // partitioningColumns: String*
                     ): Unit

  def saveCSVFile(dataFrame: DataFrame, outputPath: String, delimiter: String): Unit

  def loadCSVFile(force: Boolean, schema: StructType, delimiter: String, paths: String*): DataFrame

  def loadFixedWidthFile(force: Boolean, schema: StructType, fieldSizes: Array[Int], paths: String*): DataFrame

  def readHRAFile(force: Boolean, format: String, paths: String*): Map[HRAFileType, DataFrame]

  def readDeceasedFile(force: Boolean, paths: String*): DataFrame

  def readDoNotSolicitFile(force: Boolean, paths: String*): DataFrame

  def readDoNotSolicitUpdateFile(force: Boolean, paths: String*): DataFrame

  def readDonorListFile(force: Boolean, paths: String*): DataFrame

  def readEmployeeRosterFile(force: Boolean, paths: String*): DataFrame

  def readMarketingListFile(force: Boolean, paths: String*): DataFrame

  def readProspectFile(force: Boolean, paths: String*): DataFrame

  def readNewMoverFile(force: Boolean, paths: String*): DataFrame

  def readReferralFile(force: Boolean, paths: String*): DataFrame

  def readCallCenterFile(force: Boolean, format: String, paths: String*): DataFrame

  def readEncounterFiles(force: Boolean, paths: String*): Map[EncounterFileType, DataFrame]

  def saveErrorFile(dataFrame: DataFrame, path: String): Unit

  def saveCleansedFile(dataFrame: DataFrame, path: String): Unit

  def readCleansedFile(paths: String*): Dataset[Activity]

  def filterBasicHeaderRows(dataFrame: DataFrame, columnNames: String*): DataFrame = {
    import dataFrame.sparkSession.implicits._
    import org.apache.spark.sql.functions._
    columnNames.foldLeft(dataFrame) { case (df, columnName) =>
      df.filter(
        upper(regexp_replace($"$columnName", "[^a-zA-Z0-9]", "")) =!= columnName.toUpperCase)

    }
  }

  def hasFileBeenProcessed(pathInfo: PathInfo): Boolean

  def getInputFolderPaths(cleanseJobConfig: CleanseJobConfig): List[String]

  def deleteFiles(path: String): Unit

  def getAllFilesInSearchPath(dateRanges: IndexedSeq[LocalDate], pathInfo: PathInfo): List[String]

  def getAllFilesInSearchPath(pathInfo: PathInfo): mutable.Buffer[String]

  def isFilePresentInTheFolder(inputDirectoryPath: String): Boolean

}
