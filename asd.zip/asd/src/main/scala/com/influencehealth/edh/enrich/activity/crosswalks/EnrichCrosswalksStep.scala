package com.influencehealth.edh.enrich.activity.crosswalks

import com.influencehealth.edh.config.EnrichJobConfig
import com.influencehealth.edh.{Constants, ProspectConstants}
import com.influencehealth.edh.dataframe.columns._
import com.influencehealth.edh.enrich.ActivityEnricher
import com.influencehealth.edh.enrich.activity.crosswalks.helper.{CrosswalkData, CrosswalkDerivatives}
import com.influencehealth.edh.lookups.messages.Location
import com.influencehealth.edh.model.Activity
import com.influencehealth.edh.utils.{CleanseUtils, PersonUtils}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.BooleanType
import org.apache.spark.sql.{Dataset, SparkSession}

class EnrichCrosswalksStep(val name: String, val next: Option[ActivityEnricher])(
  implicit enrichJobConfig: EnrichJobConfig, sparkSession: SparkSession)
  extends ActivityEnricher {

  override def enrich(ds: Dataset[Activity]): Dataset[Activity] = {
    val crosswalkDataContext: CrosswalkData =
      CrosswalkData(sparkSession: SparkSession)

    val crosswalkDerivatives = CrosswalkDerivatives(crosswalkDataContext)

    import sparkSession.implicits._

    ds
      .withColumn(SourceType, upper(crosswalkDerivatives.sourceType(lower(col(SourceType)))))
      .withColumn(PatientType, upper(crosswalkDerivatives.patientType(
        col(SourcePatientType),
        col(Customer),
        col(Source),
        col(SourceType)))
      )
      .withColumn(IsErPatient, crosswalkDerivatives.erPatient(
        col(SourceErPatient),
        col(Customer),
        col(Source),
        col(SourceType))
      )
      .withColumn(DischargeStatus, crosswalkDerivatives.dischargeStatus(
        col(SourceDischargeStatus))
      )
      .withColumn(ExclusionFlag, crosswalkDerivatives.exclusionFlag(
        col(SourceExclusionFlag),
        col(Customer),
        col(Source),
        col(SourceType))
      )
      .withColumn(IsDeceased, crosswalkDerivatives.deceasedFlag(
        col(DischargeStatus),
        col(ExclusionFlag),
        col(DateOfDeath))
      )
      .withColumn(IsOptedOutDirectMail, crosswalkDerivatives.dnsBool(
        col(DischargeStatus),
        col(ExclusionFlag))
      )
      .withColumn(OptOutDirectMailReasons, crosswalkDerivatives.dnsReason(
        col(DischargeStatus),
        col(ExclusionFlag),
        col(ActivityDate))
      )
      .withColumn(GrossMargin, when(col(GrossMargin).isNull && col(Charges).isNotNull, crosswalkDerivatives.profitProxy(
        col(SourceFinancialClass),
        col(Customer),
        col(Source),
        col(SourceType),
        col(Charges))).otherwise(col(GrossMargin))
      )
      .withColumn(IsOptedOutCall, col(IsOptedOutDirectMail))
      .withColumn(IsOptedOutEmail, col(IsOptedOutDirectMail))
      .withColumn(IsOptedOutText, col(IsOptedOutDirectMail))
      .withColumn(OptOutCallReasons, col(OptOutDirectMailReasons))
      .withColumn(OptOutEmailReasons, col(OptOutDirectMailReasons))
      .withColumn(OptOutTextReasons, col(OptOutDirectMailReasons))
      .withColumn(IsErPatient, $"$IsErPatient".cast(BooleanType))
      .withColumn(OptOutDirectMailReasons, crosswalkDerivatives.dnsReasonFromSource(
        col(Customer),
        col(Source),
        col(SourceType),
        col(SourceDoNotSolicitReason))
      )
      .withColumn(OptOutCallReasons, col(OptOutDirectMailReasons))
      .withColumn(OptOutEmailReasons, col(OptOutDirectMailReasons))
      .withColumn(OptOutTextReasons, col(OptOutDirectMailReasons))
      .withColumn(DateModified, lit(current_timestamp()))
      .withColumn(SourceFirstName, col(FirstName))
      .withColumn(SourceMiddleName, col(MiddleName))
      .withColumn(SourceLastName, col(LastName))
      .withColumn(FirstName, upper(col(FirstName)))
      .withColumn(LastName, upper(col(LastName)))
      .withColumn(MiddleName, upper(col(MiddleName)))
      .withColumn(Email, upper(col(Email)))
      .withColumn(HomePhone, CleanseUtils.cleanse_phone_numbers(col(HomePhone)))
      .withColumn(MobilePhone, CleanseUtils.cleanse_phone_numbers(col(MobilePhone)))
      .withColumn(WorkPhone, CleanseUtils.cleanse_phone_numbers(col(WorkPhone)))
      .withColumn(BeehiveCluster, getDeriveBeehiveCluster(
        $"$SourceAge",
        $"$Education",
        $"$MaritalStatus",
        $"$Occupation",
        $"$LastName",
        $"$HouseholdIncome",
        $"$IsChildPresent"))
      .withColumn(InferredPayerType, deriveInferredPayerType(col(BeehiveCluster), col(SourceAge)))
      .withColumn(FinancialClass,
        when(col(ActivityType).equalTo(Constants.ProspectActivityType),
          deriveFinancialClass(col(BeehiveCluster), col(SourceAge)))
        otherwise crosswalkDerivatives.financialClass(
          col(SourceFinancialClass),
          col(Customer),
          col(Source),
          col(SourceType)))
      .withColumn(PayerType,
        when(col(ActivityType).equalTo(Constants.ProspectActivityType),
          derivePayerType(col(BeehiveCluster), col(SourceAge)))
          otherwise upper(crosswalkDerivatives.payerType(
          col(SourceFinancialClass),
          col(Customer),
          col(Source),
          col(SourceType))))
      .withColumn(PayerTypeDescription,mapToPayerTypeDescription(col(PayerType)))
      .withColumn(LocationDesc, derive_location_name(col(LocationCode)))
      .withColumn(Sex, PersonUtils.sex(col(SourceSex)))
      .as[Activity]

  }

  val getDeriveBeehiveCluster = udf[
    Option[Int], Int, String, String, String, String, String, Boolean]((age: Int,
                                                                        education: String,
                                                                        maritalStatus: String,
                                                                        occupation: String,
                                                                        lastName: String,
                                                                        householdIncome: String,
                                                                        isChildPresent: Boolean
                                                                       ) => {
    deriveBeehiveCluster(
      Option(age),
      Option(education),
      Option(maritalStatus),
      Option(occupation),
      Option(lastName),
      Option(householdIncome),
      Option(isChildPresent))
  })

  /** Gets a Beehive code given person attributes
    *
    * @param sourceAge       Optional age value
    * @param education       Optional education value
    * @param maritalStatus   Optional marital status
    * @param occupation      Optional occupation code
    * @param lastName        Optional last name
    * @param householdIncome Optional houeshold income
    * @param presenceOfChild Optional presence of child
    * @return Option[Beehive] */
  def deriveBeehiveCluster(
                            sourceAge: Option[Int],
                            education: Option[String],
                            maritalStatus: Option[String],
                            occupation: Option[String],
                            lastName: Option[String],
                            householdIncome: Option[String],
                            isChildPresent: Option[Boolean]
                          ): Option[Int] = {

    val educationCode: Option[String] = education.
      flatMap(e => Constants.EducationMapping.find(_._2 == e).map(_._1)).
      map(e => ProspectConstants.educationCodes(e))

    val maritalStatusCode: Option[String] = maritalStatus.map(x =>
      Constants.MaritalStatusCodes.getOrElse(x.toUpperCase, "07"))

    val occupationGroupCode: Option[String] = occupation.flatMap(x =>
      ProspectConstants.occupationCodes.get(x.takeRight(1).toInt))

    val householdIncomeCode: Option[String] = householdIncome.flatMap(x =>
      ProspectConstants.incomeCodes.get(x.toUpperCase))

    val ageCode: Option[String] = sourceAge.flatMap(x =>
      ProspectConstants.ageCodes.get(x))

    val pocCode: Option[String] = isChildPresent.map {
      case true => "45"
      case _ => "44"
    }

    val ethnicCode: Option[String] = lastName.map(x =>
      ProspectConstants.lastNameCodes.getOrElse(x.toUpperCase, "34")).orElse(Some("34"))

    val allDefined: Boolean = educationCode.isDefined && maritalStatusCode.isDefined && householdIncomeCode.isDefined &&
      ageCode.isDefined && ethnicCode.isDefined && occupationGroupCode.isDefined && pocCode.isDefined

    val combinedCode: String = if (allDefined) {
      educationCode.get + maritalStatusCode.get + householdIncomeCode.get + ageCode.get + ethnicCode.get +
        occupationGroupCode.get + pocCode.get
    } else {
      ""
    }

    val beehive = ProspectConstants.combinedToCluster.get(combinedCode)

    beehive
  }


  val deriveFinancialClass = udf[Option[String], Int, Int](
    (beehiveCluster: Int, age: Int) => {
      getFinancialClass(Option(beehiveCluster), Option(age))._2
    })

  val derivePayerType = udf[Option[String], Int, Int](
    (beehiveCluster: Int, age: Int) => {
      getPayerTypeFinancialClass(Option(beehiveCluster), Option(age))._3
    })


  val deriveInferredPayerType = udf[String, Int, Int]((beehiveCluster: Int, age: Int) => {
    getFinancialClass(Option(beehiveCluster), Option(age))._3 match {
      case Some(x) => x.toUpperCase
      case None => "CD"
    }
  })

  val mapToPayerTypeDescription = udf[Option[String], String](payerType => {
    Option(payerType).flatMap(Constants.PayerTypeDescriptionMapping.get)
  })

  val upperArrayString = udf[Seq[String],Seq[String]]((stringArray:Seq[String]) => {
    stringArray.map(_.toUpperCase)
  })

  def getFinancialClass(beehive: Option[Int], age: Option[Int]): (Option[Int], Option[String], Option[String]) = {
    (age, beehive) match {
      case (Some(x), _) if x >= 65 => (Some(9930), Some(Constants.FinancialClassTargetPayerMedicare), Some(Constants.PayerTypeMedicareInferred))
      case (_, Some(x)) => Constants.BeehiveToFinancialClass.getOrElse(x, (None, None, None))
      case _ => (None, None, None)
    }
  }

  /** Return payterType based on person age and beehive or financial class
    * @param beehive beehive value
    * @param age soruceAge of person
    * @return payerType
    */
  def getPayerTypeFinancialClass(
          beehive: Option[Int], age: Option[Int]): (Option[Int], Option[String], Option[String]) = {
    (age, beehive) match {
      case (Some(x), _) if x >= 65 => (Some(9930),
            Some(Constants.FinancialClassTargetPayerMedicare), Some(Constants.PayerTypeMedicareInferredDesc))
      case (_, Some(x)) => Constants.PayerTypeBeehiveToFinancialClass.getOrElse(x, (None, None, None))
      case _ => (None, None, None)
    }
  }

  private def derive_location_name = udf((inputLocationCode: String) => {
    inputLocationCode match {
      case x if x == null || x.isEmpty => None
      case x if x.toInt >= 0 => {
        val locationdesc: Option[String] = enrichJobConfig.customerLocations.find {
          locationdesc => locationdesc.Id.equals(x.toInt)
        }.map(_.Name)
        locationdesc
      }
      case _ => None
    }
  })

}
