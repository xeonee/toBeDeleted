package com.influencehealth.edh.model.address

/**
  * The format of this class must match (field order) the Baldur_Minimal_Input layout on Anchor
  */
case class AnchorInputData( // key values
                            personId: Option[String],
                            customer: String,
                            batchId: String,
                            bucketNumber: Int,
                            source: Option[String],
                            sourceType: Option[String],
                            sourceRecordId: Option[String],
                            sourcePersonId: Option[String],
                            // required data for anchor
                            firstName: Option[String],
                            middleName: Option[String],
                            lastName: Option[String],
                            address1: Option[String],
                            address2: Option[String],
                            city: Option[String],
                            state: Option[String],
                            zip5: Option[String]
                          )

object AnchorInputData {

  def paddingRecord = AnchorInputData(
    personId = None,
    customer = "removeMe",
    batchId = "removeMe",
    bucketNumber = -1,
    source = Some("removeMe"),
    sourceType = Some("removeMe"),
    sourceRecordId = Some("-1"),
    sourcePersonId = Some("removeMe111111"),
    firstName = None,
    middleName = None,
    lastName = None,
    address1 = None,
    address2 = None,
    city = None,
    state = None,
    zip5 = Some("00000")
  )
}