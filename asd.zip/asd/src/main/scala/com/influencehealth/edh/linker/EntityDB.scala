package com.influencehealth.edh.linker

import org.apache.spark.sql.Dataset

trait EntityDB[T] {

  val MAX_ITERATION: Int

  def get(inputDF: Dataset[IdentityEntity[T]]): Dataset[IdentityEntity[T]] = {
    // implicit val classEncoder: Encoder[T] = Encoders.kryo[T]
    inputDF
  }

  def mergeCandidatesOnBlockingKeys(
                                     linkageCandidates: Dataset[IdentityEntity[T]]
                                   ): Dataset[IdentityEntity[T]]

}
