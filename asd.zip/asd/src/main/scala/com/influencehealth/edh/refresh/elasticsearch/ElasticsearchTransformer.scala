package com.influencehealth.edh.refresh.elasticsearch

import com.google.gson.{JsonElement, JsonObject}
import com.influencehealth.edh.Constants
import com.influencehealth.edh.model.{Activity, Person}
import com.typesafe.scalalogging.LazyLogging
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.{col, collect_list, struct, _}
import org.apache.spark.sql.types.{DecimalType, FloatType, StringType, StructType}
import org.apache.spark.sql.{Column, DataFrame, Dataset}

import scala.collection.JavaConverters._
import scala.collection.mutable.ListBuffer

class ElasticsearchTransformer extends LazyLogging {

  val PatientTypes = Map(
    "I" -> "INPATIENT",
    "O" -> "OUTPATIENT",
    "INPATIENT" -> "INPATIENT",
    "OUTPATIENT" -> "OUTPATIENT"
  )

  val Occupation: Map[String, String] = Map(
    "2" -> "Professional/Technical",
    "3" -> "Upper Management/Executive",
    "4" -> "Middle Management",
    "5" -> "Sales/Marketing",
    "6" -> "Clerical/Office",
    "7" -> "Skilled Trade/Machine/Laborer",
    "8" -> "Retired",
    "10" -> "Executive/Administrator",
    "11" -> "Self Employed",
    "12" -> "Professional Driver",
    "13" -> "Military",
    "14" -> "Civil Servant",
    "15" -> "Farming/Agriculture",
    "16" -> "Work from Home",
    "17" -> "Health Services",
    "18" -> "Financial Services",
    "21" -> "Teacher/Educator",
    "22" -> "Retail Sales",
    "23" -> "Computer Professional",
    "30" -> "Beauty (Cosmetologist, Barber, Manicurist, Nails)",
    "31" -> "Real Estate (Sales, Brokers, Appraisers)",
    "32" -> "Architects",
    "33" -> "Interior Designers",
    "34" -> "Landscape Architects",
    "35" -> "Electricians",
    "36" -> "Engineers",
    "37" -> "Accountants/CPA",
    "38" -> "Attorneys",
    "39" -> "Social Worker",
    "40" -> "Counselors",
    "41" -> "Occupational Therapist/Physical Therapist",
    "42" -> "Speech Pathologist/Audiologist",
    "43" -> "Psychologists",
    "44" -> "Pharmacist",
    "45" -> "Opticians/Optometrist",
    "46" -> "Veterinarian",
    "47" -> "Dentist/Dental Hygienist",
    "48" -> "Nurses",
    "49" -> "Doctors/Physicians/Surgeons",
    "50" -> "Chiropractors",
    "51" -> "Surveyors",
    "52" -> "Clergy",
    "53" -> "Insurance/Underwriters",
    "54" -> "Services/Creative"
  )

  val OccupationGroup = Map(
    "9100" -> "Management/Business and Financial Operations",
    "9105" -> "Technical: Computers/Math and Architect/Engineerin",
    "9110" -> "Professional: Legal/Education and Health Practitioner",
    "9115" -> "Sales",
    "9120" -> "Office and Administrative Support",
    "9125" -> "Blue Collar",
    "9130" -> "Farming/Fish/Forestry",
    "9135" -> "Other",
    "9140" -> "Retired",
    "9145" -> "Management/Business and Financial Operations",
    "9150" -> "Technical: Computers/Math and Architect/Engineerin",
    "9155" -> "Professional: Legal/Education and Health Practitioner",
    "9160" -> "Sales",
    "9165" -> "Office and Administrative Support",
    "9170" -> "Blue Collar",
    "9175" -> "Farming/Fish/Forestry",
    "9180" -> "Other",
    "9185" -> "Retired"
  )

  val MosaicZip4 = Map(
    "A01" -> "A01 - American Royalty",
    "A02" -> "A02 - Platinum Prosperity",
    "A03" -> "A03 - Kids and Cabernet",
    "A04" -> "A04 - Picture Perfect Families",
    "A05" -> "A05 - Couples with Clout",
    "A06" -> "A06 - Jet Set Urbanites",
    "B07" -> "B07 - Generational Soup",
    "B08" -> "B08 - Babies and Bliss",
    "B09" -> "B09 - Family Fun-tastic",
    "B10" -> "B10 - Cosmopolitan Achievers",
    "C11" -> "C11 - Aging of Aquarius",
    "C12" -> "C12 - Golf Carts and Gourmets",
    "C13" -> "C13 - Silver Sophisticates",
    "C14" -> "C14 - Boomers and Boomerangs",
    "D15" -> "D15 - Sports Utility Families",
    "D16" -> "D16 - Settled in Suburbia",
    "D17" -> "D17 - Cul de Sac Diversity",
    "D18" -> "D18 - Suburban Attainment",
    "E19" -> "E19 - Full Pockets, Empty Nests",
    "E20" -> "E20 - No Place Like Home",
    "E21" -> "E21 - Unspoiled Splendor",
    "F22" -> "F22 - Fast Track Couples",
    "F23" -> "F23 - Families Matter Most",
    "G24" -> "G24 - Status Seeking Singles",
    "G25" -> "G25 - Urban Edge",
    "H26" -> "H26 - Progressive Potpourri",
    "H27" -> "H27 - Birkenstocks and Beemers",
    "H28" -> "H28 - Everyday Moderates",
    "H29" -> "H29 - Destination Recreation",
    "I30" -> "I30 - Stockcars and State Parks",
    "I31" -> "I31 - Blue Collar Comfort",
    "I32" -> "I32 - Steadfast Conventionalists",
    "I33" -> "I33 - Balance and Harmony",
    "J34" -> "J34 - Aging in Place",
    "J35" -> "J35 - Rural Escape",
    "J36" -> "J36 - Settled and Sensible",
    "K37" -> "K37 - Wired for Success",
    "K38" -> "K38 - Gotham Blend",
    "K39" -> "K39 - Metro Fusion",
    "K40" -> "K40 - Bohemian Groove",
    "L41" -> "L41 - Booming and Consuming",
    "L42" -> "L42 - Rooted Flower Power",
    "L43" -> "L43 - Homemade Happiness",
    "M44" -> "M44 - Red, White and Bluegrass",
    "M45" -> "M45 - Diapers and Debit Cards",
    "N46" -> "N46 - True Grit Americans",
    "N47" -> "N47 - Countrified Pragmatics",
    "N48" -> "N48 - Rural Southern Bliss",
    "N49" -> "N49 - Touch of Tradition",
    "O50" -> "O50 - Full Steam Ahead",
    "O51" -> "O51 - Digital Dependents",
    "O52" -> "O52 - Urban Ambition",
    "O53" -> "O53 - Colleges and Cafes",
    "O54" -> "O54 - Striving Single Scene",
    "O55" -> "O55 - Family Troopers",
    "P56" -> "P56 - Mid-scale Medley",
    "P57" -> "P57 - Modest Metro Means",
    "P58" -> "P58 - Heritage Heights",
    "P59" -> "P59 - Expanding Horizons",
    "P60" -> "P60 - Striving Forward",
    "P61" -> "P61 - Humble Beginnings",
    "Q62" -> "Q62 - Reaping Rewards",
    "Q63" -> "Q63 - Footloose and Family Free",
    "Q64" -> "Q64 - Town Elders",
    "Q65" -> "Q65 - Senior Discounts",
    "R66" -> "R66 - Dare to Dream",
    "R67" -> "R67 - Hope for Tomorrow",
    "S68" -> "S68 - Small Town Shallow Pockets",
    "S69" -> "S69 - Urban Survivors",
    "S70" -> "S70 - Tight Money",
    "S71" -> "S71 - Tough Times"
  )
  val MosaicGlobalZip4 = Map(
    "31" -> "Power Elite",
    "32" -> "Flourishing Families",
    "33" -> "Booming with Confidence",
    "34" -> "Suburban Style",
    "35" -> "Thriving Boomers",
    "36" -> "Promising Families",
    "37" -> "Young, City Solos",
    "38" -> "Middle-class Melting Pot",
    "39" -> "Family Union",
    "40" -> "Autumn Years",
    "41" -> "Significant Singles",
    "42" -> "Blue Sky Boomers",
    "43" -> "Families in Motion",
    "44" -> "Pastoral Pride",
    "45" -> "Singles and Starters",
    "46" -> "Cultural Connections",
    "47" -> "Golden Year Guardians",
    "48" -> "Aspirational Fusion",
    "49" -> "Economic Challenges"
  )

  val EstimatedHomeValue = Map(
    "A" -> "0-49999",
    "B" -> "50000-99999",
    "C" -> "100000-149999",
    "D" -> "150000-199999",
    "E" -> "200000-249999",
    "F" -> "250000-299999",
    "G" -> "300000-349999",
    "H" -> "350000-399999",
    "I" -> "400000-449999",
    "J" -> "450000-499999",
    "K" -> "500000+"
  )

  val HouseholdIncome = Map(
    "A" -> "0 - 14,999",
    "B" -> "15,000 - 24,999",
    "C" -> "25,000 - 34,999",
    "D" -> "35,000 - 49,999",
    "E" -> "50,000 - 74,999",
    "F" -> "75,000 - 99,999",
    "G" -> "100,000 - 124,999",
    "H" -> "125,000 - 149,999",
    "I" -> "150,000 - 174,999",
    "J" -> "175,000 - 199,999",
    "K" -> "200,000 - 249,999",
    "L" -> "250,000+"
  )

  val HomeOwnership = Map(
    "7" -> "Likely Home Owner",
    "8" -> "Highly Likely Home Owner",
    "9" -> "Extremely Likely Home Owner",
    "H" -> "Home Owner",
    "R" -> "Renter",
    "T" -> "Probable Renter"
  )

  val HouseHoldComposition = Map(
    "A" -> "Adult Female",
    "B" -> "1 Adult Male",
    "C" -> "1 Adult Female and 1 Adult Male",
    "D" -> "1 Adult Female, 1 Adult Male and Children",
    "E" -> "1 Adult Female and Children",
    "F" -> "1 Adult Male and Children",
    "G" -> "2 or More Adult Males",
    "H" -> "2 or More Adult Females",
    "I" -> "2 or More Adult Males and Children",
    "J" -> "2 or More Adult Females and Children"
  )

  val WealthRating = Map(
    "1" -> "First / Bottom (0-9th Percentile)",
    "2" -> "Second (10-19th Percentile)",
    "3" -> "Third (20-29th Percentile)",
    "4" -> "Fourth (30-39th Percentile)",
    "5" -> "Fifth (40-49th Percentile)",
    "6" -> "Sixth (50-59th Percentile)",
    "7" -> "Seventh (60-69th Percentile)",
    "8" -> "Eighth (70-79th Percentile)",
    "9" -> "Ninth (80-89th Percentile)",
    "10" -> "Tenth / Top (90-99th Percentile)"
  )

  val PayerType = Map(
    "MI" -> "Medicare Inferred",
    "MK" -> "Medicare Known",
    "NI" -> "Not profitable Inferred",
    "NK" -> "Not profitable Known",
    "PI" -> "Profitable Inferred",
    "PK" -> "Profitable Known"
  )

  val UnityMappings = Map[String, Map[String, String]](
    "patientType" -> PatientTypes,
    "occupation" -> Occupation,
    "occupationGroup" -> OccupationGroup,
    "mosaicZip4" -> MosaicZip4,
    "mosaicGlobalZip4" -> MosaicGlobalZip4,
    "estimatedHomeValue" -> EstimatedHomeValue,
    "householdIncome" -> HouseholdIncome,
    "homeOwnership" -> HomeOwnership,
    "householdComposition" -> HouseHoldComposition,
    "wealthRating" -> WealthRating,
    "isoLanguage" -> Constants.StandardLanguageMap.map{case(k, v)  => (v._2, v._1)},
    "payerType" -> PayerType
  )

  /**
    * Transforms Person & activity dataset to Person ES dataframe
    *
    * @param persons
    * @param activities
    * @param complexColumnsToPreserve
    * @param columnsToIgnore
    * @param personMapping
    * @return
    */
  def transformToElasticsearchIndex(
                                     persons: Dataset[Person],
                                     activities: Dataset[Activity],
                                     complexColumnsToPreserve: Seq[String],
                                     columnsToIgnore: Seq[String],
                                     personMapping: JsonObject
                                   ): DataFrame = {

    logger.info(s"Ignoring the following columns: ${columnsToIgnore.mkString(", ")}")
    logger.info(s"Preserving the following complex columns: ${complexColumnsToPreserve.mkString(", ")}")

    val personFields = getColumnList(personMapping.get("properties")). // Gets all the list of field names from person-mapping-json
      filterNot(_.startsWith("activities.")). // Removed 'activities.' nested fields
      map(_.replaceAll("\\..*$", "")).
      filterNot(columnsToIgnore.contains). // filters columns that needs to be ignored
      distinct.map(col)

    val esPersons = persons.
      transform(p => p.select(flattenSchema(p.schema, complexColumnsToPreserve): _*)). // complex structs like sg2, phoneNumbers etc are flattened
      drop("activities"). // drops activities column
      select(personFields: _*). // selects personField without activities nested fields
      transform(prepColumnsForEs).
      transform(transformToUnityValues)

    val pattern = "activities\\.([a-zA-Z0-9]+)".r

    val activityFields = getColumnList(personMapping.get("properties")). // Gets all the list of field names from person-mapping-json
      filter(_.startsWith("activities.")). // Removs all NON 'activities.' nested fields
      flatMap { str =>
      pattern.findAllIn(str).matchData.map(_.group(1)) // maps to pattern's ([a-zA-Z0-9]+) i.e field names
      }.distinct.
      filterNot(columnsToIgnore.contains). // filters columns that needs to be ignored
      map(col)

    val esActivities = activities.withColumn("providers", getProviders(col("providers"))).
      transform(a => a.select(flattenSchema(a.schema, complexColumnsToPreserve): _*)). // complex structs like sg2, phoneNumbers etc are flattened
      select(activityFields :+ col("personId"): _*). // selects only activity fields and personId(this is going to be used for later join)
      transform(prepColumnsForEs).
      transform(transformToUnityValues).
      transform { a =>
        a.columns.mkString(", ") // not useful statement
        a.groupBy("personId").
          agg(collect_list(struct(a.columns.filterNot(_ == "personId").map(col): _*)) as "activities")
        // groups by personId,
        // And very row in relational groupped dataset, (uses struct to be able to use columns functionality for filtering out a specific columnName)
        // 1. removes column, personId
        // 2. all other columns are mapped to respective columnNames
        // 3. all mapped columns with values are collected as a list under alias activities
      }

    esPersons.join(esActivities, Seq("personId"), "left_outer") // joins persons and activities on personId
  }

  /**
    * Flattens schema with complex struct types like phoneNumbers, sg2 etc...
    *
    * @param schema
    * @param complexColumnsToPreserve
    * @param prefix
    * @return
    */
  private def flattenSchema(schema: StructType, complexColumnsToPreserve: Seq[String],
                            prefix: String = null): Array[Column] = {
    schema.flatMap(f => {
      val colName = if (prefix == null) f.name else prefix + "." + f.name
      f.dataType match {
        case _ if complexColumnsToPreserve.contains(colName) => Array(col(colName))
        case st: StructType => flattenSchema(st, complexColumnsToPreserve, colName)
        case _ => Array(col(colName))
      }
    }).toArray
  }

  /**
    * Converts decomals to flat coz elastic search doesn't support decimals
    *
    * @param df
    * @return
    */
  private def prepColumnsForEs(df: DataFrame): DataFrame = {

    df.schema.fields.filter(_.dataType.isInstanceOf[DecimalType]).foldLeft(df) {
      (updateDf, field) => {
        updateDf.withColumn(field.name, col(field.name).cast(FloatType))
      }
    }
  }

  /**
    * Gets list of field names from person-mapping.json
    *
    * @param jsonElement
    * @param columns
    * @return
    */
  private def getColumnList(jsonElement: JsonElement, columns: List[String] = List.empty): List[String] = {
    jsonElement.getAsJsonObject.entrySet().asScala.flatMap { entry =>
      if (entry.getValue.isJsonObject &&
        entry.getValue.getAsJsonObject.entrySet().asScala.exists(entry => entry.getKey == "properties")
      ) {
        // for nested json fields
        getColumnList(entry.getValue.getAsJsonObject.get("properties")).map(name => s"${entry.getKey}.$name")
      } else {
        // for other non-nested json fields
        List(entry.getKey)
      }
    }.toList
  }

  /**
    * Maps values that unity expects
    * @param dataFrame
    * @return
    */
  private def transformToUnityValues(dataFrame: DataFrame): DataFrame = {
    import dataFrame.sparkSession.implicits._

    UnityMappings.foldLeft(dataFrame) { (df, kv) =>
      val columnName = kv._1
      val mappings = kv._2
      if (df.columns.contains(columnName)) {
        df.withColumn(kv._1, map_to_unity_value(mappings)(upper($"$columnName".cast(StringType))))
      } else {
        df
      }
    }
  }

  private def map_to_unity_value(unityValueMap: Map[String, String]) = udf((str: String) => {
    Option(str).flatMap(unityValueMap.get)
  })

  /**
    * converting providers values into Unity required format
    *
    * @param input input providers value
    * @return unity format of providers
    */
  private def getProviders: UserDefinedFunction = udf((inputValue: Seq[String]) => {
    val outputValue = new ListBuffer[Map[String, String]]()
    inputValue match {
      case x if x == null || x.isEmpty => None
      case x if x.forall(_.contains(";")) => x.map { y =>
        val split = y.split(";")
        val npi = split.head
        val physType = Constants.physicianNPICodesForES.getOrElse(split(1).toInt, "NULL")
        outputValue += Map("npi" -> npi, "type" -> physType)
      }
        Some(outputValue.toList)
      case _ => None
    }
  })
 
}
