package com.influencehealth.edh.cleanse

import com.influencehealth.edh.model.activitytype.ActivityType
import com.influencehealth.edh.utils.{CleanseUtils, PersonUtils}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{col, lit}

class MarketingListCleanser(val dateBatchReceived: String) extends DataCleanser {

  this: ActivityType =>


  override def cleanseData(
                            df: DataFrame,
                            customer: Option[String],
                            batchId: String
                          ): (DataFrame, DataFrame) = {

    // Apply default values for Required Columns if found NULL
    val defaultCodeForRequiredColumnsContainingNulls = assignDefaultValuesForRequiredColumnsContainingNulls(df).
      withColumn("source", lit(defaultSource)).
      transform(addSourceRecordId(_, batchId))

    // Filters required columns that are not null
    val (dataFrameContainingNonNullColumns, dataFrameContainingNullColumns) =
      filterRequiredColumnsContainingInvalidValues(
        defaultCodeForRequiredColumnsContainingNulls, nullColumnNames, mandatoryContactColumnsNames)

    // cleanses & filters Date column
    val dataFrameContainingValidDateColumns = formatDateColumns(dataFrameContainingNonNullColumns)

    // Cleanses String Column
    val dataFrameContainingCleansedStringColumns = cleanseStringColumns(dataFrameContainingValidDateColumns, cleanseStringColumnNames)

    // Cleanses Contact details: Phone numbers and emails
    val dataFrameContainingCleansedContactDetails = cleanseContactDetails(dataFrameContainingCleansedStringColumns)


    val cleansedZips = cleanseZips(dataFrameContainingCleansedContactDetails)
    // Aliases Data
    val aliasedData = aliasData(cleansedZips, customer)

    (aliasedData, dataFrameContainingNullColumns)

  }

  override def formatDateColumns(df: DataFrame): DataFrame = {

    import df.sqlContext.implicits._
    // Convert string date into Date type columns after validating the dates, known behavior
    import org.apache.spark.sql.functions.{when, _}

    val formattedDatesDataFrame = df.
      withColumn("dateOfBirth", CleanseUtils.timestamp_to_date(PersonUtils.validateInputDate(
        date_format(unix_timestamp($"dateOfBirth", "MM/dd/yy").cast("timestamp"), "yyyy-MM-dd")))).
      withColumn("activityDate", when(col("activityDate").isNotNull,
        PersonUtils.validateInputDate(date_format(unix_timestamp($"activityDate", "MM/dd/yy").cast("timestamp"),
          "yyyy-MM-dd"))) otherwise lit(CleanseUtils.parseStringToDate(dateBatchReceived)))

    formattedDatesDataFrame
  }


  override def cleanseStringColumns(df: DataFrame, stringColumnsToBeCleansed: Seq[String]): DataFrame = {
    stringColumnsToBeCleansed.foldLeft(df)((curr, n) => curr.withColumn(n, CleanseUtils.cleanseStringColumns(curr(n))))
  }

  override def assignDefaultValuesForRequiredColumnsContainingNulls(df: DataFrame): DataFrame = {
    val addingColumnNames: DataFrame = df.
      withColumn("sourceType", lit(defaultSourceType)).
      withColumn("addressType", lit(defaultAddressType))

    addingColumnNames
  }

  override def aliasData(df: DataFrame, customer: Option[String]): DataFrame = {
    super.aliasData(df, customer).
      withColumn("activity", df("listName")).
      withColumn("activityType", lit(defaultActivityType))
  }

  /** Filter out the required columns containing null values
    *
    * @param df
    * @param nullColumns
    * @return filtered dataFrame with columns which do not contain null for required columns &
    *         dirty dataFrame with columns that contains null for required columns
    */
  private def filterRequiredColumnsContainingNullValues(df: DataFrame, nullColumns: Seq[String]):
  (DataFrame, DataFrame) = {
    val methodOfContactNulls: Seq[String] = Seq("emails", "phoneNumbers", "address1")
    CleanseUtils.filterRequiredColumnsValues(df, nullColumns, methodOfContactNulls)
  }

  /** Validates the email and phone number columns
    *
    * @param df
    * @return formated coloumn
    **/
  private def cleanseContactDetails(df: DataFrame): DataFrame = {
    df
      .withColumn("emails", getStringToArray(CleanseUtils.cleanseAndValidateEmail(df("emails"))))
      .withColumn("phoneNumbers", CleanseUtils.cleanseAndParsePhones(col("phoneNumbers")))

  }

  /** Cleanse zip values
    *
    * @param df
    * @return
    */
  private def cleanseZips(df: DataFrame): DataFrame = {
    df.withColumn("zip4", CleanseUtils.get_zip4(df("zip5")))
      .withColumn("zip5", CleanseUtils.get_zip5(df("zip5")))
  }


}
