package com.influencehealth.edh.cleanse

import com.influencehealth.edh.{Constants}
import com.influencehealth.edh.model.activitytype.ActivityType
import com.influencehealth.edh.utils.{CleanseUtils, PersonUtils}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._

class DonorListCleanser(val dateBatchReceived: String) extends DataCleanser {

  this: ActivityType =>


  override def cleanseData(
                            df: DataFrame,
                            customer: Option[String],
                            batchId: String
                          ): (DataFrame, DataFrame) = {

    // Apply default values for Required Columns if found NULL
    val defaultCodeForRequiredColumnsContainingNulls = assignDefaultValuesForRequiredColumnsContainingNulls(df)

    // filters required columns that are not null
    val (dataFrameContainingNonNullColumns, dataFrameContainingNullColumns) =
      filterRequiredColumnsContainingInvalidValues(
        defaultCodeForRequiredColumnsContainingNulls, nullColumnNames, mandatoryContactColumnsNames)

    // cleanses & filters Date column
    val dataFrameContainingValidDateColumns = formatDateColumns(dataFrameContainingNonNullColumns)

    // Cleanses String Column
    val dataFrameContainingCleansedStringColumns = cleanseStringColumns(dataFrameContainingValidDateColumns,
      cleanseStringColumnNames)

    // Cleanses Contact details: Phone numbers and emails
    val dataFrameContainingCleansedContactDetails = cleanseContactDetails(dataFrameContainingCleansedStringColumns)


    // Cleanse zip5 column
    val cleansedZips = cleanseZips(dataFrameContainingCleansedContactDetails)

    // Aliases Data
    val aliasedData = aliasData(cleansedZips, customer)

    (aliasedData, dataFrameContainingNullColumns)

  }


  override def formatDateColumns(df: DataFrame): DataFrame = {

    import df.sqlContext.implicits._
    // Convert string date into Date type columns after validating the dates, known behavior

    val formattedDatesDataFrame = df
      .withColumn("dateOfBirth", CleanseUtils.timestamp_to_date(PersonUtils.validateInputDate(
        date_format(unix_timestamp($"dateOfBirth", "MM/dd/yy").cast("timestamp"), "yyyy-MM-dd"))))

    formattedDatesDataFrame
  }


  override def cleanseStringColumns(df: DataFrame, stringColumnsToBeCleansed: Seq[String]): DataFrame = {
    stringColumnsToBeCleansed.foldLeft(df) { (df, column) =>
      df.withColumn(s"$column", CleanseUtils.cleanseStringColumns(df(s"$column")))
    }
  }

  override def assignDefaultValuesForRequiredColumnsContainingNulls(df: DataFrame): DataFrame = df

  override def aliasData(df: DataFrame, customer: Option[String]): DataFrame = {
    df.withColumn("sourcePersonId", col("sourceRecordId"))
      .withColumn("messageType", lit(defaultMessageType))
      .withColumn("activityType", lit(defaultActivityType))
      .withColumn("activityDate", lit(CleanseUtils.parseStringToDate(dateBatchReceived)))
      .withColumn("customer", lit(customer.get))
      .withColumn("dateCreated", lit(Constants.Now.toString))
  }

  /** Validates the email and phone number columns
    *
    * @param df
    * @return formated coloumn
    * */
  private def cleanseContactDetails(df: DataFrame): DataFrame = {
    df
      .withColumn("emails", getStringToArray(CleanseUtils.cleanseAndValidateEmail(df("emails"))))
      .withColumn("phoneNumbers", CleanseUtils.cleanseAndParsePhones(df("phoneNumbers")))
  }


  val stringify: UserDefinedFunction = udf((vs: Seq[String]) =>
    s"""[${vs.mkString(",").replace("null,", "").replace("null", "")}]""")


  /** Cleanse zip values
    *
    * @param df
    * @return
    */
  private def cleanseZips(df: DataFrame): DataFrame = {
    val x = df.withColumn("zip4", CleanseUtils.get_zip4(df("zip5"))).
      withColumn("zip5", CleanseUtils.get_zip5(df("zip5")))
    x
  }
}
