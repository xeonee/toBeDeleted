package com.influencehealth.edh.model.schema

import org.apache.spark.sql.types.{StringType, StructField, StructType}

object HraSchema {

  val trueFlag: Boolean = true
  val falseFlag: Boolean = false

  val hraHeaderSchema: StructType = StructType(
    Array(
      StructField("transactionId", StringType, trueFlag),
      StructField("transactionDate", StringType, trueFlag),
      StructField("firstName", StringType, trueFlag),
      StructField("middleName", StringType, trueFlag),
      StructField("lastName", StringType, trueFlag),
      StructField("address1", StringType, trueFlag),
      StructField("address2", StringType, trueFlag),
      StructField("city", StringType, trueFlag),
      StructField("state", StringType, trueFlag),
      StructField("zip5", StringType, trueFlag),
      StructField("sourceSex", StringType, trueFlag),
      StructField("dateOfBirth", StringType, trueFlag),
      StructField("phoneNumbers", StringType, trueFlag),
      StructField("emails", StringType, trueFlag)
    )
  )

  val hraDetailSchema: StructType = StructType(
    Array(
      StructField("transactionId", StringType, falseFlag),
      StructField("assessmentCode", StringType, falseFlag),
      StructField("assessmentDescription", StringType, trueFlag),
      StructField("variable", StringType, trueFlag),
      StructField("value", StringType, trueFlag)
    )
  )

  val hraHeaderV2Schema: StructType = StructType(
    Array(
      StructField("transactionId", StringType, trueFlag),
      StructField("assessmentCodeHeader", StringType, trueFlag),
      StructField("transactionDate", StringType, trueFlag),
      StructField("firstName", StringType, trueFlag),
      StructField("middleName", StringType, trueFlag),
      StructField("lastName", StringType, trueFlag),
      StructField("address1", StringType, trueFlag),
      StructField("address2", StringType, trueFlag),
      StructField("city", StringType, trueFlag),
      StructField("state", StringType, trueFlag),
      StructField("zip5", StringType, trueFlag),
      StructField("sourceSex", StringType, trueFlag),
      StructField("dateOfBirth", StringType, trueFlag),
      StructField("phoneNumbers", StringType, trueFlag),
      StructField("emails", StringType, trueFlag)
    )
  )

  val hraDetailV2Schema: StructType = StructType(
    Array(
      StructField("transactionId", StringType, falseFlag),
      StructField("assessmentCode", StringType, falseFlag),
      StructField("campaignId", StringType, trueFlag),
      StructField("assessmentDescription", StringType, trueFlag),
      StructField("questionDescription", StringType, trueFlag),
      StructField("answerDescription", StringType, trueFlag)
    )
  )
}
