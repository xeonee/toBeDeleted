package com.influencehealth.edh.check.loadcheck

import allbegray.slack.SlackClientFactory
import allbegray.slack.`type`.Payload
import com.influencehealth.edh.AppCleanser
import com.influencehealth.edh.{BaldurApplication, Constants, SuccessfulBaldurJob}
import com.influencehealth.edh.config.CheckLoadConfig
import com.influencehealth.edh.dao.{DatabaseDao, FileSystemDao, S3FileSystemDao}
import com.influencehealth.edh.lookups.client.LookupsClient
import com.influencehealth.edh.utils.DataLakeUtilities
import com.typesafe.config.Config
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.util.Try

object CheckLoadApp extends BaldurApplication[CheckLoadConfig] {

  var inputRecordCount: Option[Long] = None
  var outputRecordCount: Option[Long] = None

  override def runJob(
                       implicit sparkSession: SparkSession,
                       config: CheckLoadConfig,
                       databaseDao: DatabaseDao
                     ) = {

    val loadCheckStat = StringBuilder.newBuilder

    // check cleanse
    val (cleanseStats, cleansedCount): (DataFrame, Long) = getS3Data(config)

    // check load
    val (loadStats, passOrFail): (DataFrame, String) = getPostgresData(config, databaseDao, cleansedCount)

    cleanseStats.union(loadStats).show(false)

    loadCheckStat.append(s"Over all Load Check: $passOrFail\n")

    if (config.isJobStatEnable.get) {
      val webhookUrl = config.slackHook.get
      val webApiClient = SlackClientFactory.createWebhookClient(webhookUrl)
      val payload = new Payload()
      payload.setText(loadCheckStat.toString())
      webApiClient.post(payload)
    }
    else {
      println(loadCheckStat)
    }

  }

  import sparkSession.implicits._

  private def getBatchIdForCleanse(batchId: String, customer: String): String = {
    if ((batchId.contains(Constants.ProspectDefaultMessageType.toLowerCase) ||
      batchId.contains(Constants.NewMoverDefaultSourceType.toLowerCase)) &&
      batchId.contains(customer)) {
      batchId.replace(batchId.split("-")(0), Constants.ProspectExperianSource.toLowerCase)
    }
    else batchId
  }

  private def getBatchIdForLoad(batchId: String, customer: String): String = {
    if (!batchId.contains(customer)) {
      batchId.replace(batchId.split("-")(0), customer)
    }
    else batchId
  }

  private def getS3Data(config: CheckLoadConfig): (DataFrame, Long) = {

    val batchId = getBatchIdForCleanse(config.batchId, config.customer)

    val fileSystemDao: FileSystemDao = new S3FileSystemDao(sparkSession, appConfig, s3client)

    val rawS3Url = DataLakeUtilities.buildRawS3Url(batchId, config.bucketName)
    val cleansedS3Url = DataLakeUtilities.buildCleansedS3Url(batchId, config.bucketName)
    val errorS3Url = DataLakeUtilities.buildErrorS3Url(batchId, config.bucketName)

    val rawData =
      AppCleanser.readRawFiles(true, rawS3Url, config.activityType, config.batchFormat, fileSystemDao).count()

    val cleansedData = Try {
      sparkSession.read.parquet(cleansedS3Url).count()
    }.getOrElse(
      throw new RuntimeException(s"No files found at $cleansedS3Url"))

    val errorData = Try {
      sparkSession.read.option("header", true).
        option("delimiter", Constants.ErrorFileDelimiter).
        csv(s"$errorS3Url*").count()
    }.
      getOrElse(0L)

    (Seq(
      ("Raw records from Data Lake (S3)", rawData),
      ("Cleansed activities from Data Lake (S3)", cleansedData),
      ("Error activities from Data Lake (S3)* (Distinct records)", errorData)).
      toDF("load_check_criteria", "count"), cleansedData)
  }

  private def getPostgresData(config: CheckLoadConfig, databaseDao: DatabaseDao,
                              cleansedCount: Long): (DataFrame, String) = {

    val batchId = getBatchIdForLoad(config.batchId, config.customer)

    val allActivitiesByCustomer: DataFrame = databaseDao.getActivitiesByCustomer(config.customer).toDF()

    val activitiesByBatch: DataFrame = allActivitiesByCustomer.where(s"batchId = '${config.batchId}'")

    val activitiesInBatch: Long = activitiesByBatch.count()

    val newActivities: Long =
      activitiesByBatch.where("size(mergedActivityIds) = 0 OR mergedActivityIds is null ").count()

    val linkedActivities: Long = activitiesByBatch.
      where("size(mergedActivityIds) > 0 AND mergedActivityIds is not null").count()

    val activityIdsByBatch: Seq[String] =
      activitiesByBatch.select("activityId").distinct().rdd.map(r => r(0).toString).collect().toSeq

    val activitiesWithUpdatedBatchIds: Long = allActivitiesByCustomer.
      filter(row=> !activityIdsByBatch.contains(row.getAs[String]("activityId"))).
      select("mergedActivityIds").
      filter(row => batchId.contains(row.getAs[List[String]]("mergedActivityIds"))).count()

    val ungroupableActivities: Long = databaseDao.getUngroupableActivitiesByBatchId(batchId).count()

    val unIdentifiableActivities: Long = databaseDao.getUnidentifiableActivitiesByBatchId(batchId).count()

    val missingActivities: Long = cleansedCount - unIdentifiableActivities - activitiesInBatch

    val passOrFail: String = if (missingActivities > 0) {
      "FAIL"
    } else "PASS"

   val statsDataFrame = Seq(
      ("Activities found in ungroupable_activities", ungroupableActivities),
      ("Activities dropped (unidentifiable_activities)", unIdentifiableActivities),
      ("New activities added", newActivities),
      (s"Linked activities in the batch Id ($batchId)", linkedActivities),
      ("Linked activities containing updated batch Ids", activitiesWithUpdatedBatchIds),
      ("Total activities present", activitiesInBatch),
      ("Missing activities from S3 (parquet records - unidentifiable_activities - activities)", missingActivities)).
      toDF("load_check_criteria", "count")

      (statsDataFrame, passOrFail)
  }

  override def buildConfig(appConfig: Config, lookupsClient: LookupsClient): CheckLoadConfig = {
    CheckLoadConfig(appConfig)
  }

  override def countInputRecords = {
    inputRecordCount
  }

  override def countOutputRecords = {
    outputRecordCount
  }
}
