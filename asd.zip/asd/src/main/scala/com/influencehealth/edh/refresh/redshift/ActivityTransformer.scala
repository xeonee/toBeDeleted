package com.influencehealth.edh.refresh.redshift
import com.influencehealth.edh.model.{Activity, Coordinates}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DateType, StringType}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession, functions}
import org.apache.spark.storage.StorageLevel
private[redshift] class ActivityTransformer(
                                             activityData: Dataset[Activity],
                                             sparkSession: SparkSession
                                           ) extends BaseTransformer with Serializable {

  import sparkSession.implicits._

  val columnsWithSizeMoreThan256: Map[String, Int] = Map(
    "merged_batch_ids" -> 50240,
    "mrids"  -> 1024,
    "merged_activity_ids" -> 50240,
    "providers" -> 1024,
    "assessment_results" -> 1024,
    "current_procedural_terminology_codes" -> 50240,
    "diagnosis_codes" -> 50240,
    "procedure_codes" -> 50240,
    "opt_out_direct_mail_reasons" -> 1024,
    "opt_out_call_reasons" -> 1024,
    "opt_out_email_reasons" -> 1024,
    "opt_out_text_reasons" -> 1024,
    "care_group_code" -> 1024,
    "care_group_description" -> 1024,
    "service_line_group" -> 1024,
    "care_family" -> 1024,
    "procedure" -> 1024,
    "procedure_group" -> 1024,
    "mental_health_conditions" -> 1024,
    "addiction_adult" -> 1024,
    "behavioral_health_conditions_adult" -> 1024,
    "diabetes_adult" -> 1024,
    "cardiac_disease_adult" -> 1024,
    "pulmonary_disease_adult" -> 1024,
    "adult_chronic_conditions_count" -> 1024,
    "asthma_pediatric" -> 1024,
    "behavioral_health_conditions_pediatric" -> 1024,
    "complex_cardiac_conditions_pediatric" -> 1024,
    "pediatric_complex_conditions_count" -> 1024,
    "trauma" -> 1024,
    "procedure_group_category" -> 1024,
    "sports_medicine" -> 1024,
    "pain_services" -> 1024,
    "primary_care_all_adults" -> 1024,
    "primary_care_geriatrics" -> 1024,
    "primary_care_pediatrics" -> 1024,
    "service_line" -> 1024
  )

  val deNormalizedActivities: DataFrame = activityData.
    withColumn("personRecordId", concat_ws("::", $"customer", $"personId")).
    withColumn("mergedActivityIds", convertSequenceStringToString(activityData("mergedActivityIds"))).
    // TODO remove this after bug fix for EDH 2461
     withColumn("mrids", lit("")).
     withColumn("isDeceased", lit(false)).
     withColumn("activityDateSourceAgeRecieved", functions.lit(null).cast(DateType)).
    // TODO Remove the above 3
    withColumn("mergedBatchIds", convertSequenceStringToString(activityData("mergedBatchIds"))).
    withColumn("providers", convertSequenceStringToString(activityData("providers"))).
    withColumn("assessmentResults", convertSequenceAssessmentResultsToString(activityData("assessmentResults"))).
    withColumn("currentProceduralTerminologyCodes", convertSequenceActivityMedicalCodeToString(activityData("currentProceduralTerminologyCodes"))).
    withColumn("diagnosisCodes", convertSequenceActivityMedicalCodeToString(activityData("diagnosisCodes"))).
    withColumn("procedureCodes", convertSequenceActivityMedicalCodeToString(activityData("procedureCodes"))).
    withColumn("optOutDirectMailReasons",  convertSequenceStringToString(activityData("optOutDirectMailReasons"))).
    withColumn("optOutCallReasons",  convertSequenceStringToString(activityData("optOutCallReasons"))).
    withColumn("optOutEmailReasons",  convertSequenceStringToString(activityData("optOutEmailReasons"))).
    withColumn("optOutTextReasons",  convertSequenceStringToString(activityData("optOutTextReasons"))).
    withColumn("addressCoordinates",  to_json($"addressCoordinates").cast(StringType)).
    withColumn("careGroupCode", $"sg2".getField("careGroupCode")).
    withColumn("careGroupDescription", $"sg2".getField("careGroupDescription")).
    withColumn("serviceLineGroup", $"sg2".getField("serviceLineGroup")).
    withColumn("careFamily", $"sg2".getField("careFamily")).
    withColumn("procedure", $"sg2".getField("procedure")).
    withColumn("procedureGroup", $"sg2".getField("procedureGroup")).
    withColumn("mentalHealthConditions", $"sg2".getField("mentalHealthConditions")).
    withColumn("addictionAdult", $"sg2".getField("addictionAdult")).
    withColumn("behavioralHealthConditionsAdult", $"sg2".getField("behavioralHealthConditionsAdult")).
    withColumn("diabetesAdult", $"sg2".getField("diabetesAdult")).
    withColumn("cardiacDiseaseAdult", $"sg2".getField("cardiacDiseaseAdult")).
    withColumn("pulmonaryDiseaseAdult", $"sg2".getField("pulmonaryDiseaseAdult")).
    withColumn("adultChronicConditionsCount", $"sg2".getField("adultChronicConditionsCount")).
    withColumn("asthmaPediatric", $"sg2".getField("asthmaPediatric")).
    withColumn("behavioralHealthConditionsPediatric", $"sg2".getField("behavioralHealthConditionsPediatric")).
    withColumn("complexCardiacConditionsPediatric", $"sg2".getField("complexCardiacConditionsPediatric")).
    withColumn("pediatricComplexConditionsCount", $"sg2".getField("pediatricComplexConditionsCount")).
    withColumn("trauma", $"sg2".getField("trauma")).
    withColumn("procedureGroupCategory", $"sg2".getField("procedureGroupCategory")).
    withColumn("sportsMedicine", $"sg2".getField("painServices")).
    withColumn("painServices", $"sg2".getField("diabetesAdult")).
    withColumn("primaryCareAllAdults", $"sg2".getField("primaryCareAllAdults")).
    withColumn("primaryCareGeriatrics", $"sg2".getField("primaryCareGeriatrics")).
    withColumn("primaryCarePediatrics", $"sg2".getField("primaryCarePediatrics")).
    withColumn("serviceLine", $"sg2".getField("serviceLine"))


  val activities: DataFrame = deNormalizedActivities.drop("sg2").
    transform(dropComplexTypes).
    transform(aliasColumnsToSnakeCase).
    transform(applyMetadataToTempTables(columnsWithSizeMoreThan256, _)).
    persist(StorageLevel.MEMORY_ONLY)

  val close: Unit = activities.unpersist()

}
