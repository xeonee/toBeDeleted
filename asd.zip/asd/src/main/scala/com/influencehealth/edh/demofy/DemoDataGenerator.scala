package com.influencehealth.edh.demofy

import com.influencehealth.edh.dao.FileReader
import org.apache.spark.sql.Row
import com.influencehealth.edh.dao.DatabaseDao
import com.influencehealth.edh.model.schema.FakePersonSchema
import com.influencehealth.edh.model.Activity
import com.influencehealth.edh.utils.CleanseUtils
import org.apache.spark.sql.expressions.{UserDefinedFunction, Window}
import org.apache.spark.sql.functions.{struct, lit, col, row_number, monotonically_increasing_id, current_timestamp, udf}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.apache.commons.codec.digest.DigestUtils
import org.apache.spark.storage.StorageLevel
import org.apache.spark.sql.types.FloatType

object DemoDataGenerator {

  val DemoCustomer: String = "peachtree"
  val sourcePersonTypeList = Seq("C", "D", "E", "O", "T", "Y", "P")

  val deIdentifyingColumns: Seq[String] = Seq("prefix",
    "firstName",
    "middleName",
    "lastName",
    "email",
    "homePhone",
    "sex",
    "address1",
    "address2",
    "city",
    "state",
    "zip5",
    "zip4",
    "addressCoordinates",
    "countyCode",
    "deliveryPointCode")

  /**
    * Initializes required parameters to generate realPersonActivities and fakePersonDemographics dataframes
    * And returns realPersonActivities for a customer & fakePersonDemographics for a demo customer
    *
    * @param sparkSession SparkSession
    * @return (realPersonActivities dataframe , fakePersonDemographics dataframe)
    */
  def getInitializedValues(sparkSession: SparkSession, databaseDao: DatabaseDao, customerName: String, bucketUrl: String
                          ): Map[String, Any]  = {
    import sparkSession.implicits._
    val realPersonActivities: DataFrame = databaseDao.getActivitiesByCustomer(customerName).toDF()
      .persist(StorageLevel.MEMORY_AND_DISK)

    val rawFakePersonDemographics =
      FileReader.readCSVinSpark(sparkSession, Some(","),
        FakePersonSchema.schema, s"$bucketUrl/mockcustomer/raw/encounter/influencehealth/", "mock").
        na.fill("").withColumn(
        "addressCoordinates", struct($"latitude".cast(FloatType) as "lat", $"longitude".cast(FloatType) as "lon")).
        drop("latitude", "longitude")

    val fakePersonDemographics = rawFakePersonDemographics.columns.
      foldLeft(rawFakePersonDemographics)((whiteSpace, noWhiteSpace) => whiteSpace.
        withColumnRenamed(noWhiteSpace, noWhiteSpace.replaceAll(" ", "")))

    Map("realPersonActivities" -> realPersonActivities,
      "fakePersonDemographics" -> fakePersonDemographics,
      "originalCustomer" -> customerName,
      "demoCustomer" -> DemoCustomer)
  }

  /**
    * Generates demo data by replacing PHI data from realPersonActivities (for a customer) with counterfeit data
    *
    * @param initializedDataFrames all DataFrames
    * @return demo activities dataframe
    */
  def buildDemoDataset(initializedDataFrames: Map[String, Any]): Dataset[Activity] = {
    val demoCustomer = initializedDataFrames("demoCustomer").toString
    val originalCustomer = initializedDataFrames("originalCustomer").toString
    val normalizedDataFrame: Map[String, DataFrame] = getNormalizedDataFrames(initializedDataFrames)

    val demoPersonActivity: DataFrame =
      applyDemoData(normalizedDataFrame("sampledRealPersonActivities"), normalizedDataFrame("fakePersonDemographics"),
        demoCustomer, originalCustomer)

    import demoPersonActivity.sparkSession.implicits._
    val demoCustomerPersonActivities: Dataset[Activity] =
      applyDemoCustomerInfo(demoPersonActivity, demoCustomer, originalCustomer).as[Activity]

    demoCustomerPersonActivities
  }

  /**
    * Generates demoData by dropping the actual demographics column and adding demoData Columns
    * Replaces and refines other PHI related columns
    *
    * @param actualDataFrame
    * @param fakePersonDemographics
    * @param demoCustomer
    * @param originalCustomer
    * @return
    */
  def applyDemoData(actualDataFrame: DataFrame, fakePersonDemographics: DataFrame,
                    demoCustomer: String, originalCustomer: String): DataFrame = {
    val droppedRealDemographicsColumnDf = actualDataFrame.drop(deIdentifyingColumns: _*)
      .dropDuplicates(Seq("personId"))

    val demoDemographicRecords = droppedRealDemographicsColumnDf.join(fakePersonDemographics, Seq("personId"), "inner")

    val columnsNotToBeHashed: Seq[String] = Seq("dateCreated")
    val hashColumns: Seq[String] = demoDemographicRecords.columns.filterNot(s => columnsNotToBeHashed.contains(s))

    val cleansedDemoDataDemographics = demoDemographicRecords
      .withColumn("homePhone", CleanseUtils.cleanse_phone_numbers(demoDemographicRecords("homePhone")))
      .withColumn("activityId", md5FromRow(struct(hashColumns.map(col): _*)))
      .withColumn("dateModified", lit(current_timestamp()))
      .drop("seqNo")
    cleansedDemoDataDemographics
  }

  /**
    * Converts a string element to a List of string elements
    *
    * @return
    */
  def convertStringToListOfStrings: UserDefinedFunction = udf((element: String) => {
    if (element != null && element.nonEmpty) List(element)
    else List()
  })

  /**
    * Normalizes fake person demographics df and real person activities df by
    * generating equal number of persons for fakePersonDemographics and realPersonActivities data and
    * Links all persons from real person Activity to fake demographics persons
    *
    * @param initializedDataFrames
    * @return
    */
  def getNormalizedDataFrames(initializedDataFrames: Map[String, Any]): Map[String, DataFrame] = {

    val realPersonActivities = initializedDataFrames("realPersonActivities").asInstanceOf[DataFrame]
    val filteredRealPersonActivities = realPersonActivities.filter(row =>
      !sourcePersonTypeList.contains(row.getAs[String]("sourcePersonType")))
    import org.apache.spark.sql
    import realPersonActivities.sparkSession.implicits._
    val fakePersonDemographics = initializedDataFrames("fakePersonDemographics").asInstanceOf[DataFrame].
      withColumn("seqNo", $"seqNo".cast(sql.types.IntegerType))

    val distinctPersons = filteredRealPersonActivities.select("personId").distinct.
      withColumn("uniqueId", monotonically_increasing_id()).
      withColumn("seqNo_string", row_number().over(Window.orderBy("uniqueId"))).
      withColumn("seqNo", $"seqNo_string".cast(sql.types.IntegerType)).
      drop("uniqueId", "seqNo_string")

    val fakePersonDemographicsCount = fakePersonDemographics.count.toInt
    val distinctPersonIdsCount = distinctPersons.count.toInt

    val (originalData, counterfeitData) =
      if (distinctPersonIdsCount >= fakePersonDemographicsCount) {
        (distinctPersons.filter($"seqNo" <= lit(fakePersonDemographicsCount)), fakePersonDemographics)
      }
      else if (distinctPersonIdsCount <= fakePersonDemographicsCount) {
        (distinctPersons, fakePersonDemographics.filter($"seqNo" <= lit(distinctPersonIdsCount)))
      }
      else {
        (distinctPersons, fakePersonDemographics)
      }

    val personIds: List[String] = originalData.drop("seqNo").rdd.map(row => row(0).toString).collect().toList

    val sampledRealPersonActivities: Dataset[Row] =
      filteredRealPersonActivities.filter(pId => personIds.contains(pId.getAs[String]("personId")))

    val fakeDataWithPersonIds = originalData.join(counterfeitData, Seq("seqNo"), "inner")

    Map("sampledRealPersonActivities" -> sampledRealPersonActivities,
      "fakePersonDemographics" -> fakeDataWithPersonIds)
  }

  /**
    * Apply demo customer information to dataframe
    *
    * @param dataFrame
    * @param demoCustomer
    * @param customer
    * @return
    */
  def applyDemoCustomerInfo(dataFrame: DataFrame, demoCustomer: String, customer: String): DataFrame = {
    val batchId = dataFrame.select("batchId").head.mkString.replace(customer, demoCustomer)
    dataFrame.withColumn("batchId", lit(batchId)).
      withColumn("hasMovedAway", lit(false)).
      withColumn("customer", lit(demoCustomer))
  }
  /**
    * Generates md5 from the content of a Row
    */
  def md5FromRow: UserDefinedFunction = udf((r: Row) => {
    val input = r.mkString
    DigestUtils.md5Hex(input.getBytes)
  })
}