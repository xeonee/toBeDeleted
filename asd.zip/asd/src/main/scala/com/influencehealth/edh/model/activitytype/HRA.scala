package com.influencehealth.edh.model.activitytype

import com.influencehealth.edh.Constants

trait HRA extends ActivityType {

  override val formatType: String = Constants.HraMedicomFormat
  override val defaultSource: String = Constants.HraDefaultSourceType
  override val defaultMessageType: String = Constants.HraDefaultMessageType
  override val defaultSourceType: String = Constants.HraDefaultSourceType
  override val defaultAddressType: String = Constants.HraDefaultAddressType
  override val defaultActivityType: String = Constants.HraActivityType
  override val defaultPersonType: String = Constants.HraPersonType

  override val nullColumnNames: Seq[String] = Seq(

    // Hra
    "firstName",
    "lastName",
    "source",
    "sourceRecordId"
  )
  override val cleanseStringColumnNames: Seq[String] = Seq(

    // Hra
    "firstName",
    "middleName",
    "lastName",
    "address1",
    "address2",
    "city",
    "state",
    "zip5",
    "sourceSex",
    "assessmentCode",
    "assessmentDescription"
  )

  override val mandatoryContactColumnsNames: Seq[String] = Seq( "phoneNumbers", "address1")

  override val zipColumnNames: Seq[String] = Seq.empty

}