package com.influencehealth.edh.model

case class EdhCustomer(
                        customerId: Int,
                        customerKey: String
                      )
