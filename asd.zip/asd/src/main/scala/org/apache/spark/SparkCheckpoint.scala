package org.apache.spark

object SparkCheckpoint {

  import org.apache.spark.rdd.RDD

  import scala.reflect.ClassTag
  def recover[T: ClassTag](sc: SparkContext, path: String): RDD[T] = {
    sc.checkpointFile[T](path)
  }

}
