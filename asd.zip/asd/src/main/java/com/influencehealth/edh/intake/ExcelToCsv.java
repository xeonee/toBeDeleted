package com.influencehealth.edh.intake;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.TimeZone;

public class ExcelToCsv {

    private static Logger log = Logger.getLogger(ExcelToCsv.class.getName());

    public static void xls(File inputFile, File outputFile, Integer expectedCellCount)
    {
        // For storing data into CSV files
        StringBuilder data = new StringBuilder();
        try
        {
            FileOutputStream fos = new FileOutputStream(outputFile,false);

            // Get the workbook object for XLS file
            HSSFWorkbook workbook = new HSSFWorkbook(new FileInputStream(inputFile));
            // Get first sheet from the workbook
            HSSFSheet sheet = workbook.getSheetAt(0);
            Cell cell;
            Row row;

            // Iterate through each rows from first sheet
            for (Row aSheet : sheet) {
                row = aSheet;

                // Grab the number of cells and compare to the expectedCellCount
                // NOTE: getLastCellNum() doesn't account for null cells between columns. We account for this through the loop.
                Integer cellCount = (int) row.getLastCellNum();
                Integer countDifference = expectedCellCount - cellCount;
                Integer rowNum = row.getRowNum();

                // Compare the cell counts to the expected, as well as check 3 columns after the expected column for any data
                // This extra check acts as a workaround to getLastCellNum()
                if(cellCount > expectedCellCount ||
                        ((row.getCell(expectedCellCount) != null && row.getCell(expectedCellCount).getCellType() != Cell.CELL_TYPE_BLANK) ||
                                (row.getCell(expectedCellCount + 1) != null &&  row.getCell(expectedCellCount + 1).getCellType() != Cell.CELL_TYPE_BLANK) ||
                                (row.getCell(expectedCellCount + 2) != null && row.getCell(expectedCellCount + 2) .getCellType() != Cell.CELL_TYPE_BLANK)
                        ))
                    log.warn("The cellcount(" + cellCount.toString() + ") for row " + rowNum.toString() + " is greater than the expected cell count("
                            + expectedCellCount.toString() + "). Data will be lost.");

                for (int i = 0; i < expectedCellCount; i++) {
                    cell = row.getCell(i);

                    if (cell == null) {
                        data.append("|");
                        cellCount++;
                        countDifference--;
                    }

                    else {
                        DataFormatter fmt = new DataFormatter();
                        switch (cell.getCellType()) {
                            case Cell.CELL_TYPE_BOOLEAN:
                                data.append(cell.getBooleanCellValue()).append("|");
                                break;
                            case Cell.CELL_TYPE_NUMERIC:
                                if (HSSFDateUtil.isCellDateFormatted(cell)) {
                                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX");
                                    sdf.setTimeZone(TimeZone.getTimeZone("UTC"));

                                    Calendar cal = Calendar.getInstance();
                                    cal.setTime(cell.getDateCellValue());
                                    Integer offset = cal.getTimeZone().getOffset(cal.getTimeInMillis());
                                    cal.add(Calendar.MILLISECOND, offset);
                                    Timestamp ts = new Timestamp(cal.getTimeInMillis());

                                    data.append(sdf.format(ts)).append("|");
                                } else {
                                    data.append(fmt.formatCellValue(cell)).append("|");
                                }
                                break;

                            case Cell.CELL_TYPE_STRING:
                                String str = cell.getStringCellValue().replace("\"", "\\\"");
                                if(str.contains("|"))
                                    data.append("\"").append(str).append("\"").append("|");
                                else
                                    data.append(str).append("|");
                                break;

                            case Cell.CELL_TYPE_BLANK:
                                data.append("|");
                                break;

                            default:
                                String defStr = fmt.formatCellValue(cell).replace("\"", "\\\"");
                                if(defStr.contains("|"))
                                    data.append("\"").append(defStr).append("\"").append("|");
                                else
                                    data.append(defStr).append("|");
                                break;
                        }
                    }
                }

                // Pad with extra delimiters if needed
                if(countDifference > 0) for (int i = 1; i < countDifference; i++) data.append("|");
                data.setLength(data.length()-1);
                // Add a new line
                data.append('\n');
            }

            data.setLength(data.length()-1);
            fos.write(data.toString().getBytes());
            fos.close();
        } catch (Exception ioe) {
            ioe.printStackTrace();
        }
    }

    public static void xlsx(File inputFile, File outputFile, Integer expectedCellCount) {
        // For storing data into CSV files
        StringBuilder data = new StringBuilder();

        try {
            FileOutputStream fos = new FileOutputStream(outputFile,false);
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = new XSSFWorkbook(new FileInputStream(inputFile));
            // Get first sheet from the workbook
            XSSFSheet sheet = wBook.getSheetAt(0);
            Row row;
            Cell cell;
            // Iterate through each rows from first sheet
            for (Row aSheet : sheet) {
                row = aSheet;

                // Grab the number of cells and compare to the expectedCellCount
                // NOTE: getLastCellNum() doesn't account for null cells between columns. We account for this through the loop.
                Integer cellCount = (int) row.getLastCellNum();
                Integer countDifference = expectedCellCount - cellCount;
                Integer rowNum = row.getRowNum();

                // Compare the cell counts to the expected, as well as check 3 columns after the expected column for any data
                // This extra check acts as a workaround to getLastCellNum()
                if(cellCount > expectedCellCount ||
                        ((row.getCell(expectedCellCount) != null && row.getCell(expectedCellCount).getCellType() != Cell.CELL_TYPE_BLANK) ||
                                (row.getCell(expectedCellCount + 1) != null &&  row.getCell(expectedCellCount + 1).getCellType() != Cell.CELL_TYPE_BLANK) ||
                                (row.getCell(expectedCellCount + 2) != null && row.getCell(expectedCellCount + 2) .getCellType() != Cell.CELL_TYPE_BLANK)
                        ))
                    log.warn("The cellcount(" + cellCount.toString() + ") for row " + rowNum.toString() + " is greater than the expected cell count("
                            + expectedCellCount.toString() + "). Data will be lost.");

                for (int i = 0; i < expectedCellCount; i++) {
                    cell = row.getCell(i);

                    if (cell == null) {
                        data.append("|");
                        cellCount++;
                        countDifference--;
                    }

                    else {
                        DataFormatter fmt = new DataFormatter();
                        switch (cell.getCellType()) {
                            case Cell.CELL_TYPE_BOOLEAN:
                                data.append(cell.getBooleanCellValue()).append("|");
                                break;
                            case Cell.CELL_TYPE_NUMERIC:
                                if (HSSFDateUtil.isCellDateFormatted(cell)) {
                                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX");
                                    sdf.setTimeZone(TimeZone.getTimeZone("UTC"));

                                    Calendar cal = Calendar.getInstance();
                                    cal.setTime(cell.getDateCellValue());
                                    Integer offset = cal.getTimeZone().getOffset(cal.getTimeInMillis());
                                    cal.add(Calendar.MILLISECOND, offset);
                                    Timestamp ts = new Timestamp(cal.getTimeInMillis());

                                    data.append(sdf.format(ts)).append("|");
                                } else {
                                    data.append(fmt.formatCellValue(cell)).append("|");
                                }
                                break;

                            case Cell.CELL_TYPE_STRING:
                                String str = cell.getStringCellValue().replace("\"", "\\\"");
                                if(str.contains("|"))
                                    data.append("\"").append(str).append("\"").append("|");
                                else
                                    data.append(str).append("|");
                                break;

                            case Cell.CELL_TYPE_BLANK:
                                data.append("|");
                                break;

                            default:
                                String defStr = fmt.formatCellValue(cell).replace("\"", "\\\"");
                                if(defStr.contains("|"))
                                    data.append("\"").append(defStr).append("\"").append("|");
                                else
                                    data.append(defStr).append("|");
                                break;
                        }
                    }
                }

                // Pad with extra delimiters if needed
                if(countDifference > 0) for (int i = 1; i < countDifference; i++) data.append("|");
                data.setLength(data.length()-1);
                // Add a new line
                data.append('\n');
            }

            data.setLength(data.length()-1);
            fos.write(data.toString().getBytes());
            fos.close();

        } catch (Exception ioe) {
            ioe.printStackTrace();
        }
    }

}
