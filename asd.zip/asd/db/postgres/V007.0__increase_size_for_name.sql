-- ***********Increasing column size of first_name/last_name column

ALTER TABLE parent_activities ALTER COLUMN first_name TYPE VARCHAR(100);
ALTER TABLE parent_activities ALTER COLUMN last_name TYPE VARCHAR(100);
ALTER TABLE parent_activities ALTER COLUMN source_first_name TYPE VARCHAR(100);
ALTER TABLE parent_activities ALTER COLUMN source_last_name TYPE VARCHAR(100);

ALTER TABLE parent_persons ALTER COLUMN first_name TYPE VARCHAR(100);
ALTER TABLE parent_persons ALTER COLUMN last_name TYPE VARCHAR(100);
ALTER TABLE parent_persons ALTER COLUMN source_first_name TYPE VARCHAR(100);
ALTER TABLE parent_persons ALTER COLUMN source_last_name TYPE VARCHAR(100);

-- ***********Increasing column size of insurance column
ALTER TABLE parent_activities ALTER COLUMN insurance TYPE VARCHAR(100);
