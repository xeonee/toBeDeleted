-- adding column payer_type_description in parent_persons, parent_activities tables.
ALTER TABLE parent_persons ADD COLUMN payer_type_description VARCHAR(256);
ALTER TABLE parent_activities ADD COLUMN payer_type_description VARCHAR(256);