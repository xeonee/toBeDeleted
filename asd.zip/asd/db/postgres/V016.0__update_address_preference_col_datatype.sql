-- change datatype of column address_preference in parent_persons.
ALTER TABLE parent_persons ADD COLUMN address_preference_new INT;
ALTER TABLE parent_persons DROP COLUMN address_preference;
ALTER TABLE parent_persons RENAME address_preference_new TO address_preference;