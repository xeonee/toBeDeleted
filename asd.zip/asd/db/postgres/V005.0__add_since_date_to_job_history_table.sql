-- adding column since_date in table Job History
ALTER TABLE job_history ADD COLUMN since_date DATE;

-- Removing Not Null Constraint from number_of_input_records column
ALTER TABLE job_history ALTER COLUMN number_of_input_records DROP NOT NULL;
