-- ************************************** Job History

DROP TABLE job_history;

CREATE TABLE job_history
(
 job_id                     SERIAL PRIMARY KEY,
 customer                   VARCHAR(50) NOT NULL,
 batch_id                   VARCHAR(50),
 job_command                VARCHAR(255),
 input_file                 VARCHAR(255),
 time_started               TIMESTAMP NOT NULL,
 time_finished              TIMESTAMP NOT NULL,
 "user"                     VARCHAR(50) NOT NULL,
 number_of_input_records    INT NOT NULL,
 number_of_updated_records  INT,
 activity_type              VARCHAR(50),
 job_type                   VARCHAR(50),
 job_status                 VARCHAR(50)
);