ALTER TABLE parent_activities ALTER COLUMN source_name TYPE VARCHAR(256);
ALTER TABLE parent_activities ALTER COLUMN location TYPE VARCHAR(256);
ALTER TABLE parent_activities ALTER COLUMN insurance TYPE VARCHAR(256);

ALTER TABLE parent_activities ALTER COLUMN guarantor_first_name TYPE VARCHAR(256);
ALTER TABLE parent_activities ALTER COLUMN guarantor_last_name TYPE VARCHAR(256);
ALTER TABLE parent_activities ALTER COLUMN guarantor_middle_name TYPE VARCHAR(256);

ALTER TABLE parent_activities ALTER COLUMN activity_location TYPE VARCHAR(256);
ALTER TABLE parent_activities ALTER COLUMN source_middle_name TYPE VARCHAR(256);
ALTER TABLE parent_activities ALTER COLUMN occupation_group TYPE VARCHAR(256);
ALTER TABLE parent_activities ALTER COLUMN household_composition TYPE VARCHAR(256);
ALTER TABLE parent_activities ALTER COLUMN education TYPE VARCHAR(256);

ALTER TABLE parent_activities ALTER COLUMN address1 TYPE VARCHAR(256);
ALTER TABLE parent_activities ALTER COLUMN address2 TYPE VARCHAR(256);

ALTER TABLE parent_activities ALTER COLUMN personal_url TYPE VARCHAR(256);
ALTER TABLE parent_activities ALTER COLUMN source_do_not_solicit_reason TYPE VARCHAR(256);
ALTER TABLE parent_activities ALTER COLUMN portal_status TYPE VARCHAR(256);

ALTER TABLE parent_activities ALTER COLUMN carrier_route TYPE VARCHAR(256);
ALTER TABLE parent_activities ALTER COLUMN delivery_point_code TYPE VARCHAR(256);
ALTER TABLE parent_activities ALTER COLUMN street_pre_direction TYPE VARCHAR(256);
ALTER TABLE parent_activities ALTER COLUMN street_name TYPE VARCHAR(256);
ALTER TABLE parent_activities ALTER COLUMN street_post_direction TYPE VARCHAR(256);
ALTER TABLE parent_activities ALTER COLUMN street_suffix TYPE VARCHAR(256);

ALTER TABLE parent_activities ALTER COLUMN street_second_number TYPE VARCHAR(256);
ALTER TABLE parent_activities ALTER COLUMN street_second_unit TYPE VARCHAR(256);
ALTER TABLE parent_activities ALTER COLUMN metropolitan_statistical_area TYPE VARCHAR(256);
ALTER TABLE parent_activities ALTER COLUMN primary_metropolitan_statistical_area TYPE VARCHAR(256);
ALTER TABLE parent_activities ALTER COLUMN core_based_statistical_area TYPE VARCHAR(256);
ALTER TABLE parent_activities ALTER COLUMN delivery_point_validation TYPE VARCHAR(256);











