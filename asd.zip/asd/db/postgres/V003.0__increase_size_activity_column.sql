-- ***********Increasing column size of activity column

ALTER TABLE parent_activities ALTER COLUMN activity TYPE VARCHAR(100);
