ALTER TABLE parent_activities ALTER COLUMN employer TYPE VARCHAR(256);
ALTER TABLE parent_activities ALTER COLUMN message_type TYPE VARCHAR(256);
ALTER TABLE parent_activities ALTER COLUMN reason TYPE VARCHAR(256);
