ALTER TABLE parent_persons ALTER COLUMN occupation_group TYPE VARCHAR(256);
ALTER TABLE parent_persons ALTER COLUMN source_middle_name TYPE VARCHAR(256);
ALTER TABLE parent_persons ALTER COLUMN middle_name TYPE VARCHAR(256);


ALTER TABLE parent_persons ALTER COLUMN employer TYPE VARCHAR(256);
ALTER TABLE parent_persons ALTER COLUMN occupation TYPE VARCHAR(256);
ALTER TABLE parent_persons ALTER COLUMN dwell_type TYPE VARCHAR(256);
ALTER TABLE parent_persons ALTER COLUMN combined_owner TYPE VARCHAR(256);
ALTER TABLE parent_persons ALTER COLUMN education TYPE VARCHAR(256);
ALTER TABLE parent_persons ALTER COLUMN address1 TYPE VARCHAR(256);
ALTER TABLE parent_persons ALTER COLUMN address2 TYPE VARCHAR(256);
ALTER TABLE parent_persons ALTER COLUMN carrier_route TYPE VARCHAR(256);

ALTER TABLE parent_persons ALTER COLUMN delivery_point_code TYPE VARCHAR(256);
ALTER TABLE parent_persons ALTER COLUMN street_pre_direction TYPE VARCHAR(256);
ALTER TABLE parent_persons ALTER COLUMN street_name TYPE VARCHAR(256);
ALTER TABLE parent_persons ALTER COLUMN street_post_direction TYPE VARCHAR(256);
ALTER TABLE parent_persons ALTER COLUMN street_second_number TYPE VARCHAR(256);
ALTER TABLE parent_persons ALTER COLUMN metropolitan_statistical_area TYPE VARCHAR(256);
ALTER TABLE parent_persons ALTER COLUMN primary_metropolitan_statistical_area TYPE VARCHAR(256);
ALTER TABLE parent_persons ALTER COLUMN core_based_statistical_area TYPE VARCHAR(256);

ALTER TABLE parent_persons ALTER COLUMN delivery_point_validation TYPE VARCHAR(256);
ALTER TABLE parent_persons ALTER COLUMN county_code TYPE VARCHAR(256);
ALTER TABLE parent_persons ALTER COLUMN census_block TYPE VARCHAR(256);
ALTER TABLE parent_persons ALTER COLUMN census_tract TYPE VARCHAR(256);
ALTER TABLE parent_persons ALTER COLUMN source_name TYPE VARCHAR(256);
ALTER TABLE parent_persons ALTER COLUMN personal_url TYPE VARCHAR(256);