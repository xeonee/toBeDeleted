ALTER TABLE parent_activities ADD service_line VARCHAR(150);

ALTER TABLE parent_activities ALTER COLUMN care_group_code TYPE VARCHAR(1000);
ALTER TABLE parent_activities ALTER COLUMN care_group_description TYPE VARCHAR(1000);
ALTER TABLE parent_activities ALTER COLUMN service_line_group TYPE VARCHAR(1000);
ALTER TABLE parent_activities ALTER COLUMN care_family TYPE VARCHAR(1000);
ALTER TABLE parent_activities ALTER COLUMN procedure TYPE VARCHAR(1000);
ALTER TABLE parent_activities ALTER COLUMN procedure_group TYPE VARCHAR(1000);
ALTER TABLE parent_activities ALTER COLUMN mental_health_conditions TYPE VARCHAR(1000);
ALTER TABLE parent_activities ALTER COLUMN addiction_adult TYPE VARCHAR(1000);
ALTER TABLE parent_activities ALTER COLUMN behavioral_health_conditions_adult TYPE VARCHAR(1000);
ALTER TABLE parent_activities ALTER COLUMN diabetes_adult TYPE VARCHAR(1000);
ALTER TABLE parent_activities ALTER COLUMN cardiac_disease_adult TYPE VARCHAR(1000);
ALTER TABLE parent_activities ALTER COLUMN pulmonary_disease_adult TYPE VARCHAR(1000);
ALTER TABLE parent_activities ALTER COLUMN adult_chronic_conditions_count TYPE VARCHAR(1000);
ALTER TABLE parent_activities ALTER COLUMN asthma_pediatric TYPE VARCHAR(1000);
ALTER TABLE parent_activities ALTER COLUMN behavioral_health_conditions_pediatric TYPE VARCHAR(1000);

ALTER TABLE parent_activities ALTER COLUMN complex_cardiac_conditions_pediatric TYPE VARCHAR(1000);
ALTER TABLE parent_activities ALTER COLUMN pediatric_complex_conditions_count TYPE VARCHAR(1000);
ALTER TABLE parent_activities ALTER COLUMN trauma TYPE VARCHAR(1000);
ALTER TABLE parent_activities ALTER COLUMN procedure_group_category TYPE VARCHAR(1000);
ALTER TABLE parent_activities ALTER COLUMN sports_medicine TYPE VARCHAR(1000);
ALTER TABLE parent_activities ALTER COLUMN pain_services TYPE VARCHAR(1000);

ALTER TABLE parent_activities ALTER COLUMN primary_care_all_adults TYPE VARCHAR(1000);
ALTER TABLE parent_activities ALTER COLUMN primary_care_geriatrics TYPE VARCHAR(1000);
ALTER TABLE parent_activities ALTER COLUMN primary_care_pediatrics TYPE VARCHAR(1000);


-- ************************************** UnGroupable Activities

CREATE TABLE ungroupable_activities
(
 UNIQUE(activity_id),
 error_reasons VARCHAR(100)[],
 PRIMARY KEY (customer, activity_id)
) INHERITS (parent_activities);



