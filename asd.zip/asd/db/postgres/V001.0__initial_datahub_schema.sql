-- ************************************** Job History

CREATE TABLE job_history
(
 job_id                     SERIAL PRIMARY KEY,
 customer                   VARCHAR(50) NOT NULL,
 batch_id                   VARCHAR(50) NOT NULL,
 job_command                VARCHAR(255) NOT NULL,
 input_file                 VARCHAR(255),
 time_started               TIMESTAMP NOT NULL,
 time_finished              TIMESTAMP NOT NULL,
 "user"                     VARCHAR(50) NOT NULL,
 number_of_input_records    INT NOT NULL DEFAULT 0,
 number_of_updated_records  INT,
 activity_type              VARCHAR(50) NOT NULL DEFAULT '',
 job_type                   VARCHAR(50) NOT NULL DEFAULT '',
 job_status                 VARCHAR(50) NOT NULL DEFAULT ''
);

-- ************************************** Do Not Solicit Emails

CREATE TABLE do_not_solicit_emails
(
    customer      VARCHAR(50),
    source        VARCHAR(50),
    date_created  TIMESTAMP NOT NULL,
    date_modified TIMESTAMP,
    email         VARCHAR(255),
    reason        VARCHAR(255),
    batch_id      VARCHAR(50),
    PRIMARY KEY (customer, email)
);

-- ************************************** Addresses

CREATE TABLE addresses
(
 customer             VARCHAR(50) NOT NULL,
 address_id           VARCHAR(50) NOT NULL,
 address1             VARCHAR(50) NOT NULL,
 address2             VARCHAR(50),
 city                 VARCHAR(50) NOT NULL,
 state                VARCHAR(50) NOT NULL,
 zip4                 VARCHAR(4),
 zip5                 VARCHAR(5) NOT NULL,
 address_coordinates  POINT,
 UNIQUE(address_id),
 PRIMARY KEY (customer, address_id)
);

-- ************************************** Parent Persons

CREATE TABLE parent_persons
(
 -- Primary Identifiers
 customer                              VARCHAR(50),
 person_id                             VARCHAR(50),
 address_id                            VARCHAR(50),
 date_created                          TIMESTAMP NOT NULL,
 date_modified                         TIMESTAMP,
 mrids                                 VARCHAR(50)[],

 -- Demographic
 source_first_name                     VARCHAR(50),
 first_name                            VARCHAR(50),
 source_middle_name                    VARCHAR(50),
 middle_name                           VARCHAR(50),
 source_last_name                      VARCHAR(50),
 last_name                             VARCHAR(50),
 prefix                                VARCHAR(50),
 personal_suffix                       VARCHAR(50),
 professional_suffix                   VARCHAR(50),
 date_of_birth                         DATE,
 date_of_death                         DATE,
 is_deceased                           BOOLEAN,
 source_age                            INT,
 date_source_age_received              DATE,
 sex                                   VARCHAR(50),
 has_sex_conflict                      BOOLEAN,
 financial_class                       VARCHAR(50),
 payer_type                            VARCHAR(50),
 inferred_payer_type                   VARCHAR(50),
 marital_status                        VARCHAR(50),
 race                                  VARCHAR(50),
 portal_status                         VARCHAR(50),
 religion                              VARCHAR(50),
 iso_language                          VARCHAR(50),
 employer                              VARCHAR(50),
 occupation_group                      VARCHAR(50),
 occupation                            VARCHAR(50),
 primary_phone_number                  VARCHAR(50),
 primary_phone_number_type             VARCHAR(50),
 phone_numbers                         JSONB,
 primary_email                         VARCHAR(255),
 emails                                TEXT[],
 dwell_type                            VARCHAR(50),
 combined_owner                        VARCHAR(50),
 household_income                      VARCHAR(50),
 recipient_reliability_code            INT,
 mail_responder                        VARCHAR(50),
 length_of_residence                   INT,
 persons_in_living_unit                INT,
 adults_in_living_unit                 INT,
 children_in_living_unit               INT,
 home_year_built                       INT,
 home_land_value                       FLOAT,
 estimated_home_value                  VARCHAR(50),
 has_donated_to_charity                BOOLEAN,
 mosaic_zip4                           VARCHAR(50),
 mosaic_global_zip4                    VARCHAR(50),
 household_composition                 VARCHAR(50),
 is_child_present                      BOOLEAN,
 has_child_zero_to_three               BOOLEAN,
 has_child_four_to_six                 BOOLEAN,
 has_child_seven_to_nine               BOOLEAN,
 has_child_ten_to_twelve               BOOLEAN,
 has_child_thirteen_to_fifteen         BOOLEAN,
 has_child_sixteen_to_eighteen         BOOLEAN,
 wealth_rating                         INT,
 address_quality_indicator             VARCHAR(50),
 education                             VARCHAR(50),
 address_type                          VARCHAR(50),
 is_valid_address                      BOOLEAN,

 -- Address Information
 address1                              VARCHAR(50),
 address2                              VARCHAR(50),
 city                                  VARCHAR(50),
 state                                 VARCHAR(50),
 zip4                                  VARCHAR(50),
 zip5                                  VARCHAR(50),
 county                                VARCHAR(50),
 carrier_route                         VARCHAR(50),
 delivery_point_code                   VARCHAR(50),
 street_pre_direction                  VARCHAR(50),
 street_name                           VARCHAR(50),
 street_post_direction                 VARCHAR(50),
 street_suffix                         VARCHAR(50),
 street_second_number                  VARCHAR(50),
 street_second_unit                    VARCHAR(50),
 street_house_number                   VARCHAR(50),
 metropolitan_statistical_area         VARCHAR(50),
 primary_metropolitan_statistical_area VARCHAR(50),
 core_based_statistical_area           VARCHAR(50),
 core_based_statistical_area_type      VARCHAR(50),
 delivery_point_validation             VARCHAR(50),
 county_code                           VARCHAR(50),
 census_block                          VARCHAR(50),
 census_tract                          VARCHAR(50),
 address_preference                    VARCHAR(50),
 address_coordinates                   POINT,

 -- Derived Fields
 locations                             JSONB,

 -- Do Not Solicit Information
 is_opted_out_direct_mail              BOOLEAN,
 is_opted_out_call                     BOOLEAN,
 is_opted_out_email                    BOOLEAN,
 is_opted_out_text                     BOOLEAN,
 do_not_solicit                        BOOLEAN,
 opt_out_direct_mail_reasons           TEXT[],
 opt_out_call_reasons                  TEXT[],
 opt_out_email_reasons                 TEXT[],
 opt_out_text_reasons                  TEXT[],

 primary_care_physician_id             VARCHAR(50),
 has_primary_care_physician            BOOLEAN,
 is_health_system_employee             BOOLEAN,
 beehive_cluster                       INT,
 source_name                           VARCHAR(50),
 personal_url                          VARCHAR(50),
 move_type                             VARCHAR(50),
 move_month                            VARCHAR(50),
 person_type                           VARCHAR(50),
 source_person_type                    VARCHAR(50),

 most_relevant_activity_type           VARCHAR(50),
 most_relevant_activity_date           DATE
);

-- ************************************** Persons
CREATE TABLE persons
(
 UNIQUE(person_id),
 PRIMARY KEY (customer, person_id),
 FOREIGN KEY (customer, address_id) REFERENCES addresses(customer, address_id)
) INHERITS (parent_persons);

-- ************************************** Person Archives

CREATE TABLE person_archives
(
 PRIMARY KEY (customer, person_id)
) INHERITS (parent_persons);

-- ************************************** EPDB List Persons

CREATE TABLE epdb_list_persons
(
 list_id VARCHAR(250),
 list_name VARCHAR(250),
 PRIMARY KEY (customer, person_id, list_id)
) INHERITS (parent_persons);

-- ************************************** Collapse History

CREATE TABLE collapse_history
(
 customer          VARCHAR(50),
 deleted_person_id VARCHAR(50),
 current_person_id VARCHAR(50),
 deleted_at        TIMESTAMP NOT NULL,
 collapse_reason   VARCHAR(50) NOT NULL,
 PRIMARY KEY (customer, current_person_id, deleted_person_id),
 FOREIGN KEY (customer, deleted_person_id) REFERENCES person_archives(customer, person_id),
 FOREIGN KEY (customer, current_person_id) REFERENCES persons(customer, person_id)
);

-- ************************************** Parent Activities
CREATE TABLE parent_activities
(
 -- Primary Identifiers
 customer                                                  VARCHAR(50) NOT NULL,
 activity_id                                               VARCHAR(50) NOT NULL,
 person_id                                                 VARCHAR(50),
 batch_id                                                  VARCHAR(50),
 merged_batch_ids                                          VARCHAR(256)[],
 mrids                                                     VARCHAR(50)[],
 source_record_id                                          VARCHAR(50),
 source_person_id                                          VARCHAR(50),
 source                                                    VARCHAR(50),
 source_type                                               VARCHAR(50),
 source_name                                               VARCHAR(50),
 date_modified                                             TIMESTAMP,
 date_created                                              TIMESTAMP NOT NULL,
 merged_activity_ids                                       VARCHAR(50)[],

  -- Activity Location Specific Information
 location                                                  VARCHAR(50),
 hospital                                                  VARCHAR(50),
 business_unit                                             VARCHAR(50),
 site                                                      VARCHAR(50),
 clinic                                                    VARCHAR(50),
 practice_location                                         VARCHAR(50),
 facility                                                  VARCHAR(50),
 source_er_patient                                         VARCHAR(50),
 is_er_patient                                             BOOLEAN,

 -- Visit Specific Information
 providers                                                 VARCHAR(50)[],
 financial_class                                           VARCHAR(50),
 payer_type                                                VARCHAR(50),
 inferred_payer_type                                       VARCHAR(50),
 source_patient_type                                       VARCHAR(50),
 patient_type                                              VARCHAR(50),
 source_financial_class                                    VARCHAR(50),
 insurance                                                 VARCHAR(50),
 admit_date                                                DATE,
 discharge_date                                            DATE,
 final_bill_date                                           DATE,
 source_discharge_status                                   VARCHAR(50),
 discharge_status                                          VARCHAR(50),
 length_of_stay                                            INT,
 charges                                                   DECIMAL(18,8),
 cost                                                      DECIMAL(18,8),
 gross_margin                                              DECIMAL(18,8),
 contribution_margin                                       DECIMAL(18,8),
 profit                                                    DECIMAL(18,8),
 systolic                                                  DOUBLE PRECISION,
 diastolic                                                 DOUBLE PRECISION,
 height                                                    DOUBLE PRECISION,
 weight                                                    DOUBLE PRECISION,
 body_mass_index                                           DOUBLE PRECISION,
 guarantor_first_name                                      VARCHAR(50),
 guarantor_last_name                                       VARCHAR(50),
 guarantor_middle_name                                     VARCHAR(50),
 assessment_results                                        JSONB,
 current_procedural_terminology_codes                      JSONB,
 diagnosis_codes                                           JSONB,
 procedure_codes                                           JSONB,
 medical_severity_diagnosis_related_group                  INT,

 -- Activity Metadata
 activity_type                                             VARCHAR(50),
 activity                                                  VARCHAR(50),
 activity_group                                            VARCHAR(50),
 activity_location                                         VARCHAR(50),
 activity_date                                             DATE,

 -- Demographic Data
 source_first_name                                         VARCHAR(50),
 source_last_name                                          VARCHAR(50),
 source_middle_name                                        VARCHAR(50),
 first_name                                                VARCHAR(50),
 last_name                                                 VARCHAR(50),
 middle_name                                               VARCHAR(50),
 prefix                                                    VARCHAR(50),
 personal_suffix                                           VARCHAR(50),
 professional_suffix                                       VARCHAR(50),
 source_sex                                                VARCHAR(50),
 sex                                                       VARCHAR(50),
 date_of_birth                                             DATE,
 date_of_death                                             DATE,
 is_deceased                                               BOOLEAN,
 source_marital_status                                     VARCHAR(50),
 marital_status                                            VARCHAR(50),
 source_race                                               VARCHAR(50),
 race                                                      VARCHAR(50),
 ethnic_insight                                            VARCHAR(50),
 religion                                                  VARCHAR(50),
 iso_language                                              VARCHAR(50),
 occupation                                                VARCHAR(50),
 occupation_group                                          VARCHAR(50),
 dwell_type                                                VARCHAR(50),
 combined_owner                                            VARCHAR(50),
 household_income                                          VARCHAR(50),
 recipient_reliability_code                                INT,
 mail_responder                                            VARCHAR(50),
 length_of_residence                                       INT,
 persons_in_living_unit                                    INT,
 adults_in_living_unit                                     INT,
 children_in_living_unit                                   INT,
 home_year_built                                           INT,
 home_land_value                                           FLOAT,
 estimated_home_value                                      VARCHAR(50),
 has_donated_to_charity                                    BOOLEAN,
 mosaic_zip4                                               VARCHAR(50),
 mosaic_global_zip4                                        VARCHAR(50),
 household_composition                                     VARCHAR(50),
 wealth_rating                                             INT,
 address_quality_indicator                                 VARCHAR(50),
 education                                                 VARCHAR(50),
 source_age                                                INT,
 activity_date_source_age_recieved                         DATE,
 beehive_cluster                                           INT,
 is_child_present                                          BOOLEAN,
 has_child_zero_to_three                                   BOOLEAN,
 has_child_four_to_six                                     BOOLEAN,
 has_child_seven_to_nine                                   BOOLEAN,
 has_child_ten_to_twelve                                   BOOLEAN,
 has_child_thirteen_to_fifteen                             BOOLEAN,
 has_child_sixteen_to_eighteen                             BOOLEAN,
 source_person_type                                        VARCHAR(50),

 -- Contact Information
 home_phone                                                VARCHAR(50),
 mobile_phone                                              VARCHAR(50),
 work_phone                                                VARCHAR(50),
 work_phone_extension                                      VARCHAR(50),
 email                                                     VARCHAR(320),

 -- Address
 address_type                                              VARCHAR(50),
 address1                                                  VARCHAR(50),
 address2                                                  VARCHAR(50),
 city                                                      VARCHAR(50),
 state                                                     VARCHAR(50),
 zip5                                                      VARCHAR(50),
 zip4                                                      VARCHAR(50),
 country                                                   VARCHAR(50),
 county                                                    VARCHAR(50),
 carrier_route                                             VARCHAR(50),
 delivery_point_code                                       VARCHAR(50),
 address_coordinates                                       POINT,
 street_pre_direction                                      VARCHAR(50),
 street_name                                               VARCHAR(50),
 street_post_direction                                     VARCHAR(50),
 street_suffix                                             VARCHAR(50),
 street_second_number                                      VARCHAR(50),
 street_second_unit                                        VARCHAR(50),
 street_house_number                                       VARCHAR(50),
 metropolitan_statistical_area                             VARCHAR(50),
 primary_metropolitan_statistical_area                     VARCHAR(50),
 core_based_statistical_area                               VARCHAR(50),
 core_based_statistical_area_type                          VARCHAR(50),
 delivery_point_validation                                 VARCHAR(50),
 county_code                                               VARCHAR(50),
 census_block                                              VARCHAR(50),
 census_tract                                              VARCHAR(50),
 is_valid_address                                          BOOLEAN,
 ncoa_move_type                                            VARCHAR(50),
 ncoa_move_date                                            VARCHAR(50),

 -- New Movers
 moved_from_zip5                                           VARCHAR(5),
 moved_to_zip5                                             VARCHAR(5),
 experian_move_type                                        VARCHAR(50),
 experian_move_month                                       VARCHAR(50),
 has_moved_away                                            BOOLEAN,

 -- Do Not Solicit Information
 is_opted_out_direct_mail                                  BOOLEAN,
 is_opted_out_call                                         BOOLEAN,
 is_opted_out_email                                        BOOLEAN,
 is_opted_out_text                                         BOOLEAN,
 do_not_solicit                                            BOOLEAN,
 opt_out_direct_mail_reasons                               TEXT[],
 opt_out_call_reasons                                      TEXT[],
 opt_out_email_reasons                                     TEXT[],
 opt_out_text_reasons                                      TEXT[],

 -- Other
 personal_url                                              VARCHAR(50),
 reason                                                    VARCHAR(50),
 employer                                                  VARCHAR(50),
 message_type                                              VARCHAR(50),
 primary_care_physician_id                                 VARCHAR(50),
 source_exclusion_flag                                     VARCHAR(50),
 source_do_not_solicit_reason                              VARCHAR(250),
 source_client                                             VARCHAR(50),
 exclusion_flag                                            VARCHAR(50),
 portal_status                                             VARCHAR(50),

 -- SG2
 care_group_code                                           VARCHAR(50),
 care_group_description                                    VARCHAR(50),
 service_line_group                                        VARCHAR(50),
 care_family                                               VARCHAR(50),
 procedure                                                 VARCHAR(50),
 procedure_group                                           VARCHAR(50),
 mental_health_conditions                                  VARCHAR(50),
 addiction_adult                                           VARCHAR(50),
 behavioral_health_conditions_adult                        VARCHAR(50),
 diabetes_adult                                            VARCHAR(50),
 cardiac_disease_adult                                     VARCHAR(50),
 pulmonary_disease_adult                                   VARCHAR(50),
 adult_chronic_conditions_count                            VARCHAR(50),
 asthma_pediatric                                          VARCHAR(50),
 behavioral_health_conditions_pediatric                    VARCHAR(50),
 complex_cardiac_conditions_pediatric                      VARCHAR(50),
 pediatric_complex_conditions_count                        VARCHAR(50),
 trauma                                                    VARCHAR(50),
 procedure_group_category                                  VARCHAR(50),
 sports_medicine                                           VARCHAR(50),
 pain_services                                             VARCHAR(50),
 primary_care_all_adults                                   VARCHAR(50),
 primary_care_geriatrics                                   VARCHAR(50),
 primary_care_pediatrics                                   VARCHAR(50)
);

-- ************************************** Activities

CREATE TABLE activities
(
 person_id VARCHAR(50) NOT NULL,
 UNIQUE(activity_id),
 PRIMARY KEY (customer, activity_id),
 FOREIGN KEY (customer, person_id) REFERENCES persons(customer, person_id)
) INHERITS (parent_activities);


-- ************************************** Unidentifiable Activities

CREATE TABLE unidentifiable_activities
(
 UNIQUE(activity_id),
 error_reasons VARCHAR(100)[],
 PRIMARY KEY (customer, activity_id)
) INHERITS (parent_activities);