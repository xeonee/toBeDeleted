
-- rename column iso_language TO iso_language_desc in tables parent_persons and parent_activities.
ALTER TABLE parent_persons RENAME iso_language TO iso_language_desc;
ALTER TABLE parent_activities RENAME iso_language TO iso_language_desc;

-- adding column iso_language_code in tables parent_persons and parent_activities.
ALTER TABLE parent_persons ADD COLUMN iso_language_code VARCHAR(50);
ALTER TABLE parent_activities ADD COLUMN iso_language_code VARCHAR(50);