-- ***********Increasing column size of occupation_group column
ALTER TABLE parent_activities ALTER COLUMN occupation_group TYPE VARCHAR(100);

ALTER TABLE parent_persons ALTER COLUMN occupation_group TYPE VARCHAR(100);

