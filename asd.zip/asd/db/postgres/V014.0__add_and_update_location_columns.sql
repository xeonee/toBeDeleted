
-- rename column location TO location_code in parent_activities table.
ALTER TABLE parent_activities RENAME location TO location_code;

-- adding column location_desc and source_location_desc in parent_activities table.
ALTER TABLE parent_activities ADD COLUMN location_desc VARCHAR(256);
ALTER TABLE parent_activities ADD COLUMN source_location_desc VARCHAR(256);