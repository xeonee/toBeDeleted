ALTER TABLE activities ADD COLUMN payer_type_description VARCHAR(100);
ALTER TABLE persons ADD COLUMN payer_type_description VARCHAR(100);
ALTER TABLE person_archives ADD COLUMN payer_type_description VARCHAR(100);

