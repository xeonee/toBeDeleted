ALTER TABLE activities ADD COLUMN old_merged_batch_ids VARCHAR(50000);
UPDATE activities SET old_merged_batch_ids = merged_batch_ids;
ALTER TABLE activities DROP COLUMN merged_batch_ids;
ALTER TABLE activities RENAME COLUMN old_merged_batch_ids TO merged_batch_ids;