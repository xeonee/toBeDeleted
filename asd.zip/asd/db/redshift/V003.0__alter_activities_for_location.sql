ALTER TABLE activities RENAME COLUMN location TO location_code;
ALTER TABLE activities ADD COLUMN location_desc VARCHAR(256);
ALTER TABLE activities ADD COLUMN source_location_desc VARCHAR(256);
