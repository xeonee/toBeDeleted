ALTER TABLE activities ADD COLUMN old_occupation_group VARCHAR(100);
UPDATE activities SET old_occupation_group = occupation_group;
ALTER TABLE activities DROP COLUMN occupation_group;
ALTER TABLE activities RENAME COLUMN old_occupation_group TO occupation_group;

ALTER TABLE persons ADD COLUMN old_occupation_group VARCHAR(100);
UPDATE persons SET old_occupation_group = occupation_group;
ALTER TABLE persons DROP COLUMN occupation_group;
ALTER TABLE persons RENAME COLUMN old_occupation_group TO occupation_group;

ALTER TABLE person_archives ADD COLUMN old_occupation_group VARCHAR(100);
UPDATE person_archives SET old_occupation_group = occupation_group;
ALTER TABLE person_archives DROP COLUMN occupation_group;
ALTER TABLE person_archives RENAME COLUMN old_occupation_group TO occupation_group;
